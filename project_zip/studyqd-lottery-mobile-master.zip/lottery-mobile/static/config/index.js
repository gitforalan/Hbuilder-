/**
 * Created by fx on 2017/9/26.
 */
// 会员中心API地址
window.API_PATH = 'http://dev.bg1207.com/'
// 直播平台地址
window.LINK_ZHIBO = 'http://120.77.148.64:8090/live/liveLottery/'
// 一元夺宝地址
window.LINK_YYDB = 'http://120.77.148.64:8090/oneyuan/'
