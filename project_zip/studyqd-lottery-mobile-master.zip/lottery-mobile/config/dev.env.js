var merge = require('webpack-merge')
var prodEnv = require('./prod.env')

module.exports = merge(prodEnv, {
  NODE_ENV: '"development"',
  BASE_API: '"//120.78.76.182:8080/lottery-wapi/wapi"',
  vuxLog: false
})
