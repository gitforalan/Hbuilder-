module.exports = {
  NODE_ENV: '"production"',
  BASE_API: '"//120.78.76.182:8080/lottery-wapi/wapi"'
}
