var vueSlider = require('./vue2-slider')

module.exports = vueSlider
