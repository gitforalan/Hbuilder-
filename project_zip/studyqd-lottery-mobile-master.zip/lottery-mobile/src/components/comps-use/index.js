/**
 * Created by fx on 2017/9/5.
 */
import Vue from 'vue'
import {
  Badge,
  ButtonTab,
  ButtonTabItem,
  Cell,
  CheckIcon,
  Checker,
  CheckerItem,
  LoadMore,
  // Range,
  Scroller,
  Group,
  Selector,
  Tab,
  TabItem,
  XButton,
  XHeader,
  XInput,
  XTextarea,
  LoadingPlugin,
  ToastPlugin,
  AlertPlugin
} from 'vux'

import CheckBox from '../check-box/index.vue'
import Range from '../xrange/index.vue'
import VueSlider from '../vue-slider/'
import Loading from '../loading/loading.vue'

// 注册组件
Vue.component('ButtonTab', ButtonTab)
Vue.component('ButtonTabItem', ButtonTabItem)
Vue.component('Badge', Badge)
Vue.component('Cell', Cell)
Vue.component('CheckIcon', CheckIcon)
Vue.component('Checker', Checker)
Vue.component('CheckerItem', CheckerItem)
Vue.component('LoadMore', LoadMore)
Vue.component('Scroller', Scroller)
Vue.component('Selector', Selector)
Vue.component('Tab', Tab)
Vue.component('TabItem', TabItem)
Vue.component('Group', Group)
Vue.component('XButton', XButton)
Vue.component('XHeader', XHeader)
Vue.component('XInput', XInput)
Vue.component('XTextarea', XTextarea)
Vue.component('CheckBox', CheckBox)

Vue.component(Range.name, Range)
Vue.component('VueSlider', VueSlider) // 替换xrange组件
Vue.component(Loading.name, Loading)

// 注册插件
Vue.use(ToastPlugin)
Vue.use(LoadingPlugin)
Vue.use(AlertPlugin)
