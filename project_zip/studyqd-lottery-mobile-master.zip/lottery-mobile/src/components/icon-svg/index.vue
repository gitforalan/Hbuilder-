<!--
  -- 2017-9-1 11:18:31
  -- 用法  <icon-svg icon-class="liwu" class="custom_style"></icon-svg>
  -->

<template>
  <i class="lott-icon">
    <svg class="svg-icon" aria-hidden="true" :class="{rotate: rotate}">
      <use :xlink:href="iconName"></use>
    </svg>
  </i>
</template>

<script>
  export default {
    name: 'icon-svg',
    props: {
      iconClass: {
        type: String,
        required: true
      },
      rotate: {
        type: Boolean,
        default: false
      }
    },
    computed: {
      iconName () {
        return `#icon-${this.iconClass}`
      }
    }
  }
</script>

<style scoped lang="stylus">
  .lott-icon
    width 2rem
    height 2rem
    display inline-block
    .svg-icon
      width 100%
      height 100%
      fill currentColor
      overflow hidden

    .rotate
      animation rotate .8s linear infinite

    @-webkit-keyframes rotate
      from
        transform rotate(0deg)
      to
        transform rotate(360deg)

</style>
