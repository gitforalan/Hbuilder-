<!-- Created By fx -->
<template>
  <footer class="app-footer" v-if="this.$route.meta.showBtmBar">
    <ul flex="box:mean cross:center">
      <router-link
        tag="li"
        v-for="nav in navConfig"
        :key="nav.name"
        :to="{ path: nav.link }"
        :class="{ 'is-active': navActive(nav) }">
        <p><icon-svg :iconClass="nav.icon"></icon-svg></p>
        <p>{{ nav.name }}</p>
      </router-link>
    </ul>
  </footer>
</template>

<script>
  export default {
    data () {
      return {
        showSelf: false,
        navConfig: [
          { icon: 'zhuye', name: '大厅', link: '/home' },
          { icon: 'liwu', name: '优惠', link: '/gift' },
          { icon: 'zoushi', name: '走势', link: '/trend' },
          { icon: 'faxian', name: '发现', link: '/find' },
          { icon: 'yonghu', name: '我的', link: '/user' }
        ]
      }
    },
    methods: {
      navActive (nav) {
        return this.$route.path.search(new RegExp(nav.link)) === 0 || false
      }
    }
  }
</script>
<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"
  div
    .app-footer
      z-index 100
      position fixed
      height $BottomBarHeight
      bottom 0
      left 0
      right 0
      background $color-el-bg
      color white
      font-size $size-medium
      border-top 1px solid $color-border
      ul
        height $BottomBarHeight
        text-align center
        color $color-gray
        li
          p
            img
              width rem(40)
              height rem(40)
          p:first-child {
            height: 2.2rem
            line-height: 2.2rem
          }
          p:last-child
            font-size rem(22)
          &:active
            color $color-red
          &.is-active {
            color: #f55
          }
</style>
