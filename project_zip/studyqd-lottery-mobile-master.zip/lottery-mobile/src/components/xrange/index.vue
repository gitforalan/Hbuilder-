<template>
  <div class="vux-range-input-box" style="position:relative;">
    <input class="vux-range-input" v-model.number="currentValue">
  </div>
</template>

<script>
import Powerange from './powerange'

export default {
  name: 'xRange',
  props: {
    decimal: Boolean,
    value: {
      default: 0,
      type: Number
    },
    min: {
      type: Number,
      default: 0
    },
    minHTML: String,
    maxHTML: String,
    max: {
      type: Number,
      default: 100
    },
    step: {
      type: Number,
      default: 1
    },
    disabled: Boolean,
    disabledOpacity: Number,
    rangeBarHeight: {
      type: Number,
      default: 1
    },
    rangeHandleHeight: {
      type: Number,
      default: 30
    }
  },
  created () {
    this.currentValue = this.value
  },
  mounted () {
    const _this = this
    this.$nextTick(() => {
      let options = {
        callback: function (value) {
          _this.currentValue = value
        },
        decimal: this.decimal,
        start: this.currentValue,
        min: this.min,
        max: this.max,
        minHTML: '', // this.minHTML,
        maxHTML: '', // this.maxHTML,
        disable: this.disabled,
        disabledOpacity: this.disabledOpacity,
        initialBarWidth: window.getComputedStyle(this.$el.parentNode).width.replace('px', '') - 80
      }
      if (this.step !== 0) {
        options.step = this.step
      }
      this.range = new Powerange(this.$el.querySelector('.vux-range-input'), options)
      // const handleTop = (this.rangeHandleHeight - this.rangeBarHeight) / 2
      const rangeBarTop = this.rangeBarHeight / 2
      // this.$el.querySelector('.range-handle').style.top = `-${handleTop}px`
      this.$el.querySelector('.range-handle').style.top = '50%'
      this.$el.querySelector('.range-handle').style.transform = 'translateY(-50%)'
      this.$el.querySelector('.range-handle').style.webkitTransform = 'translateY(-50%)'
      this.$el.querySelector('.range-bar').style.height = `${this.rangeBarHeight}px`
      this.$el.querySelector('.range-bar').style.top = `-${rangeBarTop}px` // fix range Bug
      this.handleOrientationchange = () => {
        this.update()
      }
      window.addEventListener('orientationchange', this.handleOrientationchange, false)
    })
  },
  methods: {
    update () {
      let value = this.currentValue
      let disabled = this.disabled
      if (value < this.min) {
        value = this.min
      }
      if (value > this.max) {
        value = this.max
      }
      this.$nextTick(() => { // 这里修改为异步
        this.range.reInit({
          min: this.min,
          max: this.max,
          step: this.step,
          disabled, // 强制传入disabled
          value
        })
        this.currentValue = value
        this.range.setStart(this.currentValue)
        this.range.setStep()
      })
    }
  },
  data () {
    return {
      currentValue: 0
    }
  },
  watch: {
    currentValue (val) {
      this.range && this.range.setStart(val)
      this.$emit('input', val)
      this.$emit('on-change', val)
    },
    value (val) {
      this.currentValue = val
    },
    min () {
      this.update()
    },
    step () {
      this.update()
    },
    max () {
      this.update()
    },
    disabled () {
      this.update()
    }
  },
  beforeDestroy () {
    window.removeEventListener('orientationchange', this.handleOrientationchange, false)
  }
}
</script>

<style lang="less">
@import '~vux/src/styles/variable.less';
@import './powerange.less';

.range-quantity,
.range-bar {
  background-color: #fff;
  box-shadow: 1px 1px 5px 1px #c7c7c7 inset
}
.range .vux-range-input-box .range-quantity {
  width: 0;
}
</style>

