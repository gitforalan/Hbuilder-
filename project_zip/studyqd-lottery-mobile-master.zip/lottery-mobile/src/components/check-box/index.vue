<!--<check-box @check="fn" ref="child"></check-box>-->
<template>
  <div @click="check">
    <img src="./check_n.png" v-show="!checked"/>
    <img src="./check_s.png" v-show="checked"/>
  </div>
</template>

<script>
  export default {
    name: 'check-box',

    data () {
      return {
        checked: false
      }
    },
    methods: {
      check () {
        this.checked = !this.checked
        this.$emit('check', this.checked)
      }
    }
  }
</script>

<style scoped lang="stylus">
  div
    width 20px
    height 20px
    img
      width 100%
      height 100%
</style>
