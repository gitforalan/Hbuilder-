<!-- Created By fx -->
<template>
  <div>
    <!-- 红包，签到 -->
    <div class="sign-redbag-prompt">
      <div v-if="showRedbag" class="redbag-prompt">
          <icon-svg @click.native="closeRedbag()" class="cha-icon" icon-class="cha"></icon-svg>
          <router-link to="user/redbags"><span>你有{{redbags}}个红包</span></router-link>
      </div>
      <div v-if="showSign" class="sign-prompt">
          <icon-svg @click.native="closeSign()" class="cha-icon" icon-class="cha"></icon-svg>
          <router-link to="user/sign"><span>你今日未签到</span></router-link>
      </div>
    </div>

    <!-- 领取红包 -->
    <div v-transfer-dom class="home-redbags-dialog">
      <x-dialog v-model="showRedbags" class="dialog-demo" hide-on-blur>
        <span class="vux-close" @click="showRedbags=false"></span>
        <div class="img-box">
          <div class="redbags-img">
              <span>您还有{{redbags}}个红包未领取</span>
          </div>
          <div class="redbags-receive">
              <router-link to="user/redbags"><img class="receive-img" src="../../assets/image/receive.png" style="max-width:100%"></router-link>
              <img src="../../assets/image/redbags.png" style="max-width:100%">
          </div>
        </div>
      </x-dialog>
    </div>
  </div>
</template>

<script>
import { XDialog, TransferDomDirective as TransferDom, cookie } from 'vux'
import * as API from 'api/wapi/user'
export default {
  data () {
    return {
      showRedbag: false,
      showRedbags: false,
      showSign: false,
      redbags: 0
    }
  },
  directives: {
    TransferDom
  },
  components: {
    XDialog
  },
  mounted () {
    if (cookie.get('token')) {
      this.tokenIsFail()
    }
  },
  methods: {
    // 关闭红包
    closeRedbag () {
      this.showRedbag = false
    },
    // 关闭签到
    closeSign () {
      this.showSign = false
    },
    // 判断用户是否登录
    tokenIsFail () {
      var params = {
        opsId: cookie.get('token')
      }
      API.verifyTokenIsFail(params, false).then(res => {
        if (!res.error && res.result) {
          if (+res.result === 1) {
            this.getSignAndRedbags()
          }
        }
      })
    },
    // 获取签到和红包个数
    getSignAndRedbags () {
      var params = {}
      API.getSignAndRedbags(params).then(res => {
        if (!res.error && res.result) {
          if (res.result.redpacketNum > 0) {
            this.showRedbag = true
            this.showRedbags = true
            this.redbags = res.result.redpacketNum
          } else {
            this.showRedbag = false
            this.showRedbags = false
          }
          if (res.result.isSign === 0) {
            this.showSign = true
          } else {
            this.showSign = false
          }
        }
      })
    }
  }
}
</script>
<style scoped lang="stylus">
  @import '~@/assets/baseStylus/variable';
  @import "~@/assets/baseStylus/user"
  @import '~vux/src/styles/close.less'

  .sign-redbag-prompt
    position fixed
    right 0
    top 55%
    z-index 999
    .sign-prompt
    .redbag-prompt
      background-color $color-red
      color $color-white
      border-radius rem(100) 0 0 rem(100)
      display block
      height rem(200)
      width rem(100)
      margin rem(20) 0
      position relative
      i
        position absolute
        left -10%
        top -10%
      span
        height: rem(100)
        width rem(66)
        display inline-block
        text-align center
        margin-left 26%
        margin-top 55%
        font-size rem(30)
        color white
</style>
<style lang="stylus">
  @import '~@/assets/baseStylus/variable';
  @import "~@/assets/baseStylus/user"
  @import '~vux/src/styles/close.less'
  .home-redbags-dialog
    .weui-dialog
      background-color transparent
    .vux-close
      position absolute
      right 0
      width rem(27)
    .vux-close:before, .vux-close:after
      width rem(27)
      height rem(4)
      color white
    .redbags-img
      position absolute
      top 50%
      width 100%
      span
        font-size rem(30)
        color white
    .redbags-receive
      .receive-img
        position: absolute
        top 76%
        width 74%
        left 13%
</style>
