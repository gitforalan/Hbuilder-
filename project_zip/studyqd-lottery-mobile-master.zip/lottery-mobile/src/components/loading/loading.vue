<template>
  <icon-svg iconClass="loading" class="icon-rotate" :rotate="rotate"></icon-svg>
</template>
<script type="text/ecmascript-6">
  export default {
    name: 'loading',
    data () {
      return {
        rotate: true
      }
    }
  }
</script>
<style lang="stylus" rel="stylesheet/stylus">
  .icon-rotate
    width 20px
    height 20px
</style>
