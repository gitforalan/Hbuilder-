/**
 * Created by fx on 2017/10/26.
 */
import commonEd from '../../public/mixin'

export default {
  mixins: [commonEd],
  data () {
    return {
      lotteryUI: {
        openNumLen: 7,
        openNumArr: [0, 0, 0, 0, 0, 0, 0],
        openNumMin: 1,
        openNumMax: 49,
        leadZero: true
      },
      colors: {
        red: ['01', '02', '07', '08', '12', '13', '18', '19', '23', '24', '29', '30', '34', '35', '40', '45', '46'],
        blue: ['03', '04', '09', '10', '14', '15', '20', '25', '26', '31', '36', '37', '41', '42', '47', '48'],
        green: ['05', '06', '11', '16', '17', '21', '22', '27', '28', '32', '33', '38', '39', '43', '44', '49']
      }
    }
  },
  methods: {
    // 生成色波class
    doGenClass (num) {
      let colors = this.colors
      for (let i in colors) {
        const _num = colors[i]
        if (_num.includes(num.toString())) {
          return {
            [i]: true
          }
        }
      }
    },
    // overwrite 处理接口数据
    currentInfoProcess (data) {
      // 把接口值挂到此对象上
      this.lotteryObj = Object.assign({}, this.lotteryObj, data)
      // 更新彩期 派发通知
      this.updateIssue(data.issue)
      // 彩种名称
      this.com_lotteryName(this.lotteryObj.lotteryName)
      // 更新返水条状态
      this.set_rebateShow(this.lotteryObj.rebateShow)
      // 剩余时间
      this.lotteryObj.time = data.time
      // 启动倒计时
      this.currentTimer()
      // 接口为空时 执行开奖动画
      if (!this.lotteryObj.lastOpenNumAni) {
        this.openNumAnimate()
        // 启动计时器取开奖号
        this.getLastOpenNum()
        // 修正计时器
        this.startBetRemainTime()
      }
    }
  },
  created () {
  },
  beforeDestroy () {
    // console.log('beforeDestroy 2')
  }
}
