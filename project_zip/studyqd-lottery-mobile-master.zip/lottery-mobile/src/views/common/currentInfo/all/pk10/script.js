/**
 * Created by fx on 2017/10/26.
 */
import commonEd from '../../public/mixin'

export default {
  mixins: [commonEd],
  data () {
    return {
      lotteryUI: {
        openNumLen: 10,
        openNumArr: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        openNumMin: 1,
        openNumMax: 10,
        leadZero: true
      }
    }
  },
  created () {
  },
  beforeDestroy () {
    // console.log('beforeDestroy 2')
  }
}
