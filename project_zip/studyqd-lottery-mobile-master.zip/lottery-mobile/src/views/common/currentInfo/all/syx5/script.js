/**
 * Created by fx on 2017/10/26.
 */
import commonEd from '../../public/mixin'

export default {
  mixins: [commonEd],
  data () {
    return {
      lotteryUI: {
        openNumLen: 5,
        openNumArr: [0, 0, 0, 0, 0],
        openNumMin: 1,
        openNumMax: 11,
        leadZero: true
      }
    }
  },
  beforeDestroy () {
    console.log('beforeDestroy 2')
  }
}
