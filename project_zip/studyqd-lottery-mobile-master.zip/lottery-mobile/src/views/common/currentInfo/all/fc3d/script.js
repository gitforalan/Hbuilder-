/**
 * Created by fx on 2017/10/26.
 */
import commonEd from '../../public/mixin'

export default {
  mixins: [commonEd],
  data () {
    return {}
  },
  created () {
  },
  beforeDestroy () {
    // console.log('beforeDestroy 2')
  }
}
