<!-- Created By fx on 2017/10/24. -->
<template>
  <section class="current-info" v-click-outside="onClickedOutside">
    <div class="end-lottery" align="center">
      <p>距 <span>{{ lotteryObj.issue | formatIssue }}</span> 期截止 <span>{{ this.timeStr }}</span></p>
    </div>
    <div v-show="!singleRow" class="table-area" ref="tableArea" :style="{height: tableArea.height + 'px'}">
      <table width="100%">
        <tr align="center" ref="line">
          <th>期数</th>
          <th>开奖号码</th>
          <th>万位</th>
          <th>千位</th>
          <th>百位</th>
          <th>十位</th>
          <th>个位</th>
          <th>前三</th>
          <th>后三</th>
        </tr>
        <tr align="center">
          <td>issue</td>
          <td>openNum 6hc</td>
          <td>大小</td>
          <td>大小</td>
          <td>单双</td>
          <td>大单</td>
          <td>小单</td>
          <td>xx</td>
          <td>xx</td>
        </tr>
      </table>
    </div>

    <v-touch
      v-show="!singleRow"
      v-on:panstart="onPanstart"
      v-on:panmove="onPanMove"
      v-on:panend="onPanend"
      v-on:tap="tap"
      tag="div" class="current-lottery"
      flex="main:center cross:center"
      align="center" ref="tapper">
      <p ref="movePart">{{ lotteryObj.lotteryName }} <span>{{ lotteryObj.lastIssue | formatIssue }}</span> 期</p>
      <ul flex="main:left cross:center" align="center" ref="numUl">
        <li v-for="(n, index) in lotteryUI.openNumArr.slice(0, lotteryUI.openNumLen - 1)" class="open-num" :class="doGenClass(n)">{{ n
          }}
        </li>
        <span flex="cross:center"><icon-svg icon-class="jia" class="jia"></icon-svg></span>
        <li class="open-num" :class="doGenClass(lotteryUI.openNumArr[lotteryUI.openNumArr.length - 1])">
          {{ lotteryUI.openNumArr[lotteryUI.openNumArr.length - 1] }}
        </li>
      </ul>
      <div class="btn-drop">
        <span></span>
        <icon-svg icon-class="bg-down" :class="{'icon-rotate':arrowShow}" ref="arrow"></icon-svg>
        <!--<icon-svg icon-class="{'bg-up':arrowShow}" ref="arrow"></icon-svg>-->
      </div>
    </v-touch>
  </section>
</template>

<script type="text/ecmascript-6">
  import ed from './script'

  export default ed
</script>

<style scoped lang="stylus">
  @import './style.styl'
</style>
