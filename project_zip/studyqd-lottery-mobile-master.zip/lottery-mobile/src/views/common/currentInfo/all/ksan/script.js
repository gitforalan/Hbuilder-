/**
 * Created by fx on 2017/10/26.
 */
import commonEd from '../../public/mixin'

export default {
  mixins: [commonEd],
  data () {
    return {
      lotteryUI: {
        openNumLen: 3,
        openNumArr: [0, 0, 0],
        openNumMin: 1,
        openNumMax: 6
      },
      touzi: {
        1: require('assets/image/touzi/1.png'),
        2: require('assets/image/touzi/2.png'),
        3: require('assets/image/touzi/3.png'),
        4: require('assets/image/touzi/4.png'),
        5: require('assets/image/touzi/5.png'),
        6: require('assets/image/touzi/6.png')
      }
    }
  },
  beforeDestroy () {
    console.log('beforeDestroy 2')
  }
}
