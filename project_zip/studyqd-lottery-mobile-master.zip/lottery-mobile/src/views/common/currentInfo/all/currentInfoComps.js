/**
 * Created by fx on 2017/10/24.
 */

const filePath = 'common/currentInfo/'
// 分包
const hotLoad = require('@/utils/import_' + process.env.NODE_ENV)

const Lhc = hotLoad(filePath + 'all/6hc/index') // 六合彩
const Fc3d = hotLoad(filePath + 'all/fc3d/index') // 福彩3D
const Kl8 = hotLoad(filePath + 'all/kl8/index') // 快乐8
const Kl10 = hotLoad(filePath + 'all/kl10/index') // 快乐十分
const Ksan = hotLoad(filePath + 'all/ksan/index') // 快三
const Pk10 = hotLoad(filePath + 'all/pk10/index') // pk拾
const Pl3 = hotLoad(filePath + 'all/pl3/index') // 排列3
const Ssc = hotLoad(filePath + 'all/ssc/index')  // 时时彩
const Ssl = hotLoad(filePath + 'all/ssl/index')  // 时时乐
const Syx5 = hotLoad(filePath + 'all/syx5/index') // 11选5
const Pcdd = hotLoad(filePath + 'all/pcdd/index') // PC蛋蛋

export default {
  Ssc,
  Ssl,
  Ksan,
  Syx5,
  Pk10,
  Pl3,
  Fc3d,
  Lhc,
  Pcdd,
  Kl8,
  Kl10
}
