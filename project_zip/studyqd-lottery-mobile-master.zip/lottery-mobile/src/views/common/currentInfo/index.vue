<!--
  -- 当前彩期信息 currentInfo
  -- ps:复用数据
  -->
<template>
  <component :is="currentView" v-if="currentView"></component>
</template>

<script type="text/ecmascript-6">
  import { mapState } from 'vuex'
  // import * as API from 'api/wapi/front'
  // 彩期组件
  import CiComps from './all/currentInfoComps'
  // 彩种类型
  import TYPE_NAME from '@/config/lottery/typeName'

  export default {
    name: 'currentInfo',
    data () {
      return {
        currentView: null
      }
    },
    props: {
      typeId: {
        type: Number,
        required: true
      }
    },
    components: CiComps,
    computed: {
      ...mapState('common', ['lotteryId'])
    },
    methods: {
      /* 分发组件 */
      setCurrentView (id) {
        switch (id) {
          case TYPE_NAME.SSC: // 时时彩
            this.currentView = CiComps.Ssc
            break
          case TYPE_NAME.KSAN: // 快三
            this.currentView = CiComps.Ksan
            break
          case TYPE_NAME.SYX5: // 11选5
            this.currentView = CiComps.Syx5
            break
          case TYPE_NAME.SSL: // 时时乐
            this.currentView = CiComps.Ssl
            break
          case TYPE_NAME.PL3: // 排列三
            this.currentView = CiComps.Pl3
            break
          case TYPE_NAME.FC3D: // 福彩3D
            this.currentView = CiComps.Fc3d
            break
          case TYPE_NAME.PK10: // pk拾
            this.currentView = CiComps.Pk10
            break
          case TYPE_NAME.LHC: // 六合彩
            this.currentView = CiComps.Lhc
            break
          case TYPE_NAME.PCDD: // pc蛋蛋
            this.currentView = CiComps.Pcdd
            break
          case TYPE_NAME.KL8: // 快乐8
            this.currentView = CiComps.Kl8
            break
          case TYPE_NAME.KLSF: // 快乐十分
            this.currentView = CiComps.Kl10
            break
          default:
            this.currentView = CiComps.Ssc // 默认
        }
      }
    },
    created () {
      this.setCurrentView(this.typeId)
      console.log('彩期模块 创建')
    },
    beforeDestroy () {
      console.log('彩期模块 销毁')
    },
    watch: {
      lotteryId (val, oval) {
        this.currentView = null // 先销毁
        if (val === -1) {
          console.log('val', val, oval)
          // this.$router.go(0) // 如果取不到彩种id 强制刷新避免出错
        }
        this.$nextTick(() => {
          this.setCurrentView(this.typeId)
        })
        console.log('切换成功: ', this.lotteryId)
      }
    }
  }
</script>
