/**
 * Created by fx on 2017/10/26.
 */

import ClickOutside from 'vux/src/directives/click-outside'
import { dateConversions } from '@/utils/date'
// import { dateFormat } from 'vux'
import { mapState, mapGetters, mapMutations, mapActions } from 'vuex'
import * as API from 'api/wapi/front'
import { xTimer } from '@/utils/timer/'

let nowHeight = 0 // 当前tableArea高度
let lastHeight = 0 // 上一次组件高度
let distance = 0 // 初始速度
let $tableTimer = null // 表格动画计时器
const $t = 500 // 滚动条自动缓移的结束时间

export default {
  name: 'currentInfo',
  data () {
    return {
      count: 0,
      showTable: false,
      arrowShow: false,
      tableArea: {
        height: 0,
        y: 0,
        dir: 0
      },
      lotteryObj: { // 存接口返回信息
        lotteryId: -1, // 彩种ID Int
        lotteryName: '', // 彩种名称 String
        lastIssue: '000', // 上期期号 String
        lastOpenNum: '', // 上期开奖号码 String
        lastOpenTime: '', // 上期开奖时间 Date
        issueCount: '', // 当日总期数 Int
        issue: '000', // 当前期期号 String
        time: 0, // 当前期投注剩余时间 单位秒 Int
        openDuration: '', // 开奖总时长 单位秒 Int
        issueStatus: '', // 1.正常 2.当期已封盘:当前彩期封盘 3.暂停投注：当前彩种暂停投注 Int
        rebateShow: '', // 返水率控制 0-可调 1-不可调 2-不显示 Int
        animals: '' // 返回当年所属的生肖值 String
      },
      // 处理数据供界面展示
      lotteryUI: {
        time: '00:00:00',
        openNumLen: 5, // 球个数
        openNumMin: 0,  // 最小数
        openNumMax: 9, // 最大数
        openNumArr: [0, 0, 0, 0, 0],
        speed: 61.8, // 球动画速度
        leadZero: false // 前导零
      },
      timer: {
        currentIssue: null, // 当前彩期倒计时
        currentIssueTimeout: 1000, // 间隔
        lastOpenNum: null, // 上期开奖号码倒计时
        lastOpenNumTimeout: 3000,
        lastOpenNumAni: null, // 上期开奖号码球动画
        betRemainTime: null, // 修正剩余投注时间
        betRemainTimeTimeout: 10000 // 每10秒修正一次
      }
    }
  },
  computed: {
    timeStr () {
      if (this.lotteryObj.time < 1) return this.lotteryUI.time
      return dateConversions(this.lotteryObj.time)
    },
    ...mapState('ui', ['singleRow']),
    ...mapGetters('common', [
      'lotteryId',
      'issue'
    ])
  },
  filters: {
    formatIssue (str) {
      return str.slice(-3)
    }
  },
  methods: {
    /* UI */
    onPanstart (e) {
      this.$refs.tableArea.style.maxHeight = 300 + 'px' // 控制最大高度
      nowHeight = this.$refs.tableArea.offsetHeight
      lastHeight = this.$refs.tableArea.offsetHeight
      distance = e.distance
    },
    onPanMove (e) {
      let eY = e.deltaY
      // 向上拉
      if (eY < 0) {
        if (nowHeight === 0) {
          this.tableArea.height = 0
        }
        if (nowHeight > 0) {
          if (nowHeight + eY < 0) {
            this.tableArea.height = 0 // 不允许出现负值
          } else {
            this.tableArea.height = nowHeight + eY // 减法 e.deltaY为递减
          }
        }
      }
      // 向下拉
      if (eY > 0) {
        this.tableArea.height = nowHeight + eY
      }
      lastHeight = this.$refs.tableArea.offsetHeight
    },
    onPanend (e) {
      let line = this.$refs.line.offsetHeight - 1
      nowHeight = this.$refs.tableArea.offsetHeight
      if (nowHeight < lastHeight) {
        if (nowHeight < line * 6) {
          if (nowHeight < line * 3) {
            this.closeTableArea()
            this.arrowShow = false
          } else {
            this.openTableArea(line * 6)
          }
        } else {
          if (nowHeight < line * 9) {
            this.openTableArea(line * 6)
          } else {
            this.openTableArea(line * 11)
            this.arrowShow = true
          }
        }
      } else {
        if (nowHeight < line * 6) {
          if (nowHeight < line * 3) {
            this.closeTableArea()
            this.arrowShow = false
          } else {
            this.openTableArea(line * 6)
          }
        } else {
          if (nowHeight < line * 9) {
            this.openTableArea(line * 6)
          } else {
            this.openTableArea(line * 11)
            this.arrowShow = true
          }
        }
      }
//         判断加速度
      if (e.distance - distance > 90) {
        // 判断结束时滚动的方向
        if (nowHeight < lastHeight) {
          this.closeTableArea()
          this.arrowShow = false
        } else {
          this.openTableArea(line * 11)
          this.arrowShow = true
        }
      }
    },
    tap () {
      // 高度未达到显示5行时,强制下拉以显示5行
      let line = this.$refs.line.offsetHeight
      if (nowHeight < line * 5) {
        this.$refs.tableArea.style.transition = $t + 'ms all ease'
        this.tableArea.height = line * 5
        $tableTimer = setTimeout(() => {
          this.$refs.tableArea.style.transition = 'none'
        }, $t)
      }
    },
    // 滚动条收起方法
    closeTableArea () {
      this.$refs.tableArea.style.transition = $t + 'ms all ease'
      this.tableArea.height = 0
      $tableTimer = setTimeout(() => {
        if (!this.$refs.tableArea) return // fixme
        this.$refs.tableArea.style.transition = 'none'
      }, $t)
    },
    // 滚动条展开方法
    openTableArea (height) {
      this.$refs.tableArea.style.transition = $t + 'ms all ease'
      this.tableArea.height = height
      setTimeout(() => {
        if (!this.$refs.tableArea) return
        this.$refs.tableArea.style.transition = 'none'
      }, $t)
    },
    onClickedOutside () {
      if (this.singleRow) return
      this.closeTableArea()
    },
    /* 数据 */
    // 当前彩期信息
    getLotteryCurrentInfo () {
      if (this.lotteryId === -1) {
        console.warn('lotteryId 未取到::', this.lotteryId)
        return
      }
      const query = { lotteryId: this.lotteryId }
      API.getLotteryCurrentInfo(query).then(res => {
        console.log(res.data)
        this.currentInfoProcess(res.data)
      }).catch(err => {
        console.log('error: getLotteryCurrentInfo')
      })
    },
    // 处理接口数据
    currentInfoProcess (data) {
      // 把接口值挂到此对象上
      this.lotteryObj = Object.assign({}, this.lotteryObj, data)
      // 更新彩期 派发通知
      this.updateIssue(data.issue)
      // 彩种名称
      this.com_lotteryName(this.lotteryObj.lotteryName)
      // 更新返水条状态
      this.set_rebateShow(this.lotteryObj.rebateShow)
      // 剩余时间
      this.lotteryObj.time = data.time
      // 启动倒计时
      this.currentTimer()
      // 接口为空时 执行开奖动画
      if (!this.lotteryObj.lastOpenNumAni) {
        this.openNumAnimate()
        // 启动计时器取开奖号
        this.getLastOpenNum()
        // 修正计时器
        this.startBetRemainTime()
      }
    },
    // 当前期倒计时
    currentTimer () {
      // 手动测试倒计时结束
      // setTimeout(() => {
      //   this.lotteryObj.time = 3
      // }, 1000)
      // 倒计时
      if (this.timer.currentIssue) clearInterval(this.timer.currentIssue) // 先清
      this.timer.currentIssue = setInterval(() => {
        // 倒计时结束 清掉
        if (this.lotteryObj.time < 1) {
          clearInterval(this.timer.currentIssue)
          // 倒计时结束 开奖动画走起
          // this.openNumAnimate()
          this.getLotteryCurrentInfo() // 取最新彩期信息
          // 启动计时器取开奖号
          // this.getLastOpenNum()
          return
        }
        this.lotteryObj.time--
      }, this.timer.currentIssueTimeout)
    },
    // 取开奖号码
    getLastOpenNum () {
      this.timer.lastOpenNum && clearInterval(this.timer.lastOpenNum) // 清
      this.timer.lastOpenNum = setInterval(() => {
        this.getLotteryLastOpenInfo()
        console.log('获取开奖结果')
      }, this.timer.lastOpenNumTimeout)
    },
    // 修正倒计时
    startBetRemainTime () {
      if (this.timer.betRemainTime) xTimer.clearInterval(this.timer.betRemainTime)
      this.timer.betRemainTime = xTimer.setInterval(() => {
        this.getLotteryBetRemainTime()
      }, this.timer.betRemainTimeTimeout)
    },
    // 查询投注剩余时间
    getLotteryBetRemainTime () {
      const query = {
        lotteryId: this.lotteryId,
        issue: this.lotteryObj.issue
      }
      API.getLotteryBetRemainTime(query).then(res => {
        const time = res.data.time
        console.log('修正计时器 dt->', this.lotteryObj.time - time)
        if (time > 0) this.lotteryObj.time = time
      })
    },
    // 最近一期开奖号码
    getLotteryLastOpenInfo () {
      const query = {
        lotteryId: this.lotteryId,
        issue: this.lotteryObj.issue
      }
      API.getLotteryLastOpenInfo(query).then(res => {
        let openNum = res.data.openNum
        if (openNum) {
          console.log('取到结果->', openNum)
          // this.lotteryObj.lastOpenNum = openNum
          this.lotteryObj = Object.assign(this.lotteryObj, { lastOpenNum: openNum })
          this.timer.lastOpenNum && clearInterval(this.timer.lastOpenNum) // 清
        }
      }).catch(err => {
      })
    },
    // 历史开奖记录
    getLotteryHistoryOpenInfo () {
      const query = {
        lotteryId: this.lotteryId,
        issueNum: 10
      }
      API.getLotteryHistoryOpenInfo(query).then(res => {
      }).catch(err => {
        console.log('error getLotteryHistoryOpenInfo')
      })
    },
    /* 动画 */
    /**
     * 随机球范围
     * @param min
     * @param max
     * @returns {number}
     */
    randomNum (min = 0, max = 9, leadZero) {
      let num = min + (Math.random() * max >> 0)
      if (leadZero && num < 10) num = '0' + num
      return num
    },
    /**
     * 随机一个数字数组 与传入的数组元素当前位不重复
     * @param size
     * @param min
     * @param max > 1
     * @param oldArr
     * @returns {Array}
     */
    randomNumArr (size = 5, min = 0, max = 9, oldArr, leadZero = false) {
      let arr = []
      for (let i = 0; i < size; i++) {
        let num = this.randomNum(min, max, leadZero)
        if (oldArr[i] === num && max > 1) {
          num = this.randomNum(min, max, leadZero)
          i--
          continue
        }
        arr.push(num)
      }
      return arr
    },
    /**
     * 开奖球动画
     */
    openNumAnimate () {
      console.log('执行 开奖动画')
      this.clearOpenNumAnimate() // 先清
      this.timer.lastOpenNumAni = xTimer.setInterval(() => {
        const opt = [this.lotteryUI.openNumLen,
          this.lotteryUI.openNumMin,
          this.lotteryUI.openNumMax,
          this.lotteryUI.openNumArr,
          this.lotteryUI.leadZero
        ]
        this.lotteryUI.openNumArr = this.randomNumArr(...opt)
      }, this.lotteryUI.speed)
    },
    /**
     * 清球动画
     * @param timer
     */
    clearOpenNumAnimate () {
      if (this.timer.lastOpenNumAni) {
        xTimer.clearInterval(this.timer.lastOpenNumAni)
        console.log('结束 开奖动画')
      }
    },
    ...mapMutations('common', ['update_issue', 'com_lotteryName', 'set_rebateShow']),
    ...mapActions('common', ['updateIssue']),
    init () {
      this.getLotteryCurrentInfo() // 获取彩期信息
    }
  },
  directives: {
    ClickOutside
  },
  created () {
    console.log('彩期模块 实例 -> ', this.lotteryId)
    this.init() // 初始化
  },
  beforeDestroy () {
    if ($tableTimer) clearTimeout($tableTimer) // 清表格动画计时器
    console.log('彩期模块 实例销毁 -> ', this.lotteryId)
    clearInterval(this.timer.currentIssue) // 清彩期倒计时
    clearInterval(this.timer.lastOpenNum) // 清开奖号倒计时
    xTimer.clearInterval(this.timer.betRemainTime) // 清修正计时器
    this.clearOpenNumAnimate() // 清球动画
    // clearInterval(this.timer.currentIssue)
  },
  watch: {
    'lotteryObj.lastOpenNum' (val) {
      if (val) {
        this.clearOpenNumAnimate() // 清动画
        this.lotteryUI.openNumArr = val.split(',')
      }
    }
  }
}
