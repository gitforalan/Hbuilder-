<template>
  <section @click="backToCart" v-if="cart.length">
    <div class="return-wrap">
      <div class="return" flex="cross:center">
        <icon-svg flex-box="1" icon-class="fanhui"></icon-svg>
        <p flex-box="1">返回购彩清单</p>
      </div>
      <badge :text="cart.length" class="badge"></badge>
    </div>
  </section>
</template>

<script type="text/ecmascript-6">
  import { mapState, mapMutations } from 'vuex'

  export default {
    name: 'cartBadge',
    computed: {
      ...mapState('common', {
        cart: state => state.betList
      })
    },
    methods: {
      /* 回购票车 */
      backToCart () {
        this.open_cart(true)
      },
      ...mapMutations('common', ['open_cart'])
    }
  }
</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"
  section
    .return-wrap
      position relative
      width rem(220)
      height rem(46)
      margin-right .5rem
      padding-top rem(15)
      .return
        width rem(220)
        height rem(46)
        line-height rem(46)
        font-size rem(24)
        color #777
        border 1px solid $color-border
        box-sizing border-box
        border-radius 4px
        .lott-icon
          width rem(36)
          height rem(28)
          transform scaleX(-1)
      .badge
        position absolute
        top 0
        right 0
        .vux-badge-single
          position absolute
          top rem(4)
          right rem(-9)
          transform scale(.8)
</style>
