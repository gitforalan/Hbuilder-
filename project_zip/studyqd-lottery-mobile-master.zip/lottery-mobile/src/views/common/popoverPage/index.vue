<!-- Created By fx on 2017/10/31. -->
<template>
  <!--<keep-alive>-->
  <component :is="currentView" v-if="currentView">
    <!-- 非活动组件将被缓存！ -->
  </component>
  <!--</keep-alive>-->
</template>

<script type="text/ecmascript-6">
  import { mapState, mapMutations } from 'vuex'
  import SwitchLottery from './switchLottery' // 切换彩种 -> 1
  import BounsRule from './bounsRule' // 奖金说明 -> 2

  const PAGE = {
    SWITCHLOTTERY: 1,
    BOUNSRULE: 2
  }

  export default {
    name: 'popoverPage',
    data () {
      return {
        currentView: null
      }
    },
    components: { SwitchLottery, BounsRule },
    computed: {
      ...mapState('ui', ['showPopoverPage'])
    },
    methods: {
      /* 分发组件 */
      setCurrentView (id) {
        switch (id) {
          case PAGE.SWITCHLOTTERY:
            this.currentView = SwitchLottery
            break
          case PAGE.BOUNSRULE:
            this.currentView = BounsRule
            break
          default:
            console.warn('弹出页面未定义，popoverPage:', id)
        }
      },
      ...mapMutations('ui', ['doPopoverPage'])
    },
    created () {
    },
    watch: {
      showPopoverPage (val, oval) {
        if (val === 0) return
        this.setCurrentView(this.showPopoverPage)
      }
    },
    beforeDestroy () {
      this.doPopoverPage(0) // 组件销毁前重置store
    }
  }
</script>

<style scoped></style>
