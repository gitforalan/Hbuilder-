<!-- Created By fx on 2017/10/31.
  -- 奖金说明
  -->
<template>
  <section class="switch-lottery" flex="">
    <div class="sl__content">
      <div class="bouns-rule">
        <div class="title">{{lotteryName}}-奖金说明</div>
        <div class="lottery-limit">中奖限额</div>
        <table class="lottery-limit-con" width="90%">
          <tr>
            <td>单期最高中奖金额</td>
            <td><span>{{maxReward}}</span>/1期</td>
          </tr>
        </table>
        <div class="lottery-limit">玩法赔率</div>
        <table class="play-odds-con" width="100%" style="margin-bottom: 0">
          <thead>
            <th style="width: 28%;text-align: center">玩法类型</th>
            <th style="width: 47%;text-align: center">玩法分类</th>
            <th style="width: 25%;text-align: center">赔率/2元</th>
          </thead>
        </table>
        <div style="height: 20rem;overflow: auto">
          <table class="play-odds-con" width="100%" style="margin-top: 0">
            <tbody>
            <tr v-for="item in allData">
              <td style="width: 28%;text-align: center">{{ item.playTabName }}</td>
              <td style="width: 47%;text-align: center">{{ item.playName }}</td>
              <td style="width: 25%;text-align: center">{{ item.prize }}</td>
            </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="btn-close" @click.stop="close">
        <icon-svg icon-class="guanbi"></icon-svg>
      </div>
    </div>

    <!-- 弹出层 -->
    <div class="weui-mask_transparent popover-mask" @click.stop="close"></div>
  </section>
</template>

<script type="text/ecmascript-6">
  import { mapState, mapMutations } from 'vuex'
  import * as API from 'api/wapi/front'

  export default {
    name: 'bounsRule',
    data () {
      return {
        maxReward: 0,
        lotteryName: '',
        allData: [],
        tabId: 0
      }
    },
    computed: {
      ...mapState('common', ['lotteryId', 'lotteryTypeId', 'playTabMode']),
      ...mapState('ui', ['showPopoverPage']),
      ...mapState('lhc', ['playTabId'])
    },
    methods: {
      getSpLotteryConf (lotteryId) {
        const query = {
          lotteryId: lotteryId
        }
        API.getSpLotteryConf(query).then(res => {
//          console.log(res.data)
          if (res.data.maxReward === -1) {
            this.maxReward = '无限额'
          } else {
            this.maxReward = res.data.maxReward + '元'
          }
          this.lotteryName = res.data.lotteryName
        })
      },
      getLotteryPlayOdds (lotteryTypeId, playTabMode) {
        const query = {
          lotteryTypeId: lotteryTypeId,
          playTabMode: playTabMode
        }
        API.getLotteryPlayOdds(query).then(res => {
//          console.log(res.data)
          this.allData = []
          res.data.playTabList.map(i => {
            i.playTypeList.map(j => {
              j.playList.map(k => {
                let obj = {
                  playTabName: i.playTabName,
                  playName: j.playTypeName + ',' + k.playName,
                  prize: this.formatPrize(k.maxPrize)
                }
                this.allData.push(obj)
              })
            })
          })
        })
      },
      getLotterySixPlayOdds (playTabId, freqType) {
        const query = {
          playTabId: playTabId,
          freqType: freqType
        }
        API.getLotterySixPlayOdds(query).then(res => {
          this.allData = []
          res.data.playTabList.map(i => {
            i.playTypeList.map(j => {
              j.playList.map(k => {
                let obj = {
                  playTabName: i.playTabName,
                  playName: j.playTypeName + ',' + k.playName,
                  prize: this.formatPrize(k.maxPrize)
                }
                this.allData.push(obj)
              })
            })
          })
        })
      },
      formatMoney (number, places, symbol, thousand, decimal) {
        number = number || 0
        places = !isNaN(places = Math.abs(places)) ? places : 2
        symbol = symbol !== undefined ? symbol : '$'
        thousand = thousand || ','
        decimal = decimal || '.'
        let negative = number < 0 ? '-' : ''
        let i = parseInt(number = Math.abs(+number || 0).toFixed(places), 10) + ''
        let j = (j = i.length) > 3 ? j % 3 : 0
        return symbol + negative + (j ? i.substr(0, j) + thousand : '') +
          i.substr(j).replace(/(\d{3})(?=\d)/g, '$1' + thousand) +
          (places ? decimal + Math.abs(number - i).toFixed(places).slice(2) : '')
      },
      formatPrize (item) {
        return ((item[0] ? item[0] : item) * 2 / 100).toFixed(2)
      },
      close () {
        this.doPopoverPage(0)
      },
      ...mapMutations('ui', ['doPopoverPage'])
    },
    created () {
//      console.log(this.lotteryId)
      console.log(this.lotteryTypeId)
//      console.log(this.playTabId)
      console.log(this.playTabMode)

      if (this.lotteryTypeId === 13) {
        this.tabId = 2
      } else {
        this.tabId = this.playTabMode
      }
      this.getSpLotteryConf(this.lotteryId)
      switch (this.lotteryId) {
        case 2001:
          this.getLotterySixPlayOdds(this.playTabId, 2)
          break
        case 2002:
          this.getLotterySixPlayOdds(this.playTabId, 1)
          break
        default:
          this.getLotteryPlayOdds(this.lotteryTypeId, this.tabId)
      }
    },
    watch: {
      showPopoverPage (val) {
        if (val) {
          // 阻止父容器滚动
          this.$root.$el.style.overflow = 'hidden'
        } else {
          // 取消阻止
          this.$root.$el.style.overflow = 'auto'
        }
      },
      playTabId (val) {
        switch (this.lotteryId) {
          case 2001:
            this.getLotterySixPlayOdds(this.playTabId, 2)
            break
          case 2002:
            this.getLotterySixPlayOdds(this.playTabId, 1)
            break
          default:
            break
        }
      }
    }
  }
</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .switch-lottery
    position fixed
    width 100%
    height 100%
    top 0
    z-index 999
    .sl__content
      position relative
      margin auto 1rem
      width 100%
      min-height rem(700)
      box-sizing border-box
      background #fff
      z-index 1001
      border-radius 5px
      .btn-close
        position absolute
        right rem(20)
        width auto
        top rem(7)
        color $color-black-c
      .bouns-rule
        margin rem(30) rem(30)
        .title
          color $color-black-c
          font-size rem(28)
          margin rem(25) auto
          padding-bottom rem(20)
          border-bottom 1px solid $color-border
        .lottery-limit
          font-size rem(28)
          color $color-black-c
          width rem(115)
          padding-bottom rem(5)
          border-bottom 2px solid $color-red
        .lottery-limit-con
          font-size rem(25)
          color $color-black-c
          margin rem(20) 0
          tr td
            padding rem(25) .5rem
            &:first-child
              background #ccc
            &:last-child
              background #e5e5e5
        .play-odds-con
          font-size rem(25)
          color $color-black-c
          margin rem(20) 0 rem(40)
          thead th
            text-align left
            padding rem(25) rem(30)
            background #ccc
            border 1px solid #ccc
          tbody tr
            &:nth-child(even)
              background #e5e5e5
            td
              padding rem(25) rem(30)
              border 1px solid #c7c7c7
              box-sizing border-box

</style>
