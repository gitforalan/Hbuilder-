<!-- Created By fx on 2017/10/30.
  -- 切换彩种
  -->
<template>
  <!-- 切换彩种 -->
  <section class="switch-lottery" flex="">
    <div class="sl__content" flex="box:mean" ref="sl__content">
      <div class="s-box">
        <scroller :lock-x="true" :height="sHeight">
          <ul class="left" ref="leftArea">
            <li v-for="(item, index) in lotteryTypeList"
                :class="{active: selectedLottery === index}"
                @click="selectelotteryType(index, item.lotteryTypeName)">{{item.lotteryTypeName}}
              <icon-svg icon-class="right" flex="cross:center"></icon-svg>
            </li>
          </ul>
        </scroller>
      </div>
      <ul class="right" flex="dir:top cross:center">
        <li v-for="t in lotteryList"
            :class="{active: t.lotteryId === lotteryId}"
            @click="jump(t.lotteryId)">{{t.lotteryName}}
        </li>
      </ul>
      <div class="btn-close" @click.stop="close">
        <icon-svg icon-class="guanbi"></icon-svg>
      </div>
    </div>

    <!-- 弹出层 -->
    <div class="weui-mask_transparent popover-mask" @click.stop="close"></div>
  </section>
</template>

<script type="text/ecmascript-6">
  import { mapState, mapMutations } from 'vuex'
  import * as API from 'api/wapi/front'

  export default {
    name: 'switchLottery',
    data () {
      return {
        lotteryTypeList: [],
        lotteryList: [],
        selectedLottery: 0,
        lotteryTypeName: '',
        sHeight: ''
      }
    },
    computed: {
      ...mapState('ui', ['showPopoverPage']),
      ...mapState('common', ['lotteryTypeId', 'lotteryId'])
    },
    methods: {
      getLotteryList () {
        API.getLotteryList().then(res => {
          this.lotteryTypeList = res.data.lotteryTypeList
          // 默认取第一个
          this.selectedLottery = 0
          this.lotteryList = this.lotteryTypeList[0].lotteryList
          // 匹配当前页彩种
          const typeName = this.findTypeName(this.lotteryTypeList, this.lotteryId)
          for (let i = 0, len = this.lotteryTypeList.length; i < len; i++) {
            const type = this.lotteryTypeList[i]
            // 匹配当前大类
            if (type.lotteryTypeName === typeName) {
              this.selectedLottery = i
              this.lotteryList = type.lotteryList
              // 定位到可视区
              if (i > len / 2) {
                this.$nextTick(() => {
                  this.$refs.leftArea.scrollTop = this.$refs.leftArea.scrollHeight
                })
              }
              break
            }
          }
          this.$nextTick(() => {
            console.log(this.$refs.sl__content.offsetHeight)
            this.sHeight = this.$refs.sl__content.offsetHeight + 'px'
          })
        })
      },
      // 查找彩种大类名称
      findTypeName (typeList = [], id) {
        let lotteryTypeName
        /* eslint no-labels: ["error", { "allowLoop": true }] */
        outer:
          for (let i = 0, len = typeList.length; i < len; i++) {
            const type = typeList[i]
            const listArr = type.lotteryList
            lotteryTypeName = type.lotteryTypeName
            for (let j = 0, len = listArr.length; j < len; j++) {
              const list = listArr[j]
              if (list.lotteryId === id) {
                break outer
              }
            }
          }
        return lotteryTypeName
      },
      selectelotteryType (index, lotteryTypeName) {
        this.selectedLottery = index
        this.lotteryTypeList.map(i => {
          if (i.lotteryTypeName === lotteryTypeName) {
            this.lotteryList = i.lotteryList
          }
        })
      },
      jump (id) {
        this.close()
        this.swich_lottery(true)
        this.$router.push({ name: 'chunkComp', params: { sid: id } })
//        this.$router.go(0)
      },
      close () {
        this.doPopoverPage(0)
      },
      ...mapMutations('ui', ['doPopoverPage']),
      ...mapMutations('common', ['swich_lottery'])
    },
    created () {
      this.getLotteryList()
    },
    watch: {
      showPopoverPage (val) {
        if (val) {
          // 阻止父容器滚动
          this.$root.$el.style.overflow = 'hidden'
        } else {
          // 取消阻止
          this.$root.$el.style.overflow = 'auto'
        }
      }
    }
  }
</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .switch-lottery
    position fixed
    width 100%
    height 100%
    top 0
    z-index 999
    .sl__content
      position relative
      margin auto 1rem
      width 100%
      height rem(700)
      box-sizing border-box
      background #fff
      z-index 1001
      border-radius 5px
      .btn-close
        position absolute
        left 47%
        width auto
        bottom rem(-80)
        color $color-black-c
      .s-box
        background $color-el-bg
      ul
        height 100%
        overflow-y auto
        &::-webkit-scrollbar
          width 0
        li
          position relative
          height 2rem
          background $color-el-bg
          margin .3rem 1rem
          box-sizing border-box
          font-size rem(27)
          color $color-black-c
          &:first-child
            margin-top rem(40)
          &:last-child
            margin-bottom rem(40)
        &.left
          border-top-left-radius 5px
          border-bottom-left-radius 5px
          background $color-el-bg
          border-top-left-radius 5px
          border-bottom-left-radius 5px
          li
            padding-left rem(15)
            height rem(65)
            line-height rem(65)
            border-bottom 1px dotted $color-border
            &.active
              color $color-red
        &.right
          color #04be02
          li
            width rem(260)
            height rem(65)
            line-height rem(65)
            border 1px solid $color-border
            text-align center
            border-radius 4px
            background $color-white
            &.active
              color $color-red
              border-color rgba(255, 0, 0, 0.1)
        .lott-icon
          position absolute
          right .3rem
          top 50%
          transform translateY(-50%)
          width 1.3rem
          height 1.3rem
</style>
