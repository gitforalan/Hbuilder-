<!--
  -- 冷热组件封装
  -->
<template>
  <ul :class="arrowClass" v-click-outside="onClickedOutside" v-show="show">
    <li v-for="(item, index) in options" @click="onTouchHandler(index)">
      {{ item }}
      <icon-svg v-if="hcsLtsFlag === index" icon-class="duihao" class="icon"></icon-svg>
    </li>
    <!--<li>最大遗漏</li>-->
  </ul>
</template>

<script type="text/ecmascript-6">
  import ClickOutside from 'vux/src/directives/click-outside'
  import { mapState, mapMutations } from 'vuex'

  export default {
    name: 'zPopoverMenu',
    props: {
      placement: String,
      show: {
        type: Boolean,
        default: false
      },
      options: {
        type: Array,
        default: []
      }
    },
    computed: {
      arrowClass () {
        return {
          'left': this.placement === 'left',
          'right': this.placement === 'right'
        }
      },
      ...mapState('common', {
        hcsLtsFlag: state => state.hcsLtsFlag
      })
    },
    methods: {
      onTouchHandler (index) {
        this.set_hcsLtsFlag({ flag: index })
        this.$emit('on-hide')
      },
      onClickedOutside () {
        if (this.show) {
          this.$emit('on-hide')
        }
      },
      ...mapMutations('common', ['set_hcsLtsFlag'])
    },
    directives: {
      ClickOutside
    }
  }

</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"
  ul
    min-width rem(164)
    background $color-white
    border 1px solid $color-red
    border-radius 5px
    box-sizing border-box
    li
      position relative
      font-size rem(28)
      padding rem(23) rem(23) rem(18)
      color $color-black-c
      border-bottom 1px solid $color-red
      box-sizing border-box
      &.active
        color $color-black-b
      span
        color $color-red
      i
        position absolute
        right rem(10)
        top .7rem
        vertical-align middle
      &:last-child
        border-bottom none
    &:before, &:after
      content ""
      border-color $color-red transparent
      border-style solid
      display block
      height 0
      font-size 0
      line-height 0
      width 0
      border-width 0 .8rem .8rem
      position absolute
      z-index 12
      top -.8rem
      left 50%
      transform translate3D(-50%, 0, 0)
      zoom 12
    &:after
      border-color: $color-white transparent
      top -.7rem
      left 50%
      transform translate3D(-50%, 0, 0)
      z-index 13

    &.right:before, &.right:after
      left 90%
      transform translate3D(-80%, 0, 0)
    &.right:after
      left 90%
      transform translate3D(-80%, 0, 0)

    &.left:before, &.left:after
      left 5%
      transform translate3D(40%, 0, 0)
    &.left:after
      left 5%
      transform translate3D(40%, 0, 0)

  .lott-icon
    width 1.2rem
    height 1.2rem
</style>
