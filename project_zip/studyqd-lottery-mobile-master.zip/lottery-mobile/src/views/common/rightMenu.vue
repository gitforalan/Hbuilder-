<!--
  -- 组件待封装
  -->
<template>
  <section v-if="rightMenu.length" ref="section" v-click-outside="onClickedOutside">
    <v-touch @tap="close()" v-on:panmove="onPanMove" v-on:panstart="onPanstart" v-on:panend="onPanend">
      <div class="right-menu" flex="" ref="menu">
        <template v-for="(item, row) in _rightMenuList">
          <ul flex="main:center dir:top" v-if="row === 0">
            <li v-for="t in item" @click="rote(t.id, t.lotteryName)">{{t.lotteryName}}</li>
          </ul>
          <ul flex="dir:top" v-else>
            <li v-for="t in item" @click="rote(t.id, t.lotteryName)">{{t.lotteryName}}</li>
          </ul>
        </template>
        <div class="title" ref="switch">{{lotteryname || name}}</div>
      </div>
    </v-touch>
  </section>
</template>

<script type="text/ecmascript-6">
  import { mapGetters, mapMutations } from 'vuex'
  import ClickOutside from 'vux/src/directives/click-outside'

  let nowTop = 0 // 当前右菜单的位置
  let choseState = false // 菜单展开状态
  export default {
    data () {
      return {
        name: '',
        menu: ''
      }
    },
    props: {
      rightMenu: {
        type: Array,
        default: () => {
          return [
            [{ lotteryName: '重庆时时彩' }, { lotteryName: '重庆时时彩' }, { lotteryName: '重庆时时彩' },
              { lotteryName: '重庆时时彩' }, { lotteryName: '重庆时时彩' }],
            [{ lotteryName: '重庆时时彩' }, { lotteryName: '重庆时时彩' }, { lotteryName: '重庆时时彩' },
              { lotteryName: '重庆时时彩' }, { lotteryName: '重庆时时彩' }]
          ]
        }
      },
      lotteryname: {
        type: String,
        default: ''
      }
    },
    computed: {
      _rightMenuList () {
        let rm = []
        if (this.rightMenu.length < 5 || this.rightMenu.length === 5) {
          rm.push(this.rightMenu)
        } else {
          for (let i = 0; i < this.rightMenu.length; i++) {
            if (i % 5 === 0) {
              let newArr = []
              if (this.rightMenu[i]) {
                newArr.push(this.rightMenu[i])
              }
              if (this.rightMenu[i + 1]) {
                newArr.push(this.rightMenu[i + 1])
              }
              if (this.rightMenu[i + 2]) {
                newArr.push(this.rightMenu[i + 2])
              }
              if (this.rightMenu[i + 3]) {
                newArr.push(this.rightMenu[i + 3])
              }
              if (this.rightMenu[i + 4]) {
                newArr.push(this.rightMenu[i + 4])
              }
              rm.push(newArr)
            }
          }
        }
        return rm
      },
      ...mapGetters('common', ['lotteryName', 'rightMenu'])
    },
    methods: {
      close () {
        let winwidth = window.screen.width
        let left = this.$refs.menu.offsetLeft
        if (this._rightMenuList[0].length === 0) return
        if (this.$refs.menu) {
          if (left < winwidth) {
            this.$refs.menu.style.right = -(winwidth - left + 3) + 'px'
            choseState = false
          } else {
            this.$refs.menu.style.transition = 'all .3s ease'
            this.$refs.menu.style.right = -3 + 'px'
            choseState = true
          }
        }
      },
      onPanstart () {
        nowTop = this.$refs.menu.offsetTop
        this.$refs.menu.style.transition = 'none'
      },
      onPanMove (e) {
        let eY = e.deltaY
        let winH = window.screen.height
        let menuH = this.$refs.menu.offsetHeight
        let swichH = this.$refs.switch.offsetHeight
        let menuT = this.$refs.menu.offsetTop
        console.log('menuT=>' + menuT)
        // 向上拉
        if (eY < 0) {
          if (nowTop === 0) {
            this.$refs.menu.style.top = 0 + 'px'
          }
          if (nowTop > 0) {
            if (nowTop + eY < 0) {
              if (choseState) {
                this.$refs.menu.style.top = 0 + 'px' // 不允许出现负值
              } else {
                this.$refs.menu.style.top = -((menuH - swichH) / 2) + 'px' // 不允许出现负值
              }
            } else {
              this.$refs.menu.style.top = nowTop + eY + 'px' // 减法 e.deltaY为递减
            }
          }
        }

        // 向下拉
        if (eY > 0) {
          if (choseState) {
            if (menuT >= (winH - menuH - 3)) {
              this.$refs.menu.style.top = (winH - menuH - 3) + 'px'
              return
            }
            this.$refs.menu.style.top = nowTop + eY + 'px'
          } else {
            if (menuT >= (winH - swichH - ((menuH - swichH) / 2) - 3)) {
              this.$refs.menu.style.top = (winH - swichH - ((menuH - swichH) / 2) - 3) + 'px'
              return
            }
            this.$refs.menu.style.top = nowTop + eY + 'px'
          }
        }
      },
      onPanend () {
        nowTop = this.$refs.menu.offsetTop
        this.$refs.menu.style.transition = 'all .3s ease'
      },
      rote (id, lotteryName) {
        this.com_lotteryName(lotteryName)
        this.swich_lottery(true) // 切换彩种，通知其他组件响应
        this.$router.push({ name: 'chunkComp', params: { sid: id } })
      },
      onClickedOutside () {
        this.choseState = false
        let winwidth = window.screen.width
        let left = this.$refs.menu.offsetLeft
        if (left >= winwidth) return
        else this.$refs.menu.style.right = -(winwidth - left + 3) + 'px'
      },
      ...mapMutations('common', ['com_lotteryName', 'swich_lottery'])
    },
    created () {
    },
    directives: {
      ClickOutside
    },
    mounted () {
      if (this.$refs.menu) {
        let winwidth = window.screen.width
        let left = this.$refs.menu.offsetLeft
        this.$refs.menu.style.transition = 'none'
        this.$refs.menu.style.right = -(winwidth - left + 3) + 'px'
      }
    },
    watch: {
      lotteryName (val) {
        this.name = val
      }
//      rightMenu (val) {
//        console.log(123)
//      }
    }
  }
</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"
  section
    .right-menu
      min-width rem(184)
      position fixed
      right -3px
      top rem(290)
      background $color-white
      border 1px solid $color-red
      border-top-left-radius 6px
      border-bottom-left-radius 6px
      z-index 101
      transition all .3s ease
      ul
        margin 0 rem(20)
        min-height rem(230)
        li
          height rem(85)
          line-height rem(85)
          font-size rem(24)
          text-align center
          color $color-black-c
          border-bottom 1px solid $color-border
          &:last-child
            border-bottom none
        &:last-child
          margin-left -0.1rem
      .title
        width rem(20)
        line-height 1.5em
        padding rem(17) rem(15) rem(17) rem(14)
        position absolute
        left rem(-50)
        top 50%
        transform translate3D(0, -50%, 0)
        -webkit-transform translate3D(0, -50%, 0)
        font-size rem(24)
        background $color-red
        color $color-white
        border-top-left-radius 4px
        border-bottom-left-radius 4px

</style>
