<!-- Created By fx on 2017/11/6. -->
<template>
  <div class="content">
    <ul class="listTitle">
      <li class="xbox-1">期号</li>
      <li class="xbox-2">开奖结果</li>
      <li class="xbox-3">中奖金额</li>
      <li class="xbox-4">详情</li>
    </ul>

    <ul class="listBox">
      <li class="listline" v-for="(item, index) in list">
        <ul class="lineTitle" @click="openDetilBox(index)">
          <li class="xbox-1">{{item.issue}}</li>
          <li class="xbox-2">{{item.openRuslt}}</li>
          <li class="xbox-3 col_red">{{item.winMoney}}</li>
          <li class="xbox-4">
            <icon-svg iconClass="right" class="icon" v-if="!showDetilBox[index]"></icon-svg>
            <icon-svg iconClass="down" class="icon" v-if="showDetilBox[index]"></icon-svg>
          </li>
        </ul>
        <ul class="lineDetil" v-if="showDetilBox[index]">
          <li>
            <div class="tl xbox-5">用户:{{item.loginId}}</div>
            <div class="tr xbox-5">所属组:代理</div>
          </li>
          <li>
            <div class="tl xbox-5 gray-color">追号时间:{{item.createTime}}</div>
            <div class="tr xbox-5">追号倍数:{{item.buyDouble}}</div>
          </li>
          <li>
            <div class="tl xbox-5">投注金额:{{item.buyMoney}}</div>
            <div class="tr xbox-5">投注返点:{{item.rebateRate}}</div>
          </li>
          <li>
            <div class="tl xbox-5">状态: <span>{{item.state}}</span></div>
            <div class="tl xbox-5" v-if="item.status === 0">
              <span class="btn" @click="revocation(item.orderCode, item.issue)">撤单</span>
            </div>
          </li>
        </ul>
      </li>
    </ul>
  </div>
</template>

<script type="text/ecmascript-6">
  import * as API from 'api/wapi/front/'
  import { mapMutations } from 'vuex'
  export default {
    data () {
      return {
        showDetilBox: [],
        list: []
      }
    },
    props: {
      traceList: {},
      lotteryId: {},
      traceCode: {},
      uId: {}
    },
    methods: {
      // 撤单操作
      revocation (orderCode, issue) {
        this.getLotteryUserBetCancel(orderCode, issue, this.lotteryId)
      },
      // 改变状态数据
      processData () {
        this.list.map(i => {
          i.show = false
          if (i.openCode.length > 0) {
            i.openRuslt = i.openCode
          } else {
            i.openRuslt = '未开奖'
          }
          switch (i.status) {
            case 0:
              i.state = '未结算'
              break
            case 1:
              i.state = '撤单'
              break
            case 2:
              i.state = '已中奖'
              break
            case 3:
              i.state = '未中奖'
              break
          }
          this.showDetilBox.push(i.show)
        })
      },
      getLotteryUserBetCancel (orderCode, issue, lotteryId) {
        const itemsArr = [
          {
            orderCode: orderCode,
            issue: issue,
            lotteryId: lotteryId
          }
        ]
        const query = {
          items: JSON.stringify(itemsArr)
        }
        API.getLotteryUserBetCancel(query).then(res => {
          this.$vux.toast.show({
            text: '撤单成功',
            time: 1000
          })
          this.with_drawal(true)
          this.getOrderTraceDetail()
        })
      },
      getOrderTraceDetail () {
        const q = {
          traceCode: this.traceCode,
          userId: this.uId
        }
        API.getOrderTraceDetail(q).then(res => {
          this.list = res.data.traceList
          this.processData()
        })
      },
      openDetilBox (index) {
        if (this.showDetilBox[index]) {
          this.showDetilBox.splice(index, 1, false)
        } else {
          this.showDetilBox.splice(index, 1, true)
        }
      },
      ...mapMutations('common', ['with_drawal'])
    },
    created () {
      this.list = this.traceList
      this.processData()
    }
  }
</script>

<style scoped lang='stylus'>
  @import "~@/assets/baseStylus/variable"
  .btn
    height auto
    font-size rem(25)
    width auto
    float right
  .col_red
    color red
  .xbox-1
    width 30%
  .xbox-2
    width 30%
  .xbox-3
    width 30%
  .xbox-4
    width 10%
    .icon
      width 1.3rem
      color rgba(165,171,179,1)
  .xbox-5
    width 50%
    color $color-black-c
    span
      color $color-black-b
      &.btn
        color #6fb4e0
  .gray-color
    color $color-black-b
  .content
    color #101010
    font-size rem(30)
    .listTitle
      background #eff3f7
      text-align center
      padding rem(20)
      display flex
    .listBox
      .listline
        .lineTitle
          padding 0 rem(20)
          text-align center
          display flex
          height rem(65)
          line-height rem(65)
          color $color-black-c
          border-bottom 1px solid #eff3f7
          .icon
            font-size rem(50)
        .lineDetil
          border-bottom 1px solid #eff3f7
          padding .5rem 0
          li
            display flex
            padding 0 rem(20)
            height rem(40)
            line-height rem(40)
            font-size rem(25)
            div
              width 50%
            .tl
              text-align left
            .tr
              text-align right
</style>
