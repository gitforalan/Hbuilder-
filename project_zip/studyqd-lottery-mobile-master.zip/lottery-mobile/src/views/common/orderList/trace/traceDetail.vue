<!-- Created By fx on 2017/11/6. -->
<template>
  <div class="trace-detail">
    <div v-if="!isShowTraceList">
      <div class="table-wrap">
        <table width="100%">
          <tr>
            <td>用户</td>
            <td>{{ item.loginId }}</td>
          </tr>
          <tr>
            <td>所属组</td>
            <td>{{ agentId }}</td>
          </tr>
          <tr>
            <td>追号编号</td>
            <td>{{ item.traceCode }}</td>
          </tr>
          <tr>
            <td>彩种</td>
            <td>{{ item.lotteryName }}</td>
          </tr>
          <tr>
            <td>玩法</td>
            <td>{{ item.playName }}</td>
          </tr>
          <tr>
            <td>单注金额</td>
            <td>{{ item.singleMoney }}</td>
          </tr>
          <tr>
            <td>倍数/注数</td>
            <td>{{ item.buyDouble }}/{{ item.buyNumber }}</td>
          </tr>
          <tr>
            <td>奖金/返点</td>
            <td>{{ item.winMoneyTotal }}/{{ item.rebateRate }}</td>
          </tr>
          <tr>
            <td>投注内容</td>
            <td>{{ item.buyCodeCase }}</td>
          </tr>
          <tr>
            <td>起追时间</td>
            <td>{{ item.createTime }}</td>
          </tr>
          <tr>
            <td>起始期号</td>
            <td>{{ item.beginIssue }}</td>
          </tr>
          <tr>
            <td>已追/总期数</td>
            <td>{{ item.alreadyTraceNum }}/{{ item.totalTraceNum }}</td>
          </tr>
          <tr>
            <td>已投/总金额</td>
            <td>{{ item.alreadyBuyMoney }}元/{{ item.totalBuyMoney }}</td>
          </tr>
          <tr>
            <td>中奖停追</td>
            <td>{{ item.toStop }}</td>
          </tr>
        </table>

        <div>
          <x-button class="btn-bottom" @click.native="showTraceList">查看追号注单</x-button>
        </div>
        <!--<div>-->
        <!--<x-button class="btn-bottom" @click.native="cancellations">撤单</x-button>-->
        <!--</div>-->
      </div>
    </div>
    <trace-list :traceList="traceList"
                :lotteryId="lotteryId"
                :traceCode="traceCode"
                :uId="uId"
                v-else></trace-list>
  </div>
</template>

<script type="text/ecmascript-6">
  import { mapState, mapMutations } from 'vuex'
//  import { mapState } from 'vuex'
  import TraceList from './traceList' // 追号注单列表明细
  import * as API from 'api/wapi/front/'

  export default {
    data () {
      return {
        isShowTraceList: false,
        item: {},
        traceList: [],
        lotteryId: ''
      }
    },
    props: {
      uId: {},
      agentId: {},
      traceCode: {}
    },
    components: { TraceList },
    computed: {
      ...mapState('common', {
        withdrawal: state => state.withdrawal
      })
    },
    methods: {
      showTraceList () {
        this.isShowTraceList = true
      },
      getOrderTraceDetail () {
        const q = {
          traceCode: this.traceCode,
          userId: this.uId
        }
        API.getOrderTraceDetail(q).then(res => {
          this.item = []
          this.item = res.data
          this.lotteryId = res.data.lotteryId
          this.traceList = res.data.traceList
          switch (this.item.traceStatus) {
            case 0:
              this.item.status = '未开始'
              break
            case 1:
              this.item.status = '已开始'
              break
            case 2:
              this.item.status = '已结束'
              break
            default:
              this.item.status = '未开始'
          }
          switch (parseInt(this.item.winningToStop)) {
            case 0:
              this.item.toStop = '否'
              break
            case 1:
              this.item.toStop = '是'
              break
          }
          this.with_drawal(false)
        })
        this.with_drawal(true)
      },
      ...mapMutations('common', ['with_drawal'])
    },
    created () {
      this.getOrderTraceDetail()
    },
    watch: {
      withdrawal (val) {
        if (val) {
          this.getOrderTraceDetail()
        }
      }
    }
  }
</script>

<style scoped lang='stylus'>
  @import "~@/assets/baseStylus/variable"
  .btn-bottom
    margin-top rem(30)
    background #ff9a00
    padding rem(5) 0
    width 40%
    font-size rem(30)
  .trace-detail
    margin-top $topBarHeight
    .table-wrap
      width 95%
      padding 0 2.5%
      marign 0 auto
      padding-top rem(51)
      table
        font-size rem(25)
        color $color-black-c
        tr
          & > td:nth-child(2)
            color $color-red
          & > td.align-top
            position absolute
          & > td:nth-child(1)
            width 20%
          & > td
            word-break break-all
            padding-bottom rem(40)
          & > td.textarea-border
            textarea
              width rem(470)
              min-height rem(134)
              font-size rem(25)
              color $color-black-c
              border-radius 4px
              border 1px solid $color-border
              -webkit-appearance none
              padding rem(10) rem(16)
        button.weui-btn, input.weui-btn
          width rem(448)
          height rem(66)
          line-height rem(66)
          font-size rem(25)
          margin-left rem(23)
          background $color-red
</style>
