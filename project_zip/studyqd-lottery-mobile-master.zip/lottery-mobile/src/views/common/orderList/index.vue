<!--
  -- 2017-10-20 10:46:05 fx
  -->
<template>

  <div class="app-main order">
    <!-- 列表 -->
    <template v-if="!isShowDetail">
      <x-header :left-options="{backText: ''}" class="is-fixed">
        <button-tab v-model="tabActive" resetstyle>
          <button-tab-item @on-item-click="btnClick(1)">
            <icon-svg iconClass="duihao"></icon-svg>
            投注记录
          </button-tab-item>
          <button-tab-item @on-item-click="btnClick(2)">
            <icon-svg iconClass="duihao"></icon-svg>
            追号记录
          </button-tab-item>
        </button-tab>
      </x-header>
      <!--<x-header :left-options="{preventGoBack:true, showBack: true, backText: ''}"-->
      <!--@on-click-back="goBack"-->
      <!--:title="LANG.title.list" class="is-fixed">-->
      <!--</x-header>-->
      <!-- 彩期模块 -->
      <current-info :typeId="lotteryTypeId" ref="currentInfo"></current-info>
      <div class="app-body">
        <!-- 注单记录 -->
        <div class="top-con list">
          <!-- 表头 -->
          <tab ref="tab"
               v-model="timeOption.index"
               :animate="false"
               :line-width="1"
               custom-bar-width="60px"
               class="tab active">
            <tab-item v-for="(item, index) in timeOption.tab"
                      :selected="timeOption.index === index"
                      :key="index"
                      active-class="active">
              <span v-show="timeOption.index === index">
                <icon-svg class="icon" icon-class="duihao"></icon-svg>
              </span>
              <span>{{ item }}</span>
            </tab-item>
          </tab>
          <!-- 列表 -->

          <scroller ref="scroller"
                    v-if="cathexisList.length"
                    lock-x
                    @on-scroll="onScroll"
                    @on-scroll-bottom="onScrollBottom"
                    :scroll-bottom-offset="scrollerOption.up"
                    :height="scrollerOption.height">
            <div class="scroll-con">
              <div v-if="tab===2">
                <div class="record-con" v-for="item in trackList" @click="showDetail(item)">
                  <table width="100%">
                    <tr>
                      <td>用户: <span>{{ item.loginId }}</span></td>
                      <td>所属组:{{ item.agentId }}</td>
                    </tr>
                    <tr>
                      <td>{{ item.lotteryName }}</td>
                      <td>{{ item.playName }}</td>
                    </tr>
                    <tr>
                      <td><i>{{ item.createTime }}</i></td>
                      <td>已投:<span>{{ item.alreadyBuyMoney }}</span></td>
                    </tr>
                    <tr>
                      <td>第{{ item.beginIssue }}期起追</td>
                      <td>共{{ item.totalBuyMonery }}元</td>
                    </tr>
                    <tr>
                      <td>已追<span>{{ item.alreadyTraceNum }}</span>期/总<span>{{item.totalTraceNum}}</span>期</td>
                      <td>状态: <span>{{ item.status }}</span></td>
                    </tr>
                  </table>
                </div>
              </div>

              <div v-if="tab===1">
                <div class="record-con" v-for="item in cathexisList" @click="showDetail(item)">
                  <table width="100%">
                    <tr>
                      <td>{{ item.lotteryName }}</td>
                      <td>{{ item.createTime }}</td>
                    </tr>
                    <tr>
                      <td>{{ item.playName }}</td>
                      <td>金额：<span>{{ item.orderMoney | formatF2Y }}元</span></td>
                    </tr>
                    <tr>
                      <td>第{{ item.issue }}期</td>
                      <td>{{ item.status | statusFormat }}</td>
                    </tr>
                    <tr>
                      <td>投注号码</td>
                      <td>
                        <span>{{ item.buyCodeCase }}</span>
                        <!--<span class="red">3</span>-->
                        <!--<span class="red">3</span>-->
                        <!--<span class="green">3</span>-->
                        <!--<span class="green">3</span>-->
                        <!--<span class="red">3</span>-->
                        <!--<span class="red">3</span>-->
                        <!--<span class="blue">3</span>-->
                      </td>
                    </tr>
                  </table>
                </div>
              </div>
            </div>
          </scroller>


          <p v-else class="empty"> {{ LANG.empty}} </p>
        </div>
      </div>
    </template>

    <!-- 详情 -->
    <template v-else-if="isShowTraceDetail">
      <!-- 追号注单记录 -->
      <x-header :left-options="{preventGoBack:true, showBack: true, backText: ''}"
                :title="LANG.title.traceDetail"
                @on-click-back="hideDetail"
                class="is-fixed"></x-header>
      <trace-detail :uId="userInfo.uid" @hideDetail="hideDetail"
                    :traceCode="traceCode" :agentId="agentId"></trace-detail>
    </template>
    <template v-else>
      <x-header :left-options="{preventGoBack:true, showBack: true, backText: ''}"
                :title="LANG.title.detail"
                @on-click-back="hideDetail"
                class="is-fixed"></x-header>
      <div class="app-body">
        <!-- 普通注单记录 -->
        <detail :orderCode="orderCode" :uId="userInfo.uid"
                @hideDetail="hideDetail"></detail>
      </div>

    </template>
  </div>
</template>

<script type="text/ecmascript-6">
  import { mapState, mapActions, mapMutations } from 'vuex'
  import * as API from 'api/wapi/front/'
  import { dateFormat } from 'vux'
  import Detail from './normal/detail.vue' // 普通注单记录
  import TraceDetail from './trace/traceDetail' // 追号方案详情

  export default {
    data () {
      return {
        tab: 1,
        agentId: 0,
        LANG: {
          title: {
            list: '投注记录',
            detail: '投注详情',
            traceDetail: '方案详情'
          },
          empty: '无投注记录',
          loading: '正在加载',
          refresh: '正在刷新',
          error: '请刷新重试！',
          tip: '已经到底了'
        },
        timeOption: {
          tab: ['今天', '昨天', '前天', '大前天'],
          index: 0
        },
        scrollerOption: {
          height: '0',
          down: -100, // 触发距离
          up: -50
        },
        tabActive: 0,
        orderList: [], // 列表数据
        isTip: false, // 是否提示
        minTipCount: 5, // 提示阈值
        isShowDetail: false, // 显示投注详情
        isShowTraceDetail: false, // 显示追号方案详情
        orderCode: '', // 注单编码
        traceCode: '',
        delayTime: 2000, // 延迟请求
        isLoading: false,
        pageSize: 15,
        cathexis_pageNo: 1,
        cathexisList: [],
        track_pageNo: 1,
        trackList: [],
        pullup: false
      }
    },
    components: { Detail, TraceDetail },
    filters: {
      // 分转元
      formatF2Y: (val) => (val / 100).toFixed(2),
      // 状态值转换 暂时未用到
      statusFormat (n) {
        let name = n
        switch (n) {
          case 0:
            name = '未结算'
            break
          case 1:
            name = '用户撤单'
            break
          case 2:
            name = '追号撤单'
            break
          case 3:
            name = '系统撤单'
            break
          case 4:
            name = '已结算_输'
            break
          case 5:
            name = '已结算_平'
            break
          case 6:
            name = '已结算_赢'
            break
        }
        return name
      }
    },
    computed: {
      // 时间段
      timeSlot () {
        let i = this.timeOption.index
        let date = new Date()
        date.setHours(0)
        date.setMinutes(0)
        date.setSeconds(0)
        date.setMilliseconds(0)
        return {
          beginTime: dateFormat(new Date(date - i * 24 * 60 * 60 * 1000), 'YYYY-MM-DD HH:mm:ss'),
          endTime: dateFormat(new Date(date - (i - 1) * 24 * 60 * 60 * 1000 - 1), 'YYYY-MM-DD HH:mm:ss')
        }
      },
      ...mapState('common', [
        'userInfo',
        'lotteryTypeId'
      ])
    },
    methods: {
      btnClick (tab) {
        this.tab = tab
        this.timeOption.index = 0
        this.orderList = []
        switch (tab) {
          case 1:
            this.LANG.empty = '无投注记录'
            this.cathexisList = []
            this.cathexis_pageNo = 1
            this.getOrderInfoList()
            break
          case 2:
            this.LANG.empty = '无追号记录'
            this.trackList = []
            this.track_pageNo = 1
            this.getOrderTraceList()
            break
        }
      },
      // 获取数据
      getOrderInfoList () {
        this.isLoading = true
        const userObj = { userId: this.userInfo.uid }
        const q = Object.assign({},
          this.timeSlot, userObj, { orderType: 0 },
          { pageSize: this.pageSize, pageNo: this.cathexis_pageNo })
        API.getOrderInfoList(q).then((res) => {
          this.orderList = []
          this.orderList = res.data.items.elements
          res.data.items.elements.map(i => {
            this.cathexisList.push(i)
          })
          this.pullup = false
        }).catch(err => {
          let _opt = {
            type: 'warn',
            text: err.desc || this.LANG.error,
            time: 5000
          }
          this.$vux.toast.show(_opt)
        }).then(() => {
          setTimeout(() => {
            this.isLoading = false
            this.$vux.loading.hide()
          }, this.delayTime >> 4)
        })
      },
      // 追号列表接口方法
      getOrderTraceList () {
        const query = {
          userId: this.userInfo.uid,
          beginTime: this.timeSlot.beginTime,
          endTime: this.timeSlot.endTime,
          pageSize: this.pageSize,
          pageNo: this.track_pageNo
        }
        API.getOrderTraceList(query).then(res => {
          this.orderList = []
          this.orderList = res.data.elements
          res.data.elements.map(i => {
            this.trackList.push(i)
          })
          // 改变状态数据
          this.orderList.map(i => {
            switch (i.traceStatus) {
              case 0:
                i.status = '未开始'
                break
              case 1:
                i.status = '已开始'
                break
              case 2:
                i.status = '已结束'
                break
              default:
                i.status = '未开始'
            }
          })
        })
      },
      // 下拉刷新
      onScroll (pos) {
        if (!this.pullup) {
          let _opt
          if (pos.top < this.scrollerOption.down) {
            _opt = {
              text: this.LANG.refresh,
              transition: ''
            }
            this.$vux.loading.show(_opt)
            this.pullup = true
            setTimeout(() => {
              this.$vux.loading.hide()
              if (this.tab === 1) {
                this.cathexisList = []
                this.cathexis_pageNo = 1
                this.getOrderInfoList()
              } else {
                this.trackList = []
                this.track_pageNo = 1
                this.getOrderTraceList()
              }
            }, 2000)
          }
        }
      },
      // 上拉加载
      onScrollBottom () {
        if (this.orderList.length > 0) {
          if (this.isTip) return
          const self = this
          const option = {
            type: 'text',
            text: '正在加载...',
            position: 'middle',
            onShow () {
              this.isTip = true
              if (self.tab === 1) {
                self.cathexis_pageNo++
                self.getOrderInfoList()
              } else {
                self.track_pageNo++
                self.getOrderTraceList()
              }
            },
            onHide () {
              this.isTip = false
            }
          }
          this.$vux.toast.show(option)
        } else {
          if (this.isTip) return
          const option = {
            type: 'text',
            text: '没有更多数据了',
            position: 'middle',
            onShow () {
              this.isTip = true
            },
            onHide () {
              this.isTip = false
            }
          }
          this.$vux.toast.show(option)
        }
      },
      resetUI () {
        const topH = this.$refs.tab.$el.offsetTop + this.$refs.tab.$el.clientHeight
        this.scrollerOption.height = '-' + topH
      },
      // 回彩种选号界面
      goBack () {
        const SID = sessionStorage.getItem('lotteryId')
        if (SID) {
          this.$router.push({ params: { sid: SID } })
        } else {
          this.$router.back()
        }
      },
      // 显示详情
      showDetail (data) {
        console.log(data)
        switch (this.tab) {
          case 1:
            this.orderCode = data.orderCode
            this.isShowDetail = true
            break
          case 2:
            this.traceCode = data.traceCode
            this.agentId = data.agentId
            this.isShowDetail = true
            this.isShowTraceDetail = true
            break
        }
      },
      // 隐藏详情
      hideDetail () {
        // 对当前的选项进行分开操作 tab=1 刷新投注接口 tab=2 刷新追号接口
        switch (this.tab) {
          case 1:
            this.isShowDetail = false
            this.cathexisList = []
            this.cathexis_pageNo = 1
            this.getOrderInfoList()
            break
          case 2:
            this.isShowDetail = false
            this.isShowTraceDetail = false
            this.trackList = []
            this.track_pageNo = 1
            this.getOrderTraceList()
            break
        }
      },
      ...mapActions('common', ['resetCommonState']),
      ...mapMutations('common', ['withdrawal']),
      ...mapMutations('ui', ['set_singleRow'])
    },
    created () {
      let _opt = {
        text: this.LANG.loading,
        transition: ''
      }
      this.$vux.loading.show(_opt)
      this.getOrderInfoList()
      this.set_singleRow(true) // 设置彩期模块显示单行
    },
    mounted () {
      this.resetUI()
    },
    watch: {
      $route (to, from) {
        if (to.name === 'login') this.resetCommonState() // 清空store
        // 离开后销毁组件
        if (from.params.sid === 'orderList') {
          this.$destroy()
        }
      },
      timeSlot (nval) {
        if (this.$refs.scroller) {
          this.$refs.scroller.reset({
            top: 0
          })
        }
        switch (this.tab) {
          case 1:
            this.cathexisList = []
            this.cathexis_pageNo = 1
            this.getOrderInfoList()
            break
          case 2:
            this.trackList = []
            this.track_pageNo = 1
            this.getOrderTraceList()
            break
        }
      }
    },
    beforeDestroy () {
    }
  }
</script>

<style scoped lang='stylus'>
  @import "style/list.styl"
</style>

<style lang='stylus'>
  @import "style/list-reset.styl"
</style>


