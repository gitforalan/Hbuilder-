<template>
  <div class="table-wrap">
    <div>
      <table width="100%">
        <tr>
          <td>倍数 / 模式</td>
          <td>{{ item.buyDouble }}倍 / {{ item.singleMoney | formatF2Y }}元</td>
        </tr>
        <tr>
          <td>彩种</td>
          <td>{{ item.lotteryName }}</td>
        </tr>
        <tr>
          <td>订单编号</td>
          <td>{{ item.orderCode }}</td>
        </tr>
        <tr>
          <td>玩法</td>
          <td>{{ item.playName }}</td>
        </tr>
        <tr>
          <td>注数</td>
          <td>{{ item.buyNumber }}</td>
        </tr>
        <tr>
          <td>下注时间</td>
          <td>{{ item.createTime }}</td>
        </tr>
        <!--<tr>-->
        <!--<td>位置</td>-->
        <!--<td>&#45;&#45;</td>-->
        <!--</tr>-->
        <tr>
          <td>投注金额</td>
          <td>{{ item.orderMoney | formatF2Y }}元 </td>
        </tr>
        <tr>
          <td>期号</td>
          <td>{{ item.issue }}</td>
        </tr>
        <tr>
          <td>开奖号码</td>
          <td>{{ item.openCode }}</td>
        </tr>
        <tr>
          <td>中奖金额</td>
          <td>{{ item.winMoney | formatF2Y }}元</td>
        </tr>
        <tr>
          <td>状态</td>
          <td>{{ item.status | statusFormat }}</td>
        </tr>
        <!--<tr>-->
        <!--<td>备注</td>-->
        <!--<td>&#45;&#45;</td>-->
        <!--</tr>-->
        <tr>
          <td class="align-top">投注号码</td>
          <td class="textarea-border">
            <textarea name="" id="" cols="33" rows="5" readonly>{{ item.buyCodeCase }}</textarea>
          </td>
        </tr>
        <tr>
          <td>一倍奖金</td>
          <td>{{ item.prize * item.singleMoney | formatF2Y | formatF2Y }}元</td>
        </tr>
        <tr v-if="item.status === 0">
          <td></td>
          <td align="left">
            <x-button type="warn" @click.native="withdrawal(item.orderCode, item.issue, item.lotteryId)">撤单</x-button>
          </td>
        </tr>
        <tr v-else>
          <td></td>
          <td align="left">
            <x-button type="warn" @click.native="jump(item)">再来一注</x-button>
          </td>
        </tr>
      </table>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import * as API from 'api/wapi/front/'
  import { mapGetters, mapActions } from 'vuex'

  export default {
    data () {
      return {
        item: {}
      }
    },
    props: {
      orderCode: {
        type: String,
        required: true
      },
      uId: {
        type: String
      }
    },
    filters: {
      // 分转元
      formatF2Y: (val) => (val / 100).toFixed(2),
      // 状态值转换
      statusFormat (n) {
        let name = n
        switch (n) {
          case 0:
            name = '未结算'
            break
          case 1:
            name = '用户撤单'
            break
          case 2:
            name = '追号撤单'
            break
          case 3:
            name = '系统撤单'
            break
          case 4:
            name = '已结算_输'
            break
          case 5:
            name = '已结算_平'
            break
          case 6:
            name = '已结算_赢'
            break
        }
        return name
      }
    },
    computed: {
      ...mapGetters('common', ['issue', 'lotteryId'])
    },
    methods: {
      // 撤销注单
      withdrawal (orderCode, issue, lotteryId) {
        this.getLotteryUserBetCancel(orderCode, issue, lotteryId)
      },
      // 撤单接口方法
      getLotteryUserBetCancel (orderCode, issue, lotteryId) {
        const self = this
        const itemsArr = [
          {
            orderCode: orderCode,
            issue: issue,
            lotteryId: lotteryId
          }
        ]
        const query = {
          items: JSON.stringify(itemsArr)
        }
        API.getLotteryUserBetCancel(query).then(res => {
          let _opt = {
            text: '撤单成功',
            time: 1000,
            onHide () {
              self.$emit('hideDetail')
            }
          }
          this.$vux.toast.show(_opt)
        })
      },
      // 请求注单详情接口
      getOrderDetail () {
        const q = { orderCode: this.orderCode }
        API.getOrderDetail(q).then(res => {
          this.item = []
          this.item = res.data.orderInfo
        })
      },
      // 请求注单接口
      getLotteryUserBet (query) {
        const self = this
        API.getLotteryUserBet(query).then(res => {
          let _opt = {
            text: '下注成功',
            time: 1000,
            onHide () {
              self.$emit('hideDetail')
            }
          }
          this.$vux.toast.show(_opt)
        }).catch(err => {
          this.$vux.alert.show({
            content: err.desc
          })
          setTimeout(() => {
            this.$vux.alert.hide()
          }, 60000)
        })
      },
      jump (item) {
        this.$router.push({ name: 'chunkComp', params: { sid: item.lotteryId } })
      },
      ...mapActions('common', ['validaSendBet'])
    },
    created () {
      this.getOrderDetail()
    }
  }
</script>

<style scoped lang="stylus">
  @import 'detail.styl'
</style>
