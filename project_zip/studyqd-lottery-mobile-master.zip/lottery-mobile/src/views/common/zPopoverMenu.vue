<!--
  -- 封装待细分
  -->
<template>
  <ul :class="arrowClass" v-click-outside="onClickedOutside" v-show="show">
    <li v-if="userInfo.status">余额：<span>{{ userInfo.balance | formatF2Y }}</span> 元</li>
    <li v-else class="logout">未登录</li>
    <li @click.stop="toggle(1)">切换彩种</li>
    <li @click="showOrderRecord">投注记录</li>
    <li @click="showTrend">开奖走势</li>
    <li @click.stop="toggle(2)">奖金说明</li>
    <li @click.stop="showPlayRule">玩法规则</li>
  </ul>
</template>

<script type="text/ecmascript-6">
  import ClickOutside from 'vux/src/directives/click-outside'
  import { mapState, mapMutations } from 'vuex'

  export default {
    name: 'zPopoverMenu',
    props: {
      placement: String,
      show: {
        type: Boolean,
        default: false
      }
    },
    filters: { // 分转元
      formatF2Y: (val) => (val / 100).toFixed(2)
    },
    computed: {
      arrowClass () {
        return {
          'left': this.placement === 'left',
          'right': this.placement === 'right'
        }
      },
      ...mapState('common', {
        userInfo: state => state.userInfo
      }),
      ...mapState('ui', ['showPopoverPage'])
    },
    methods: {
      showOrderRecord () {
        this.$router.push({ params: { sid: 'orderList' } })
      },
      showTrend () {
        this.$router.push({ name: 'trend' })
      },
      showPlayRule () {
        this.$router.push({ name: 'playRule' })
      },
      onClickedOutside () {
        if (this.show) {
          this.$emit('on-hide')
        }
      },
      // 开关切换彩种界面
      toggle (n) {
        this.doPopoverPage(n)
        this.$emit('on-hide')
      },
      ...mapMutations('ui', ['doPopoverPage'])
    },
    directives: {
      ClickOutside
    }
  }

</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"
  ul
    min-width rem(202)
    padding 0 rem(20)
    background $color-white
    border 1px solid $color-red
    border-radius 5px
    box-sizing border-box
    li
      position relative
      font-size rem(28)
      padding rem(25) 0 rem(18)
      color $color-black-c
      text-align center
      border-bottom 1px solid $color-border
      box-sizing border-box
      &.active
        color $color-black-b
      span
        color $color-red
      i
        position absolute
        right 0
        top .7rem
        vertical-align middle
      &:last-child
        border-bottom none
      &.logout
        color $color-gray-a
    &:before, &:after
      content ""
      border-color $color-red transparent
      border-style solid
      display block
      height 0
      font-size 0
      line-height 0
      width 0
      border-width 0 .8rem .8rem
      position absolute
      z-index 12
      top -.8rem
      left 50%
      transform translate3D(-50%, 0, 0)
      zoom 12
    &:after
      border-color: $color-white transparent
      top -.7rem
      left 50%
      transform translate3D(-50%, 0, 0)
      z-index 13

    &.right:before, &.right:after
      left 90%
      transform translate3D(-80%, 0, 0)
    &.right:after
      left 90%
      transform translate3D(-80%, 0, 0)

    &.left:before, &.left:after
      left 5%
      transform translate3D(40%, 0, 0)
    &.left:after
      left 5%
      transform translate3D(40%, 0, 0)
</style>
