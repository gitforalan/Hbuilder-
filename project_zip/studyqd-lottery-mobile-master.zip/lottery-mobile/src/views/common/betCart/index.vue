<template>
  <div class="app-main lm-cart">
    <!-- 头部 -->
    <sub-header
      :title="lotteryName"
      :defalutBack="false"
      @on-click-back="onClickBack"
      @on-click-title="onClickTitle"
      @show-popover-menu="showPopoverMenu"
      type="text"
      ref="header">
    </sub-header>
    <div class="popover-menu">
      <z-popover-menu
        placement="right"
        :show="isShowPopoverMenu"
        @on-hide="onPopoverMenuHide">
      </z-popover-menu>
    </div>

    <!-- 主内容区 -->
    <div class="app-body" ref="appBody">
      <!-- cart区 -->
      <div class="cart" ref="cart">
        <div class="btn-wrap" ref="btnWrap" flex="box:mean cross:center">
          <div class="btn" flex="main:center cross:center" align="center" @click="onClickBack">
            <icon-svg icon-class="jia"></icon-svg>
            <p>自选号码</p>
          </div>
          <div class="btn" flex="main:center cross:center" @click="randomBetList(1)">
            <icon-svg icon-class="jia"></icon-svg>
            <p>机选一注</p>
          </div>
          <div class="btn" flex="main:center cross:center" @click="clear_bet">
            <icon-svg icon-class="shanchu"></icon-svg>
            <p>清空列表</p>
          </div>
        </div>
        <div class="cart-wrap" ref="cartWrap">
          <div v-if="cart" v-for="(item, index) in cart" class="cart-con" flex="main:justify dir:top">
            <div><p class="ellipsis">{{item.buyCodeFront | formatBuyCode(30) }}</p></div>
            <div flex="main:justify">
              <div class="lot-tit-wrap" flex="">
                <div class="btn-delete" flex="cross:center" @click="delOneBet(cart, index)">
                  <icon-svg icon-class="guanbi"></icon-svg>
                </div>
                <div class="lot-tit-con" flex="cross:center">
                  <p>{{item.playTabName + ' ' + item.playName}}</p>
                </div>
              </div>
              <div class="money" flex="cross:center">
                <span>{{ item.buyDouble }}</span>倍
                <span>{{ item.buyCount }}</span>注
                <span>{{ item.singleMoneyTotal | formatP2 }} 元</span>
              </div>
              <div flex="dir:right cross:center" class="btn">
                <div class="jia" @click="doBetTimes(item, true)">
                  <icon-svg icon-class="jia"></icon-svg>
                </div>
                <div class="jian" @click="doBetTimes(item, false)">
                  <icon-svg icon-class="jian"></icon-svg>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 底部 -->
    <footer ref="footer">
      <div class="btn-group" flex="main:justify cross:center">
        <div class="btn btn-chase"
             :class="{disabled: !cart.length}"
             @click="goSmartOrder"
        >
          <span>智能追号</span>
        </div>
        <div class="notes" flex="main:justify">
          <p>共<span>{{ betNumber }}</span>注</p>
          <p>共<span>{{ totalMoney }}</span>元</p>
        </div>
        <div
          class="btn btn-betting"
          :class="{disabled: !cart.length}"
          @click="sendUserBet"
        >
          <span>确认投注</span>
        </div>
      </div>
    </footer>
  </div>
</template>

<script type="text/ecmascript-6">
  import { mapState, mapGetters, mapMutations, mapActions } from 'vuex'
  import * as API from 'api/wapi/front/'

  import SubHeader from '../subHeader'
  import ZPopoverMenu from '../zPopoverMenu'

  export default {
    name: 'betCart',
    data () {
      return {
        isShowPopoverMenu: false
      }
    },
    components: { SubHeader, ZPopoverMenu },
    filters: {
      formatBuyCode (code, maxLen) {
        if (code.length > maxLen) {
          return code.slice(0, maxLen) + '...'
        } else {
          return code
        }
      },
      formatP2: val => val.toFixed(2)
    },
    computed: {
      betNumber () {
        return this.cart.map(item => item.buyCount).reduce((a, b) => a + b, 0)
      },
      totalMoney () {
        const _smt = this.cart.map(item => parseFloat(item.singleMoneyTotal)).reduce((a, b) => a + b, 0)
        return _smt.toFixed(2)
      },
      ...mapState('common', {
        userInfo: state => state.userInfo,
        cart: state => state.betList,
        issue: state => state.issue,
        winningToStop: state => state.winningToStop
      }),
      ...mapGetters('common', ['lotteryId', 'lotteryName', 'willSubmitData'])
    },
    methods: {
      onClickTitle () {
        this.showPlayTabList = !this.showPlayTabList
      },
      onClickBack () {
        // this.$router.back()
        this.open_cart(false)
      },
      // 增减倍数
      doBetTimes (item, flag) {
        let temp = 0
        if (flag) {
          item.buyDouble++
          temp += item.tempSingleMoneyTotal
        } else {
          item.buyDouble--
          if (item.buyDouble < 1) {
            item.buyDouble = 1
          } else {
            temp -= item.tempSingleMoneyTotal
          }
        }
        item.singleMoneyTotal += temp
      },
      // 删除一行
      delOneBet (arr, index) {
        arr.splice(index, 1)
      },
      // 进智能追号
      goSmartOrder () {
        if (!this.cart.length) return
        this.$router.push({ params: { sid: 'smartOrder' } })
      },
      // 请求注单接口
      getLotteryUserBet (query) {
        const self = this
        API.getLotteryUserBet(query).then(res => {
          this.clear_bet() // 清空购票车
          this.open_cart(false) // 关闭购票车 ver1.2.0
          this.$vux.toast.show({
            text: '下注成功',
            time: 1000,
            onHide () {
              self.$router.push({ params: { sid: query.lotteryId } })
            }
          })
        }).catch(err => {
          this.$vux.alert.show({
            content: err.desc
          })
          setTimeout(() => {
            this.$vux.alert.hide()
          }, 60000)
        })
      },
      sendUserBet () { // 组装数据
        if (!this.cart.length) return
        this.validaSendBet().then(() => {
          const q = {
            lotteryId: this.lotteryId,
            issue: this.issue,
            winningToStop: this.winningToStop,
            betList: JSON.stringify(this.willSubmitData)
            // traceList
          }
          this.getLotteryUserBet(q)
        }).catch(err => {
          console.log(err)
        })
      },
      showPopoverMenu () {
        this.isShowPopoverMenu = !this.isShowPopoverMenu
      },
      onPopoverMenuHide () {
        this.delayExec(() => {
          this.isShowPopoverMenu = false
        })
      },
      hidePlayTabList () {
        this.delayExec(() => {
          this.showPlayTabList = false
        })
      },
      resetUIHeight () { // 计算内容区域高度、投注列表高度
        this.delayExec(() => {
          const wH = window.innerHeight
          const wHeader = this.$refs.header.$el.offsetHeight
          const wFooter = this.$refs.footer.offsetHeight
          const btnWrapHeight = this.$refs.btnWrap.offsetHeight
          const cartTop = this.$refs.cart.offsetTop - wHeader
          this.$refs.appBody.style.height = wH - (wHeader + wFooter) + 'px'
          this.$refs.cartWrap.style.height = wH - (wHeader + wFooter + btnWrapHeight + cartTop) + 'px'
        })
      },
      delayExec (fn) {
        setTimeout(fn, 20)
      },
      ...mapMutations('common', ['randomBetList', 'clear_bet', 'open_cart']),
      ...mapMutations('ui', ['set_singleRow']),
      ...mapActions('common', ['validaSendBet'])
    },
    created () {
      this.set_singleRow(true) // 设置彩期模块单行显示
      this.resetUIHeight()
      console.log('betCart ...')
    }
  }
</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .lm-cart
    background $color-white
    .popover-menu
      position fixed
      top 4rem
      right .3rem
      z-index 99
    .cart
      margin-top rem(44)
      .btn-wrap
        width 100%
        height rem(120)
        padding .5rem
        background $color-el-bg
        box-shadow 2px 2px 7px 2px $color-gray-a
        border-top 1px solid $color-border
        box-sizing border-box
        .lott-icon
          width 1.7rem
        .btn
          width rem(223)
          line-height rem(65)
          margin-left rem(26)
          background $color-red
          color $color-white
          border-radius 5px
          font-size rem(32)
          p
            padding-top .13rem
          &:nth-child(1)
            margin-left 0

      .cart-wrap
        width 100%
        overflow-y auto
        font-size $size-medium-x
        padding-top .5rem
        .cart-con
          position relative
          width 100%
          margin 0 auto
          padding .8rem
          border-bottom 1px dotted $color-border
          box-sizing border-box
          .btn
            .jian, .jia
              width rem(45)
              height rem(45)
              line-height rem(45)
              text-align center
              border 1px solid $color-border
              border-radius 4px
            .jia
              margin-left rem(26)
            .lott-icon
              display inline
              color $color-red
          div
            p.ellipsis
              width rem(490)
              margin-left rem(46)
              padding-bottom rem(10)
              color $color-red
              font-size rem(28)
        .btn-delete
          i
            position absolute
            top 1.7rem
            width 1.7rem
        .money
          font-size rem(26)
          span
            color $color-red
            &:nth-child(3)
              display inline-block
              margin-left rem(20)
        .lot-tit-wrap
          .lot-tit-con
            padding-left rem(25)
            p:first-child
              font-size rem(28)
              color #5c5c5c
              padding-bottom rem(10)
              margin-left rem(20)
          .btn-delete
            i
              color $color-gray-a
              width rem(30)
              height rem(30)

    footer
      position fixed
      left 0
      right 0
      bottom 0
      width 100%
      color $color-black
      font-size $size-medium
      background $color-el-bg
      border-top 1px solid $color-border
      height $BottomBarHeight
      .btn-group
        box-sizing border-box
        padding .5rem rem(29)
        .btn
          width rem(180)
          height rem(70)
          line-height rem(70)
          background $color-red
          border-radius 5px
          color $color-white
          font-size rem(36)
          text-align center
          &.btn-betting
            width rem(200)
            height rem(70)
          &.disabled
            background $color-gray-a
      .notes
        background none
        font-size rem(28)
        color $color-black-c
        p
          span
            color $color-red
          &:nth-child(1)
            margin-right rem(40)
</style>
