<!-- Created By fx on 2017/9/11.
  -- 智能追号
  -->
<template>
  <div class="app-main smart-order">
    <x-header :title="title" class="is-fixed" resetstyle></x-header>
    <!-- 彩期模块 -->
    <current-info :typeId="lotteryTypeId" ref="currentInfo"></current-info>
    <div class="app-body">
      <issue-popover :itemsData="selectObj" :show="showPopover" @on-hide="onPopoverHide" class="popover"
                     ref="popover"></issue-popover>
      <!-- 弹出层 -->
      <div v-if="showPopover" class="weui-mask_transparent"></div>
      <div class="setting">
        <div class="tab">
          <tab :animate="false" :line-width="1" class="active">
            <tab-item
              active-class="active"
              v-for="(item, index) in tabs"
              :selected="currentTabIndex === index"
              :key="index"
              @on-item-click="changeTab"
            >
              <span v-if="index === currentTabIndex" class="selected-icon">
                <icon-svg icon-class="duihao"></icon-svg>
              </span>
              <span>{{ item }}</span>
            </tab-item>
          </tab>
        </div>
        <div class="tab-content-title" flex="box:mean" align="center">
          <span>追 {{ selectedIssues }} 期</span>
          <span>累计金额 {{ totalTraceMoney | formatF2Y }}</span>
        </div>
        <!--同倍追号start-->
        <div v-if="isTabSame" class="tab-content">
          <div flex="box:mean">
            <div></div>
            <div>起始倍数</div>
            <div>期数</div>
          </div>
          <div class="input-group" flex="box:mean">
            <div>
              <p flex="cross:center main:justify" ref="selIssue" @click="onSelIssue">
                <span>{{ selectIssue }}期</span>
                <icon-svg class="icon" icon-class="down"></icon-svg>
              </p>
            </div>
            <!-- 起始倍数 -->
            <div><input type="text" v-model="startTimes" @click="$event.target.select()"></div>
            <!-- 期数 -->
            <div><input type="text" v-model="inputIssue" @click="$event.target.select()"></div>
          </div>
        </div>
        <!--同倍追号end-->
        <!--翻倍追号start-->
        <div v-else class="tab-content">
          <div flex="box:mean">
            <div></div>
            <div>每隔</div>
            <div>倍X</div>
            <div>期数</div>
            <div>起始倍数</div>
          </div>
          <div class="input-group" flex="box:mean">
            <div>
              <p flex="cross:center main:justify" ref="selIssue" @click="onSelIssue">
                <span>{{ inputIssue }}期</span>
                <icon-svg class="icon" icon-class="down"></icon-svg>
              </p>
            </div>
            <!-- 每隔 -->
            <div><input type="text" v-model="interval" @click="$event.target.select()"></div>
            <!-- 倍x -->
            <div><input type="text" v-model="intervalTimes" @click="$event.target.select()"></div>
            <!-- 期数 -->
            <div><input type="text" v-model="inputIssue" @click="$event.target.select()"></div>
            <!-- 起始倍数 -->
            <div><input type="text" v-model="startTimes" @click="$event.target.select()"></div>
          </div>
        </div>
        <!--翻倍追号end-->

        <div class="btn-generate" @click="generateIssue">
          <x-button type="warn">生成</x-button>
        </div>
        <div flex="box:mean" align="center">
          <div class="stop">
            <check-icon :value.sync="intervalToStop" type="plain" default-item-class="stop">官方跳开即停</check-icon>
          </div>
          <div class="stop">
            <check-icon :value.sync="winningToStop" type="plain">中奖后停止追号</check-icon>
          </div>
        </div>
      </div>

      <!-- scroller -->
      <div class="scroller" ref="scroller">
        <table v-if="issueList.length" style="width: 100%">
          <tr
            v-for="(item,index) in issueList"
            :key="index"
            :class="{selected:item.isChecked}"
            @click="doIssue(item)">
            <td>
              <icon-svg v-if="item.isChecked" icon-class="correct"></icon-svg>
            </td>
            <td>{{ item.issue }}期</td>
            <td>
              <!--<input v-if="false" type="text"-->
              <!--v-model="item.betTimes"-->
              <!--@click="$event.target.select()"-->
              <!--:disabled="!item.isChecked"-->
              <!--@input="doInputChange(idx,$event)">-->
              <span>{{ item.betTimes }}</span> 倍
            </td>
            <td>
              <icon-svg icon-class="jia" class="icon" @click.native.stop="doBetTimes(item, true)"></icon-svg>
              <icon-svg icon-class="jian" class="icon" @click.native.stop="doBetTimes(item, false)"></icon-svg>
            </td>
            <td>{{ singleTraceMoney * item.betTimes | formatF2Y }}元</td>
          </tr>
        </table>
        <div v-else>
          <br><br>
          <p align="center">{{ emptyTip || todayOver }}</p>
        </div>
        <!--</scroller>-->
      </div>
      <!-- // scroller -->

      <footer>
        <x-button type="warn" @click.native="sendUserBet">确认追号</x-button>
      </footer>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import * as API from 'api/wapi/front/'
  import { mapState, mapGetters, mapMutations, mapActions } from 'vuex'
  import IssuePopover from './issuePopover'

  export default {
    name: 'smartOrder',
    data () {
      return {
        title: '智能追号',
        tabs: ['同倍追号', '翻倍追号'],
        emptyTip: '列表为空',
        todayOver: '今日可追期号为 0 期',
        showPopover: false, // popover
        currentTabIndex: 0, // 当前tab位置
        issueList: [], // 剩余彩期
        selectedIssueList: [], // 已选择彩期
        intervalToStop: true, // 官方跳开即停
        winningToStop: true, // 中奖后停止
        selectIssue: 10, // 默认选择的期数
        startTimes: 1, // 起始倍数
        interval: 1, // 间隔数
        intervalTimes: 2, // 间隔倍数
        inputIssue: 10, // 输入追号期数
        totalTraceMoney: 0 // 追号总金额
      }
    },
    components: { IssuePopover },
    filters: { // 分转元
      formatF2Y: (val) => (val / 100).toFixed(2)
    },
    computed: {
      isTabSame () { // 是不是同倍追号
        return this.currentTabIndex === 0
      },
      // 追号基础金额
      singleTraceMoney () {
        return this.totalMoney
      },
      // 总期数
      totalIssues () {
        return this.issueList.length
      },
      // 选择的期数
      selectedIssues () {
        return this.selectedIssueList.length
      },
      selectObj () {
        return {
          options: [['5期', 5], ['10期', 10], ['15期', 15], ['25期', 25], [`全${this.totalIssues}期`, this.totalIssues]]
        }
      },
      ...mapState('common', [
        'lotteryTypeId',
        'lotteryId',
        'issue'
      ]),
      ...mapGetters('common', ['totalMoney', 'willSubmitData'])
    },
    methods: {
      onSelIssue () {
        this.showPopover = !this.showPopover
      },
      onPopoverHide (n) {
        if (typeof n === 'number') { // 拿到需要的期数
          this.selectIssue = n
        }
        this.delayExec(() => {
          this.showPopover = false
        })
      },
      delayExec (fn) {
        setTimeout(fn, 20)
      },
      changeTab (index) { // 切换同倍 翻倍 tab
        this.currentTabIndex = index
      },
      // 拿数据
      LotteryIssueList () {
        const q = {
          lotteryId: this.lotteryId,
          issue: this.issue
        }
        if (q.lotteryId === -1 || q.issue === '') return
        this.$vux.loading.show()
        API.getLotteryIssueList(q).then(res => {
          const _issueList = res.data.issueList
          this.setLotteryIssueList(_issueList) // 打上标记
          if (_issueList.length === 0) this.emptyTip = '' // 无期号显示
          setTimeout(() => {
            this.$vux.loading.hide()
          }, 200)
        })
      },
      // 标记
      setLotteryIssueList (data) {
        let willAddData = {
          isChecked: false, // 界面初始是否选中
          betTimes: 0 // 界面初始倍数
        }
        data.forEach((item, index) => {
          if (index === 0) item.issue = parseInt(item.issue, 10) + '(当前)'
          item = Object.assign(item, willAddData)
        })
        this.issueList = data
      },
      // 选择期数
      doSelectIssue (data, issueNum = this.selectIssue) {
        data.forEach((j, idx) => {
          if (idx < issueNum) {
            j.isChecked = true
          } else {
            j.isChecked = false
          }
        })
      },
      // 更新彩期倍数
      updateBetTimes () {
        let type = this.currentTabIndex
        if (type === 0) { // 同倍追号
          this.issueList.forEach(i => {
            if (i.isChecked) i.betTimes = this.startTimes
            else i.betTimes = 0
          })
        } else { // 翻倍追号
          let times = [] // 处理各种翻倍
          let interval = this.interval
          let intervalTimes = this.intervalTimes
          let maxLen = this.totalIssues
          for (let j = 0, p = 0; j < maxLen; j += interval, p++) {
            for (let k = 0; k < interval; k++) {
              times[j + k] = Math.pow(intervalTimes, p) * this.startTimes // 加上起始倍数
            }
          }
          this.issueList.forEach((i, idx) => {
            if (i.isChecked) i.betTimes = times[idx]
            else i.betTimes = 0
          })
        }
      },
      // 生成
      generateIssue () {
        this.doSelectIssue(this.issueList, this.inputIssue) // 先选择
        this.updateBetTimes() // 再更新倍数
        this.setSelectedIssueList() // 设置已选择的彩期
      },
      doIssue (item) { // 是否选择行
        item.isChecked = !item.isChecked
        item.betTimes = item.isChecked ? 1 : 0
        this.setSelectedIssueList()
      },
      doBetTimes (item, flag) { // 增减倍数
        if (flag) {
          item.betTimes++
          !item.isChecked && (item.isChecked = true)
        } else {
          item.betTimes--
          if (item.betTimes <= 0) {
            item.betTimes = 0
            item.isChecked && (item.isChecked = false)
          }
        }
        this.setSelectedIssueList()
      },
      // 已选择的彩期
      setSelectedIssueList () {
        // this.updateBetTimes() // 更新倍数
        this.selectedIssueList = JSON.parse(JSON.stringify(this.issueList.filter(i => i.isChecked === true)))
        this.totalTraceMoney = this.selectedIssueList.map(i => i.betTimes * this.singleTraceMoney).reduce((a, b) => a + b, 0)
        // this.willTraceData()
      },
      // 追号数据
      willTraceData () {
        const data = this.selectedIssueList.map(i => {
          return {
            issue: parseInt(i.issue, 10).toString(),
            times: i.betTimes
          }
        })
        this.update_tracelist(data) // 可删
        return data
      },
      // 请求注单接口
      getLotteryUserBet (query) {
        const self = this
        API.getLotteryUserBet(query).then(res => {
          this.clear_bet() // 清空购票车
          this.open_cart(false) // 关闭购票车界面
          this.$vux.toast.show({
            text: '下注成功',
            time: 1000,
            onHide () {
              self.$router.push({ params: { sid: query.lotteryId } })
            }
          })
        })
      },
      // 组装数据
      sendUserBet () {
        const traceList = this.willTraceData()
        if (traceList.length === 0) {
          alert('至少选择一期追号！')
          return
        }
        this.validaSendBet().then(() => {
          const q = {
            lotteryId: this.lotteryId,
            issue: this.issue,
            winningToStop: this.winningToStop,
            betList: JSON.stringify(this.willSubmitData),
            traceList: JSON.stringify(traceList)
          }
          this.getLotteryUserBet(q)
        }).catch(err => {
          console.log(err)
        })
      },
      resetUI () { // set scroller view
        this.$nextTick(() => {
          // popover
          const selIssuePos = {
            x: this.$refs.selIssue.offsetLeft,
            y: this.$refs.selIssue.offsetTop + this.$refs.selIssue.clientHeight
          }
          const popoverX = selIssuePos.x - 3 // rem(126) - rem(120) >> 1
          const popoverY = selIssuePos.y + 10
          this.$refs.popover.$el.style.left = popoverX + 'px'
          this.$refs.popover.$el.style.top = popoverY + 'px'
          // scroller
          const scroller = this.$refs.scroller
          const sHeight = document.documentElement.clientHeight - scroller.offsetTop
          scroller.style.height = (sHeight - 1) + 'px'
        })
      },
      ...mapMutations('common', ['update_wts', 'update_tracelist', 'clear_bet', 'open_cart']),
      ...mapMutations('ui', ['set_singleRow']),
      ...mapActions('common', ['validaSendBet'])
    },
    created () {
      this.LotteryIssueList()
      this.set_singleRow(true) // 设置彩期模块显示单行
      this.resetUI()
      console.log('smartBet')
    },
    watch: {
      $route (to, from) {
        // 离开后销毁组件
        if (from.params.sid === 'smartOrder') {
          this.$destroy()
        }
      },
      // 监听选择的期号
      selectIssue (n) {
        this.inputIssue = n
      },
      // 监听输入追号期数
      inputIssue (nVal) {
        let val = nVal.toString().trim().replace(/[^0-9]/g, '') * 1
        if (val < 1) {
          this.inputIssue = 10
        } else if (val > this.totalIssues) {
          this.inputIssue = this.totalIssues
        } else {
          this.inputIssue = val
        }
      },
      // 监听起始倍数
      startTimes (nVal) {
        let val = nVal.toString().trim().replace(/[^0-9]/g, '') * 1
        if (val === 0) val = 1
        this.startTimes = val
        this.selectedIssueList.forEach(i => {
          i.betTimes = this.startTimes
        })
      },
      // 监听翻倍的间隔数
      interval (nVal) {
        let val = nVal.toString().trim().replace(/[^0-9]/g, '') * 1
        if (val === 0) val = 1
        this.interval = val
      },
      // 监听间隔倍数
      intervalTimes (nVal) {
        let val = nVal.toString().trim().replace(/[^0-9]/g, '') * 1
        if (val === 0) val = 1
        this.intervalTimes = val
      },
      // 监听中奖后停止追号
      winningToStop (nVal) {
        if (nVal) { // 停
          this.update_wts(1)
        } else { // 不停
          this.update_wts(0)
        }
      }
    }
  }
</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .smart-order
    background $color-white
    .app-body
      padding-bottom 0
      .setting
        padding-bottom .5rem
        .tab
          margin-top rem(44)
          .active
            setBottomLine()
          .vux-tab
            height rem(70)
            padding-top .5rem
            line-height rem(70)
            font-size rem(30)
            color $color-black-c
            &:after
              border-color #ff5151
            .vux-tab-item.vux-tab-selected
              height rem(70)
              margin-left rem(33)
              margin-right rem(33)
              color $color-red
              background $color-el-bg
              border 1px solid #ff5151
              border-bottom none
              &:after
                border 3px solid $color-el-bg
                height 0
                bottom -1px
                opacity 1
                z-index 1
            .vux-tab-item
              background: none
              line-height rem(70)
              border-top-left-radius 3px
              border-top-right-radius 3px
              font-size rem(30)
              span:nth-child(2)
                vertical-align middle
              .lott-icon
                vertical-align middle
        .tab-content-title
          padding rem(17) rem(17) rem(24)
          font-size rem(26)
          color $color-black-c
        .tab-content
          width 100%
          padding .5rem
          box-sizing border-box
          color $color-gray
          div:nth-child(1)
            div
              margin 0 .5rem
          div:nth-child(2)
            div
              margin .5rem
              border-radius 3px
              height rem(75)
              box-sizing border-box
              input
                width rem(120)
                height 100%
                padding 3px
                border 1px solid $color-border
                border-radius 3px
                background transparent
                box-sizing border-box
                text-align center
                color $color-gray
                -webkit-appearance none
              &:first-child
                p
                  border 1px solid $color-border
                  padding 3px
                  width rem(120)
                  height rem(75)
                  font-size rem(22)
                  border-radius 3px
                  box-sizing border-box
                  span
                    white-space nowrap
                  .icon
                    vertical-align middle
                    margin-left 5px
                    width rem(35)
                    height rem(35)
        /*
      .count, .double
        margin 0 auto
        &:last-child
          margin-left none
      .double
        font-size rem(26)
        color $color-black-c
        .first
          width 6.15rem
          margin-right .5rem
          */
        .btn-generate
          margin 0 auto
          button
            font-size rem(30)
            margin-top rem(20)
            margin-bottom rem(20)
            width rem(704)
            height rem(72)
            line-height rem(72)
            background $color-red

      .scroller
        width 100%
        background $color-el-bg
        padding 0 0 1rem
        margin-bottom 3.5rem
        overflow-y auto
        color $color-black-b
        font-size rem(25)
        table
          text-align center
          width 100%
          tr
            height rem(80)
            border-bottom 1px solid $color-border
            td
              word-break: break-all
              vertical-align middle
              &:nth-child(1)
                width rem(56)
              &:nth-child(2)
                text-align left
              &:nth-child(3)
                min-width rem(80)
                max-width rem(160)
                text-align right
                span
                  color $color-red
              &:last-child
                text-align right
                padding-right .5rem
                min-width rem(128)
                max-width rem(160)
                box-sizing border-box
              input
                width rem(50)
                text-align center
                margin-right .3rem
        .icon
          color $color-red
          width rem(45)
          height rem(35)
          extend-click()
          padding rem(5) 0
          border 1px solid $color-border
          background $color-white
          border-radius 3px
          &:active
            background $color-gray-e
    footer
      position fixed
      width 100%
      bottom 0
      background $color-el-bg
      button
        font-size rem(30)
        width rem(704)
        height rem(80)
        line-height rem(80)
        margin-top .5rem
        margin-bottom .5rem
        background $color-red

    .popover
      position absolute
      width rem(126)
      z-index 1001
</style>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .smart-order
    .weui-cell:before
      border-top none
    .weui-select
      font-size $size-small
      color $color-black-c
    .weui-cells
      &:before, &:after
        border-top none
        border-bottom none
    .weui-cell_select .weui-cell__bd:after
      transform rotate(135deg) translateY(3px)
    .weui-cell_select .weui-cell__bd
      width 6rem
    .vux-check-icon > span
      color $color-black-c
    .vux-check-icon
      .weui-icon-success:before,
      .weui-icon-success-circle:before
        color $color-red
</style>
