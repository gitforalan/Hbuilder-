<!-- Created By fx on 2017/9/8. -->
<template>
  <x-header
    :left-options="{preventGoBack:true, showBack: showBack, backText: ''}"
    :right-options="{showMore: showMore}"
    @on-click-title="onClickTitle"
    @on-click-back="onClickBack"
    @on-click-more="onClickMore"
    class="is-fixed" resetstyle>
    <div v-if="!type" class="x-title" flex="main:center">
      <p flex-box="0" flex="dir:top main:center cross:center">
        <span>玩</span>
        <span>法</span>
      </p>
      <p flex="cross:center main:right">
        <span v-if="title">{{ title }}</span>
        <loading v-else></loading>
        <icon-svg icon-class="down" :class="{'icon-rotate': rotate}"></icon-svg>
      </p>
    </div>
    <p v-else>{{ title }}</p>
  </x-header>
</template>

<script type="text/ecmascript-6">
  import { mapState } from 'vuex'

  export default {
    name: 'subHeader',
    data () {
      return {
        showDialogStyle: true
      }
    },
    props: {
      type: String,
      title: String,
      // 传false 屏蔽路由默认back()
      defalutBack: {
        type: Boolean,
        default: true
      },
      showMore: {
        type: Boolean,
        default: true
      },
      showBack: {
        type: Boolean,
        default: true
      }
    },
    computed: {
      ...mapState({
        rotate: state => state.ui.icon_isRotate
      })
    },
    methods: {
      onClickBack () {
        this.$emit('on-click-back')
        this.defalutBack && this.goBack()
      },
      onClickTitle () {
        this.$emit('on-click-title')
      },
      onClickMore () {
        this.$emit('show-popover-menu')
      },
      goBack () {
        this.$router.back()
      }
    }
  }
</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .x-title
    margin-top rem(15)
    box-sizing border-box
    p:nth-child(1)
      height rem(60)
      font-size rem(24)
      line-height rem(60)
      margin-right .3rem
      span
        height 1.1rem
        line-height 1rem
    p:nth-child(2)
      position: relative
      min-width: 5rem
      box-sizing: border-box
      height: pw = rem(60)
      line-height: rem(60)
      border: 1px solid #fff
      border-radius: 2px
      font-size rem(30)
      span
        margin-left .6rem
        font-size $size-medium
        height rem(60)
        line-height rem(60)
      i
        transition transform .5s
        transform translateY(-2%) scale(0.6)
        &.icon-rotate
          transform translateY(4%) scale(0.6) rotate(180deg)


</style>
