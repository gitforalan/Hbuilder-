<!-- Created By fx on 2017/10/31.
  -- 玩法规则
  -->
<template>
  <div class="app-main play-rule">
    <!-- 头部 -->
    <sub-header :title="title" :showMore="false" type="text"
                ref="header"></sub-header>
    <!-- 主内容区 -->
    <div class="app-body" ref="appBody">
      <!-- 选择区 -->
      <div class="set-area" flex="main:center cross:center">
        <div class="set-con">
          <div class="lotteryMenu">
            <selector :options="lotteryList" v-model="defaultValue" class="select" @on-change="onChange" resetstyle>
            </selector>
          </div>
          <icon-svg icon-class="bg-down" class="icon_down"></icon-svg>
        </div>
        <div class="set-con">
          <div class="lotteryMenu">
            <selector :options="lotteryList" v-model="defaultValue" class="select" @on-change="onChange" resetstyle>
            </selector>
          </div>
          <icon-svg icon-class="bg-down" class="icon_down"></icon-svg>
        </div>
      </div>
      <div class="rule"> {{ title }} </div>
      <!--官方玩法 信用玩法 内容切换-->
      <div class="rule-nav" flex="box:mean">
        <div class="active">官方玩法</div>
        <div>信用玩法</div>
      </div>
      <div class="rule-content" ref="ruleContent">
        <div class="way-item-text" id="test1">
          <p class="f-b">游戏规则</p>
          <p>一、玩法类型及承销</p>
          <p>1.时时彩是一种在线即开型彩票玩法，由市福利彩票发行管理中心负责承销。</p>
          <p>二、开奖与购买方式</p>
          <p class="playway-show" v-if="lotteryId === 1001">
            1. 本站重庆时时彩，每天10:00第一期开奖，早10:00-22:00十分钟一期,22:00-1:55五分钟一期，每天120期。</p>
          <p class="playway-show" v-if="lotteryId === 1003">
            1. 本站新疆时时彩，每天10:00第一期开奖，10分钟1期，23:40最后一期，共83期。
          </p>
          <p class="playway-show" v-if="lotteryId === 1004">
            1. 本站天津时时彩，每天09:00第一期开奖，23:00最后一期开奖，每10分钟开奖一次,全天84期。
          </p>
          <p class="playway-show" v-if="lotteryId === 1005">
            1. 本站分分时时彩游戏每天进行,购买者可在对其选定的投注号码进行投注，返点越高则投注赔率越低。<br/>
          </p>
          <p class="playway-show" v-if="lotteryId === 1021">
            1. 本站QQ分分彩游戏每天进行,购买者可在对其选定的投注号码进行投注，返点越高则投注赔率越低。<br/>
          </p>
          <p class="playway-show" v-if="lotteryId === 1022">
            1. 本站北京5分彩游戏每天进行,购买者可在对其选定的投注号码进行投注，返点越高则投注赔率越低。<br/>
          </p>
          <p class="playway-show" v-if="lotteryId === 1023">
            1. 本站斯洛伐克5分彩游戏每天进行,购买者可在对其选定的投注号码进行投注，返点越高则投注赔率越低。<br/>
          </p>
          <p class="playway-show" v-if="lotteryId === 1024">
            1. 本站加拿大3.5分彩游戏每天进行,购买者可在对其选定的投注号码进行投注，返点越高则投注赔率越低。<br/>
          </p>
          <p>
            2. 购买者可选择机选号码投注、自选号码投注。机选号码投注是指由投注机随机产生投注号码进行投注，自选号码投注是指将购买者选定的号码输入投注机进行投注。<br/> 3. 购买者还可进行追号投注。追号投注是指将一注或一组号码进行两期或两期以上的投注。追号可分为连续追号和间隔追号，连续追号指追号的期数是连续的，间隔追号指追号的期数不连续。
            <br/> 4. 如果用户投注成功后，若因销售终端故障、通讯线路故障和投注站信用额度受限等原因造成当期无法开奖的，应退还购买者投注金额。
          </p>
          <p>三、兑奖</p>
          <p>1. 返奖：无论大小奖均返还至用户在本站的账户中，一旦用户中奖，系统将自动返还中奖金额。可继续投注或提款，永无弃奖。</p>
        </div><br><br>
        <div class="way-item-text" id="test2">
          <p class="f-b">官方玩法</p>
          <table width="100%" class="s-table" cellspacing="1" border="0" cellpadding="0">
            <thead>
            <tr align="center">
              <th width="10%">玩法组</th>
              <th width="12%">玩法</th>
              <th width="40%">玩法说明</th>
            </tr>
            </thead>
            <tbody>
            <tr align="center">
              <td rowspan="2">五星直选</td>
              <td>直选（复式）</td>
              <td>从万位、千位、百位、十位、个位中选择一个5位数号码组成一注，所选号码与开奖号码全部相同，且顺序一致，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>直选（单式）</td>
              <td>手动输入一个5位数号码组成一注，所选号码的万位、千位、百位、十位、个位与开奖号码相同，且顺序一致，即为中奖。</td>

            </tr>
            <tr align="center">
              <td rowspan="6">五星组选</td>
              <td>五星组选120</td>
              <td>从0-9中任意选择5个号码组成一注，所选号码与开奖号码的万位、千位、百位、十位、个位相同，顺序不限，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>五星组选60</td>
              <td>选择1个二重号码和3个单号号码组成一注，所选的单号号码与开奖号码相同，且所选二重号码在开奖号码中出现了2次，顺序不限，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>五星组选30</td>
              <td>选择2个二重号和1个单号号码组成一注，所选的单号号码与开奖号码相同，且所选的2个二重号码分别在开奖号码中出现了2次，顺序不限，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>五星组选20</td>
              <td>选择1个三重号码和2个单号号码组成一注，所选的单号号码与开奖号码相同，且所选三重号码在开奖号码中出现了3次，顺序不限，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>五星组选10</td>
              <td>选择1个三重号码和1个二重号码，所选三重号码在开奖号码中出现3次，并且所选二重号码在开奖号码中出现了2次，顺序不限，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>五星组选5</td>
              <td>选择1个四重号码和1个单号号码组成一注，所选的单号号码与开奖号码相同，且所选四重号码在开奖号码中出现了4次，顺序不限，即为中奖。</td>

            </tr>
            <tr align="center">
              <td rowspan="2">前四直选</td>
              <td>直选（复式）</td>
              <td>从万位、千位、百位、十位中选择一个4位数号码组成一注，所选号码与开奖号码相同，且顺序一致，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>直选 （单式）</td>
              <td>手动输入一个4位数号码组成一注，所选号码的万位、千位、百位、十位与开奖号码相同，且顺序一致，即为中奖。</td>

            </tr>
            <tr align="center">
              <td rowspan="2">后四直选</td>
              <td>直选（复式）</td>
              <td>从千位、百位、十位、个位中选择一个4位数号码组成一注，所选号码与开奖号码相同，且顺序一致，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>直选（单式）</td>
              <td>手动输入一个4位数号码组成一注，所选号码的千位、百位、十位、个位与开奖号码相同，且顺序一致，即为中奖。</td>

            </tr>
            <tr align="center">
              <td rowspan="3">前三直选</td>
              <td>直选复式</td>
              <td>从万位、千位、百位中选择一个3位数号码组成一注，所选号码与开奖号码前3位相同，且顺序一致，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>直选单式</td>
              <td>手动输入一个3位数号码组成一注，所选号码与开奖号码的万位、千位、百位相同，且顺序一致，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>直选和值</td>
              <td>所选数值等于开奖号码万位、千位、百位三个数字相加之和，即为中奖。</td>

            </tr>
            <tr align="center">
              <td rowspan="3">中三直选</td>
              <td>直选复式</td>
              <td>从千位、百位、十位中选择一个3位数号码组成一注，所选号码与开奖号码前3位相同，且顺序一致，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>直选单式</td>
              <td>手动输入一个3位数号码组成一注，所选号码与开奖号码的千位、百位、十位相同，且顺序一致，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>直选和值</td>
              <td>所选数值等于开奖号码千位、百位、十位三个数字相加之和，即为中奖。</td>

            </tr>
            <tr align="center">
              <td rowspan="3">后三直选</td>
              <td>直选复式</td>
              <td>从百位、十位、个位中选择一个3位数号码组成一注，所选号码与开奖号码后3位相同，且顺序一致，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>直选单式</td>
              <td>手动输入一个3位数号码组成一注，所选号码与开奖号码的百位、十位、个位相同，且顺序一致，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>直选和值</td>
              <td>所选数值等于开奖号码的百位、十位、个位三个数字相加之和，即为中奖。</td>

            </tr>
            <tr align="center">
              <td rowspan="5">前三组选</td>
              <td>组三</td>
              <td>从0-9中任意选择2个号码组成两注，所选号码与开奖号码的万位、千位、百位相同，且顺序不限，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>组六</td>
              <td>从0-9中任意选择3个号码组成一注，所选号码与开奖号码的万位、千位、百位相同，顺序不限，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>组选和值</td>
              <td>所选数值等于开奖号码万位、千位、百位三个数字相加之和，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>混合组选</td>
              <td>手动输入购买号码，3个数字为一注，开奖号码的万位、千位、百位符合前三的组三或组六均为中奖。</td>

            </tr>
            <tr align="center">
              <td>组选包胆</td>
              <td>从0-9中任意选择一个包胆号码，开奖号码的万位、千位、百位中任意一位与所选包胆号码相同（不含豹子号）即为中奖。</td>

            </tr>
            <tr align="center">
              <td rowspan="5">中三组选</td>
              <td>组三</td>
              <td>从0-9中任意选择2个号码组成两注，所选号码与开奖号码的千位、百位、十位相同，且顺序不限，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>组六</td>
              <td>从0-9中任意选择3个号码组成一注，所选号码与开奖号码的千位、百位、十位相同，顺序不限，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>组选和值</td>
              <td>所选数值等于开奖号码千位、百位、十位三个数字相加之和，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>混合组选</td>
              <td>键盘手动输入购买号码，3个数字为一注，开奖号码的千位、百位、十位符合中三的组三或组六均为中奖。</td>

            </tr>
            <tr align="center">
              <td>组选包胆</td>
              <td>从0-9中任意选择一个包胆号码，开奖号码的千位、百位、十位中任意一位与所选包胆号码相同（不含豹子号），即为中奖。</td>

            </tr>
            <tr align="center">
              <td rowspan="5">后三组选</td>
              <td>组三</td>
              <td>从0-9中任意选择2个号码组成两注，所选号码与开奖号码的百位、十位、个位相同，且顺序不限，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>组六</td>
              <td>从0-9中任意选择3个号码组成一注，所选号码与开奖号码的百位、十位、个位相同，顺序不限，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>组选和值</td>
              <td>所选数值等于开奖号码百位、十位、个位三个数字相加之和，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>混合组选</td>
              <td>手动输入购买号码，3个数字为一注，开奖号码的百位、十位、个位符合前三的组三或组六均为中奖。</td>

            </tr>
            <tr align="center">
              <td>组选包胆</td>
              <td>从0-9中任意选择一个包胆号码，开奖号码的百位、十位、个位中任意一位与所选包胆号码相同（不含豹子号），即为中奖。</td>

            </tr>
            <tr align="center">
              <td rowspan="2">前三不定位</td>
              <td>一码不定位</td>
              <td>从0-9中选择1个号码，每注由1个号码组成，只要开奖号码的万位、千位、百位中包含所选号码，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>二码不定位</td>
              <td>从0-9中选择2个号码，每注由2个不同的号码组成，开奖号码的万位、千位、百位中同时包含所选的2个号码，即为中奖。</td>

            </tr>
            <tr align="center">
              <td rowspan="2">后三不定位</td>
              <td>一码不定位</td>
              <td>从0-9中选择1个号码，每注由1个号码组成，只要开奖号码的百位、十位、个位中包含所选号码，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>二码不定位</td>
              <td>从0-9中选择2个号码，每注由2个不同的号码组成，开奖号码的百位、十位、个位中同时包含所选的2个号码，即为中奖。</td>

            </tr>
            <tr align="center">
              <td rowspan="2">前四不定位</td>
              <td>一码不定位</td>
              <td>从0-9中选择1个号码，每注由1个号码组成，只要开奖号码的万位、千位、百位、十位中包含所选号码，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>二码不定位</td>
              <td>从0-9中选择2个号码，每注由2个不同的号码组成，开奖号码的万位、千位、百位、十位中同时包含所选的2个号码，即为中奖。</td>

            </tr>
            <tr align="center">
              <td rowspan="2">后四不定位</td>
              <td>一码不定位</td>
              <td>从0-9中选择1个号码，每注由1个号码组成，只要开奖号码的千位、百位、十位、个位中包含所选号码，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>二码不定位</td>
              <td>从0-9中选择2个号码，每注由2个不同的号码组成，开奖号码的千位、百位、十位、个位中同时包含所选的2个号码，即为中奖。</td>

            </tr>
            <tr align="center">
              <td rowspan="3">五星不定位</td>
              <td>一码不定位</td>
              <td>从0-9中选择1个号码，每注由1个号码组成，只要开奖号码的万位、千位、百位、十位、个位中包含所选号码，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>二码不定位</td>
              <td>从0-9中选择2个号码，每注由2个不同的号码组成，开奖号码的万位、千位、百位、十位、个位中同时包含所选的2个号码，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>三码不定位</td>
              <td>从0-9中选择3个号码，每注由3个不同的号码组成，开奖号码的万位、千位、百位、十位、个位中同时包含所选的3个号码，即为中奖。</td>

            </tr>
            <tr align="center">
              <td rowspan="16">二星</td>
              <td>前二直选复式</td>
              <td>从万位和千位上至少各选1个号码，所选号码与开奖号码的万位、千位相同，且顺序一致，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>前二直选单式</td>
              <td>手动输入一个2位数号码组成一注，所选号码与开奖号码的万位、千位相同，且顺序一致，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>前二直选和值</td>
              <td>所选数值等于开奖号码的万位、千位两个数字相加之和，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>前二直选跨度</td>
              <td>所选数值等于开奖号码的万位、千位两个数字相减之差，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>前二组选复式</td>
              <td>从0-9中选2个号码组成一注，所择号码与开奖号码的万位、千位相同，顺序不限，即为中奖（不含对子号）。</td>

            </tr>
            <tr align="center">
              <td>前二组选单式</td>
              <td>手动输入购买号码，2个数字为一注，所选号码与开奖号码的万位、千位相同，顺序不限，即为中奖（不含对子号）。</td>

            </tr>
            <tr align="center">
              <td>前二组选和值</td>
              <td>所选数值等于开奖号码的万位、千位两个数字相加之和（不含对子号）即为中奖。</td>

            </tr>
            <tr align="center">
              <td>前二组选包胆</td>
              <td>从0-9中任意选择一个包胆号码，开奖号码的万位、千位中任意一位与所选包胆号码相同（不含对子号），即为中奖。</td>

            </tr>
            <tr align="center">
              <td>后二直选复式</td>
              <td>从十位和个位上至少各选1个号码，所选号码与开奖号码的十位、个位相同，且顺序一致，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>后二直选单式</td>
              <td>手动输入一个2位数号码组成一注，所选号码与开奖号码的十位、个位相同，且顺序一致，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>后二直选和值</td>
              <td>所选数值等于开奖号码的十位、个位两个数字相加之和即为中奖。</td>

            </tr>
            <tr align="center">
              <td>后二直选跨度</td>
              <td>所选数值等于开奖号码的十位、个位两个数字相减之差即为中奖。</td>

            </tr>
            <tr align="center">
              <td>后二组选复式</td>
              <td>从0-9中选2个号码组成一注，所选号码与开奖号码的十位、个位相同，顺序不限，即为中奖（不含对子号）。</td>

            </tr>
            <tr align="center">
              <td>后二组选单式</td>
              <td>手动输入购买号码，2个数字为一注，所选号码与开奖号码的十位、个位相同，顺序不限，即为中奖（不含对子号）。</td>

            </tr>
            <tr align="center">
              <td>后二组选和值</td>
              <td>所选数值等于开奖号码的十位、个位两个数字相加之和（不含对子号），即为中奖。</td>

            </tr>
            <tr align="center">
              <td>后二组选包胆</td>
              <td>从0-9中任意选择一个包胆号码，开奖号码的十位、个位中任意一位与所选包胆号码相同（不含对子号），即为中奖。</td>

            </tr>
            <tr align="center">
              <td rowspan="5">定位胆</td>
              <td>万位</td>
              <td rowspan="5">从万位、千位、百位、十位、个位任意1个位置或多个位置上选择1个号码，所选号码与相同位置上的开奖号码一致，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>千位</td>

            </tr>
            <tr align="center">
              <td>百位</td>

            </tr>
            <tr align="center">
              <td>十位</td>

            </tr>
            <tr align="center">
              <td>个位</td>

            </tr>
            <tr align="center">
              <td  rowspan="10">大小单双</td>
              <td>前二</td>
              <td>对万位和千位的“大（56789）小（01234）、单（13579）双（02468）”形态进行购买，所选号码的位置、形态与开奖号码的位置、形态相同，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>后二</td>
              <td>对十位和个位的“大（56789）小（01234）、单（13579）双（02468）”形态进行购买，所选号码的位置、形态与开奖号码的位置、形态相同，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>前三</td>
              <td>对万位、千位和百位的“大（56789）小（01234）、单（13579）双（02468）”形态进行购买，所选号码的位置、形态与开奖号码的位置、形态相同，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>后三</td>
              <td>对百位、十位和个位的“大（56789）小（01234）、单（13579）双（02468）”形态进行购买，所选号码的位置、形态与开奖号码的位置、形态相同，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>第一球</td>
              <td>对万位的“大（56789）小（01234）、单（13579）双（02468）”形态进行购买，所选号码的位置、形态与开奖号码的位置、形态相同，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>第二球</td>
              <td>对千位的“大（56789）小（01234）、单（13579）双（02468）”形态进行购买，所选号码的位置、形态与开奖号码的位置、形态相同，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>第三球</td>
              <td>对百位的“大（56789）小（01234）、单（13579）双（02468）”形态进行购买，所选号码的位置、形态与开奖号码的位置、形态相同，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>第四球</td>
              <td>对十位的“大（56789）小（01234）、单（13579）双（02468）”形态进行购买，所选号码的位置、形态与开奖号码的位置、形态相同，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>第五球</td>
              <td>对个位的“大（56789）小（01234）、单（13579）双（02468）”形态进行购买，所选号码的位置、形态与开奖号码的位置、形态相同，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>总和</td>
              <td>对万、千、百、十、个五个位置上的数字之和的形态进行购买，所选号码的形态与开奖号码的形态相同，即为中奖。大于22为大，小于等于22为小。</td>

            </tr>
            <tr align="center">
              <td rowspan="4">特殊玩法</td>
              <td>一帆风顺</td>
              <td>从0-9中任意选择1个号码组成一注，只要开奖号码的万位, 千位,百位, 十位, 个位中包含所选号码, 即为中奖，所选号码出现多次按一次计算，不重复派彩。</td>

            </tr>
            <tr align="center">
              <td>好事成双</td>
              <td>从0-9中任意选择1个号码组成一注，只要所选号码在开奖号码的万位, 千位, 百位, 十位, 个位中出现两次相同，即为中奖，所选号码出现两次以上按两次计算，不重复派彩。</td>

            </tr>
            <tr align="center">
              <td>三星报喜</td>
              <td>从0-9中任意选择1个号码组成一注，只要所选号码在开奖号码的万位, 千位, 百位, 十位, 个位中出现三次, 即为中奖，所选号码出现三次以上按三次计算，不重复派彩。</td>

            </tr>
            <tr align="center">
              <td>四季发财</td>
              <td>从0-9中任意选择1个号码组成一注，只要所选号码在开奖号码的万位, 千位, 百位, 十位, 个位中出现四次, 即为中奖，所选号码出现四次以上按四次计算，不重复派彩。</td>

            </tr>
            <tr align="center">
              <td rowspan="6">任选二</td>
              <td>任二直选复式</td>
              <td>从万位、千位、百位、十位、个位中至少两位上各选至少一个号码组成一注，所选号码与开奖号码指定位置上的号码相同且顺序一致，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>任二直选单式</td>
              <td>从万位、千位、百位、十位、个位中至少选择两个位置，手动输入一个两位数的号码构成一注，所选号码与开奖号码的指定位置上的号码相同，且顺序一致，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>任二直选和值</td>
              <td>从万位、千位、百位、十位、个位中至少选择两个位置，至少选择一个和值号码构成一注，所选号码与开奖号码的和值相同，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>任二组选复式</td>
              <td>从万位、千位、百位、十位、个位中至少选择两个位置，号码区至少选择两个号码构成一注，所选号码与开奖号码的指定位置上的号码相同，且顺序不限，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>任二组选单式</td>
              <td>从万位、千位、百位、十位、个位中至少选择两个位置，手动输入一个两位数的号码构成一注，所选号码与开奖号码的指定位置上的号码相同，且顺序不限，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>任二组选和值</td>
              <td>从万位、千位、百位、十位、个位中至少选择两个位置，至少选择一个和值号码构成一注，所选号码与开奖号码的和值相同，即为中奖。</td>

            </tr>
            <tr align="center">
              <td rowspan="9">任选三</td>
              <td>任三直选复式</td>
              <td>从万位、千位、百位、十位、个位中至少三位上各选1个号码组成一注，所选号码与开奖号码的指定位置上的号码相同，且顺序一致，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>任三直选单式</td>
              <td>从万位、千位、百位、十位、个位中至少选择三个位置，手动输入一个三位数的号码构成一注，所选号码与开奖号码的指定位置上的号码相同，且顺序一致，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>任三直选和值</td>
              <td>从万位、千位、百位、十位、个位中至少选择三个位置，至少选择一个和值号码构成一注，所选号码与开奖号码的和值相同，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>组三复式</td>
              <td>从万位、千位、百位、十位、个位中至少选择三个位置，号码区至少选择两个号码构成一注，所选号码与开奖号码的指定位置上的号码相同，且顺序不限，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>组三单式</td>
              <td>从万位、千位、百位、十位、个位中至少选择三个位置，手动输入至少两个号码构成一注，所选号码与开奖号码的指定位置上的号码相同，且顺序不限，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>组六复式</td>
              <td>从万位、千位、百位、十位、个位中至少选择三个位置，号码区至少选择三个号码构成一注，所选号码与开奖号码的指定位置上的号码相同，且顺序不限，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>组六单式</td>
              <td>从万位、千位、百位、十位、个位中至少选择三个位置，手动输入至少三个号码构成一注，所选号码与开奖号码的指定位置上的号码相同，且顺序不限，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>混合组选</td>
              <td>从万位、千位、百位、十位、个位中至少选择三个位置，手动输入至少三个号码构成一注（不包含豹子号），所选号码与开奖号码的指定位置上的号码相同，且顺序不限，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>组选和值</td>
              <td>从万位、千位、百位、十位、个位中至少选择三个位置，至少选择一个和值号码构成一注，所选号码与开奖号码的和值（不包含豹子号）相同，即为中奖。</td>

            </tr>
            <tr align="center">
              <td rowspan="6">任选四</td>
              <td>任四直选复式</td>
              <td>从万位、千位、百位、十位、个位中至少四位上各选1个号码组成一注，所选号码与开奖号码的指定位置上的号码相同，且顺序一致，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>任四直选单式</td>
              <td>从万位、千位、百位、十位、个位中至少选择四个位置，手动输入一个四位数的号码构成一注，所选号码与开奖号码的指定位置上的号码相同，且顺序不限，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>组选24</td>
              <td>从万位、千位、百位、十位、个位中至少选择四个位置，号码区至少选择四个号码构成一注，所选号码与开奖号码的指定位置上的号码相关，且顺序不限，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>组选12</td>
              <td>从万位、千位、百位、十位、个位中至少选择四个位置，从“二重号”选择一个号码，“单号”中选择两个号码组成一注，所选号码与开奖号码的指定位置上的号码相关，且顺序不限，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>组选6</td>
              <td>从万位、千位、百位、十位、个位中至少选择四个位置，从“二重号”选择两个号码组成一注，所选号码与开奖号码的指定位置上的号码相关，且顺序不限，即为中奖。</td>

            </tr>
            <tr align="center">
              <td>组选4</td>
              <td>从万位、千位、百位、十位、个位中至少选择四个位置，从“三重号”选择一个号码，“单号”中选择一个号码组成一注，所选号码与开奖号码的指定位置上的号码相关，且顺序不限，即为中奖。</td>

            </tr>
            </tbody>
          </table>
        </div><br><br>
        <div class="way-item-text" id="test3">
          <p class="f-b">信用玩法</p>
          一、以下所有投注皆含本金。<br/>
          二、两面：指单、双；大、小。<br/>
          1.单、双：号码为双数叫双，如0、2、4、6、8；号码为单数叫单，如1、3、5、7、9。<br/>
          2.大、小：开出之号码大于或等于5为大，小于或等于4为小。<br/>
          3.每一个号码为一投注组合，假如投注号码为开奖号码并在所投的球位置，视为中奖，其余情形视为不中奖。<br/>
          三、总和单双：所有5个开奖号码的数字总和值是单数为总和单，如数字总和值是45、29、31；所有5个开奖号码的数字总和值是双数为总和双，如数字总和是42、0、30；假如投注组合符合中奖结果，视为中奖，其余情形视为不中奖。<br/>
          四、总和大小：所有5个开奖号码的数字总和值23到45为总和大；所有5个开奖号码的数字总和值0到22为总和小。如开奖号码为02、08、07、09、01，数字总和是27，则总和大。假如投注组合符合中奖结果，视为中奖，其余情形视为不中奖。<br/>
          五、后三特殊玩法。<br/>
          1.豹子：中奖号码的个位十位百位数字都相同。----如中奖号码为000、111、999等，中奖号码的个位十位百位数字相同，则投注豹子者视为中奖，其它视为不中奖。<br/>
          2.顺子：中奖号码的个位十位百位数字都相连，不分顺序。（数字9、0、1相连）----如中奖号码为123、901、890、321、546等，中奖号码个位十位百位数字相连，则投注顺子者视为中奖，其它视为不中奖。<br/>
          3.对子：中奖号码的个位十位百位任意两位数字相同。（不包括豹子）----如中奖号码为001，112、696，中奖号码有两位数字相同，则投注对子者视为中奖，其它视为不中奖。 如中奖号码为001，112、696，中奖号码有两位数字相同，则投注对子者视为中奖，其它视为不中奖。<br/>
          4.半顺：中奖号码的个位十位百位任意两位数字相连，不分顺序。（不包括顺子、对子，数字9、0、1相连）----如中奖号码为125、540、390、706，中奖号码有两位数字相连，则投注半顺者视为中奖，其它视为不中奖。<br/>
          5.杂六：不包括豹子、对子、顺子、半顺的所有中奖号码。----如中奖号码为157，中奖号码位数之间无关联性，则投注杂六者视为中奖，其它视为不中奖。<br/>
          六、中三特殊玩法。
          1.豹子：中奖号码的十位百位千位数字都相同。----如中奖号码为000、111、999等，中奖号码的十位百位千位数字相同，则投注豹子者视为中奖，其它视为不中奖。<br/>
          2.顺子：中奖号码的十位百位千位数字都相连，不分顺序。（数字9、0、1相连）----如中奖号码为123、901、321、546等，中奖号码十位百位千位数字相连，则投注顺子者视为中奖，其它视为不中奖。<br/>
          3.对子：中奖号码的十位百位千位任意两位数字相同。（不包括豹子）----如中奖号码为001，112、696，中奖号码有两位数字相同，则投注对子者视为中奖，其它视为不中奖。 如中奖号码为001，112、696，中奖号码有两位数字相同，则投注对子者视为中奖，其它视为不中奖。<br/>
          4.半顺：中奖号码的十位百位千位任意两位数字相连，不分顺序。（不包括顺子、对子，数字9、0、1相连）----如中奖号码为125、540、390、706，中奖号码有两位数字相连，则投注半顺者视为中奖，其它视为不中奖。<br/>
          5.杂六：不包括豹子、对子、顺子、半顺的所有中奖号码。----如中奖十位百位千位号码为157，中奖号码位数之间无关联性，则投注杂六者视为中奖，其它视为不中奖。<br/>
          七、前三特殊玩法。
          1.豹子：中奖号码的百位千位万位数字都相同。----如中奖号码为000、111、999等，中奖号码的百位千位万位数字相同，则投注豹子者视为中奖，其它视为不中奖。<br/>
          2.顺子：中奖号码的百位千位万位数字都相连，不分顺序。（数字9、0、1相连）----如中奖号码为123、901、321、546等，中奖号码百位千位万位数字相连，则投注顺子者视为中奖，其它视为不中奖。<br/>
          3.对子：中奖号码的百位千位万位任意两位数字相同。（不包括豹子）----如中奖号码为001，112、696，中奖号码有两位数字相同，则投注对子者视为中奖，其它视为不中奖。 如中奖号码为001，112、696，中奖号码有两位数字相同，则投注对子者视为中奖，其它视为不中奖。<br/>
          4.半顺：中奖号码的百位千位万位任意两位数字相连，不分顺序。（不包括顺子、对子，数字9、0、1相连）----如中奖号码为125、540、390、706，中奖号码有两位数字相连，则投注半顺者视为中奖，其它视为不中奖。<br/>
          5.杂六：不包括豹子、对子、顺子、半顺的所有中奖号码。----如中奖百位千位万位号码为157，中奖号码位数之间无关联性，则投注杂六者视为中奖，其它视为不中奖。<br/>
          6.龙虎斗：共有10个单独的投注台面，每一个投注台面的左边为龙，右边为虎。如在第1球vs第2球的投注台面，则第一球为龙，第二球为虎；计算公式为：第一球的结果为龙的点数，第二球的结果为虎的点数。若选择第1球vs第5球台面，则第一球为龙，第五球为虎，以此类推。<br/>
          7.龙、虎：以龙和虎点数大小比较来判断胜负，龙大于虎则投注"龙"者中奖，如龙开8，虎开0；若龙小于虎则投注"虎"者中奖。 其余情形视为不中奖。<br/>
          8.和：龙和虎点数相同，投注"和"者中奖，如龙开8，虎开8。其余情形视为不中奖。<br/>
          9.全5中1∶0~9任选1号进行投注,当所有5个开奖号码中任一数与所选的号码相同时，即为中奖。
        </div><br><br>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import SubHeader from 'views/common/subHeader'
  import * as API from 'api/wapi/front'

  export default {
    name: 'bounsRule',
    data () {
      return {
        title: '玩法规则',
        defaultValue: '',
        lotteryList: [] // 当前所有的彩种列表
      }
    },
    components: { SubHeader },
    methods: {
      // 彩种列表接口方法
      getLotteryList () {
        API.getLotteryList().then(res => {
          // console.log(res.data.lotteryTypeList)
          let lotteryTypeList = []
          let lotteryList = []
          if (res.data.lotteryTypeList) {
            lotteryTypeList = res.data.lotteryTypeList
            lotteryTypeList.map(i => {
              i.lotteryList.map(j => {
                lotteryList.push(j) // 二维数组转换一维
              })
            })
            lotteryList.map((i, k) => {
              // 拼数据
              let obj = {}
              let val = {}
              val.lotteryId = i.lotteryId
              val.lotteryTypeId = i.lotteryTypeId
              obj.key = JSON.stringify(val) // VUX插件只接受字符串
              obj.value = i.lotteryName
              this.lotteryList.push(obj)
              if (i.lotteryId === 1001) {
                this.defaultValue = this.lotteryList[k].key // 默认时时彩的第一个彩种
              }
            })
          }
        })
      },
      close () {
        this.doPopoverPage(0)
      },
      onChange (val) {
        console.log(val)
      },
      resetUI () {
        const ruleContent = this.$refs.ruleContent
        const ruleContentHeight = document.documentElement.clientHeight - ruleContent.offsetTop
        ruleContent.style.height = (ruleContentHeight - 5) + 'px'
      }
    },
    created () {
      this.getLotteryList() // 取数据
    },
    mounted () {
      this.resetUI()
    }
  }
</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .play-rule
    position fixed
    width 100%
    height 100%
    top 0
    background rgb(255, 255, 255)
    padding-bottom $BottomBarHeight * 2
    z-index 999
    .set-area
      margin rem(30) rem(30) rem(40)
      border-bottom 1px solid $color-border
      .set-con
        position relative
        margin-left rem(20)
        .lotteryMenu
          float left
          text-align center
          height rem(65)
          line-height rem(65)
          border 1px solid $color-border
          border-radius 5px
          color $color-black-c
          margin-bottom rem(20)
    .icon_down
      position absolute
      top rem(18)
      right rem(10)
      width rem(40)
      height rem(35)
    .rule
      margin 0 rem(30) rem(20)
      color $color-black-c
      border-left 3px solid $color-red
      box-sizing border-box
      padding-left .2rem
      font-size rem(30)
    .rule-nav
      width 50%
      margin-left rem(30)
      div
        background #d8d6d6
        text-align center
        height rem(50)
        line-height rem(50)
        font-size rem(24)
        &.active
          background $color-red
          color $color-white
    .rule-content
      margin 0 rem(30)
      border 1px solid $color-border
      box-sizing border-box
      font-size rem(20)
      color $color-black-c
      padding rem(20)
      overflow-y auto
      .title
        color $color-red
        font-size rem(24)
        padding-bottom rem(15)
      p
        text-indent 2em
</style>
<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .play-rule
    *[resetstyle].select
    .weui-select
      height rem(65)
      line-height rem(65)
      color $color-black-c
    .weui-cell__bd:after
      border-style none !important

    *[resetstyle].checkArea
    .weui-cells__title
      width 20%
      line-height rem(70)
      margin-top 0
      margin-bottom 0
      padding-left 0
      padding-right 0
      font-size rem(30)
    .weui-cells
      width 80%
      padding 0 rem(10)
      background transparent
      font-size rem(30)
      .weui-cell
        width 50%
        float left
        height rem(70)
        line-height rem(70)
        padding 0
        .weui-cell__hd
          .weui-icon-checked:before
            font-size rem(40)
      .weui-cell:before
        border none !important
    .weui-cells:before
      border none !important
    .weui-cells:after
      border none !important
</style>
