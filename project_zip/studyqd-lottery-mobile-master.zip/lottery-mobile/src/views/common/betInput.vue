<template>
  <div class="bet-warp bet-input">
    <group>
      <x-textarea
        v-model="inputCurrentLayout"
        :placeholder="lang.dividerRule"
        :show-counter="false"
        :rows="9"
        autosize
      ></x-textarea>
    </group>
    <div flex="main:right">
      <div class="btn-clear" @click="clearTextarea">
        <x-button type="warn">{{ lang.clear }}</x-button>
      </div>
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
  export default {
    data () {
      return {
        lang: {
          dividerRule: '每一注号码之间请用一个空格[ ]、逗号[,] 或者 分号[;] 隔开',
          clear: '清空号码'
        },
        inputCurrentLayout: ''
      }
    },
    props: {
      currentLayout: {
        type: String,
        default: ''
      },
      currentPlay: {
        type: Object,
        default: {}
      }
    },
    methods: {
      clearTextarea () { // 清空输入框
        this.$emit('on-clear')
      }
    },
    watch: {
      inputCurrentLayout (val) {
        this.$emit('update:currentLayout', val)
        this.$emit('on-input')
      },
      currentLayout (val) {
        if (!val) {
          this.inputCurrentLayout = ''
        }
      }
    }
  }
</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .bet-warp
    width rem(670)
    margin 0 auto
    padding-top rem(40)
    p
      font-size rem(26)
      line-height 1.3em
      text-align left
      color $color-black-c
    .weui-cell
      padding-left .2rem
      border 1px solid $color-border
      border-radius 4px
      font-size rem(28)
      padding rem(8) rem(17)
    .btn-clear
      width rem(220)
      margin-top rem(13)
      .weui-btn
        height rem(60)
        line-height rem(60)
        font-size rem(36)

      .weui-btn_warn
        background $color-red
</style>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .bet-input
    .weui-cells
      margin-top rem(20)
      &:before
        border-top: none
      &:after
        border-bottom: none
</style>
