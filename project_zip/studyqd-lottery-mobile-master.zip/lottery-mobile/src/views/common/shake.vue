<template>
  <section>
    <div class="shake-hot-wrap">
      <div flex="cross:center">摇一摇<icon-svg icon-class="yaoyiyao"></icon-svg></div>
    </div>
  </section>
</template>

<script type="text/ecmascript-6">
  export default {
    data () {
      return {}
    }
  }
</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"
  section
    padding 0 .5rem
    .shake-hot-wrap
      padding-top rem(25)
      color $color-red
      font-size rem(32)
      .lott-icon
        width rem(60)
        height rem(60)
</style>
