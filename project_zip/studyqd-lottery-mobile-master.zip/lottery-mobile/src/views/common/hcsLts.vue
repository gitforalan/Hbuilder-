<template>
  <div class="hcs-lts__main">
    <div class="hcs-lts__title" flex="cross:center" @click="onTouchHandler">
      {{ text }}
      <icon-svg icon-class="circle-down"></icon-svg>
    </div>
    <!-- 冷热弹出框 -->
    <hcs-lts-popover
      :options="options"
      :show="show"
      @on-hide="onPopoverMenuHide"
      class="hcs-lts__popover">
    </hcs-lts-popover>
  </div>
</template>

<script type="text/ecmascript-6">
  import HcsLtsPopover from 'views/common/hcsLtsPopover'
  import { mapState } from 'vuex'

  export default {
    data () {
      return {
        show: false,
        options: ['冷热', '遗漏'] //  可扩展
      }
    },
    components: { HcsLtsPopover },
    computed: {
      text () {
        return this.options[this.hcsLtsFlag]
      },
      ...mapState('common', {
        hcsLtsFlag: state => state.hcsLtsFlag
      })
    },
    methods: {
      onPopoverMenuHide () {
        this.delayExec(() => {
          this.show = false
        })
      },
      onTouchHandler () {
        this.show = !this.show
      },
      delayExec (fn) {
        setTimeout(fn, 20)
      }
    }
  }
</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .hcs-lts__main
    /*padding 0 .5rem*/
    box-sizing border-box
    color $color-red
    font-size rem(28)
    .hcs-lts__title
      height 1.7rem
    .hcs-lts__popover
      position absolute
      top 2.4rem
      left -.2rem

  .lott-icon
    width rem(38)
    height rem(38)
</style>
