<template>
  <div class="app-main page-navigation">
    <header>
      <span>
        <i></i>
        <p>收藏本站</p>
      </span>
    </header>
    <div class="padding10">
      <ul class="time">
        <li class="first">
          <div class="flex">
            <div class="flex center"><span class="hide">线路1</span><span class="num">响应时间</span><button class="hide">进入</button></div>
            <div class="flex center"><span class="hide">线路2</span><span class="num">响应时间</span><button class="hide">进入</button></div>
          </div>
        </li>
        <li>
          <div class="flex">
            <div class="flex center"><span>线路1</span><span class="num"><b>{{time[0]}}</b>ms</span><button>进入</button></div>
            <div class="flex center"><span>线路2</span><span class="num"><b>{{time[1]}}</b>ms</span><button>进入</button></div>
          </div>
        </li>
        <li>
          <div class="flex">
            <div class="flex center"><span>线路3</span><span class="num"><b>{{time[2]}}</b>ms</span><button>进入</button></div>
            <div class="flex center"><span>线路4</span><span class="num"><b>{{time[3]}}</b>ms</span><button>进入</button></div>
          </div>
        </li>
        <li>
          <div class="flex">
            <div class="flex center"><span>线路5</span><span class="num"><b>{{time[4]}}</b>ms</span><button>进入</button></div>
          </div>
        </li>
      </ul>
      <div class="tips flex center mt15">
        <i></i><span>温馨提醒：响应时间越短，访问速度越快</span>
      </div>
      <div class="download mt15">
        <h1>下载手机APP，随时随地来一注！</h1>
        <div class="link">
          <a href=''>IOS</a><a href=''>Android版</a>
        </div>
      </div>
    </div> 
    <div class="banner mt15">
      <img v-lazy="banner[0]">
    </div>
    <div class="fontwarp">
      <img v-lazy="fontwarp[0]">
      <div class="link">
        <a href=''>官方玩法</a><a href=''>信用玩法</a>
      </div>
    </div>
    <div class="type">
      <ul class="flex">
        <li v-for="row in type" :key="row.key"><img v-lazy="row"></li>
      </ul>
    </div>
    <div class="banner1">
      <img v-lazy="banner[1]">
    </div>
    <div class="fontwarp1">
      <img v-lazy="fontwarp[1]" class="img1">
      <img v-lazy="banner[2]" class="img2">
    </div>
    <div class="fontwarp2">
      <img v-lazy="fontwarp[2]" class="img1">
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import Vue from 'vue'
  import VueLazyload from 'vue-lazyload'
  Vue.use(VueLazyload)
  export default {
    data () {
      return {
        time: [10, 10, 10, 10, 10],
        type: [
          require('assets/image/lottery_10.png'),
          require('assets/image/lottery_1005.png'),
          require('assets/image/lottery_14.png'),
          require('assets/image/lottery_2002.png'),
          require('assets/image/lottery_12.png'),
          require('assets/image/lottery_11.png'),
          require('assets/image/lottery_15.png'),
          require('assets/image/lottery_13.png'),
          require('assets/image/lottery_21.png'),
          require('assets/image/lottery_18.png'),
          require('assets/image/lottery_1901.png'),
          require('assets/image/lottery_16.png')
        ],
        banner: [require('assets/image/navigation/banner1.png'), require('assets/image/navigation/banner2.png'), require('assets/image/navigation/banner3.png')],
        fontwarp: [require('assets/image/navigation/font1.png'), require('assets/image/navigation/font2.png'), require('assets/image/navigation/font3.png')]
      }
    },
    created () {
      this.time = this.time.map(item => {
        item = Math.round(Math.random() * 50)
        return item
      })
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .page-navigation {
    .first {
      padding-bottom 0 !important
      border none !important
      .num {
        border-color $color-white !important
      }
    }
    .hide {
      visibility hidden
    }
    .time {
      li {
        padding rem(18) 0
        border-bottom dashed 1px #7a7a7a
      }
      & li .flex {
        & > .flex {
          &:nth-child(odd) {
            margin-right rem(42)
          }
        } 
      }
      span {
        vertical-align top
      }
      .num {
        margin 0 rem(18)
        color #7a7a7a
        width rem(114)
        height rem(54)
        line-height rem(54)
        text-align center
        border solid 1px #eaeaea
        b {
          color $color-red
        }
        display inline-block
      }
      font-size rem(24)
      button {
        -webkit-webkit-appearance none
        border none
        color $color-white
        background $color-red
        width rem(116)
        height rem(56)
        line-height rem(56)
        display inline-block
      }
    }
    .fontwarp2 {
      text-align center
      padding 0 0 rem(54) 0
      .img1 {
        width rem(526)
        height rem(337)
      }
    }
    .fontwarp1 {
      padding rem(60) 0 0 0
      text-align center
      .img1 {
        width rem(463)
        height rem(108)
        margin-bottom rem(50)
      }
      .img2 {
        width rem(632)
        height rem(590)
        margin-bottom rem(71)
      }
    }
    .type {
      .flex {
        flex-wrap: wrap
        padding 0 rem(79)
      }
      li {
        padding 0 rem(15) rem(42) rem(15)
        img {
          width rem(116)
          height rem(116)
        }
      }
    }
    .fontwarp {
      padding rem(60) 0 0 0
      text-align center
      img {
        width rem(440)
        height rem(97)
      }
      .link {
        padding rem(38) 0 rem(60) 0
        a {
          font-size rem(28)
          display inline-block
          width rem(174)
          height rem(68)
          line-height rem(68)
          background #00a2ff
          border-radius rem(8)
          color $color-white
          &:last-child {
            background #29a910
          }
          &:not(:last-child) {
            margin-right rem(70)
          }
        }
      }
    }
    .banner {
      img {
        width rem(750)
        height rem(426)
        max-width 100%
      }
    }
    .banner1 {
      img {
        width rem(750)
        height rem(763)
        max-width 100%
      }
    }
    .mt15 {
      margin-top rem(15)
    }
    .download {
      color $color-red
      font-size rem(30)
      text-align center
      background $color-eee
      border-radius rem(8)
      padding rem(26) 0 rem(44) 0
      .link {
        padding-top rem(34)
        a {
          display inline-block
          width rem(290)
          height rem(76)
          line-height rem(76)
          background #00a2ff
          border-radius rem(8)
          color $color-white
          position relative
          &:before {
            content ''
            display inline-block
            background url(../../assets/image/navigation/ios.png) no-repeat center center
            width rem(50)
            height rem(50)
            margin-right rem(15)
            background-size contain
            position relative
            top 50%
            transform translateY(-50%)
          }
          &:last-child {
            background #ff9415
            &:before {
              background url(../../assets/image/navigation/android.png) no-repeat center center
              background-size contain
            }
          }
          &:not(:last-child) {
            margin-right rem(70)
          }
        }
      }
    }
    .flex {
      display flex
      &.center {
        align-items center
        justify-content: center
      }
    }
    font-size rem(11)
    color #404040
    .padding10 {
      padding 0 rem(10)
    }      
    .tips {
      text-align center
      background #faf2bf
      border solid 1px #fce27c
      i {
        background url(../../assets/image/navigation/warn.png) no-repeat center center
        background-size auto rem(44)
        display inline-block
        width rem(44)
        height rem(44)
      }
    }
    header {
      height rem(90)
      background-color $color-red
      background-image url(../../assets/image/navigation/top.png)
      background-size auto rem(90)
      background-position center center
      background-repeat no-repeat
      position relative
      span {
        display inline-block
        color $color-white
        font-size rem(11)
        height rem(90)
        position absolute
        right rem(40)
        top rem(10)
        text-align center
        i {
          background url(../../assets/image/navigation/collect.png) no-repeat center center
          background-size auto rem(40)
          display inline-block
          width rem(40)
          height rem(40)
        }
      }
    }
  }
</style>