<template>
  <div class="app-main giftDetail">
    <x-header :title="title" class="is-fixed"
    :left-options="{ backText: '', preventGoBack: true }"
    @on-click-back="$router.push({ path: '/gift' })"></x-header>
    <div class="app-body">
      <div class="img" :style="{backgroundImage: 'url(' + detail.image_url + ')'}"></div>
      <div class="detailWrap">
        <h2>{{detail.activity_name}}</h2>
        <time v-if="detail.type == 5">活动期间:{{detail.create_time}}</time>
        <div class="detail" v-if="$route.params.type == 3">
          <div class="li">
            <span class="hr">当前等级：{{isLogin ? 'vip-' + (activityDetailContent.userLevel == undefined ? '' : activityDetailContent.userLevel) : '未登录'}}</span>
            <span class="hr" v-if="isLogin ? (activityDatailInfo.flag === 1 ? true : false) : false">晋级奖励：{{isLogin ? (activityDetailContent.winMoney == undefined ? 0.00 : (activityDetailContent.winMoney).toFixed(2)) : 0}}</span>
            <button class="get" :disabled="activityDatailInfo.flag === 1 ? false : true" @click="receiveReward">{{activityDatailInfo.flag === 1 ? '领取' : '不可领取'}}</button>
          </div>
          <div class="labelWrap"><span class="label">晋级机制</span></div>
          <x-table :cell-bordered="false" style="background-color:#fff;">
            <thead>
              <tr>
                <th>等级</th>
                <th>头衔</th>
                <th>成长积分</th>
                <th>晋级奖励</th>
                <th>跳级奖励</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="row in activityDetailPromotion" :key="row.key">
                <td>VIP{{row.level}}</td>
                <td>{{row.levelName}}</td>
                <td>{{row.integral}}</td>
                <td>{{(+row.promotionAward).toFixed(2)}}</td>
                <td>{{(+row.skipAward).toFixed(2)}}</td>
              </tr>
            </tbody>
          </x-table>
          <div class="labelWrap"><span class="label">活动说明</span></div>
          <div v-html="detail.content"></div>
        </div>
        <div class="detail" v-else-if="$route.params.type == 4">
          <div class="li">
            <span class="hr" v-if="activityDatailInfo.flag == 1">昨日投注：{{isLogin ? (activityDetailContent.totalCharge == undefined ? 0.00 : (activityDetailContent.totalCharge).toFixed(2)) : 0}}</span>
            <span class="hr">当前等级：{{isLogin ? 'VIP-' + (activityDetailContent.userLevel == undefined ? '' : activityDetailContent.userLevel): '未登录'}}</span>
            <span class="hr" v-if="activityDatailInfo.flag == 1">加奖比例：{{isLogin ? (activityDetailContent.totalRate != undefined ? activityDetailContent.totalRate : 0): 0}}%</span>
            <span class="hr" v-if="activityDatailInfo.flag == 1">可得加奖：{{isLogin ? (activityDetailContent.winMoney == undefined ? 0.00 : (activityDetailContent.winMoney).toFixed(2)) : 0}}</span>
            <button class="get" :disabled="activityDatailInfo.flag === 1 ? false : true" @click="receiveReward">{{activityDatailInfo.flag === 1 ? '领取' : '不可领取'}}</button>
          </div>
          <div class="labelWrap"><span class="label">加奖比例</span></div>
          <div style="width: 100%; overflow-x: scroll">
          <x-table class="type4" :cell-bordered="false" :style="{'background-color': ' #fff', 'width': tableWith + 'px'}">
            <thead>
              <tr>
                <th class="col col0"><span style="visibility:hidden">1</span></th>
                <th class="col col1"><span style="visibility:hidden">1</span></th>
                <th v-for="(i, index) in activityRatioSetLength" :key="index" :class="'col col' + (index + 2)">VIP{{i}}</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(item, index) in activityRatioSet" :key="index">
                <td class="col col0">昨日有效投注 ≥ {{(+item.validBet).toFixed(2)}}</td>
                <td class="col col1">加奖比例</td>
                <td v-for="(i, index) in item.levelRatio" :key="index" :class="'col col' + (index + 2)">{{i.awardRatio}}%</td>
              </tr>
            </tbody>
          </x-table>
          </div>
          <div class="labelWrap"><span class="label">活动说明</span></div>
          <div v-html="detail.content"></div>
        </div>
        <div class="detail" v-else>
            <div v-html="detail.content"></div>
        </div>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { XTable, cookie } from 'vux'
  import * as API from 'api/wapi/user'
  import comFun from 'views/user/agent/comFunction'
  export default {
    data () {
      return {
        title: '优惠活动',
        detail: {},
        activityDetailPromotion: [],
        activityRatioSet: [],
        activityDatailInfo: {},
        activityRatioSetLength: 0,
        tableWith: 0,
        activityDetailContent: {},
        isLogin: false
      }
    },
    components: {
      XTable
    },
    mounted () {
      if (cookie.get('token')) {
        this.isLogin = true
      }
      this.getCouponDetail()
    },
    methods: {
      receiveReward () {
        // 晋级奖励, 可得加奖：领取
        if (this.activityDatailInfo.flag === 0) {
          return false
        }
        let reportId = this.activityDatailInfo.reportId
        let actionId = this.detail.action_id
        var params = {
          actionId: actionId
        }
        if (reportId !== undefined && reportId !== null && reportId !== '') {
          params.reportId = reportId
        }
        API.getCouponActions(params).then(res => {
          if (!res.error && res.result) {
            var result = res.result
            if (+result.code === 1) {
              this.$vux.toast.show({
                text: result.msg
              })
              this.activityDatailInfo.flag = 0
              this.activityDetailContent.winMoney = 0.00
            } else {
              this.$vux.toast.show({
                text: result.msg
              })
            }
          } else {
            this.$vux.toast.show({
              type: 'warn',
              text: res.error.message
            })
          }
        })
      },
      getCouponDetail () {
        (async () => {
          let filePath = await comFun.getImgFilePath()
          let params = {
            actionId: this.$route.params.sid,
            type: this.$route.params.type,
            host: window.location.hostname,
            isLogin: this.isLogin ? 1 : 0
          }
          if (this.isLogin) {
            params.sessionId = cookie.get('token')
          }
          API.getCouponDetail(params).then(res => {
            if (!res.error) {
              res.result.image_url = filePath + '/' + res.result.image_url
              res.result.content = res.result.content.replace(/\/images/g, filePath + '/images')
              this.detail = res.result
              this.activityDetailPromotion = this.detail.promotion === undefined ? this.detail.promotion : JSON.parse(this.detail.promotion)
              this.activityDatailInfo = this.detail.condition || {}
              this.activityRatioSet = this.detail.ratio_set === undefined ? [] : JSON.parse(this.detail.ratio_set)
              if (this.activityDatailInfo !== undefined && this.activityDatailInfo !== null && this.activityDatailInfo !== '') {
                this.activityDetailContent = this.activityDatailInfo.winCondition && JSON.parse(this.activityDatailInfo.winCondition)
              }
              for (var i = 0; i < this.activityRatioSet.length; i++) {
                this.activityRatioSetLength = this.activityRatioSet[i].levelRatio.length
              }
              this.tableWith = this.activityRatioSetLength * 50 + 150 + 80
            } else {
              this.$vux.toast.show({
                type: 'warn',
                text: res.error.message
              })
            }
          })
        })()
      }
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .giftDetail
    img
      max-width 100%
    .type4
      table-layout: fixed
    .col
      width 50px
    .col0
      width 150px
    .col1
      width 80px
    .vux-table
      margin rem(20) 0
    .li
      padding rem(10) 0
    .hr
      margin-right rem(20)
    .get
      display: inline;
      padding: .2em .6em .3em;
      font-weight: 700;
      line-height: 1;
      color: #fff;
      text-align: center;
      white-space: nowrap;
      vertical-align: baseline;
      border-radius: .25em;
      background-color: $color-red;
      -webkit-appearance none
      border: none
      &[disabled='disabled']
        background-color: $color-ccc;
    .labelWrap
      padding rem(10) 0
      border-radius: .25em;
      line-height 1
    .label
      display: inline;
      padding: .2em .6em .3em;
      font-weight: 700;
      line-height: 1;
      color: #fff;
      text-align: center;
      white-space: nowrap;
      vertical-align: baseline;
      border-radius: .25em;
      background-color: #f0ad4e;
    line-height:1.5
    .img
      height: rem(250);
      background-size: cover;
      background-position: center center;
      background-repeat: no-repeat;
    .detailWrap
      padding: rem(30) rem(24)
      h2
        color:$color-red;
        font-size: rem(30);
    .detail
      font-size: rem(24);
    time
      color:$color-gray-b;
      font-size: $size-small;
      display:block;
      padding: rem(10) 0 rem(44) 0;
</style>
