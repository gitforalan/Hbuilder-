<template>
  <div class="app-layout">
    <div class="app-main giftIndex" v-if="this.isCurrentRoute">
      <x-header :title="title" class="is-fixed"
      :left-options="{ backText: '', preventGoBack: true }"
      @on-click-back="$router.push({ path: '/' })"></x-header>
      <div class="app-body">
        <ul>
          <li class="flex items" v-for="row in list" :key="row.action_id">
              <div class="img" v-lazy:background-image="row.image_url"></div>
              <div class="flex_item flex detail">
                <div>
                <h2>{{row.activity_name}}</h2>
                <!--<time v-if="row.type == 'redpacket'">活动期间:{{row.start_time}}</time>-->
                <time>{{row.remark}}</time>
                </div>
                <div class="see">
                  <router-link :to="'/gift/' + row.action_id + '/' + row.type">查看详情&gt;</router-link>
                </div>
              </div>
          </li>
          <!--<div class="getMore">更多&gt;&gt;</div>-->
        </ul>
      </div>
    </div>
    <router-view></router-view>
  </div>
</template>

<script type="text/ecmascript-6">
  import Vue from 'vue'
  import VueLazyload from 'vue-lazyload'
  Vue.use(VueLazyload)
  import * as API from 'api/wapi/user'
  import comFun from 'views/user/agent/comFunction'
  export default {
    data () {
      return {
        title: '优惠活动',
        isCurrentRoute: true,
        list: []
      }
    },
    created () {
      // 决定显示index还是detail
      if (this.$route.name === 'giftDetail') {
        this.isCurrentRoute = false
      }
      if (this.isCurrentRoute) {
        this.getCouponList()
      }
    },
    methods: {
      getCouponList () {
        (async () => {
          let filePath = await comFun.getImgFilePath()
          API.getCouponList({host: window.location.hostname}).then(res => {
            if (!res.error) {
              this.list = res.result.map(items => {
                items.image_url = filePath + '/' + items.image_url
                return items
              })
            } else {
              this.$vux.toast.show({
                type: 'warn',
                text: res.error.message
              })
            }
          })
        })()
      }
    },
    watch: {
      $route (to, from) {
        // 决定显示index还是detail
        if (from.name === 'gift') {
          this.isCurrentRoute = false
        } else if (to.name === 'gift') {
          this.isCurrentRoute = true
          this.getCouponList()
        }
      }
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .giftIndex
    background rgb(247, 247, 247)
    line-height:1.5;
    .getMore
        text-align:center;
        color:$color-red;
        padding rem(24) 0 rem(24) 0;
    .app-body
      padding-bottom:0;
    .items
      margin-top: rem(20);
      background:#fff;
      h2
        font-size: rem(30) /* 设计稿像素/基准28 = rem */
        font-weight bold
        word-wrap: break-word;
        word-break: break-all;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        overflow: hidden;
        -webkit-box-orient: vertical;
        word-wrap: break-word;
        word-break: break-all;
      time
        color:$color-gray-b;
        font-size: rem(24);
        display: -webkit-box;
        -webkit-line-clamp: 2;
        overflow: hidden;
        -webkit-box-orient: vertical;
        word-wrap: break-word;
        word-break: break-all;
    .flex
      display: flex;
      .img
        width:rem(338);
        height:rem(250);
        background-size: cover;
        background-position: center center;
        background-repeat: no-repeat;
    .flex_item
      flex:1;
      &.detail
        justify-content: space-between;
        flex-direction: column;
        padding: rem(44) rem(10) 0 rem(20)
    .see
      font-size: $size-small;
      text-align:right;
      & > a
          color:$color-red;
          display: inline-block;
          padding 0 0 rem(24) 0;
</style>
