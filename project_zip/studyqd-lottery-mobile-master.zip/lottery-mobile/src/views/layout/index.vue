/* Created By fx on 2017/8/22. */
<template>
  <div class="app-layout">
    <router-view :key="key"></router-view>
    <btm-bar></btm-bar>
  </div>
</template>

<script>
  import BtmBar from '@/components/naviBar/btm'

  export default {
    name: 'AppLayout',
    components: {BtmBar},
    computed: {
      key () {
        return this.$route.name !== undefined ? this.$route.name + +new Date() : this.$route + +new Date()
      }
    }
  }
</script>

<style lang="stylus">
  /*@import "~@/assets/baseStylus/variable"*/
</style>

