export default [{
  'playTabName': '整合',
  'playTabId': 14210,
  'playTypeList': [
    {
      'playTypeId': 1421020,
      'playTypeName': '冠亚军和',
      'playList': [{
        'playId': 142102010,
        'playName': '冠亚大'
      }, {
        'playId': 142102011,
        'playName': '冠亚小'
      }, {
        'playId': 142102012,
        'playName': '冠亚单'
      }, {
        'playId': 142102013,
        'playName': '冠亚双'
      }]
    },
    {
      'playTypeId': 1421010,
      'playTypeName': '冠军',
      'playList': [{
        'playId': 142101020,
        'playName': '大'
      }, {
        'playId': 142101021,
        'playName': '小'
      }, {
        'playId': 142101022,
        'playName': '单'
      }, {
        'playId': 142101023,
        'playName': '双'
      }]
    },
    {
      'playTypeId': 1421011,
      'playTypeName': '亚军',
      'playList': [{
        'playId': 142101110,
        'playName': '大'
      }, {
        'playId': 142101111,
        'playName': '小'
      }, {
        'playId': 142101112,
        'playName': '单'
      }, {
        'playId': 142101113,
        'playName': '双'
      }]
    },
    {
      'playTypeId': 1421012,
      'playTypeName': '第三名',
      'playList': [{
        'playId': 142101210,
        'playName': '大'
      }, {
        'playId': 142101211,
        'playName': '小'
      }, {
        'playId': 142101212,
        'playName': '单'
      }, {
        'playId': 142101213,
        'playName': '双'
      }]
    },
    {
      'playTypeId': 1421013,
      'playTypeName': '第四名',
      'playList': [{
        'playId': 142101310,
        'playName': '大'
      }, {
        'playId': 142101311,
        'playName': '小'
      }, {
        'playId': 142101312,
        'playName': '单'
      }, {
        'playId': 142101313,
        'playName': '双'
      }]
    },
    {
      'playTypeId': 1421014,
      'playTypeName': '第五名',
      'playList': [{
        'playId': 142101410,
        'playName': '大'
      }, {
        'playId': 142101411,
        'playName': '小'
      }, {
        'playId': 142101412,
        'playName': '单'
      }, {
        'playId': 142101413,
        'playName': '双'
      }]
    },
    {
      'playTypeId': 1421015,
      'playTypeName': '第六名',
      'playList': [{
        'playId': 142101510,
        'playName': '大'
      }, {
        'playId': 142101511,
        'playName': '小'
      }, {
        'playId': 142101512,
        'playName': '单'
      }, {
        'playId': 142101513,
        'playName': '双'
      }]
    },
    {
      'playTypeId': 1421016,
      'playTypeName': '第七名',
      'playList': [{
        'playId': 142101610,
        'playName': '大'
      }, {
        'playId': 142101611,
        'playName': '小'
      }, {
        'playId': 142101612,
        'playName': '单'
      }, {
        'playId': 142101613,
        'playName': '双'
      }]
    },
    {
      'playTypeId': 1421017,
      'playTypeName': '第八名',
      'playList': [{
        'playId': 142101710,
        'playName': '大'
      }, {
        'playId': 142101711,
        'playName': '小'
      }, {
        'playId': 142101712,
        'playName': '单'
      }, {
        'playId': 142101713,
        'playName': '双'
      }]
    },
    {
      'playTypeId': 1421018,
      'playTypeName': '第九名',
      'playList': [{
        'playId': 142101810,
        'playName': '大'
      }, {
        'playId': 142101811,
        'playName': '小'
      }, {
        'playId': 142101812,
        'playName': '单'
      }, {
        'playId': 142101813,
        'playName': '双'
      }]
    },
    {
      'playTypeId': 1421019,
      'playTypeName': '第十名',
      'playList': [{
        'playId': 142101910,
        'playName': '大'
      }, {
        'playId': 142101911,
        'playName': '小'
      }, {
        'playId': 142101912,
        'playName': '单'
      }, {
        'playId': 142101913,
        'playName': '双'
      }]
    }]
},
{
  'playTabName': '冠亚军和',
  'playTabId': 14211,
  'playTypeList': [{
    'playTypeId': 1421110,
    'playTypeName': '冠亚军和',
    'playList': [{
      'playId': 142111010,
      'playName': 1
    }, {
      'playId': 142111011,
      'playName': 1
    }, {
      'playId': 142111012,
      'playName': 1
    }, {
      'playId': 142111013,
      'playName': 1
    }, {
      'playId': 142111014,
      'playName': 1
    }, {
      'playId': 142111015,
      'playName': 1
    }, {
      'playId': 142111016,
      'playName': 1
    }, {
      'playId': 142111017,
      'playName': 1
    }, {
      'playId': 142111018,
      'playName': 1
    }, {
      'playId': 142111019,
      'playName': 1
    }, {
      'playId': 142111020,
      'playName': 1
    }, {
      'playId': 142111021,
      'playName': 1
    }, {
      'playId': 142111022,
      'playName': 1
    }, {
      'playId': 142111023,
      'playName': 1
    }, {
      'playId': 142111024,
      'playName': 1
    }, {
      'playId': 142111025,
      'playName': 1
    }, {
      'playId': 142111026,
      'playName': 1
    }]
  }, {
    'playTypeId': 1421110,
    'playTypeName': '大小单双',
    'playList': [{
      'playId': 142111027,
      'playName': 1
    }, {
      'playId': 142111028,
      'playName': 1
    }, {
      'playId': 142111029,
      'playName': 1
    }, {
      'playId': 142111030,
      'playName': 1
    }, {
      'playId': 142111031,
      'playName': 1
    }, {
      'playId': 142111032,
      'playName': 1
    }, {
      'playId': 142111033,
      'playName': 1
    }, {
      'playId': 142111034,
      'playName': 1
    }]
  }]
},
{
  'playTabName': '冠亚组合',
  'playTabId': 14212,
  'playTypeList': [{
    'playTypeId': 1421210,
    'playTypeName': '冠亚组合',
    'playList': [{
      'playId': 142121010,
      'playName': '1-2'
    }, {
      'playId': 142121011,
      'playName': '1-2'
    }, {
      'playId': 142121012,
      'playName': '1-2'
    }, {
      'playId': 142121013,
      'playName': '1-2'
    }, {
      'playId': 142121014,
      'playName': '1-2'
    }, {
      'playId': 142121015,
      'playName': '1-2'
    }, {
      'playId': 142121016,
      'playName': '1-2'
    }, {
      'playId': 142121017,
      'playName': '1-2'
    }, {
      'playId': 142121018,
      'playName': '1-2'
    }, {
      'playId': 142121019,
      'playName': '1-2'
    }, {
      'playId': 142121020,
      'playName': '1-2'
    }, {
      'playId': 142121021,
      'playName': '1-2'
    }, {
      'playId': 142121022,
      'playName': '1-2'
    }, {
      'playId': 142121023,
      'playName': '1-2'
    }, {
      'playId': 142121024,
      'playName': '1-2'
    }, {
      'playId': 142121025,
      'playName': '1-2'
    }, {
      'playId': 142121026,
      'playName': '1-2'
    }, {
      'playId': 142121027,
      'playName': '1-2'
    }, {
      'playId': 142121028,
      'playName': '1-2'
    }, {
      'playId': 142121029,
      'playName': '1-2'
    }, {
      'playId': 142121030,
      'playName': '1-2'
    }, {
      'playId': 142121031,
      'playName': '1-2'
    }, {
      'playId': 142121032,
      'playName': '1-2'
    }, {
      'playId': 142121033,
      'playName': '1-2'
    }, {
      'playId': 142121034,
      'playName': '1-2'
    }, {
      'playId': 142121035,
      'playName': '1-2'
    }, {
      'playId': 142121036,
      'playName': '1-2'
    }, {
      'playId': 142121037,
      'playName': '1-2'
    }, {
      'playId': 142121038,
      'playName': '1-2'
    }, {
      'playId': 142121039,
      'playName': '1-2'
    }, {
      'playId': 142121040,
      'playName': '1-2'
    }, {
      'playId': 142121041,
      'playName': '1-2'
    }, {
      'playId': 142121042,
      'playName': '1-2'
    }, {
      'playId': 142121043,
      'playName': '1-2'
    }, {
      'playId': 142121044,
      'playName': '1-2'
    }, {
      'playId': 142121045,
      'playName': '1-2'
    }, {
      'playId': 142121046,
      'playName': '1-2'
    }, {
      'playId': 142121047,
      'playName': '1-2'
    }, {
      'playId': 142121048,
      'playName': '1-2'
    }, {
      'playId': 142121049,
      'playName': '1-2'
    }, {
      'playId': 142121050,
      'playName': '1-2'
    }, {
      'playId': 142121051,
      'playName': '1-2'
    }, {
      'playId': 142121052,
      'playName': '1-2'
    }, {
      'playId': 142121053,
      'playName': '1-2'
    }, {
      'playId': 142121054,
      'playName': '1-2'
    }]
  }]
},
{
  'playTabName': '龙虎斗',
  'playTabId': 14214,
  'playTypeList': [{
    'playTypeName': '第一球VS第十球',
    'playTypeId': 1421410,
    'playList': [{
      'playId': 142141010,
      'playName': '龙'
    }, {
      'playId': 142141011,
      'playName': '虎'
    }]
  },
  {
    'playTypeId': 1421411,
    'playTypeName': '第二球VS第九球',
    'playList': [{
      'playId': 142141110,
      'playName': '龙'
    }, {
      'playId': 142141111,
      'playName': '虎'
    }]
  },
  {
    'playTypeId': 1421412,
    'playTypeName': '第三球VS第八球',
    'playList': [{
      'playId': 142141210,
      'playName': '龙'
    }, {
      'playId': 142141211,
      'playName': '虎'
    }]
  },
  {
    'playTypeId': 1421413,
    'playTypeName': '第四球VS第七球',
    'playList': [{
      'playId': 142141310,
      'playName': '龙'
    }, {
      'playId': 142141311,
      'playName': '虎'
    }]
  },
  {
    'playTypeId': 1421414,
    'playTypeName': '第五球VS第六球',
    'playList': [{
      'playId': 142141410,
      'playName': '龙'
    }, {
      'playId': 142141411,
      'playName': '虎'
    }]
  }
  ]
}
]
