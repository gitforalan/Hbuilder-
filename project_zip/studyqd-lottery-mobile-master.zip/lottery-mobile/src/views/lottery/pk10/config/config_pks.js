/*
 * pks基础数据 官方玩法
 * eslint 格式化 format by fx， 2017-9-19 12:49:16
 * */

export default {
  /* 前一 */
  // 前一直选
  141101010: {
    selectarea: {
      type: 'digital',
      noBigIndex: 6,
      isButton: true,
      hcltPosition: [0],
      layout: [{
        title: '冠军',
        no: '01|02|03|04|05|06|07|08|09|10',
        place: 0,
        cols: 1
      }]
    }
  },

  /* 前二直选 */
  // 直选复式
  141111010: {
    alias: 'BJZ2',
    selectarea: {
      type: 'digital',
      hcltPosition: [0, 1],
      layout: [{
        title: '冠军',
        no: '01|02|03|04|05|06|07|08|09|10',
        place: 0,
        cols: 1,
        minchosen: 1
      }, {
        title: '亚军',
        no: '01|02|03|04|05|06|07|08|09|10',
        place: 1,
        cols: 1,
        minchosen: 1
      }],
      noBigIndex: 6,
      isButton: true
    }
  },
  // 直选单式
  141111011: {
    alias: 'ZX2',
    selectarea: {
      type: 'input'
    }
  },

  /* 前三直选 */
  // 直选复式
  141121010: {
    alias: 'BJZ3',
    selectarea: {
      type: 'digital',
      hcltPosition: [0, 1, 2],
      layout: [{
        title: '冠军',
        no: '01|02|03|04|05|06|07|08|09|10',
        place: 0,
        cols: 1
      }, {
        title: '亚军',
        no: '01|02|03|04|05|06|07|08|09|10',
        place: 1,
        cols: 1
      }, {
        title: '季军',
        no: '01|02|03|04|05|06|07|08|09|10',
        place: 2,
        cols: 1
      }],
      noBigIndex: 6,
      isButton: true
    }
  },
  // 直选单式
  141121011: {
    alias: 'ZX3',
    selectarea: {
      type: 'input'
    }
  },

  /* 定位胆 */
  141131010: {
    alias: 'DWD',
    selectarea: {
      type: 'digital',
      hcltPosition: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
      layout: [{
        title: '冠军',
        no: '01|02|03|04|05|06|07|08|09|10',
        place: 0,
        cols: 1
      }, {
        title: '亚军',
        no: '01|02|03|04|05|06|07|08|09|10',
        place: 1,
        cols: 1
      }, {
        title: '季军',
        no: '01|02|03|04|05|06|07|08|09|10',
        place: 2,
        cols: 1
      }, {
        title: '第四名',
        no: '01|02|03|04|05|06|07|08|09|10',
        place: 3,
        cols: 1
      }, {
        title: '第五名',
        no: '01|02|03|04|05|06|07|08|09|10',
        place: 4,
        cols: 1
      }, {
        title: '第六名',
        no: '01|02|03|04|05|06|07|08|09|10',
        place: 5,
        cols: 1
      }, {
        title: '第七名',
        no: '01|02|03|04|05|06|07|08|09|10',
        place: 6,
        cols: 1
      }, {
        title: '第八名',
        no: '01|02|03|04|05|06|07|08|09|10',
        place: 7,
        cols: 1
      }, {
        title: '第九名',
        no: '01|02|03|04|05|06|07|08|09|10',
        place: 8,
        cols: 1
      }, {
        title: '第十名',
        no: '01|02|03|04|05|06|07|08|09|10',
        place: 9,
        cols: 1
      }],
      noBigIndex: 6,
      isButton: true
    }
  }
}
