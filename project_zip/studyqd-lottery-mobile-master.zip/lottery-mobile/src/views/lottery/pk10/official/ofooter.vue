<!-- Created By fx on 2017/9/26. -->
<template>
  <footer class="footer official-footer">
    <!-- 弹出层 -->
    <div v-if="showRandomBetPopover || showPopover" class="weui-mask_transparent"></div>

    <mode-popover :show="showPopover" @on-hide="onPopoverMenuHide" class="popover"></mode-popover>
    <random-bet-popover :show="showRandomBetPopover" @on-hide="onRandomBetPopoverHide"
                        class="random-bet-popover"></random-bet-popover>

    <!-- 设置区 -->
    <div class="set-group" flex="cross:center">
      <div class="double-mode" flex-box="0" flex="box:mean">
        <div flex="dir:left cross:center">
          <p class="multiple">
            <input type="number" v-model.number="defaultBet" @blur="validateBuyDouble"
                   oninput="if(value.length>4)value=value.slice(0,4)">
          </p>
          <div>倍</div>
        </div>
        <div flex="dir:left cross:center" @click="onChangeMode">
          <p flex="cross:center">
            <span>{{ modeName }}</span>
            <icon-svg icon-class="down"></icon-svg>
          </p>
        </div>
      </div>
      <!-- 返水设置 -->
      <div class="rebate-wrap" flex="dir:top main:center" flex-box="1">
        <div class="rebate-txt" flex="cross:center main:justify">
          <div v-if="rebateShow !== 2" align="right">{{computedRebateRate | formatNumToDecimal}} %</div>
          <div v-else align="right"></div>
          <div></div>
          <div>{{ rebateShow !== 2 ? '' : '赔率：' }}{{ compuetdRate.join(' | ') }}</div>
        </div>
        <div v-show="rebateShow !== 2" class="range-wrap" flex="cross:center main:right" ref="range" resetstyle>
          <icon-svg icon-class="circle-jian"></icon-svg>
          <vue-slider
            v-model="rangeValue"
            width="100%"
            height="10"
            :disabled="rebateShow === 1"
            :bgStyle="{backgroundColor: '#fff',boxShadow: 'inset 0.5px 0.5px 3px 1px rgba(0,0,0,.36)'}"
            :processStyle="{backgroundColor: 'rgb(255, 81, 81)'}"
            :sliderStyle="{backgroundColor: '#ff5151'}"
            :tooltip="false"
            :min="0"
            :max="maxSliderVal">
          </vue-slider>
          <!--<x-range class="range-bar" v-model="rangeValue" :min="0" :max="maxSliderVal" :rangeBarHeight="10"></x-range>-->
          <icon-svg icon-class="circle-jia"></icon-svg>
        </div>
      </div>
    </div>

    <!-- 按钮区 -->
    <div class="btn-group" flex="main:justify cross:center">
      <div v-if="isSelNum" @click="doClearLayout" class="btn btn-clear">
        <span>清空</span>
      </div>
      <div v-else @click="onRandomBet" class="btn btn-clear">
        <span>机选</span>
      </div>

      <div class="notes" flex="main:justify">
        <p>共<span>{{ betNumber }}</span>注</p>
        <p>共<span>{{ totalMoney }}</span>元</p>
      </div>
      <div class="btn btn-choice" @click="onBetCart">
        <span>选好了</span>
      </div>
    </div>
  </footer>
</template>

<script type="text/ecmascript-6">
  import { mapState, mapMutations, mapActions } from 'vuex'
  import ModePopover from 'views/common/modePopover'
  import RandomBetPopover from 'views/common/randomBetPopover'

  export default {
    data () {
      return {
        showPopover: false,
        showRandomBetPopover: false,
        modeName: '',
        defaultBet: 1,
        rangeValue: 0
      }
    },
    components: {ModePopover, RandomBetPopover},
    filters: {
      formatNumToDecimal (num) {
        return (num / 100).toFixed(1)
      }
    },
    computed: {
      // 返水点滚动条最大百分比,number
      maxSliderVal () {
        if (!this.currentPlay) return 1
        return this.currentPlay.rebateRate
      },
      computedRebateRate () {
        let val = this.rangeValue
        let newVal = (val / 100).toFixed(1) * 100
        return newVal.toFixed(0)
      },
      compuetdRate () { // 实时赔率
        if (!this.currentPlay) return []
        let max = this.currentPlay.maxPrize
        let min = this.currentPlay.minPrize
        let s = (this.rangeValue / 10).toFixed(0) * 10 // 处理小数点一位的精度问题
        let changedRate = max.map((i, index) => {
          let diff = max[index] - min[index]
          let b = (max[index] - (diff / this.maxSliderVal) * s) / 100 // 除100转成元
          b = b.toFixed(2)
          return b
        })
        return changedRate
      },
      ...mapState('pks', {
        currentPlay: state => state.currentPlay,
        isSelNum: state => state.isSelNum,
        betNumber: state => state.betNumber
      }),
      ...mapState('common', {
        buyDouble: state => state.buyDouble,
        modeA: state => state.modeA,
        rebateShow: state => state.rebateShow
      }),
      totalMoney () {
        const _tm = ((this.defaultBet || 1) * this.betNumber * this.modeA / 100).toFixed(2)
        return _tm
      }
    },
    methods: {
      onChangeMode () {
        this.showPopover = !this.showPopover
      },
      onPopoverMenuHide (data) {
        if (data) this.modeName = data.name
        this.delayExec(() => {
          this.showPopover = false
        })
      },
      onRandomBet () {
        this.showRandomBetPopover = !this.showRandomBetPopover
      },
      onRandomBetPopoverHide (n) {
        if (typeof n === 'number') { // 拿到需要随机的注数
          this.randomBet(n)
        }
        this.delayExec(() => {
          this.showRandomBetPopover = false
        })
      },
      delayExec (fn) {
        setTimeout(fn, 20)
      },
      onBetCart () {
        this.notice_addToCart(true)
      },
      randomBet (n) {
        this.randomBetList(n)
        // this.$router.push({ params: { sid: 'betCart' } }) // 跳转到购彩车
      },
      validateBuyDouble () {
        if (!this.defaultBet) this.defaultBet = 1 // 为空时 默认1
      },
      ...mapMutations('common', ['set_buyDouble', 'randomBetList']),
      ...mapMutations('pks', ['doClearLayout', 'set_rebateRate']),
      ...mapActions('common', ['notice_addToCart'])
    },
    created () {
    },
    watch: {
      currentPlay () {
        this.rangeValue = 0
      },
      defaultBet (val) {
        const patt = /^\+?[1-9][0-9]*$/
        let newVal
        if (patt.test(val)) {
          newVal = (val > 9999) ? 9999 : val
        }
        this.$nextTick(() => {
          this.set_buyDouble(newVal)
        })
      },
      rangeValue (val) {
        this.set_rebateRate(val)
      }
    }
  }
</script>
