/* eslint-disable */
const random = require('lodash/random')
export default {

  doSelectNumber (index, attribute, rowIndex) {
    switch (attribute) {
      case 'all':
        this.doSelectAll(index)
        break
      case 'big':
        this.doSelectBig(index)
        break
      case 'small':
        this.doSelectSmall(index)
        break
      case 'odd':
        this.doSelectOdd(index)
        break
      case 'even':
        this.doSelectEven(index)
        break
      case 'clear':
        this.doUnselectAll(index)
        break
      case 'single':
        this.doSelectSingle(index, rowIndex)
        break
    }
    // 计算注数
    this.calcNumber()
  },

  doSelectAll (index) {
    let row = this.currentLayout[index].no
    row.forEach(i => i.isSelected = 1)
  },
  doUnselectAll (index) {
    if (this.currentLayout[index].no) {
      let row = this.currentLayout[index].no
      row.forEach(i => i.isSelected = 0)
    }
  },
  doSelectBig (index) {
    this.doUnselectAll(index)
    let row = this.currentLayout[index].no
    let target = row.filter(i => i.number >= this.noBigIndex)
    target.forEach(i => i.isSelected = 1)
  },
  doSelectSmall (index) {
    this.doUnselectAll(index)
    let row = this.currentLayout[index].no
    let target = row.filter(i => i.number < this.noBigIndex)
    target.forEach(i => i.isSelected = 1)
  },
  doSelectOdd (index) {
    this.doUnselectAll(index)
    let row = this.currentLayout[index].no
    let target = row.filter((i, index) => index % 2 == 0)
    target.forEach(i => i.isSelected = 1)
  },
  doSelectEven (index) {
    this.doUnselectAll(index)
    let row = this.currentLayout[index].no
    let target = row.filter((i, index) => !(index % 2 == 0))
    target.forEach(i => i.isSelected = 1)
  },
  doSelectSingle (index, rowIndex) {
    let alias = this.currentPlay.alias
    let selected = this.currentLayout[index].no[rowIndex]
    selected.isSelected === 1 ? selected.isSelected = 0 : selected.isSelected = 1
  },
  doClearLayout () {
    let len = this.currentLayout.length
    for (let i = 0; i < len; i++) {
      this.doUnselectAll(i)
    }
  },
  doSelectRandom () {
    var mname = this.currentPlay.alias
    var otype = this.layoutType
    var data_sel = this.currentLayout
    var repeate = 1
    var repeatetmp = []

    if (otype == 'input') { // 输入框形式的检测
      this.allInputCode = [] // 清空随机号码
      nums = parseInt(mname.charAt(mname.length - 1))
      var s = ''
      var repeatetmp = []
      for (let j = 0; j < nums; j++) {
        if (repeate == 0) { // 号码不允许重复
          do {
            var index = Math.ceil(10 * Math.random())
            index < 10 ? index = '0' + index : index = '' + index
            if (!repeatetmp.includes(index)) {
              repeatetmp.push(index)
              break
            }
          } while (1)
        } else {
          var index = Math.ceil(10 * Math.random())
          index < 10 ? index = '0' + index : index = '' + index
        }
        s = s + index
      }
      this.allInputCode[0] = [s]
      let sss = s.split('').join('')
      return sss
    } else { // 其他选择号码形式[暂时就数字型和大小单双]
      this.doClearLayout() // 清除手动选择的号码
      this.betNumber = 0
      this.randomSelNum = []

      var nums = this.maxPlace
      var amin = []
      switch (mname) { // 根据玩法分类不同做不同处理
        case 'DWD': // 定位胆所有在一起特殊处理
          var weiNum = 10 // pk10
          var amin = Array(10)
          repeate = 1
          var j = Math.ceil(Math.random() * 100) % weiNum // 随机一位
          amin[j] = 1 // 随机一注
          break
        default: // 默认情况,有多少位选择多少位
          for (var j = 0; j <= nums; j++) {
            amin[j] = 1
          }
          break
      }
      var _this = this

      function genTempCode () {
        var tmp = []
        var repeatetmp = [] // 用于检查重复的数组
        _this.randomSelNum = []
        for (let i = 0; i < amin.length; i++) {
          /* 处理每一行数据 开始 */
          let min = _this.currentLayoutNum[i][0]
          let max = _this.currentLayoutNum[i][_this.currentLayoutNum[i].length - 1]
          var rowCode // 数组，保存每一行上的号码
          var len = amin[i] ? Number(amin[i]) : 0 // 如果amin[i]为undefined，则初始len为0，不进入循环
          do { // 确保一行上的随机数不重复
            rowCode = []
            for (let j = 0; j < len; j++) {
              let _random = random(min, max)
              _random = _random < 10 ? '0' + _random : '' + _random
              rowCode.push(_random)
              repeatetmp.push(_random)
            }
            let _set = Array.from(new Set(rowCode))
            if (_set.length == rowCode.length) break
          } while (true)
          /* 处理每一行数据 结束 */

          tmp.push(rowCode)
        }
        // 检查单注是否有重复号码
        // debugger
        if (repeate == 0) {
          repeatetmp.sort()
          let flg = ''
          for (let i of repeatetmp) {
            if (flg !== i) {
              flg = i
            } else {
              return genTempCode()
            }
          }
        }
        // 生成用于注数计算的数组
        tmp.forEach((i, idx) => {
          if (i.length) {
            // _this.randomSelNum.push(i.split(','))
            _this.randomSelNum.push(i)
          } else {
            _this.randomSelNum.push([]) // 添加个空数据，否则注数计算出错
          }
        })

        // 处理随机号码的显示格式
        let finalName
        switch (mname) {
          case 'DWD':
          case 'ZX2':
          case 'ZX3':
            finalName = tmp.join(',')
            break
          default:
            finalName = tmp.join(',')
            break
        }
        // debugger
        // 返回购买的号码
        return finalName
      }

      return genTempCode()
    }
  }
}
