<template>
  <div class="app-main lm-ssc">
    <!-- 头部 -->
    <sub-header :title="title"
                @on-click-title="onClickTitle"
                @show-popover-menu="showPopoverMenu"
                ref="header"
    >
    </sub-header>
    <div class="popover-menu">
      <z-popover-menu
        placement="right"
        :show="isShowPopoverMenu"
        @on-hide="onPopoverMenuHide">
      </z-popover-menu>
    </div>

    <!-- 主内容区 -->
    <div class="app-body" ref="appBody">
      <!-- 玩法-->
      <play-tab-list :show="showPlayTabList" @on-hide="hidePlayTabList"></play-tab-list>
      <!-- 拖拽 -->
      <drag-row ref="dragRow" :species="species"></drag-row>
      <!-- 选号 -->
      <play-area ref="lotContent"></play-area>
    </div>

    <!-- 底部 -->
    <pks-footer ref="footer"></pks-footer>
  </div>
</template>

<script type="text/ecmascript-6">
  import { mapState } from 'vuex'

  import SubHeader from '../../../common/subHeader'
  import PlayTabList from '../public/playTabList'
  import ZPopoverMenu from 'views/common/zPopoverMenu'
  import PlayArea from './playArea'
  import PksFooter from './ofooter'

  export default {
    data () {
      return {
        isShowPopoverMenu: false,
        showPlayTabList: false,
        species: {
          digits: 2,
          NumberDigits: 10
        }
      }
    },
    components: { SubHeader, PlayTabList, ZPopoverMenu, PlayArea, PksFooter },
    computed: {
      title () {
        if (this.playTabName && this.playName) {
          return this.playTabName + ' ' + this.playName
        }
        return ''
      },
      ...mapState('pks', {
        playTabName: state => state.playTabName,
        playName: state => state.playName,
        playId: state => state.ssc.playId
      })
    },
    methods: {
      onClickTitle () {
        this.showPlayTabList = !this.showPlayTabList
      },
      showPopoverMenu () {
        this.isShowPopoverMenu = !this.isShowPopoverMenu
      },
      onPopoverMenuHide () {
        this.delayExec(() => {
          this.isShowPopoverMenu = false
        })
      },
      hidePlayTabList () {
        this.delayExec(() => {
          this.showPlayTabList = false
        })
      },
      delayExec (fn) {
        setTimeout(fn, 20)
      },
      resetUI () { // 计算内容区域高度、投注列表高度
        this.delayExec(() => {
          const wH = window.innerHeight
          const wHeader = this.$refs.header.$el.offsetHeight
          const wFooter = this.$refs.footer.$el.offsetHeight
          this.$refs.appBody.style.minHeight = wH - (wHeader + wFooter) + 'px'
          this.$refs.lotContent.$el.style.marginTop = this.$refs.dragRow.$el.offsetHeight + 'px'
        })
      }
    },
    created () {
      this.resetUI()
    },
    mounted () {
      window.scrollTo(0, 0)
    },
    beforeDestroy () {
    }
  }
</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .app-body
    background #fff

  .popover-menu
    position fixed
    top 4rem
    right .3rem
    z-index 99
</style>
