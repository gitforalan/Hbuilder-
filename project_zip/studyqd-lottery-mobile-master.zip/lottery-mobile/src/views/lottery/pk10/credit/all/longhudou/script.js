import { mapState, mapMutations, mapGetters } from 'vuex'
import Layout from '../../../config/config_pks_credit'
import ZHFooter from '../../public/footer'
import BetConfirm from '../../public/betConfirm'
import * as API from 'api/wapi/front'

export default {
  name: 'longhudou',
  filters: {
    formatF2Y (num) {
      return (num / 100).toFixed(2)
    }
  },
  data () {
    return {
      rangeValue: 0,
      layout: [],
      hotList: [],
      singleMoney: 5,
      showPopover: false,
      chips: [{ isActive: false, value: '' }, { isActive: true, value: 5 }]
    }
  },
  components: { ZHFooter, BetConfirm },
  methods: {
    getLotteryPlayOdds () {
      let query = {
        lotteryTypeId: 14,
        playTabMode: 2
      }
      API.getLotteryPlayOdds(query).then(res => {
        let p
        for (let i = 0; i < res.data.playTabList.length; i++) {
          if (res.data.playTabList[i].playTabId === this.playTabId) {
            p = res.data.playTabList[i].playTypeList
          }
        }
        this.layout = this.doMergeData(p)
        this.hotList = this.recombination(this.layout)
      })
    },
    // 处理配置文件数据
    doHandleData () {
      return Layout[3].playTypeList.map(j => {
        j.playList.map(k => {
          k.isactive = 0
          k.money = 0
          k.maxPrize = 0
          k.minPrize = 0
          k.rebateRate = 0
          k.computedMaxPrize = 0
          return k
        })
        return j
      })
    },
    // 根据接口数据，更新本地数据
    doMergeData (data) {
      let p = data
      return this.layout.map(i => {
        i.playList.map(m => {
          p.map(n => {
            let targetPlay = n.playList.find(x => x.playId === m.playId)
            if (targetPlay) {
              m.maxPrize = targetPlay.maxPrize
              m.minPrize = targetPlay.minPrize
              m.rebateRate = targetPlay.rebateRate
              m.computedMaxPrize = targetPlay.maxPrize
            }
          })
        })
        return i
      })
    },
    doSelectBoal (item, bool) {
      item.isactive = bool
      if (bool === 1) {
        if ((item.money + this.singleBetMoney) > 999999) {
          return
        } else {
          item.money += this.singleBetMoney
        }
      } else item.money = 0
    },
    doUnselectAll () {
      for (let i = 0; i < this.hotList.length; i++) {
        this.hotList[i].forEach(j => {
          if (j.playList) {
            j.playList.forEach(k => {
              k.isactive = 0
              k.money = 0
            })
          }
        })
      }
    },
    recombination (arr) {
      let newArr = []
      for (let i = 0; i < arr.length; i++) {
        let at = []
        if (i % 2 === 0) {
          at.push(arr[i])
          if (arr[i + 1]) {
            at.push(arr[i + 1])
          } else {
            at.push([])
          }
          newArr.push(at)
        }
      }
      return newArr
    },
    ...mapMutations('pks', [
      'pks_flattenBetList',
      'setClearNow',
      'setBetNow',
      'updateMaxSliderVal',
      'updateInputStyleFooter',
      'updateShowBetConfirm',
      'updateSelectedNumber'
    ])
  },
  created () {
    this.layout = this.doHandleData()
    this.hotList = this.recombination(this.layout)
  },
  mounted () {
    this.getLotteryPlayOdds()
  },
  computed: {
    ...mapState('pks', [
      'playTabId',
      'playTabName',
      'clearNow',
      'singleBetMoney',
      'rebateRate',
      'betNow',
      'isShowBetConfirm'
    ]),
    ...mapGetters('common', [
      'lotteryId'
    ]),
//       已选择的球
    selectedBoal () {
      let ret = []
      this.layout.forEach(i => {
        let tmp = i.playList.filter(j => j.isactive === 1)
        if (tmp.length) ret.push(tmp)
      })
      return [].concat(...ret)
    },
//       计算后的注单信息
    flattenBetList () {
      return this.selectedBoal.map(j => ({
        playId: j.playId,
        imp: 0,
        money: j.money,
        moneyUnit: 3,
        playName: j.playName,
        buyCode: j.playName,
        buyCodeFront: j.playName,
        singleMoney: j.money * 100,
        rebateRate: this.rebateRate,
        playTypeName: this.playTabName,
        computedMaxPrize: j.computedMaxPrize // 前端显示
      }))
    },
    totalBetMoney () {
      return this.selectedBoal.map(i => i.money).reduce((a, b) => a + b, 0)
    },
    // 返水点滚动条最大百分比
    maxSliderVal () {
      if (this.layout.length) {
        return +this.layout[0].playList[0].rebateRate
      }
    }
  },
  watch: {
    // 根据选择的球，拼接号码
    selectedBoal (nval) {
      this.updateSelectedNumber(nval.map(i => i.playName).join(','))
    },
    // 实时检查当前页面所有注单信息,产生变化后将变化后的注单信息推入store保存
    flattenBetList (nval) {
      this.pks_flattenBetList({ flattenBetList: nval })
    },
    clearNow (nval) {
      if (nval) this.doUnselectAll()
      this.setClearNow(false)
    },
    betNow (nval) {
      if (nval) {
        this.getLotteryUserBet()
        this.setBetNow(false)
      }
    },
    maxSliderVal (nval) {
      this.updateMaxSliderVal(nval)
    },
    // 监测返水，实时计算前台奖金
    rebateRate (nVal) {
      this.layout.forEach(i => {
        i.playList.forEach(j => {
          let max = j.maxPrize
          let diff = j.maxPrize - j.minPrize
          let t = (diff / this.maxSliderVal) * nVal
          let b = (max - t).toFixed(0)
          j.computedMaxPrize = b
        })
      })
    }
  }
}
