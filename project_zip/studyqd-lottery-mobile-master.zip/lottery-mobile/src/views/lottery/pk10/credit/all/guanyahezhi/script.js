import commonEd from '../../public/mixin'
import Layout from '../../../config/config_pks_credit'

export default {
  name: 'guanyahezhi',
  mixins: [commonEd],
  methods: {
    // 处理配置文件数据
    doHandleData () {
      return Layout[1].playTypeList.map(j => {
        j.playList.map(k => {
          k.isactive = 0
          k.money = 0
          k.maxPrize = 100
          k.minPrize = 0
          k.rebateRate = 0
          k.computedMaxPrize = 0
          return k
        })
        return j
      })
    }
  }
}
