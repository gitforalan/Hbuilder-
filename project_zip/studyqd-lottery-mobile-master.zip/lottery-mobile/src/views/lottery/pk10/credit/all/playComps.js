/**
 * Created by fx on 2017/8/28.
 */
const filePath = 'lottery/pk10/credit/all/'
const hotLoad = require('@/utils/import_' + process.env.NODE_ENV)
const ZhengHe = hotLoad(filePath + 'zhenghe/index')
const GuanYaHeZhi = hotLoad(filePath + 'guanyahezhi/index')
const GuanYaZuHe = hotLoad(filePath + 'guanyazuhe/index')
const LongHuDou = hotLoad(filePath + 'longhudou/index')

export default {
  ZhengHe,
  GuanYaHeZhi,
  GuanYaZuHe,
  LongHuDou
}
