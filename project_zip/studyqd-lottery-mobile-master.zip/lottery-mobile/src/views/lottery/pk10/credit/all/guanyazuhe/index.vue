<template>
  <section class="lm-content">
    <div class="lm-selector" v-for="(item, row) in layout">
      <div class="tips"><icon-svg icon-class="shou"></icon-svg>点击：筹码下注 <span>长按：筹码删除</span></div>

      <div class="tag-top" flex="">
        <div flex-box="1" class="tag-line line-down line-top">
          <span>{{item.playList[0].computedMaxPrize / 100}}</span>
        </div>
      </div>
      <div class="credit-wrap" flex="main:justify">
        <div flex-box="1" class="credit-con reset-h">
          <ul flex="box:mean" class="num">
            <li v-for="t in item.playList" :class="{active: t.isactive}">
              <v-touch @tap="doSelectBoal(t, 1)"

                       @pressup="doSelectBoal(t, 0)">
                <span>{{t.playName}}</span>
                <p :class="{'rect':t.money > 9999}">{{t.money}}</p>
              </v-touch>
            </li>
          </ul>
        </div>
      </div>

      <div class="tag-bottom" flex="">
        <div flex-box="1" class="tag-line line-down line-top">
          <span>{{item.playList[0].computedMaxPrize / 100}}</span>
        </div>
      </div>
    </div>

    <!-- 下注确认 -->
    <BetConfirm
      v-if="isShowBetConfirm"
      :top="marginTop"
    />
    <!-- 底部 -->
    <ZHFooter/>

  </section>
</template>

<script type="text/ecmascript-6">
  import ed from './script'

  export default ed
</script>

<style scoped lang="stylus">
  @import './style.styl'
</style>
