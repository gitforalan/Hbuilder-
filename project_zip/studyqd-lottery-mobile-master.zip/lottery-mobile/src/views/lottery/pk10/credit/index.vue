<!--
  -- pks 信用玩法
  -->
<template>
    <component :is="currentPlay" v-if="currentPlay">
      <!-- 非活动组件将被缓存！ -->
    </component>
</template>

<script type="text/ecmascript-6">
  import { mapState } from 'vuex'
  import playComps from './all/playComps'

  const TAB_ID = {
    ZHENGHE: 14210,  // 整合
    GUANYAHEZHI: 14211, // 冠亚和值
    GUANYAZUHE: 14212, // 冠亚组合
    LONGHUDOU: 14214  // 龙虎斗
  }

  export default {
    data () {
      return {
        currentPlay: null,
        marginTop: 0
      }
    },
    components: playComps,
    computed: {
      ...mapState('pks', {
        playTabId: state => state.playTabId
      }),
      ...mapState('common', {
        currentIssue: state => state.issue // 临时
      })
    },
    methods: {
      /* 设置玩法 */
      setCurrentPlay (playTabId) {
        switch (playTabId) {
          case TAB_ID.ZHENGHE:
            this.currentPlay = playComps.ZhengHe
            break
          case TAB_ID.GUANYAHEZHI:
            this.currentPlay = playComps.GuanYaHeZhi
            break
          case TAB_ID.GUANYAZUHE:
            this.currentPlay = playComps.GuanYaZuHe
            break
          case TAB_ID.LONGHUDOU:
            this.currentPlay = playComps.LongHuDou
            break
          default:
            this.currentPlay = playComps.ZhengHe // 默认 整合玩法
        }
      }
    },
    created () {
      this.setCurrentPlay()
    },
    watch: {
      /* 监听玩法切换 */
      playTabId (nval) {
        this.setCurrentPlay(nval)
      }
    }
  }
</script>

<style scoped></style>
