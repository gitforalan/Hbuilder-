import { mapState, mapMutations, mapActions } from 'vuex'
import PlayTabList from './public/playTabList'
import SubHeader from '@/views/common/subHeader'
import ZPopoverMenu from '@/views/common/zPopoverMenu'
import * as API from 'api/wapi/front'

// 特码
const tema = () => import('./all/tema')
// 混合
const hunhe = () => import('./all/hunhe')

export default {
  name: 'PCDD',
  methods: {
    getLotteryCurrentInfo () {
      if (this.lotteryId === -1) return
      const query = {
        lotteryId: this.lotteryId
      }
      API.getLotteryCurrentInfo(query).then(res => {
        if (res.code === 0) {
          this.currentInfo = res.data
        } else {
          console.log('getLotteryCurrentInfo:', res.data.desc)
        }
      })
    },
    setCurrentPlay (id) {
      let map = {
        1: hunhe, // 混合
        2: tema // 特码
      }
      this.currentPlay = map[id]
    },
    onClickTitle () {
      if (this.isShowBack) return // 在弹出页时屏蔽标题事件
      this.showPlayTabList = !this.showPlayTabList
    },
    showPopoverMenu () {
      this.isShowPopoverMenu = !this.isShowPopoverMenu
    },
    onPopoverMenuHide () {
      this.delayExec(() => {
        this.isShowPopoverMenu = false
      })
    },
    hidePlayTabList () {
      this.delayExec(() => {
        this.showPlayTabList = false
      })
    },
    delayExec (fn) {
      setTimeout(fn, 20)
    },
    getMarginTop () {
      this.marginTop = this.$refs.currentInfo.$el.offsetHeight
    },
    ...mapActions('common', [
      'resetCommonState'
    ]),
    ...mapMutations('pcdd', [
      'updateShowBetConfirm'
    ])
  },
  watch: {
    playTabId (nval) {
      this.setCurrentPlay(nval)
    },
    noticeIssue (nval) {
      if (nval) {
        let options = {
          type: 'text',
          isShowMask: false,
          time: 2000,
          text: `第 ${this.currentIssue} 期已停止销售`
        }
        this.$vux.toast.show(options)
      }
    }
  },
  computed: {
    isShowBack () {
      // 弹出购票车隐藏左上角回退 '<' 按钮
      return this.isShowBetConfirm
    },
    ...mapState('pcdd', [
      'playTabName',
      'playTabId'
    ]),
    ...mapState('common', [
      'lotteryTypeId',
      'lotteryId',
      'noticeIssue'
    ]),
    ...mapState('common', {
      currentIssue: state => state.issue
    }),
    ...mapState('ui', {
      showPopoverPage: state => state.showPopoverPage
    })
  },
  data () {
    return {
      isShowPopoverMenu: false,
      showPlayTabList: false,
      // rangeValue: 0,
      // playTabList: [],
      // value: [true],
      // options: [],
      marginTop: 0,
      currentInfo: null, // 当前彩种详情
      currentPlay: null, // 当前玩法
      typeId: 15
    }
  },
  components: { SubHeader, PlayTabList, ZPopoverMenu },
  created () {
    this.getLotteryCurrentInfo()
    this.setCurrentPlay(1)
  },
  mounted () {
    this.$nextTick(() => {
      this.getMarginTop()
    })
    window.scrollTo(0, 0)
  },
  beforeDestroy () {
    this.resetCommonState()
    this.updateShowBetConfirm(false)
  }
}
