<template>
  <div class="app-main lm-6hc" >
    <!-- 头部 -->
    <sub-header
      :title="playTabName"
      :showBack="!isShowBack"
      :type="isShowBack ? playTabName : ''"
      @on-click-title="onClickTitle"
      @show-popover-menu="showPopoverMenu">
    </sub-header>
    <div class="popover-menu">
      <z-popover-menu
        placement="right"
        :show="isShowPopoverMenu"
        @on-hide="onPopoverMenuHide">
      </z-popover-menu>
    </div>
    <!-- 通用区 -->
    <!-- 彩期 -->
    <current-info :typeId="typeId" ref="currentInfo"></current-info>

    <!-- 主内容区 -->
    <div class="app-body" ref="appBody">
      <!-- 玩法-->
      <play-tab-list :show="showPlayTabList" @on-hide="hidePlayTabList"></play-tab-list>
      <!-- 选号 -->
      <div
        ref="lotContent"
        :is="currentPlay"
        :marginTop="marginTop"
        :currentIssue="currentIssue"
        />
    </div>

    <!-- 弹出页 -->
    <popover-page v-show="showPopoverPage"></popover-page>
  </div>
</template>

<script src="./index_script.js"></script>
<style scoped lang="styl" src="./index_style.styl"></style>
