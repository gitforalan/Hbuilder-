export default [{
  id: 1,
  playTabName: '混合'
}, {
  id: 2,
  playTabName: '特码'
} ]
