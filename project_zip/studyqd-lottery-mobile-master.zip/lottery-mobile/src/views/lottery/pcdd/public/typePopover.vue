<template>
  <div class="mid-pop" v-click-outside="onClickedOutside">
    <div class="selected" flex="" @click="doToggleMenu">
      <span flex-box="1" class="value">{{defaultValue}}</span>
      <icon-svg icon-class="down" flex-box="0"></icon-svg>
    </div>
    <ul class="z-popover" align="center" v-show="show">
      <li v-for="(item, index) in types" :class="{active: defaultValue === item.name}" @click="doSelectOne(item)">
        <p> {{ item.name }}</p>
      </li>
    </ul>
  </div>
</template>

<script type="text/ecmascript-6">
import ClickOutside from 'vux/src/directives/click-outside'

export default {
  name: 'mid-pop',
  data () {
    return {
      show: false
    }
  },
  props: {
    types: Array,
    defaultValue: [String, Number]
  },
  computed: {
  },
  methods: {
    onClickedOutside () {
      this.$nextTick(() => {
        this.show = false
      })
    },
    doToggleMenu () {
      this.show = !this.show
    },
    doSelectOne (item) {
      if (item.name === this.defaultValue) return
      this.$emit('on-hide', item)
      this.show = false
    }
  },
  directives: {
    ClickOutside
  },
  created () {
  }
}
</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .mid-pop
    width 100%
    line-height 28px
    box-sizing border-box
    position relative
    .selected
      border 1px solid $color-border
      padding 0 3px
      .value
        text-align center
      i
        vertical-align middle
  ul.z-popover
    min-width rem(126)
    background-color rgba(0, 0, 0, .93)
    border-radius 0
    margin-top .7rem
    position absolute
    left 0
    right 0
    z-index 101
    li
      width 100%
      height rem(55)
      line-height rem(55)
      font-size rem(28)
      color $color-white
      &.active
        background $color-red
        color: $color-white
        p
          border-bottom 0
      &.prev p
        border-bottom 0
      p
        margin 0 rem(9)
        border-bottom 1px solid $color-white
        box-sizing border-box
    &:before
      content ""
      border-color rgba(0, 0, 0, .93) transparent
      border-style solid
      display block
      height 0
      font-size 0
      line-height 0
      width 0
      border-width 0 .75rem .75rem
      position absolute
      z-index 12
      top -.7rem
      right 7px
      zoom 1

    &.right:before
      transform translate3D(10%, 0, 0) rotate(180deg)

    &.left:before
      transform translate3D(-90%, 0, 0) rotate(180deg)

</style>
