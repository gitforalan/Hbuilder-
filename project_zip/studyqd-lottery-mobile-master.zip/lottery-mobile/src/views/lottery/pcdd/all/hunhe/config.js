export default [{
  'playTabId': 15010, // 随便配的，没用到
  'playTabName': '混合',
  'playTypeList': [{
    'playTypeId': 1501001, // 随便配的，没用到
    'playTypeName': '混合',
    'playListGroup': [{
      'playListGroupName': '混合',
      'playList': [
        { 'playId': 152111010, 'name': '大' },
        { 'playId': 152111011, 'name': '小' },
        { 'playId': 152111012, 'name': '单' },
        { 'playId': 152111013, 'name': '双' }
      ]
    }, {
      'playListGroupName': '',
      'playList': [
        { 'playId': 152111018, 'name': '大单' },
        { 'playId': 152111019, 'name': '小单' },
        { 'playId': 152111016, 'name': '大双' },
        { 'playId': 152111017, 'name': '小双' }
      ]
    }, {
      'playListGroupName': '',
      'playList': [
        { 'playId': 152111014, 'name': '极大' },
        { 'playId': 152111015, 'name': '极小' }
      ]
    }, {
      'playListGroupName': '',
      'playList': [
        { 'playId': 152131010, 'name': '红波' },
        { 'playId': 152131011, 'name': '蓝波' },
        { 'playId': 152131012, 'name': '绿波' },
        { 'playId': 152121010, 'name': '豹子' }
      ]
    }
    ]
  }]
}]
