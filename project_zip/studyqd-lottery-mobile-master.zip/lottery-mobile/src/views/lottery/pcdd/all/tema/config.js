export default [{
  'playTabId': 15011, // 随便配的，没用到
  'playTabName': '特码',
  'playTypeList': [{
    'playTypeId': 1501101, // 随便配的，没用到
    'playTypeName': '特码',
    'playListGroup': [{
      'playListGroupName': '特码',
      'playList': [
        { 'playId': 152101010, 'name': '0' },
        { 'playId': 152101011, 'name': '1' },
        { 'playId': 152101012, 'name': '2' },
        { 'playId': 152101013, 'name': '3' },
        { 'playId': 152101014, 'name': '4' },
        { 'playId': 152101015, 'name': '5' },
        { 'playId': 152101016, 'name': '6' },
        { 'playId': 152101017, 'name': '7' },
        { 'playId': 152101018, 'name': '8' },
        { 'playId': 152101019, 'name': '9' },
        { 'playId': 152101020, 'name': '10' },
        { 'playId': 152101021, 'name': '11' },
        { 'playId': 152101022, 'name': '12' },
        { 'playId': 152101023, 'name': '13' },
        { 'playId': 152101024, 'name': '14' },
        { 'playId': 152101025, 'name': '15' },
        { 'playId': 152101026, 'name': '16' },
        { 'playId': 152101027, 'name': '17' },
        { 'playId': 152101028, 'name': '18' },
        { 'playId': 152101029, 'name': '19' },
        { 'playId': 152101030, 'name': '20' },
        { 'playId': 152101031, 'name': '21' },
        { 'playId': 152101032, 'name': '22' },
        { 'playId': 152101033, 'name': '23' },
        { 'playId': 152101034, 'name': '24' },
        { 'playId': 152101035, 'name': '25' },
        { 'playId': 152101036, 'name': '26' },
        { 'playId': 152101037, 'name': '27' }
      ]
    }, {
      'playListGroupName': '特码包三',
      'playList': [
        { 'playId': 152101038, 'name': '' }
      ]
    }
    ]
  }]
}]
