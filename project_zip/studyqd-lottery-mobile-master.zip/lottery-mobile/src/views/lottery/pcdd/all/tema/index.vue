<template>
  <section class="lm-content" :style="{marginTop:marginTop+'px'}">
    <div flex="main:justify cross:center">
      <!--摇一摇-->
      <!-- <shake></shake> -->
      <!--冷热-->
      <!-- <return-cart></return-cart> -->
    </div>
    <!--长牌-->
    <div class="lm-selector">
      <div class="tips">
        <icon-svg icon-class="shou"></icon-svg>
        点击：筹码下注
        <span>长按：筹码删除</span>
      </div>
      <template v-if="layout.length">
        <!-- 特码 -->
        <div class="credit-wrap" flex="main:justify">
          <div flex-box="0" class="credit-unit">{{layout[0].playListGroupName}}</div>
          <div flex-box="1" class="credit-con">
            <ul flex="main:left" class="num">
              <li v-for="t in layout[0].playList">
                <v-touch @tap="doSelectBoal(t,1)" @pressup="doSelectBoal(t,0)"  style="height:100%">
                  <span class="boal" :class="{active:t.isactive}">
                    <div :class="doGenClass(t.name)">{{t.name}}</div>
                    <div class="prize">{{t.computedMaxPrize | formatF2Y}}</div>
                    <span class="bet-pop" :class="{'rect':t.money > 9999}">{{t.money}}</span>
                  </span>
                </v-touch>
              </li>
            </ul>
          </div>
        </div>
        <!-- 特码包三 -->
        <template v-if="tmb3">
          <!-- 赔率 -->
          <div class="tag-top" flex="">
            <div class="tag-left" flex-box="0"></div>
            <div flex-box="1" class="tag-line line-down line-top">
              <span>{{tmb3.computedMaxPrize | formatF2Y}}</span>
            </div>
          </div>
          <!-- 球 -->
          <div class="credit-wrap" flex="main:justify">
            <div flex-box="0" class="credit-unit">{{layout[1].playListGroupName}}</div>
            <div flex-box="1" class="credit-con">
              <div class="tmb3" :class="{active:tmb3.isactive}">
                <div flex="main:justify box:mean">
                  <div class="boal" :class="doGenClass(pos1.join(''))">
                    <div flex="main:justify box:mean"  @click="showPos1 = true">
                      <div>{{pos1.join('')}}</div>
                      <div class="iconsanj"><icon-svg icon-class="bgicondown"></icon-svg></div>
                    </div>
                    <popup-picker :show.sync="showPos1" :show-cell="false" :data="[tmOptions]" v-model="pos1"></popup-picker>
                  </div>
                  <div class="boal" :class="doGenClass(pos2.join(''))">
                    <div flex="main:justify box:mean" @click="showPos2 = true">
                      <div>{{pos2.join('')}}</div>
                      <div class="iconsanj"><icon-svg icon-class="bgicondown"></icon-svg></div>
                    </div>
                    <popup-picker :show.sync="showPos2" :show-cell="false" :data="[tmOptions]" v-model="pos2"></popup-picker>
                  </div>
                  <div class="boal delete-marg-r" :class="doGenClass(pos3.join(''))">
                    <div flex="main:justify box:mean" @click="showPos3 = true">
                      <div>{{pos3.join('')}}</div>
                      <div class="iconsanj"><icon-svg icon-class="bgicondown"></icon-svg></div>
                    </div>
                    <popup-picker :show.sync="showPos3" :show-cell="false" :data="[tmOptions]" v-model="pos3"></popup-picker>
                  </div>
                </div>
                <div class="bet-pop">
                  <v-touch @tap="doSelectTmb3" @pressup="doUnselectTmb3">
                    {{tmb3.money}}
                  </v-touch>
                </div>
              </div>
            </div>
          </div>
        </template>

      </template>

    </div>
    <!-- 底部 -->
    <PcddFooter/>
    <!-- 下注确认 -->
    <BetConfirm v-if="isShowBetConfirm" :top="marginTop" />
  </section>
</template>

<script src="./script.js"></script>
<style scoped lang="stylus" src="./style.styl"></style>
