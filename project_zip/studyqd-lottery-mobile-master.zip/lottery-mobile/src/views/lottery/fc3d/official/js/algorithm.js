/* eslint-disable */
import { accMul, Combination, getCombination } from '@/utils/lotteryUtil.js'
import each from 'lodash/each'

export default {
  /* 计算实时注数 */
  calcNumber () {
    let loType = this.layoutType
    if (loType == 'input') {
      this._input_deal()
      this.betNumber = this.checkInputNum()
    } else {
      this.betNumber = this.checkSelectedNum()
    }
    return this.betNumber
  },
  // 输入号码合法性检测
  _input_deal () { // all the original input in here
    // debugger
    var s = this.currentLayout
    var methodname = this.currentPlay.alias

    let quanjiao = (obj) => {
      if (obj.length > 0) {
        for (var i = obj.length - 1; i >= 0; i--) {
          let unicode = obj.charCodeAt(i)
          if (unicode > 65280 && unicode < 65375) {
            this.$common.toast('不能输入全角字符，请输入半角字符', 'warning')
            s = obj.substr(0, i)
          }
        }
      }
    }
    quanjiao(s)
    // s = s.replace(/[^\s\r,;，；　０１２３４５６７８９0-9]/g, "").trim();
    s = s.replace(/[^\s\r,;，；　０１２３４５６７８９0-9]/g, '')
    this.currentLayout = s
    // var m = s;
    switch (methodname) {
      default: s = s.replace(/[\s\r,;，；　]/g, '|').replace(/(\|)+/g, '|')
        break
    }
    s = s.replace(/０/g, '0')
      .replace(/１/g, '1')
      .replace(/２/g, '2')
      .replace(/３/g, '3')
      .replace(/４/g, '4')
      .replace(/５/g, '5')
      .replace(/６/g, '6')
      .replace(/７/g, '7')
      .replace(/８/g, '8')
      .replace(/９/g, '9')
    if (s == '') {
      this.currentLayout = '' // 清空数据
      this.allInputCode[0] = ''
    } else {
      this.allInputCode[0] = s.split('|')
    }
    // return m;
  },

  /**
   * 号码检测
   * @param  {Number} l     [号码长度]
   * @param  {Boolean} e    [是否返回非法号码，true是,false返回合法注数]
   * @param  {Function} fun [对每个号码的附加检测]
   * @param  {Boolean} sort [是否对每个号码排序]
   * @return {Number}
   * 注意：这个函数有一个额外的作用，记录了当前输入的合法和不合法的号码
   */
  _inputCheck_Num (l, e, fun, sort) {
    var data_sel = this.allInputCode
    var nums = data_sel[0].length
    var error = []
    var newsel = []
    var partn = ''

    l = parseInt(l, 10)
    // debugger
    switch (l) {
      case 2:
        partn = /^[0-9]{2}$/
        break
      case 4:
        partn = /^[0-9]{4}$/
        break
      case 5:
        partn = /^[0-9]{5}$/
        break
      case 6:
        partn = /^[0-9]{6}$/
        break
      default:
        partn = /^[0-9]{3}$/
        break
    }

    fun = typeof fun === 'function' ? fun : function (s) {
      return true
    }
    var _this = this
    each(data_sel[0], function (n, i) {
      n = n.trim()
      if (partn.test(n) && fun(n, l)) { // 合格号码
        if (sort) {
          if (n.indexOf(' ') == -1) {
            n = n.split('')
            n.sort(_this._SortNum)
            n = n.join('')
          } else {
            n = n.split(' ')
            n.sort(_this._SortNum)
            n = n.join(' ')
          }
        }
        data_sel[0][i] = n
        newsel.push(n)
      } else { // 不合格则注数减
        if (n.length > 0) {
          error.push(n)
        }
        nums = nums - 1
      }
    })
    // 保存临时数据，
    // 下注时，直接提交有效号码
    _this.validInputCode = [].concat(newsel)
    _this.invalidInputCode = [].concat(error)
    // debugger
    /* if (e == true) {
      data_sel[0] = newsel;
      return error;
    } */
    return nums
  },
  _SortNum (a, b) { // 数字大小排序
    let loType = this.layoutType
    if (loType != 'input') {
      a = a.replace(/豹子/g, 0).replace(/顺子/g, 1).replace(/对子/g, 2)
      a = a.replace(/大/g, 0).replace(/小/g, 1).replace(/单/g, 2).replace(/双/g, 3).replace(/\s/g, '')
      b = b.replace(/豹子/g, 0).replace(/顺子/g, 1).replace(/对子/g, 2)
      b = b.replace(/大/g, 0).replace(/小/g, 1).replace(/单/g, 2).replace(/双/g, 3).replace(/\s/g, '')
    }
    a = parseInt(a, 10)
    b = parseInt(b, 10)
    if (isNaN(a) || isNaN(b)) {
      return true
    }
    return (a - b)
  },
  // 根据玩法，返回注数
  checkInputNum () {
    let tmp_nums = 1
    let mname = this.currentPlay.alias
    let data_sel = this.allInputCode
    let isrx = this.currentPlay.isrx
    let max_place = this.maxPlace
    let minchosen = this.minChosen
    let selposition = this.selectedPosition
    // debugger
    /** ******** 验证号码合法性 ***********/
    var _HHZXcheck = function (n, len) { // 混合组选合法号码检测，合法返回TRUE，非法返回FALSE,n号码，len号码长度
      if (len == 2) { // 两位
        var a = ['00', '11', '22', '33', '44', '55', '66', '77', '88', '99']
      } else { // 三位[默认]
        var a = ['000', '111', '222', '333', '444', '555', '666', '777', '888', '999']
      }
      n = n.toString()

      if (a.includes(n) == false) { // 不在非法列表中
        return true
      }
      return false
    }

    var _ZUSDScheck = function (n, len) { // 组三单式合法号码检测，合法返回TRUE，非法返回FALSE,n号码，len号码长度
      if (len != 3) {
        return false
      }
      var first = ''
      var second = ''
      var third = ''
      var i = 0
      for (i = 0; i < len; i++) {
        if (i == 0) {
          first = n.substr(i, 1)
        }
        if (i == 1) {
          second = n.substr(i, 1)
        }
        if (i == 2) {
          third = n.substr(i, 1)
        }
      }
      if (first == second && second == third) {
        return false
      }
      if (first == second || second == third || third == first) {
        return true
      }
      return false
    }

    var _ZULDScheck = function (n, len) { // 组六单式合法号码检测，合法返回TRUE，非法返回FALSE,n号码，len号码长度
      if (len != 3) {
        return false
      }
      var first = ''
      var second = ''
      var third = ''
      var i = 0
      for (i = 0; i < len; i++) {
        if (i == 0) {
          first = n.substr(i, 1)
        }
        if (i == 1) {
          second = n.substr(i, 1)
        }
        if (i == 2) {
          third = n.substr(i, 1)
        }
      }
      if (first == second || second == third || third == first) {
        return false
      } else {
        return true
      }
      return false
    }
    /** ******** 根据玩法返回注数 ***********/
    if (data_sel[0].length > 0) { // 如果输入的有值
      switch (mname) {
        case 'ZX5':
          return this._inputCheck_Num(5, false)
        case 'ZX4':
          return this._inputCheck_Num(4, false)
        case 'ZX3':
        case 'ZXDS3':
          return this._inputCheck_Num(3, false)
        case 'ZUS': // 组三单式
          var nums = this._inputCheck_Num(3, false, _ZUSDScheck, true)
          if (isrx == 1) { // 任选玩法：考虑选择的位置
            nums *= selposition.length == 0 ? 0 : Combination(selposition.length, 3)
          }
          return nums
        case 'ZUL': // 组六单式
          var nums = this._inputCheck_Num(3, false, _ZULDScheck, true)
          if (isrx == 1) { // 任选玩法：考虑选择的位置
            nums *= selposition.length == 0 ? 0 : Combination(selposition.length, 3)
          }
          return nums
        case 'HHZX': // 混合组选
          var nums = this._inputCheck_Num(3, false, _HHZXcheck, true)
          if (isrx == 1) { // 任选玩法：考虑选择的位置
            nums *= selposition.length == 0 ? 0 : Combination(selposition.length, 3)
          }
          return nums
        case 'ZX2': // 直选二
          return this._inputCheck_Num(2, false)
        case 'ZU2': // 组选二
          var nums = this._inputCheck_Num(2, false, _HHZXcheck, true)
          if (isrx == 1) { // 任选玩法：考虑选择的位置
            nums *= selposition.length == 0 ? 0 : Combination(selposition.length, 2)
          }
          return nums
        case 'RZX2': // 任选二直选单式
        case 'RZX3': // 任选三直选单式
        case 'RZX4': // 任选四直选单式
          var sellen = mname.substring(mname.length - 1)
          nums = this._inputCheck_Num(sellen, false)
          nums *= selposition.length == 0 ? 0 : Combination(selposition.length, sellen)
          return nums
        case 'BJZ2':
          return _inputCheckBjscNum(4, true)
        case 'BJZ3':
          return _inputCheckBjscNum(6)
        default:
          // debugger
          break
      }
    } else {
      return 0
    }
  },
  /*  以上是输入型注数的检测和计算 */

  // 选择型注数计算
  checkSelectedNum (randomSelNum) {
    // let nums = 0
    let tmp_nums = 1
    let mname = this.currentPlay.alias
    let data_sel = randomSelNum || this.currentSelNumArr
    // debugger
    let isrx = this.currentPlay.isrx
    let max_place = this.maxPlace
    let minchosen = this.minChosen
    let selposition = this.selectedPosition
    // 根据玩法分类不同做不同处理
    switch (mname) {
      case 'ZH5': // 组合五
      case 'ZH4':
      case 'ZH3':
        var _num = 0
        for (let i = 0; i <= max_place; i++) {
          if (data_sel[i].length == 0) { // 有位置上没有选择
            tmp_nums = 0
            break
          }
          tmp_nums = accMul(tmp_nums, data_sel[i].length)
        }
        _num = tmp_nums * parseInt(mname.charAt(mname.length - 1))
        return _num

      case 'WXZU120': // 五星组选120
        var _num = 0
        var s = data_sel[0].length
        if (s > 4) { // 必须选5位或者以上
          _num += Combination(s, 5)
        }
        return _num
      case 'WXZU60':
      case 'WXZU30':
      case 'WXZU20':
      case 'WXZU10':
      case 'WXZU5':
        var _num = 0
        if (data_sel[0].length >= minchosen[0] && data_sel[1].length >= minchosen[1]) {
          var h = Array.intersect(data_sel[0], data_sel[1]).length // 交叉检测
          tmp_nums = Combination(data_sel[0].length, minchosen[0]) * Combination(data_sel[1].length, minchosen[1])
          if (h > 0) {
            // C(m,1)*C(n,3)-C(h,1)*C(n-1,2)
            if (mname == 'WXZU60') {
              tmp_nums -= Combination(h, 1) * Combination(data_sel[1].length - 1, 2)
            }
            // C(m,2)*C(n,1)-C(h,2)*C(2,1)-C(h,1)*C(m-h,1)
            else if (mname == 'WXZU30') {
              tmp_nums -= Combination(h, 2) * Combination(2, 1)
              if (data_sel[0].length - h > 0) {
                tmp_nums -= Combination(h, 1) * Combination(data_sel[0].length - h, 1)
              }
            }
            // C(m,1)*C(n,2)-C(h,1)*C(n-1,1)
            else if (mname == 'WXZU20') {
              tmp_nums -= Combination(h, 1) * Combination(data_sel[1].length - 1, 1)
            }
            // C(m,1)*C(n,1)-C(h,1)
            else if (mname == 'WXZU10' || mname == 'WXZU5') {
              tmp_nums -= Combination(h, 1)
            }
          }
          _num += tmp_nums
        }
        return _num
        //
      case 'SXZU24': // 四星组选
        var _num = 0
        var s = data_sel[0].length
        if (s > 3) { // 必须选4位或者以上
          _num += Combination(s, 4)
        }
        if (isrx == 1) { // 任选玩法：考虑选择的位置
          _num *= selposition.length == 0 ? 0 : Combination(selposition.length, 4)
        }
        return _num
      case 'SXZU6':
        var _num = 0
        if (data_sel[0].length >= minchosen[0]) {
          // C(n,2)
          _num += Combination(data_sel[0].length, minchosen[0])
        }
        if (isrx == 1) { // 任选玩法：考虑选择的位置
          _num *= selposition.length == 0 ? 0 : Combination(selposition.length, 4)
        }
        return _num
      case 'SXZU12':
      case 'SXZU4':
        var _num = 0
        if (data_sel[0].length >= minchosen[0] && data_sel[1].length >= minchosen[1]) {
          var h = Array.intersect(data_sel[0], data_sel[1]).length
          tmp_nums = Combination(data_sel[0].length, minchosen[0]) * Combination(data_sel[1].length, minchosen[1])
          if (h > 0) {
            // C(m,1)*C(n,2)-C(h,1)*C(n-1,1)
            if (mname == 'SXZU12') {
              tmp_nums -= Combination(h, 1) * Combination(data_sel[1].length - 1, 1)
            }
            // C(m,1)*C(n,1)-C(h,1)
            else if (mname == 'SXZU4') {
              tmp_nums -= Combination(h, 1)
            }
          }
          _num += tmp_nums
        }
        if (isrx == 1) { // 任选玩法：考虑选择的位置
          _num *= selposition.length == 0 ? 0 : Combination(selposition.length, 4)
        }
        return _num
        //
      case 'ZXKD': // 直选跨度3特殊算法 后三直选跨度
        var _num = 0
        var cc = { 0: 10, 1: 54, 2: 96, 3: 126, 4: 144, 5: 150, 6: 144, 7: 126, 8: 96, 9: 54 }
        for (i = 0; i <= max_place; i++) {
          var s = data_sel[i].length
          for (j = 0; j < s; j++) {
            _num += cc[parseInt(data_sel[i][j], 10)]
          }
        }
        return _num

        // 后二直选跨度
        //
      case 'ZXKD2': // 直选跨度2特殊算法
        var _num = 0
        var cc = { 0: 10, 1: 18, 2: 16, 3: 14, 4: 12, 5: 10, 6: 8, 7: 6, 8: 4, 9: 2 }
        for (i = 0; i <= max_place; i++) {
          var s = data_sel[i].length
          for (j = 0; j < s; j++) {
            _num += cc[parseInt(data_sel[i][j], 10)]
          }
        }
        return _num

      case 'ZXHZ': // 直选和值特殊算法 后三直选和值
        var cc = { 0: 1, 1: 3, 2: 6, 3: 10, 4: 15, 5: 21, 6: 28, 7: 36, 8: 45, 9: 55, 10: 63, 11: 69, 12: 73, 13: 75, 14: 75, 15: 73, 16: 69, 17: 63, 18: 55, 19: 45, 20: 36, 21: 28, 22: 21, 23: 15, 24: 10, 25: 6, 26: 3, 27: 1 }
      case 'ZUHZ': // 混合组选特殊算法
        var _num = 0
        if (mname == 'ZUHZ') {
          cc = { 1: 1, 2: 2, 3: 2, 4: 4, 5: 5, 6: 6, 7: 8, 8: 10, 9: 11, 10: 13, 11: 14, 12: 14, 13: 15, 14: 15, 15: 14, 16: 14, 17: 13, 18: 11, 19: 10, 20: 8, 21: 6, 22: 5, 23: 4, 24: 2, 25: 2, 26: 1 }
        }
        for (i = 0; i <= max_place; i++) {
          // debugger
          var s = data_sel[i].length

          for (j = 0; j < s; j++) {
            _num += cc[parseInt(data_sel[i][j], 10)]
          }
        }
        if (isrx == 1) { // 任选玩法：考虑选择的位置
          _num *= selposition.length == 0 ? 0 : Combination(selposition.length, 3)
        }
        return _num

      case 'ZUSHZ': // 组选三和值
        var _num = 0
        var cc = { 1: 1, 2: 2, 3: 2, 4: 4, 5: 5, 6: 6, 7: 8, 8: 10, 9: 11, 10: 13, 11: 14, 12: 14, 13: 15, 14: 15, 15: 14, 16: 14, 17: 13, 18: 11, 19: 10, 20: 8, 21: 6, 22: 5, 23: 4, 24: 2, 25: 2, 26: 1 }

        for (i = 0; i <= max_place; i++) {
          var s = data_sel[i].length
          for (j = 0; j < s; j++) {
            _num += cc[parseInt(data_sel[i][j], 10)]
          }
        }
        return _num

      case 'ZULHZ': // ?
        var _num = 0
        var cc = { 3: 1, 4: 1, 5: 2, 6: 3, 7: 4, 8: 5, 9: 7, 10: 8, 11: 9, 12: 10, 13: 10, 14: 10, 15: 10, 16: 9, 17: 8, 18: 7, 19: 5, 20: 4, 21: 3, 22: 2, 23: 1, 24: 1 }

        for (i = 0; i <= max_place; i++) {
          var s = data_sel[i].length
          for (j = 0; j < s; j++) {
            _num += cc[parseInt(data_sel[i][j], 10)]
          }
        }
        return _num

      case 'ZUS': // 组选三
        var _num = 0
        for (i = 0; i <= max_place; i++) {
          var s = data_sel[i].length
          if (s > 1) { // 组三必须选两位或者以上
            _num += s * (s - 1)
          }
        }
        if (isrx == 1) { // 任选玩法：考虑选择的位置
          _num *= selposition.length == 0 ? 0 : Combination(selposition.length, 3)
        }
        return _num
      case 'ZUL': // 组选六
        var _num = 0
        for (i = 0; i <= max_place; i++) {
          var s = data_sel[i].length
          if (s > 2) { // 组六必须选三位或者以上
            _num += s * (s - 1) * (s - 2) / 6
          }
        }
        if (isrx == 1) { // 任选玩法：考虑选择的位置
          _num *= selposition.length == 0 ? 0 : Combination(selposition.length, 3)
        }
        return _num

      case 'ZXHZ2': // 二星直选和值
        var _num = 0
        var cc = { 0: 1, 1: 2, 2: 3, 3: 4, 4: 5, 5: 6, 6: 7, 7: 8, 8: 9, 9: 10, 10: 9, 11: 8, 12: 7, 13: 6, 14: 5, 15: 4, 16: 3, 17: 2, 18: 1 }
        for (i = 0; i <= max_place; i++) {
          var s = data_sel[i].length
          for (j = 0; j < s; j++) {
            _num += cc[parseInt(data_sel[i][j], 10)]
          }
        }
        if (isrx == 1) { // 任选玩法：考虑选择的位置
          _num *= selposition.length == 0 ? 0 : Combination(selposition.length, 2)
        }
        return _num
      case 'ZUHZ2': // 二星组选和值
        var _num = 0
        var cc = { 0: 0, 1: 1, 2: 1, 3: 2, 4: 2, 5: 3, 6: 3, 7: 4, 8: 4, 9: 5, 10: 4, 11: 4, 12: 3, 13: 3, 14: 2, 15: 2, 16: 1, 17: 1, 18: 0 }
        for (i = 0; i <= max_place; i++) {
          var s = data_sel[i].length
          for (j = 0; j < s; j++) {
            _num += cc[parseInt(data_sel[i][j], 10)]
          }
        }
        if (isrx == 1) { // 任选玩法：考虑选择的位置
          _num *= selposition.length == 0 ? 0 : Combination(selposition.length, 2)
        }
        return _num
      case 'ZU3BD': // 组选三 包胆
        var _num = 0
        _num = data_sel[0].length * 54
        return _num
      case 'ZU2BD': // 组选二 包胆
        var _num = 0
        _num = data_sel[0].length * 9
        return _num

      case 'BDW3':
        var _num = 0
        for (i = 0; i <= max_place; i++) {
          var s = data_sel[i].length
          if (s > 2) { // 三码不定位必须选3位或者以上
            _num += Combination(data_sel[i].length, 3)
          }
        }
        return _num
      case 'BDW2': // 二码不定位
      case 'ZU2': // 组选二
        var _num = 0
        for (i = 0; i <= max_place; i++) {
          var s = data_sel[i].length
          if (s > 1) { // 二码不定位必须选两位或者以上
            _num += s * (s - 1) / 2
          }
        }
        if (isrx == 1) { // 任选玩法：考虑选择的位置
          _num *= selposition.length == 0 ? 0 : Combination(selposition.length, 2)
        }
        return _num

      case 'DWD': // 定位胆所有在一起特殊处理
        var _num = 0
        for (i = 0; i <= max_place; i++) {
          _num += data_sel[i].length
        }
        return _num

      case 'RZX2': // 任二直选 复式
      case 'RZX3': // 任三直选
      case 'RZX4': // 任四直选
        var _num = 0
        var aCodePosition = []
        for (i = 0; i <= max_place; i++) {
          var codelen = data_sel[i].length // 指定位置上的号码长度
          if (codelen > 0) {
            aCodePosition.push(i)
          }
        }
        var sellen = mname.substring(mname.length - 1)
        var aPositionCombo = getCombination(aCodePosition, sellen)
        var iComboLen = aPositionCombo.length // 组合个数
        var aCombo = []
        var iLen = 0
        var tmpNums = 1
        for (j = 0; j < iComboLen; j++) {
          aCombo = aPositionCombo[j].split(',')
          iLen = aCombo.length
          tmpNums = 1
          for (h = 0; h < iLen; h++) {
            tmpNums *= data_sel[aCombo[h]].length
          }
          _num += tmpNums
        }
        return _num

      case 'BJZ2':
        var _num = 0
        for (i = 0; i <= max_place; i++) {
          if (data_sel[i].length == 0) { // 有位置上没有选择
            tmp_nums = 0
            break
          }
          tmp_nums = accMul(tmp_nums, data_sel[i].length)
        }
        _num = tmp_nums
        var len1 = data_sel[0].length
        var len2 = data_sel[1].length
        var same_nums = 0
        for (var i = 0; i < len1; i++) {
          for (var j = 0; j < len2; j++) {
            if (data_sel[0][i] == data_sel[1][j]) {
              same_nums++
              break
            }
          }
        }
        _num -= same_nums
        return _num
      case 'BJZ3':
        var _num = 0
        var len1 = data_sel[0].length
        var len2 = data_sel[1].length
        var len3 = data_sel[2].length
        for (var i = 0; i < len1; i++) {
          for (var j = 0; j < len2; j++) {
            if (data_sel[0][i] == data_sel[1][j]) {
              continue
            }
            for (var k = 0; k < len3; k++) {
              if (data_sel[0][i] == data_sel[2][k] || data_sel[1][j] == data_sel[2][k]) {
                continue
              } else {
                _num++
              }
            }
          }
        }
        return _num

      default: // 默认情况
        // console.log('数字型默认算法')
        var _num = 0
        for (i = 0; i <= max_place; i++) {
          if (data_sel[i].length == 0) { // 有位置上没有选择
            tmp_nums = 0
            break
          }
          tmp_nums = accMul(tmp_nums, data_sel[i].length)
        }
        _num = tmp_nums
        return _num
    }
    //
  }

}
