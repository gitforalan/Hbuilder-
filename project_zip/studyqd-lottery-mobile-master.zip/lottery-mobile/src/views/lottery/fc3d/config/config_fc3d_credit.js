// eslint-disable
export default [{
  'playTabName': '整合',
  'playTabId': 18210,
  'playTypeList': [{
    'playTypeId': 1821010,
    'playTypeName': '第一球',
    'playList': [{ 'playId': 182101010 }, { 'playId': 182101011 }, { 'playId': 182101012 }, { 'playId': 182101013 }, { 'playId': 182101014 }, { 'playId': 182101015 }, { 'playId': 182101016 }, { 'playId': 182101017 }, { 'playId': 182101018 }, { 'playId': 182101019 }, { 'playId': 182101620 }, { 'playId': 182101621 }, { 'playId': 182101622 }, { 'playId': 182101623 }]
  },
  {
    'playTypeId': 1821011,
    'playTypeName': '第二球',
    'playList': [{ 'playId': 182101110 }, { 'playId': 182101111 }, { 'playId': 182101112 }, { 'playId': 182101113 }, { 'playId': 182101114 }, { 'playId': 182101115 }, { 'playId': 182101116 }, { 'playId': 182101117 }, { 'playId': 182101118 }, { 'playId': 182101119 }, { 'playId': 182101120 }, { 'playId': 182101121 }, { 'playId': 182101122 }, { 'playId': 182101123 }]
  },
  {
    'playTypeId': 1821012,
    'playTypeName': '第三球',
    'playList': [{ 'playId': 182101210 }, { 'playId': 182101211 }, { 'playId': 182101212 }, { 'playId': 182101213 }, { 'playId': 182101214 }, { 'playId': 182101215 }, { 'playId': 182101216 }, { 'playId': 182101217 }, { 'playId': 182101218 }, { 'playId': 182101219 }, { 'playId': 182101220 }, { 'playId': 182101221 }, { 'playId': 182101222 }, { 'playId': 182101223 }]
  },
  {
    'playTypeId': 1821013,
    'playTypeName': '第四球',
    'playList': [{ 'playId': 182101310 }, { 'playId': 182101311 }, { 'playId': 182101312 }, { 'playId': 182101313 }, { 'playId': 182101314 }, { 'playId': 182101315 }, { 'playId': 182101316 }, { 'playId': 182101317 }, { 'playId': 182101318 }, { 'playId': 182101319 }, { 'playId': 182101320 }, { 'playId': 182101321 }, { 'playId': 182101322 }, { 'playId': 182101323 }]
  },
  {
    'playTypeId': 1821014,
    'playTypeName': '第五球',
    'playList': [{ 'playId': 182101410 }, { 'playId': 182101411 }, { 'playId': 182101412 }, { 'playId': 182101413 }, { 'playId': 182101414 }, { 'playId': 182101415 }, { 'playId': 182101416 }, { 'playId': 182101417 }, { 'playId': 182101418 }, { 'playId': 182101419 }, { 'playId': 182101420 }, { 'playId': 182101421 }, { 'playId': 182101422 }, { 'playId': 182101423 }]
  },
  {
    'playTypeId': 1821015,
    'playTypeName': '总和',
    'playList': [{ 'playId': 182101510 }, { 'playId': 182101511 }, { 'playId': 182101512 }, { 'playId': 182101513 }]
  },
  {
    'playTypeId': 1821016,
    'playTypeName': '前三',
    'playList': [{ 'playId': 182101610 }, { 'playId': 182101611 }, { 'playId': 182101612 }, { 'playId': 182101613 }, { 'playId': 182101614 }]
  },
  {
    'playTypeId': 1821017,
    'playTypeName': '中三',
    'playList': [{ 'playId': 182101710 }, { 'playId': 182101711 }, { 'playId': 182101712 }, { 'playId': 182101713 }, { 'playId': 182101714 }]
  },
  {
    'playTypeId': 1821018,
    'playTypeName': '后三',
    'playList': [{ 'playId': 182101810 }, { 'playId': 182101811 }, { 'playId': 182101812 }, { 'playId': 182101813 }, { 'playId': 182101814 }]
  }
  ]
},
{
  'playTabName': '龙虎斗',
  'playTabId': 18211,
  'playTypeList': [{
    'playTypeName': '第一球VS第二球',
    'playTypeId': 1821110,
    'playList': [{ 'playId': 182111010 }, { 'playId': 182111012 }, { 'playId': 182111011 }]
  },
  {
    'playTypeId': 1821111,
    'playTypeName': '第一球VS第三球',
    'playList': [{ 'playId': 182111110 }, { 'playId': 182111112 }, { 'playId': 182111111 }]
  },
  {
    'playTypeId': 1821112,
    'playTypeName': '第一球VS第四球',
    'playList': [{ 'playId': 182111210 }, { 'playId': 182111212 }, { 'playId': 182111211 }]
  },
  {
    'playTypeId': 1821113,
    'playTypeName': '第一球VS第五球',
    'playList': [{ 'playId': 182111310 }, { 'playId': 182111312 }, { 'playId': 182111311 }]
  },
  {
    'playTypeId': 1821114,
    'playTypeName': '第二球VS第三球',
    'playList': [{ 'playId': 182111410 }, { 'playId': 182111412 }, { 'playId': 182111411 }]
  },
  {
    'playTypeId': 1821115,
    'playTypeName': '第二球VS第四球',
    'playList': [{ 'playId': 182111510 }, { 'playId': 182111512 }, { 'playId': 182111511 }]
  },
  {
    'playTypeId': 1821116,
    'playTypeName': '第二球VS第五球',
    'playList': [{ 'playId': 182111610 }, { 'playId': 182111612 }, { 'playId': 182111611 }]
  },
  {
    'playTypeId': 1821117,
    'playTypeName': '第三球VS第四球',
    'playList': [{ 'playId': 182111710 }, { 'playId': 182111712 }, { 'playId': 182111711 }]
  },
  {
    'playTypeId': 1821118,
    'playTypeName': '第三球VS第五球',
    'playList': [{ 'playId': 182111810 }, { 'playId': 182111812 }, { 'playId': 182111811 }]
  },
  {
    'playTypeId': 1821119,
    'playTypeName': '第四球VS第五球',
    'playList': [{ 'playId': 182111910 }, { 'playId': 182111912 }, { 'playId': 182111911 }]
  }
  ]
},
{
  'playTabName': '全5中1',
  'playTabId': 18212,
  'playTypeList': [{
    'playTypeId': 1821210,
    'playTypeName': '全5中1',
    'playList': [{ 'playId': 182121010 }, { 'playId': 182121011 }, { 'playId': 182121012 }, { 'playId': 182121013 }, { 'playId': 182121014 }, { 'playId': 182121015 }, { 'playId': 182121016 }, { 'playId': 182121017 }, { 'playId': 182121018 }, { 'playId': 182121019 }]
  }]
}
]
