/*
 * 时时乐基础数据 官方玩法 参考时时彩
 * 待修改 todo
 * eslint 格式化 format by fx， 2017-10-24
 * */

export default {
  /* 定位胆 */
  181101010: {
    alias: 'DWD',
    selectarea: {
      type: 'digital',
      hcltPosition: [0, 1, 2],
      layout: [{
        title: '百位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }, {
        title: '十位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 1,
        cols: 1
      }, {
        title: '个位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 2,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
  /* 二星 */
  /* 前二直选 */
  181111010: {
    selectarea: {
      type: 'digital',
      layout: [{
        title: '百位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }, {
        title: '十位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 1,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
  /* 前二组选 */
  181111110: {
    alias: 'ZU2',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '组选',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
  /* 后二直选 */
  181111011: {
    selectarea: {
      type: 'digital',
      layout: [{
        title: '十位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }, {
        title: '个位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 1,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
  /* 后二组选 */
  181111111: {
    alias: 'ZU2',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '组选',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
  /* 三星直选 */
  // 直选复式
  181121010: {
    alias: 'ZH3',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '百位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }, {
        title: '十位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 1,
        cols: 1
      }, {
        title: '个位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 2,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
  // 直选单式
  181121011: {
    alias: 'ZX3',
    selectarea: {
      type: 'input'
    }
  },
  // 直选和值
  181121012: {
    alias: 'ZUSHZ',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '和值',
        no: '1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: false
    }
  },
  /* 三星组选 */
  // 组选组三
  181121110: {
    alias: 'ZUS',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '组三',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
  // 组选组六
  181121111: {
    alias: 'ZUL',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '组六',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
  // 组选和值
  181121112: {
    alias: 'ZUSHZ',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '和值',
        no: '1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: false
    }
  },
  /* 一码不定位 */
  181131010: {
    selectarea: {
      type: 'digital',
      layout: [{
        title: '不定位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
  /* 二码不定位 */
  181131011: {
    alias: 'BDW2',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '不定位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
  /* 前二大小单双 */
  181141010: {
    alias: 'DXDS',
    selectarea: {
      type: 'dxds',
      isButton: false,
      layout: [{
        title: '百位',
        no: '大|小|单|双',
        place: 0,
        cols: 1
      }, {
        title: '十位',
        no: '大|小|单|双',
        place: 1,
        cols: 1
      }]
    }
  },
  /* 后二大小单双 */
  181141011: {
    alias: 'DXDS',
    selectarea: {
      type: 'dxds',
      isButton: false,
      layout: [{
        title: '十位',
        no: '大|小|单|双',
        place: 0,
        cols: 1
      }, {
        title: '个位',
        no: '大|小|单|双',
        place: 1,
        cols: 1
      }]
    }
  }
}
