<!-- Created By fx on 2017-10-24
  -- 玩法列表
  -->

<template>
  <section v-click-outside="onClickedOutside" v-show="show">
    <tab :animate="false" :line-width="1" custom-bar-width="60px" class="active">
      <tab-item
        :disabled="(index + 1) === 2"
        active-class="active"
        v-for="(item, index) in playTabModeArr"
        :selected="(index + 1) === playTabMode"
        @on-item-click="onPlayTabModeChange"
        :key="index"
      >
        <span v-if="(index + 1) === playTabMode" class="selected-icon"><icon-svg icon-class="duihao"></icon-svg></span>
        <span>{{ item }}</span>
      </tab-item>
    </tab>

    <div class="tab-con">
      <div class="play-type">
        <checker
          v-model="playTab.tab"
          @on-change="onPlayTabChange"
          default-item-class="play-item"
          selected-item-class="play-item-selected"
          :radio-required="true">
          <checker-item
            v-for="tab in playTab.list"
            :value="tab"
            :key="tab.playTabName"
            @on-item-click="onPlayTabClick"> {{ tab.playTabName }}
          </checker-item>
        </checker>
      </div>
      <div class="play-type-con">
        <ul class="play-con-list">
          <checker
            v-model="play.play"
            @on-change="onPlayChange"
            default-item-class="play-item"
            selected-item-class="play-item-selected"
            :radio-required="true">
            <li flex="" v-for="type in playType.list">
              <span flex-box="0">{{ type.playTypeName }}</span>
              <div class="type-list" flex-box="1">
                <checker-item
                  v-for="play in type.playList"
                  :value="play"
                  :key="play.playName"
                  v-if="play.display"
                  @on-item-click="onPlayClick"
                > {{ play.playName }}
                </checker-item>
              </div>
            </li>
          </checker>
        </ul>
      </div>
    </div>
  </section>
</template>

<script type="text/ecmascript-6">
  import Layout from '../config/config_ssl.js' // 官方配置文件
  import LayoutCredit from '../config/config_ssl_credit' // 信用玩法配置文件

  import { xStore } from '@/utils/xstore/'
  import { xTimer } from '@/utils/timer/'
  import ClickOutside from 'vux/src/directives/click-outside'
  import { mapState, mapMutations, mapActions } from 'vuex'
  import * as API from 'api/wapi/front'

  const MODE = {
    OFFICIAL: 1, // 官方
    CREDIT: 2    // 信用
  }
  export default {
    name: 'playTabList',
    data () {
      return {
        playTabModeArr: ['官方玩法', ''],
        playTab: {
          tab: null,
          list: [],
          default: 0
        },
        playType: {
          type: null,
          list: [],
          default: 0
        },
        play: {
          play: null,
          name: '',
          list: [],
          default: 0,
          display: 1
        },
        cache: {
          [MODE.OFFICIAL]: '161', // 官方缓存key
          [MODE.CREDIT]: '162', // 信用缓存key
          timer: 'sslCache', // 其它彩种更换命名空间 ssl xxxCache
          timeOut: 10000
        }
      }
    },
    props: {
      show: {
        type: Boolean,
        default: false
      }
    },
    computed: {
      ...mapState('common', {
        lotteryId: state => state.lotteryId,
        lotteryTypeId: state => state.lotteryTypeId,
        playTabMode: state => state.playTabMode
      }),
      ...mapState('ui', {
        rotate: state => state.icon_isRotate
      }),
      ...mapState('ssl', {
        playTabName: state => state.playTabName,
        playName: state => state.playName,
        playId: state => state.playId
      })
    },
    methods: {
      // 缓存key 传versionCode看新数据和缓存是否一致
      getLotteryPlayOdds (cacheKey, versionCode) {
        if (this.lotteryTypeId === -1) return
        const query = {
          lotteryTypeId: this.lotteryTypeId,
          playTabMode: this.playTabMode,
          versionCode: versionCode
        }
        API.getLotteryPlayOdds(query).then(res => {
          if (versionCode && versionCode === res.data.versionCode) return // 缓存有效 (有更新后 返回全部还是部分？)
          // tab
          this.playTab.list = res.data.playTabList
          this.playTab.list.sort((a, b) => a['sort'] - b['sort']) // 按sort字段排序
          let ptl
          if (this.playTabMode === MODE.OFFICIAL) { // 官方
            ptl = this.addCommonTag(this.playTab.list, Layout)
            this.playTab.list = Object.assign({}, ptl) // 更新成新对象 触发更新
          }
          if (this.playTabMode === MODE.CREDIT) { // 信用
            ptl = this.mergeCreditData(LayoutCredit, this.playTab.list) // 小坑 pc端参数写反了
            this.playTab.list = Object.assign({}, ptl) // 更新成新对象 触发更新
          }
          let newCacheData = {
            versionCode: res.data.versionCode,
            playTabList: this.playTab.list // 标记后的数据
          }
          xStore(cacheKey, JSON.stringify(newCacheData))
          this.$nextTick(() => {
            this.playTab.tab = this.playTab.list[this.playTab.default] // 更新tab
          })
        }).catch(err => {
          this.$vux.toast.show({
            type: 'warn',
            text: err.desc,
            time: 30000
          })
        })
      },
      /* 传 update 触发更新 */
      setPlayData (cacheKey, update) {
        const cache = xStore.has(cacheKey) //  判断是否有缓存
        let cacheData = null
        // 如果有缓存
        if (cache) {
          cacheData = JSON.parse(xStore.get(cacheKey))
          // false 直接读缓存
          if (!update) {
            this.playTab.list = cacheData.playTabList
            this.$nextTick(() => {
              this.playTab.tab = this.playTab.list[this.playTab.default] // 更新tab
            })
            return
          }
          // true 更新
          const versionCode = cacheData.versionCode
          this.getLotteryPlayOdds(cacheKey, versionCode)
          return
        }
        // 没有缓存
        this.getLotteryPlayOdds(cacheKey)
      },
      addCommonTag (data, layout) {
        let map = {} // 用于存放不显示的子级玩法
        data.forEach(i => {
          i.isactive = 0
          i.playTypeList.forEach(j => {
            j.isactive = 0
            // 先遍历一次，拿到所有子级玩法
            j.playList.forEach(m => {
              if (m.parentId && m.parentId !== 0) {
                if (map[m.parentId]) {
                  map[m.parentId].push(m)
                } else {
                  map[m.parentId] = []
                  map[m.parentId].push(m)
                }
              }
            })
            let _map = JSON.parse(JSON.stringify(map))
            let allshow = j.playList.filter(n => n.display === 1) // 过滤掉不显示的玩法
            allshow.forEach(k => {
              k.isactive = 0
              let pId = k.playId
              if (pId in _map) {
                // console.log(k.playId)
                k.maxPrize = []
                k.minPrize = []
                _map[pId].forEach(n => {
                  k.maxPrize.push(n.maxPrize)
                  k.minPrize.push(n.minPrize)
                })
                // 排序
                k.maxPrize.sort((a, b) => b - a)
                k.minPrize.sort((a, b) => b - a)
              } else {
                let tmpMaxprize = k.maxPrize
                let tmpMinPrize = k.minPrize
                k.maxPrize = [tmpMaxprize]
                k.minPrize = [tmpMinPrize]
              }
              if (typeof k.defaultposition === 'undefined') {
                k.defaultposition = '00000'
              }
              let playId = k.playId
              if (!(playId in layout)) {
                console.log(`配置文件缺少该玩法数据:${k.playId}`)
                // throw new Error(`配置文件缺少该玩法数据: ${k.playId}`)
              }
              k = Object.assign(k, layout[playId])
            })
            j.playList = allshow
          })
        })
        return data
      },
      mergeCreditData (layoutData, data) { // 合并信用玩法数据
        for (let i = 0; i < layoutData.length; i++) {
          let playTab = data.filter(p => p.playTabId === layoutData[i].playTabId)[0]
          for (let j = 0; j < layoutData[i].playTypeList.length; j++) {
            let playList = playTab.playTypeList[j].playList
            for (let k = 0; k < layoutData[i].playTypeList[j].playList.length; k++) {
              let playId = layoutData[i].playTypeList[j].playList[k].playId
              let _data = playList.filter(i => i.playId === playId)
              if (_data.length) {
                layoutData[i].playTypeList[j].playList[k] = _data[0]
              }
            }
          }
        }
        return layoutData
      },
      updateCache (mode) { // 定时更新缓存
        if (!this.$timer.hasOwnProperty(this.cache.timer)) {
          this.setPlayData(this.cache[mode], 1)
          this.$timer[this.cache.timer] = xTimer.setInterval(() => {
            this.setPlayData(this.cache[mode], 1)
            console.log('更新缓存 ->', this.lotteryId, mode)
          }, this.cache.timeOut)
        }
      },
      clearTimer (timer) {
        xTimer.clearInterval(this.$timer[timer])
        delete this.$timer[timer]
      },
      init (mode) { // 初始化
        this.setPlayData(this.cache[mode], 0)
      },
      onPlayTabModeChange (index) {
        this.set_playTabMode({ playTabMode: index + 1 })
      },
      onPlayTabChange (tab) {
        this.set_playTabName(tab.playTabName)
        this.set_playTabId(tab.playTabId)
        if (this.playTabMode === MODE.CREDIT) { // 信用玩法不展开 type、play类
          this.playType.list = []
          this.play.list = []
          this.currentTab(this.playTab.list) // 存tab 用于信用玩法
          this.set_playName('') // 玩法名称为空
          return
        }
        this.playType.list = tab.playTypeList
        let playList = this.playType.list[this.playType.default].playList
        const defaultPlay = playList[this.play.default]
        this.play.play = defaultPlay
      },
      onPlayTabClick (item) {
        if (this.playTabMode === MODE.CREDIT) this.$emit('on-hide')
        // this.playTab.tab = item
      },
      onPlayChange (play) {
        this.play.play = play
        this.set_playName(play.playName)
        this.set_playId(play.playId)
        // 存 play 数据 在 playArea.vue 监听、渲染
        this.currentPlay({ play: play })
      },
      onPlayClick (play) {
        this.$emit('on-hide')
      },
      onClickedOutside () {
        if (this.show) {
          this.$emit('on-hide')
        }
      },
      ...mapMutations('ssl', ['set_playTabName', 'set_playName', 'set_playId', 'set_playTabId', 'currentPlay', 'currentTab']),
      ...mapMutations('common', ['set_playTabMode']),
      ...mapActions('common', ['getLotteryHclt']),
      ...mapActions('ui', ['ui_icon_rotate'])
    },
    directives: {
      ClickOutside
    },
    created () {
      // this.getLotteryPlayOdds() // 彩种类型的玩法及赔率查询
      this.getLotteryHclt({ lotteryId: this.lotteryId }) // 彩种冷热遗漏查询
      this.ui_icon_rotate({ rotate: false }) // 刷新后重置图标状态
      this.init(this.playTabMode) // 初始化
      this.updateCache(this.playTabMode) // 更新缓存
    },
    watch: {
      show (val) {
        this.ui_icon_rotate({ rotate: val })
      },
      playTabMode (mode) {
        this.init(mode) // 切换官方、信用 重新初始化
        this.clearTimer(this.cache.timer)
        this.updateCache(mode) // 更新缓存
        // this.getLotteryPlayOdds()
      }
    },
    beforeDestroy () {
      this.clearTimer(this.cache.timer) // 清掉更新缓存的计时器
    }
  }
</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"

  section
    position fixed
    z-index 10
    width 100%
    box-shadow 2px 3px 5px $color-gray-a
    .active
      setBottomLine()
    .vux-tab
      height rem(70)
      padding-top .5rem
      line-height rem(70)
      font-size rem(30)
      color #5c5c5c
      &:after
        border-color #ff5151
      .vux-tab-item.vux-tab-selected
        height rem(70)
        margin-left rem(32)
        margin-right rem(32)
        color $color-red
        background $color-el-bg
        border 1px solid #ff5151
        border-bottom none
        &:after
          border 3px solid $color-el-bg
          height 0
          bottom -1px
          opacity 1
          z-index 9999
      .vux-tab-item
        background: none
        line-height rem(70)
        border-top-left-radius 7px
        border-top-right-radius 7px
    .tab-con
      background $color-el-bg
      padding-top rem(22)
      max-height 80vh
      overflow-y auto
      .play-type
        padding rem(22) .5rem rem(15)
        color #5c5c5c
        ul
          padding-bottom rem(26)
      .play-type ul li:nth-chlid(last)
        margin-right 0
    .play-type-con
      background $color-white
      padding rem(9) 0 0

      background $color-white
      ul.play-con-list
        padding 0 .5rem
        border-bottom 2px solid $color-red
        li
          border-bottom 1px solid $color-border
          padding rem(38) 0 rem(10) 0
          font-size rem(28)
          span
            padding-right rem(18)
            color #5c5c5c
          .type-list
            margin-top -.5rem
          .play-item
            color #9b9b9b
            border 1px solid $color-border
            font-size rem(28)
            margin-right rem(15)
            padding rem(14) rem(12)
          .play-item-selected
            background $color-white
            border 1px solid $color-red
            color $color-red
        li:last-child
          border-bottom none
</style>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .play-item
    padding rem(21) rem(30)
    border-radius 4px
    margin-bottom rem(12)
    font-size rem(28)
    color #5C5C5C
    background $color-white
    margin-right rem(33)

  .play-item-selected
    background $color-red
    color $color-white

  .selected-icon .lott-icon .svg-icon
    width rem(44)
    height rem(44)
    vertical-align middle

</style>
