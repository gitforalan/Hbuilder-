// eslint-disable
export default [{
  'playTabName': '整合',
  'playTabId': 16210,
  'playTypeList': [{
    'playTypeId': 1621010,
    'playTypeName': '第一球',
    'playList': [{ 'playId': 162101010 }, { 'playId': 162101011 }, { 'playId': 162101012 }, { 'playId': 162101013 }, { 'playId': 162101014 }, { 'playId': 162101015 }, { 'playId': 162101016 }, { 'playId': 162101017 }, { 'playId': 162101018 }, { 'playId': 162101019 }, { 'playId': 162101620 }, { 'playId': 162101621 }, { 'playId': 162101622 }, { 'playId': 162101623 }]
  },
  {
    'playTypeId': 1621011,
    'playTypeName': '第二球',
    'playList': [{ 'playId': 162101110 }, { 'playId': 162101111 }, { 'playId': 162101112 }, { 'playId': 162101113 }, { 'playId': 162101114 }, { 'playId': 162101115 }, { 'playId': 162101116 }, { 'playId': 162101117 }, { 'playId': 162101118 }, { 'playId': 162101119 }, { 'playId': 162101120 }, { 'playId': 162101121 }, { 'playId': 162101122 }, { 'playId': 162101123 }]
  },
  {
    'playTypeId': 1621012,
    'playTypeName': '第三球',
    'playList': [{ 'playId': 162101210 }, { 'playId': 162101211 }, { 'playId': 162101212 }, { 'playId': 162101213 }, { 'playId': 162101214 }, { 'playId': 162101215 }, { 'playId': 162101216 }, { 'playId': 162101217 }, { 'playId': 162101218 }, { 'playId': 162101219 }, { 'playId': 162101220 }, { 'playId': 162101221 }, { 'playId': 162101222 }, { 'playId': 162101223 }]
  },
  {
    'playTypeId': 1621013,
    'playTypeName': '第四球',
    'playList': [{ 'playId': 162101310 }, { 'playId': 162101311 }, { 'playId': 162101312 }, { 'playId': 162101313 }, { 'playId': 162101314 }, { 'playId': 162101315 }, { 'playId': 162101316 }, { 'playId': 162101317 }, { 'playId': 162101318 }, { 'playId': 162101319 }, { 'playId': 162101320 }, { 'playId': 162101321 }, { 'playId': 162101322 }, { 'playId': 162101323 }]
  },
  {
    'playTypeId': 1621014,
    'playTypeName': '第五球',
    'playList': [{ 'playId': 162101410 }, { 'playId': 162101411 }, { 'playId': 162101412 }, { 'playId': 162101413 }, { 'playId': 162101414 }, { 'playId': 162101415 }, { 'playId': 162101416 }, { 'playId': 162101417 }, { 'playId': 162101418 }, { 'playId': 162101419 }, { 'playId': 162101420 }, { 'playId': 162101421 }, { 'playId': 162101422 }, { 'playId': 162101423 }]
  },
  {
    'playTypeId': 1621015,
    'playTypeName': '总和',
    'playList': [{ 'playId': 162101510 }, { 'playId': 162101511 }, { 'playId': 162101512 }, { 'playId': 162101513 }]
  },
  {
    'playTypeId': 1621016,
    'playTypeName': '前三',
    'playList': [{ 'playId': 162101610 }, { 'playId': 162101611 }, { 'playId': 162101612 }, { 'playId': 162101613 }, { 'playId': 162101614 }]
  },
  {
    'playTypeId': 1621017,
    'playTypeName': '中三',
    'playList': [{ 'playId': 162101710 }, { 'playId': 162101711 }, { 'playId': 162101712 }, { 'playId': 162101713 }, { 'playId': 162101714 }]
  },
  {
    'playTypeId': 1621018,
    'playTypeName': '后三',
    'playList': [{ 'playId': 162101810 }, { 'playId': 162101811 }, { 'playId': 162101812 }, { 'playId': 162101813 }, { 'playId': 162101814 }]
  }
  ]
},
{
  'playTabName': '龙虎斗',
  'playTabId': 16211,
  'playTypeList': [{
    'playTypeName': '第一球VS第二球',
    'playTypeId': 1621110,
    'playList': [{ 'playId': 162111010 }, { 'playId': 162111012 }, { 'playId': 162111011 }]
  },
  {
    'playTypeId': 1621111,
    'playTypeName': '第一球VS第三球',
    'playList': [{ 'playId': 162111110 }, { 'playId': 162111112 }, { 'playId': 162111111 }]
  },
  {
    'playTypeId': 1621112,
    'playTypeName': '第一球VS第四球',
    'playList': [{ 'playId': 162111210 }, { 'playId': 162111212 }, { 'playId': 162111211 }]
  },
  {
    'playTypeId': 1621113,
    'playTypeName': '第一球VS第五球',
    'playList': [{ 'playId': 162111310 }, { 'playId': 162111312 }, { 'playId': 162111311 }]
  },
  {
    'playTypeId': 1621114,
    'playTypeName': '第二球VS第三球',
    'playList': [{ 'playId': 162111410 }, { 'playId': 162111412 }, { 'playId': 162111411 }]
  },
  {
    'playTypeId': 1621115,
    'playTypeName': '第二球VS第四球',
    'playList': [{ 'playId': 162111510 }, { 'playId': 162111512 }, { 'playId': 162111511 }]
  },
  {
    'playTypeId': 1621116,
    'playTypeName': '第二球VS第五球',
    'playList': [{ 'playId': 162111610 }, { 'playId': 162111612 }, { 'playId': 162111611 }]
  },
  {
    'playTypeId': 1621117,
    'playTypeName': '第三球VS第四球',
    'playList': [{ 'playId': 162111710 }, { 'playId': 162111712 }, { 'playId': 162111711 }]
  },
  {
    'playTypeId': 1621118,
    'playTypeName': '第三球VS第五球',
    'playList': [{ 'playId': 162111810 }, { 'playId': 162111812 }, { 'playId': 162111811 }]
  },
  {
    'playTypeId': 1621119,
    'playTypeName': '第四球VS第五球',
    'playList': [{ 'playId': 162111910 }, { 'playId': 162111912 }, { 'playId': 162111911 }]
  }
  ]
},
{
  'playTabName': '全5中1',
  'playTabId': 16212,
  'playTypeList': [{
    'playTypeId': 1621210,
    'playTypeName': '全5中1',
    'playList': [{ 'playId': 162121010 }, { 'playId': 162121011 }, { 'playId': 162121012 }, { 'playId': 162121013 }, { 'playId': 162121014 }, { 'playId': 162121015 }, { 'playId': 162121016 }, { 'playId': 162121017 }, { 'playId': 162121018 }, { 'playId': 162121019 }]
  }]
}
]
