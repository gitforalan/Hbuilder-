<!--
 独立大厅
-->
<template>
  <div class="app-layout" ref="appLayout">
    <div class="app-main" v-if="this.isCurrentRoute">
      <div class="app-body">
        <!-- 大厅 -->
        <transition-group name="fade" tag="section" class="hall-group" ref="hallGroups" flex="dir:top">
          <div v-for="(row, rowIndex) in lotteryList"
               class="hall-row"
               :class="{'hall-sub-row': row.subRow, 'current': currentRowKey === row.key, 'last': row.lastSubRow && rowIndex !== lotteryList.length - 1}"
               flex="box:mean"
               :key="row.key">
            <div v-for="(col,colIndex) in row.data"
                 class="hall-col"
                 ref='hallCol'
                 :class="{'open-sub-row': isOpenSubRow(row, colIndex)}"
                 flex="cross:center dir:left box:first"
                 @click.stop="expandCol(row, rowIndex, col, colIndex)">
              <div><img :src="col.icon" alt="" width="60px" height="60px"></div>
              <div>
                <h3 class="title-lg">{{ col.title }}</h3>
                <p class="title-sm ellipsis">{{ col.desc }}</p>
              </div>
            </div>
            <div class="hall-col" v-if="(row.data.length % 2 !== 0 )"></div>
          </div>
        </transition-group>
      </div>
    </div>

    <router-view></router-view>
  </div>
</template>
<script type="text/ecmascript-6">
  import { lotteryListFac } from 'views/home/hallData'
  import { mapState, mapMutations } from 'vuex'
  import { cookie } from 'vux'
  import * as API from 'api/wapi/front'

  let lastId = 0
  export default {
    data () {
      return {
        title: '大厅',
        isCurrentRoute: true,
        lotteryList: [],
        openSubRow: {}, // 存子行展开状态
        currentRowKey: 0, // 存当前展开行的key 用做高亮线条样式
        cacheLotteryList: 'CACHE_LOTTERYLIST' // 大厅列表缓存key
      }
    },
    computed: {
      ...mapState({
        lotteryTypeId: state => state.common.lotteryTypeId
      })
    },
    methods: {
      // 大厅列表
      getLotteryList () {
//        let cacheLotteryList = localStorage.getItem(this.cacheLotteryList)
//        let versionCode
//        if (cacheLotteryList) {
//          cacheLotteryList = JSON.parse(cacheLotteryList)
//          versionCode = cacheLotteryList.versionCode
//          this.lotteryList = cacheLotteryList.lotteryList // 取缓存
//        }
//        const query = { versionCode: versionCode }
        API.getLotteryList().then(res => {
          // 判断缓存是否有效
//          if (versionCode && versionCode === res.data.versionCode) {
//            console.log('取缓存list')
//            return
//          }
          // 处理数据
          this.lotteryList = lotteryListFac(res.data.lotteryTypeList)
          // 写入缓存
          const cacheData = {
            versionCode: res.data.versionCode,
            lotteryList: this.lotteryList
          }
          localStorage.setItem(this.cacheLotteryList, JSON.stringify(cacheData))
          console.log('lotteryList 写入缓存', this.lotteryList)
        })
      },
      expandCol (row, rowIndex, col, colIndex) {
        if (col.expand && col.expand.length === 0) {
          this.$vux.loading.show({
            position: 'absolute'
          })
          setTimeout(() => {
            this.$vux.loading.hide({})
          }, 3000)
        }

        if (col.expand instanceof Array) {
          // 关闭其它子行
          for (let i = this.lotteryList.length - 1; i >= 0; i--) {
            let _row = this.lotteryList[i]
            if (_row.key !== row.key) {
              if (_row.hasOwnProperty('subRow')) {
                this.lotteryList.splice(i, 1)
              } else {
                if (this.openSubRow.hasOwnProperty(_row.key)) {
                  delete this.openSubRow[_row.key]
                }
              }
            }
          }
          // 若已经展开
          if (this.openSubRow[row.key]) {
            if (col.typeId === lastId) {
              for (let r = this.lotteryList.length - 1; r >= 0; r--) {
                let _row = this.lotteryList[r]
                let key = row.key
                if (_row.hasOwnProperty('parentKey') && _row.parentKey === key) {
                  this.lotteryList.splice(r, 1)
                }
              }
              delete this.openSubRow[row.key]
              this.currentRowKey = 0 // 还原标记的key
              return
            }
          }
          let rightMenuArr = [] // 右菜单列表
          // 子项添加到渲染列表
          col.expand.map((v, k) => {
            lastId = col.typeId
            v.subRow = true
            if (k === col.expand.length - 1) v.lastSubRow = true
            v.parentKey = row.key
            this.lotteryList.splice(row.key + k, 0, v)
            v.data.map(i => {
              let obj = {}
              obj.id = i.id
              obj.lotteryName = i.title
              rightMenuArr.push(obj)
            })
          })
          this.set_rightMenu(rightMenuArr)
          this.openSubRow[row.key] = { ci: colIndex } // 标记打开状态 当前列序号ci
          this.currentRowKey = row.key // 当前行的key

          this.$nextTick(() => {
            // const APPBODY_TOP = this.$refs.appBody.offsetTop
            // const XHEADER_TOP = this.$refs.xHeader.$el.offsetHeight
            const HALLGROUP_TOP = 0 // this.$refs.hallGroup.$el.offsetTop
            const ROW_HEIGHT = document.querySelector('.hall-row').offsetHeight
            // 当前行底边top
            const rowTop = HALLGROUP_TOP + ROW_HEIGHT * row.key
            // 滚动条位置
            const pageY = window.pageYOffset
            const subRowTotalHeight = col.expand.length * ROW_HEIGHT
            const sY = rowTop + subRowTotalHeight - window.innerHeight - pageY
            if (sY > 0) {
              window.scrollBy(0, sY)
            }
          })
        } else {
          if (col.expand === 'undefined') return  // 防止接口无数据走跳转
          // this.swich_lottery(true)
          // 直播彩票特殊处理
          const spCode = cookie.get('sn')
          const token = cookie.get('token')
          if (col.lotteryTypeId === 'zhubo') {
            if (spCode && token) {
              // 有token带token  没有直接跳
              window.location.href = col.link + `?spCode=${spCode}&token=${token}`
            } else {
              window.location.href = col.link
            }
          } else {
            this.$router.push({ name: 'chunkComp', params: { sid: col.id } })
          }
        }
      },
      isOpenSubRow (row, colIndex) {
        const osr = this.openSubRow.hasOwnProperty(row.key) && this.openSubRow[row.key]
        return osr && osr.ci === colIndex && !row.subRow
      },
      ...mapMutations('common', ['set_rightMenu', 'swich_lottery'])
    },
    created () {
      if (this.$route.name !== 'lottery') {
        this.isCurrentRoute = false
      } else {
        this.getLotteryList() // 请求 大厅列表
      }
    },
    watch: {
      $route (to, from) {
        if (from.name === 'lottery') {
          this.isCurrentRoute = false
        } else if (to.name === 'lottery') {
          this.isCurrentRoute = true
        }
      }
    }
  }
</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"
  $t = .3s
  .app-body
    padding-top 0

  .app-layout
    height calc(100vh - 3.5rem - 4rem)

  .hall-group
    ul
      background #d5d5d5
      margin 1rem
      li
        padding 2rem .5rem
        margin: .5rem
        background #eecebc
        text-align center
        font-size 2rem
        color #666

  .hall-group
    .hall-row
      transition all $t
      background #fff
      border-bottom 1px solid $color-border
      min-height rem(121)
      width 100%
      z-index 10
      box-sizing border-box
      .hall-col
        position relative
        margin-left rem(40)
        transition background .5s
        border-right 1px solid $color-border
        box-sizing border-box
        div
          .title-lg
            font-size rem(28)
            margin-bottom rem(7)
            color #000
            i
              width 2.3rem
              height .8rem
              padding 0 .2rem
              background #ffb70b
              color $color-white
              font-size $size-medium
              font-style normal
              text-align center
              border-top-left-radius 15px
              border-top-right-radius 25px
              border-bottom-right-radius 25px
          .title-sm
            line-height 1.2em
            font-size rem(22)
            color $color-black-b
          img
            margin-right rem(10)
            width rem(80)
            height rem(80)
            border-radius 1.88rem
        &:active
          background #eee
      .open-sub-row:before, .open-sub-row:after
        content: "";
        border-color: $color-red transparent;
        border-style: solid;
        display: block;
        height: 0;
        font-size: 0;
        line-height: 0;
        width: 0;
        border-width: 0 .5rem .5rem;
        position: absolute;
        z-index: 12;
        bottom: -.05rem;
        left: 50%
        zoom: 12
      .open-sub-row:after
        border-color: transparent transparent;
        bottom: -1px
        left: 50%;
        z-index: 13;
      &.current
        border-bottom 1px solid $color-red
    .hall-sub-row
      background: #f7f7f7
      border-bottom none
      z-index 9
      &.last
        border-bottom 1px solid $color-border
      .hall-col
        border-right none
    & > div:last-child
      border-bottom 0

    .fade-enter
      z-index 1
      opecity 0
      border-bottom 0
      transform translateY(-100%)
    .fade-enter-active
      border-bottom-color transparent !important
    .fade-leave
      z-index 2
      border-bottom-color transparent !important
    .fade-leave-to
      opacity 0
      transform translateY(10%)
    .fade-leave-active
      position absolute
    .fade-move
      transform translateY(0%)
      transition all  $t
</style>
