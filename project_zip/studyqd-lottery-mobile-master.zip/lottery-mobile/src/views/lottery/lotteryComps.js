/**
 * Created by fx on 2017/8/28.
 */
const hotLoad = require('@/utils/import_' + process.env.NODE_ENV)
const Ssc = hotLoad('lottery/ssc/index')  // 时时彩
const Ssl = hotLoad('lottery/ssl/index')  // 时时乐
const Ksan = hotLoad('lottery/ksan/index') // 快三
const Syx5 = hotLoad('lottery/syx5/index') // 11选5
const Pl3 = hotLoad('lottery/pl3/index') // 排列3
const Fc3d = hotLoad('lottery/fc3d/index') // 福彩3D
const Pk10 = hotLoad('lottery/pk10/index') // pk拾
const Lhc = hotLoad('lottery/6hc/index') // 六合彩
const Pcdd = hotLoad('lottery/pcdd/index') // PC蛋蛋
const Kl8 = hotLoad('lottery/kl8/index') // 快乐8
const Kl10 = hotLoad('lottery/kl10/index') // 快乐十分

const OrderList = hotLoad('common/orderList/index') // 注单记录
const SmartOrder = hotLoad('common/smartOrder/index') // 智能追号
const BetInput = hotLoad('common/betInput')

export default {
  Ssc,
  Ssl,
  Ksan,
  Syx5,
  Pk10,
  Pl3,
  Fc3d,
  Lhc,
  Pcdd,
  Kl8,
  Kl10,
  OrderList,
  SmartOrder,
  BetInput
}
