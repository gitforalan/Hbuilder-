<template>
  <footer class="footer credit-footer">
    <!-- 设置区 -->
    <div v-if="rebateShow !== 2" class="set-group" flex="cross:center">
      <div flex-box="0" class="empty"></div>
      <div flex-box="1" flex="cross:center">
        <div class="rebate-wrap" flex="dir:top main:center">
          <div align="center" class="rebate-txt">
            <div>{{rangeValue | formatNumToDecimal}}%</div>
          </div>
          <div class="range-wrap" flex="cross:center" ref="range" resetstyle>
            <icon-svg icon-class="circle-jian"></icon-svg>
            <vue-slider
              v-model="rangeValue"
              width="100%"
              height="10"
              :disabled="rebateShow === 1"
              :bgStyle="{backgroundColor: '#fff',boxShadow: 'inset 0.5px 0.5px 3px 1px rgba(0,0,0,.36)'}"
              :processStyle="{backgroundColor: 'rgb(255, 81, 81)'}"
              :sliderStyle="{backgroundColor: '#ff5151'}"
              :tooltip="false"
              :min="0"
              :max="maxSliderVal">
            </vue-slider>
            <icon-svg icon-class="circle-jia"></icon-svg>
          </div>
        </div>
      </div>
    </div>
    <!-- 按钮区 -->
    <div class="btn-wrap" flex="cross:center">
      <div class="total-money" flex-box="0" flex="dir:top cross:center main:center">
        <p align="">共 <span>{{totalBetNumbers}}</span> 注</p>
        <p align="">共 <span>{{totalBetMoney}}</span> 元</p>
      </div>
      <div flex-box="1" flex="dir:right box:first cross:center">
        <div class="bet-btn" flex="dir:top cross:center" align="center">
          <div @click="doConfirm">投 注</div>
        </div>
        <div flex="box:mean cross:center dir:right">

          <template v-if="isInputStyleFooter">
            <!-- 只有输入金额的玩法 -->
            <div class="input-only">
              每注
              <input type="text" v-model="singleMoney" @input="checkInputOnly($event)"
                     @click="setInputOnlyFocus($event)">元
            </div>
          </template>
          <template v-else>
            <!-- 选择金额 -->
            <div class="set-rate rate-num" :class="{active:chips[1].isActive}" @click="setCurrentBetMoney(1)">
              {{chips[1].value}}
              <mode-popover :value="singleMoney" :show="showPopover" v-show="showPopover"
                            @on-hide="selectSingleBetMoney"/>
            </div>
            <!-- 输入金额 -->
            <div class="set-rate" :class="{active:chips[0].isActive}">
              <input type="text" placeholder="自定义" v-model="chips[0].value" @input="checkInputCustom($event)"
                     @blur="checkInputCustomBlur" @click="setCurrentBetMoney(0,$event)">
            </div>
          </template>
          <!-- 清空 -->
          <div class="delete" @click="setClearNow(true)"></div>
        </div>
      </div>
    </div>
  </footer>
</template>
<script type="text/ecmascript-6">
  import { mapMutations, mapGetters, mapState, mapActions } from 'vuex'
  import modePopover from './modePopover.vue'

  export default {
    name: 'sscCreditFooter',
    components: { modePopover },
    filters: {
      formatNumToDecimal (num) {
        return (num / 100).toFixed(2)
      }
    },
    methods: {
      ...mapMutations('ssc', [
        'setClearNow',
        'updateSingleBetMoney',
        'updateRebateRate',
        'setBetNow',
        'updateShowBetConfirm',
        'updateResetRebateRateSlider'
      ]),
      ...mapActions('common', [
        'validaSendBet'
      ]),
      // 选择当前筹码金额
      setCurrentBetMoney (type, $event) {
        this.chips.forEach((i, idx) => {
          if (idx === type) {
            i.isActive = true
            if (type === 1) this.showPopover = true
          } else {
            i.isActive = false
            this.showPopover = false
          }
        })
        if (!$event) return
        // 处理自定义类型
        let target = $event.target
        let nodeName = target.nodeName.toLowerCase()
        if (nodeName === 'input') {
          target.focus()
          target.select()
        }
      },
      // 检测设置自定义筹码金额
      checkInputCustom ($event) {
        let val = $event.target.value
        val = val.replace(/[^0-9]/g, '')
        if (val === '' || val === 0) val = ''
        if (val > 99999) {
          val = val.split('')
          val.pop()
          val = val.join('')
        }
        if (val !== '') {
          val = parseInt(val, 10)
          this.chips[0].value = val
          this.singleMoney = val
        } else {
          return
        }
      },
      // 检测是否输入了具体的数值
      checkInputCustomBlur () {
        if (this.chips[0].value === '') {
          this.chips[0].isActive = false
          this.chips[1].isActive = true
          this.singleMoney = this.chips[1].value
        }
      },
      // 只有输入金额:选中数字
      setInputOnlyFocus ($event) {
        let target = $event.target
        let nodeName = target.nodeName.toLowerCase()
        if (nodeName === 'input') {
          // target.focus()
          target.select()
        }
      },
      // 只有输入金额:输入格式校验
      checkInputOnly ($event) {
        let val = $event.target.value
        val = val.replace(/[^0-9]/g, '')
        if (val === '' || val === 0) val = 1
        if (val > 9999) val = 9999
        val = parseInt(val, 10)
        this.singleMoney = val
      },
      // 下拉选择金额
      selectSingleBetMoney (num) {
        this.singleMoney = num
        this.chips[1].value = num
        this.delayExec(() => {
          this.showPopover = false
        })
      },
      delayExec (fn) {
        setTimeout(fn, 20)
      },
      doConfirm () {
        this.validaSendBet().then(res => {
          let options = {
            type: 'warn',
            isShowMask: false,
            time: 2000
          }
          // 判断是否选了球
          if (this.selectedNumber === '') {
            options.text = '请先选择下注号码'
            this.$vux.toast.show(options)
            return
          }
//          // 判断是否选择了足够的球
//          if (this.selectedNumber !== '' && this.flattenBetList.length === 0) {
//            options.text = `至少需要选择 ${this.minChosen} 个`
//            this.$vux.toast.show(options)
//            return
//          }
          // 判断用户余额
          let userBalance = res.balance
          if (userBalance < this.totalBetMoney) {
            options.text = `您的余额不足`
            this.$vux.toast.show(options)
            return
          }
          // 确认投注
          this.setBetNow(true)
        })
      }
    },
    watch: {
      // 监听金额变化，同步到store
      singleMoney (nval) {
        this.updateSingleBetMoney(nval)
      },
      // 复位活动条
      isResetRebateRateSlider (nval) {
        if (nval) this.rangeValue = 0
        this.updateResetRebateRateSlider(false)
      },
      rangeValue (val) {
        if (val < 0.1) val = 0
        this.updateRebateRate(val)
      }
    },
    computed: {
      ...mapGetters('ssc', [
        'totalBetNumbers',
        'totalBetMoney'
      ]),
      ...mapState('ssc', [
        'selectedNumber',
        'maxSliderVal',
        'isInputStyleFooter',
        'singleBetMoney',
        'flattenBetList',
        'minChosen',
        'isResetRebateRateSlider'
      ]),
      ...mapState('common', {
        rebateShow: state => state.rebateShow
      })
    },
    data () {
      return {
        setRateVal: '',
        rangeValue: 0,
        singleMoney: 5,
        showPopover: false,
        chips: [{ isActive: false, value: '' }, { isActive: true, value: 5 }]
      }
    },
    props: {},
    created () {
      this.updateSingleBetMoney(this.singleMoney)
    }
  }
</script>
