/**
 * Created by fx on 2017/10/11.
 */
import commonEd from '../../public/mixin'

export default {
  name: 'quanWuZhongYi',
  mixins: [commonEd]
}
