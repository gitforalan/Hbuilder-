/**
 * Created by fx on 2017/8/28.
 */
const filePath = 'lottery/ssc/credit/'
// 分包
const hotLoad = require('@/utils/import_' + process.env.NODE_ENV)
const ZhengHe = hotLoad(filePath + 'all/zhenghe/index')
const QuanWuZhongYi = hotLoad(filePath + 'all/quanwuzhongyi/index')
const LongHuDou = hotLoad(filePath + 'all/longhudou/index')
// 合并js
// const ZhengHe = r => require.ensure([], () => r(require(filePath + 'zhenghe/index.vue'), 'ssc'))
// const QuanWuZhongYi = r => require.ensure([], () => r(require(filePath + 'quanwuzhongyi/index.vue'), 'ssc'))
// const LongHuDou = r => require.ensure([], () => r(require(filePath + 'longhudou/index.vue'), 'ssc'))

export default {
  ZhengHe,
  QuanWuZhongYi,
  LongHuDou
}
