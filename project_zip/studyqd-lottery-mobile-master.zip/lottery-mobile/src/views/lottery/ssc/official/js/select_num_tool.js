/* eslint-disable */
const random = require('lodash/random')
export default {

  doSelectNumber (index, attribute, rowIndex) {
    switch (attribute) {
      case 'all':
        this.doSelectAll(index)
        break
      case 'big':
        this.doSelectBig(index)
        break
      case 'small':
        this.doSelectSmall(index)
        break
      case 'odd':
        this.doSelectOdd(index)
        break
      case 'even':
        this.doSelectEven(index)
        break
      case 'clear':
        this.doUnselectAll(index)
        break
      case 'single':
        this.doSelectSingle(index, rowIndex)
        break
    }
    // 计算注数
    // this.calcNumber()
  },

  doSelectAll (index) {
    let row = this.currentLayout[index].no
    row.forEach(i => i.isSelected = 1)
  },
  doUnselectAll (index) {
    let row = this.currentLayout[index].no
    row.forEach(i => i.isSelected = 0)
  },
  doSelectBig (index) {
    this.doUnselectAll(index)
    let row = this.currentLayout[index].no
    let target = row.filter(i => i.number >= this.noBigIndex)
    target.forEach(i => i.isSelected = 1)
  },
  doSelectSmall (index) {
    this.doUnselectAll(index)
    let row = this.currentLayout[index].no
    let target = row.filter(i => i.number < this.noBigIndex)
    target.forEach(i => i.isSelected = 1)
  },
  doSelectOdd (index) {
    this.doUnselectAll(index)
    let row = this.currentLayout[index].no
    let target = row.filter((i, index) => !(index % 2 == 0))
    target.forEach(i => i.isSelected = 1)
  },
  doSelectEven (index) {
    this.doUnselectAll(index)
    let row = this.currentLayout[index].no
    let target = row.filter((i, index) => index % 2 == 0)
    target.forEach(i => i.isSelected = 1)
  },
  doSelectSingle (index, rowIndex) {
    let alias = this.currentPlay.alias
    let selected = this.currentLayout[index].no[rowIndex]
    // 针对包胆玩法，特殊处理
    // 这里暂时检查玩法别名最后两位是不是'BD'字符
    if (alias && alias.slice(-2) == 'BD') {
      let cacheStatus = selected.isSelected
      this.doUnselectAll(index)
      cacheStatus === 1 ? selected.isSelected = 0 : selected.isSelected = 1
      return
    }
    selected.isSelected === 1 ? selected.isSelected = 0 : selected.isSelected = 1
  },
  doClearLayout () {
    let len = this.currentLayout.length
    for (let i = 0; i < len; i++) {
      this.doUnselectAll(i)
    }
  },
  doSelectRandom () {
    var mname = this.currentPlay.alias
    var otype = this.layoutType
    var data_sel = this.currentLayout
    var repeate = 1
    var repeatetmp = []

    if (otype == 'input') { // 输入框形式的检测
      this.allInputCode = [] // 清空随机号码
      nums = parseInt(mname.charAt(mname.length - 1))
      switch (mname) { // 根据玩法分类不同做不同处理
        case 'ZUS':
          repeate = 0
          nums = 2
          break
        case 'ZUL':
          repeate = 0
          nums = 3
          break
        case 'HHZX':
          repeate = 0
          nums = 3
        case 'ZU2':
          repeate = 0
          break
        case 'BJZ3':
          repeate = 0
          break
        case 'BJZ2':
          repeate = 0
          break
        default: // 默认情况
          break
      }
      var s = ''
      var repeatetmp = []
      if (mname == 'ZUS') {
        var tmp = Math.floor(2 * Math.random())
      }
      if (mname == 'HHZX') {
        var tmp = Math.floor(3 * Math.random())
      }
      for (var j = 0; j < nums; j++) {
        if (repeate == 0) { // 号码不允许重复
          if (mname == 'BJZ3' || mname == 'BJZ2') {
            do {
              var index = Math.floor(9 * Math.random() + 1)
              if (!repeatetmp.contains(index)) {
                repeatetmp.push(index)
                break
              }
            } while (1)
          } else {
            do {
              var index = Math.floor(10 * Math.random())
              if (!repeatetmp.contains(index)) {
                repeatetmp.push(index)
                break
              }
            } while (1)
          }
        } else {
          var index = Math.floor(10 * Math.random())
        }
        if (mname == 'BJZ3' || mname == 'BJZ2') {
          s = s + 0 + index
        } else {
          s = s + index
        }
        if (mname == 'ZUS' && tmp == j) {
          s = s + index
        }
        if (mname == 'HHZX' && tmp == j && j == 1) {
          s = s + index
          break
        }
      }
      //
      this.allInputCode[0] = [s]
      let sss = s.split('').join('')
      return sss
    } else { // 其他选择号码形式[暂时就数字型和大小单双]
      this.doClearLayout() // 清除手动选择的号码
      this.betNumber = 0
      this.randomSelNum = []

      var nums = this.maxPlace
      var amin = []
      switch (mname) { // 根据玩法分类不同做不同处理
        case 'WXZU120':
          nums = 0
          amin[0] = 5
          break
        case 'WXZU60':
          repeate = 0
          nums = 1
          amin[0] = 1
          amin[1] = 3
          break
        case 'WXZU30':
          repeate = 0
          nums = 1
          amin[0] = 2
          amin[1] = 1
          break
        case 'WXZU10':
        case 'WXZU5':
        case 'SXZU4':
          repeate = 0
          nums = 1
          amin[0] = 1
          amin[1] = 1
          break
        case 'SXZU24':
          nums = 0
          amin[0] = 4
          break
        case 'SXZU6':
          nums = 0
          amin[0] = 2
          break
        case 'WXZU20':
        case 'SXZU12':
          repeate = 0
          nums = 1
          amin[0] = 1
          amin[1] = 2
          break
        case 'ZUS': // 组三
          nums = 0
          amin[0] = 2
          break
        case 'ZUL': // 组六
          nums = 0
          amin[0] = 3
          break
        case 'BDW3':
          nums = 0
          amin[0] = 3
          break
        case 'BDW2': // 二码不定位
        case 'ZU2': // 2位组选
          nums = 0
          amin[0] = 2
          break
        case 'DWD': // 定位胆所有在一起特殊处理
          var weiNum = 5 // 时时彩
          var amin = Array(5)
          var j = Math.ceil(Math.random() * 100) % weiNum // 随机一位
          amin[j] = 1 // 随机一注
          break
        case 'RZX2': // 任二直选
          nums = 4
          for (var j = 0; j <= nums; j++) {
            amin[j] = 1
          }
          do {
            let p = random(0, nums)
            delete amin[p]
            let len = amin.filter(i => i == 1).length
            if (len == 2) break
          } while (1)
          break
        case 'RZX3': // 任三直选
          nums = 4
          for (var j = 0; j <= nums; j++) {
            amin[j] = 1
          }
          do {
            let p = random(0, nums)
            delete amin[p]
            let len = amin.filter(i => i == 1).length
            if (len == 3) break
          } while (1)
          break
        case 'RZX4': // 任四直选
          nums = 4
          for (var j = 0; j <= nums; j++) {
            amin[j] = 1
          }
          var p = random(0, nums)
          delete amin[p]
          break
        case 'ZXHZ': // 和值特殊处理
        case 'ZUSHZ':
        case 'ZXHZ2':
        case 'ZUHZ':
          var amin = Array(2)
          var j = random(0, 1) // 和值类上下两行的 ,随机一行
          amin[j] = 1 // 随机一注
          break
        default: // 默认情况,有多少位选择多少位
          for (var j = 0; j <= nums; j++) {
            amin[j] = 1
          }
          break
      }
      //
      var _this = this

      function genTempCode () {
        var tmp = []
        _this.randomSelNum = []
        for (let i = 0; i < amin.length; i++) {
          /* 处理每一行数据 开始 */
          let min = _this.currentLayoutNum[i][0]
          let max = _this.currentLayoutNum[i][_this.currentLayoutNum[i].length - 1]
          var rowCode // 数组，保存每一行上的号码
          var len = amin[i] ? Number(amin[i]) : 0 // 如果amin[i]为undefined，则初始len为0，不进入循环
          do { // 确保一行上的随机数不重复
            rowCode = []
            for (let j = 0; j < len; j++) {
              let _random = random(min, max)
              rowCode.push(_random)
            }
            let _set = Array.from(new Set(rowCode))
            if (_set.length == rowCode.length) break
          } while (true)
          rowCode.sort((a, b) => a - b) // 排序
          /* 处理每一行数据 结束 */

          tmp.push(rowCode)
        }
        // 处理特定数据两行数据交叉包含，重新计算，直到不交叉包含
        if (repeate == 0) { // 都是有repeate标记的特殊玩法
          _this.randomSelNum = []
          let _max, _min
          if (tmp[0].length >= tmp[1].length) {
            _max = tmp[0].join('')
            _min = tmp[1].join('')
          } else {
            _max = tmp[1].join('')
            _min = tmp[0].join('')
          }
          // debugger
          if (_max == _min) {
            return genTempCode()
          }
          if (_max.indexOf(_min) != -1) {
            return genTempCode()
          }
        }
        // 生成用于注数计算的数组
        tmp.forEach((i, idx) => {
          if (i.length) {
            // _this.randomSelNum.push(i.split(','))
            _this.randomSelNum.push(i)
          } else {
            _this.randomSelNum.push([]) // 添加个空数据，否则注数计算出错
          }
        })

        // 处理随机号码的显示格式
        let finalName
        switch (mname) {
          case 'ZXHZ':
          case 'ZUSHZ':
          case 'ZXHZ2':
          case 'ZUHZ':
            finalName = tmp.join(',').replace(',', '')
            break
          case 'DWD':
          case 'RZX2':
          case 'RZX3':
          case 'RZX4':
            finalName = tmp.join(',')
            break
          case 'WXZU20':
          case 'WXZU30':
          case 'WXZU60':
          case 'WXZU5':
          case 'WXZU10':
          case 'SXZU12':
            let _name = tmp.map(i => {
              if (i.length > 1) return i.join('')
              return i
            })
            finalName = _name.join(',')
            break
          case 'ZUS':
          case 'ZUL':
            finalName = tmp.join(',')
            break
          default:
            finalName = tmp.join(',')
            break
        }
        // debugger
        // 返回购买的号码
        return finalName
      }

      return genTempCode()
    }
  }
}
