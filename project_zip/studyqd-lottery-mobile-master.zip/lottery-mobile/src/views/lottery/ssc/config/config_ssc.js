/*
 * 时时彩基础数据 官方玩法
 * eslint 格式化 format by fx， 2017-9-19 12:49:16
 * */

export default {
  /* 五星直选 */
// 直选复式
  101101010: {
    alias: 'ZX5',
    selectarea: {
      type: 'digital',
      noBigIndex: 5,
      isButton: true,
      hcltPosition: [0, 1, 2, 3, 4],
      layout: [{
        title: '万位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }, {
        title: '千位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 1,
        cols: 1
      }, {
        title: '百位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 2,
        cols: 1
      }, {
        title: '十位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 3,
        cols: 1
      }, {
        title: '个位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 4,
        cols: 1
      }]
    }
  },
// 直选单式
  101101011: {
    alias: 'ZX5',
    selectarea: {
      type: 'input'
    }
  },
  /* 五星组选 */
// 五星组选 组选5
  101101110: {
    alias: 'WXZU5',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '四重号',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1,
        minchosen: 1
      }, {
        title: '单　号',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 1,
        cols: 1,
        minchosen: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 五星组选 组选10
  101101111: {
    alias: 'WXZU10',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '三重号',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1,
        minchosen: 1
      }, {
        title: '二重号',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 1,
        cols: 1,
        minchosen: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 五星组选 组选20
  101101112: {
    alias: 'WXZU20',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '三重号',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1,
        minchosen: 1
      }, {
        title: '单　号',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 1,
        cols: 1,
        minchosen: 2
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 五星组选 组选30
  101101113: {
    alias: 'WXZU30',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '二重号',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1,
        minchosen: 2
      }, {
        title: '单　号',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 1,
        cols: 1,
        minchosen: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 五星组选 组选60
  101101114: {
    alias: 'WXZU60',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '二重号',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1,
        minchosen: 1
      }, {
        title: '单　号',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 1,
        cols: 1,
        minchosen: 3
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 五星组选 组选120
  101101115: {
    alias: 'WXZU120',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '组选120',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1,
        minchosen: 5
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
  /* 前四直选 */
// 前四直选 直选复式
  101111010: {
    selectarea: {
      type: 'digital',
      noBigIndex: 5,
      isButton: true,
      hcltPosition: [0, 1, 2, 3],
      layout: [{
        title: '万位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }, {
        title: '千位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 1,
        cols: 1
      }, {
        title: '百位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 2,
        cols: 1
      }, {
        title: '十位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 3,
        cols: 1
      }]
    }
  },
// 前四直选 直选单式
  101111011: {
    alias: 'ZX4',
    selectarea: {
      type: 'input'
    }
  },
  /* 后四直选 */
// 后四直选 直选复式
  101111110: {
    selectarea: {
      type: 'digital',
      hcltPosition: [1, 2, 3, 4],
      noBigIndex: 5,
      isButton: true,
      layout: [{
        title: '千位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }, {
        title: '百位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 1,
        cols: 1
      }, {
        title: '十位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 2,
        cols: 1
      }, {
        title: '个位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 3,
        cols: 1
      }]
    }
  },
// 后四直选 直选单式
  101111111: {
    alias: 'ZX4',
    selectarea: {
      type: 'input'
    }
  },
  /* 后三直选 */
// 后三直选复式
  101121010: {
    selectarea: {
      type: 'digital',
      hcltPosition: [2, 3, 4],
      layout: [{
        title: '百位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }, {
        title: '十位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 1,
        cols: 1
      }, {
        title: '个位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 2,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 后三直选单式
  101121011: {
    alias: 'ZX3',
    selectarea: {
      type: 'input'
    }
  },
// 后三直选和值
  101121012: {
    alias: 'ZXHZ',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '和值',
        no: '0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27',
        place: 0,
        cols: 1
      }],
      isButton: false
    }
  },
// 后三直选跨度
  101121013: {
    alias: 'ZXKD',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '跨度',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 后三直选组合百十个
  101121014: {},
// 后三直选组合十个
  101121015: {},
// 后三直选组合个
  101121016: {},
// 后三直选组合
  101121017: {
    alias: 'ZH3',
    selectarea: {
      type: 'digital',
      hcltPosition: [2, 3, 4],
      layout: [{
        title: '百位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }, {
        title: '十位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 1,
        cols: 1
      }, {
        title: '个位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 2,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
  /* 后三组选 */
// 后三组选组三
  101121110: {
    alias: 'ZUS',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '组三',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 后三组选组六
  101121111: {
    alias: 'ZUL',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '组六',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 后三混合组选组三
  101121112: {},
// 后三混合组选组六
  101121113: {},
// 后三混合组选
  101121114: {
    alias: 'HHZX',
    selectarea: {
      type: 'input'
    }
  },
// 后三组选和值组三
  101121115: {},
// 后三组选和值组六
  101121116: {},
// 后三组选和值
  101121117: {
    alias: 'ZUSHZ',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '和值',
        no: '1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: false
    }
  },
// 后三组选包胆组三
  101121118: {},
// 后三组选包胆组六
  101121119: {},
// 后三组选包胆
  101121120: {
    alias: 'ZU3BD',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '包胆',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: false
    }
  },
  /* 后三其他 */
// 后三其他和值尾数
  101121210: {
    alias: 'HZWS',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '和值尾数',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 特殊号
  101121214: {
    alias: 'TSH3',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '特殊号',
        no: '豹子|顺子|对子',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: false
    }
  },
// 豹子
  101121211: {},
// 顺子
  101121212: {},
// 对子
  101121213: {},
  /* 前三直选 */
// 直选复式
  101131010: {
    selectarea: {
      type: 'digital',
      hcltPosition: [0, 1, 2],
      layout: [{
        title: '万位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }, {
        title: '千位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 1,
        cols: 1
      }, {
        title: '百位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 2,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 直选单式
  101131011: {
    alias: 'ZX3',
    selectarea: {
      type: 'input'
    }
  },
// 直选和值
  101131012: {
    alias: 'ZXHZ',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '和值',
        no: '0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27',
        place: 0,
        cols: 1
      }],
      isButton: false
    }
  },
// 直选跨度
  101131013: {
    alias: 'ZXKD',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '跨度',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },

// 直选组合万千百
  101131014: {},
// 直选组合千百
  101131015: {},
// 直选组合百
  101131016: {},
// 直选组合
  101131017: {
    alias: 'ZH3',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '万位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }, {
        title: '千位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 1,
        cols: 1
      }, {
        title: '百位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 2,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
  /* 前三组选 */
// 组选组三
  101131110: {
    alias: 'ZUS',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '组三',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 组选组六
  101131111: {
    alias: 'ZUL',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '组六',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 混合组选组三
  101131112: {},
// 混合组选组六
  101131113: {},
// 混合组选
  101131114: {
    alias: 'HHZX',
    selectarea: {
      type: 'input'
    }
  },
// 组选和值组三
  101131115: {},
// 组选和值组六
  101131116: {},
// 组选和值
  101131117: {
    alias: 'ZUSHZ',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '和值',
        no: '1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: false
    }
  },
// 组选包胆组三
  101131118: {},
// 组选包胆组六
  101131119: {},
// 组选包胆
  101131120: {
    alias: 'ZU3BD',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '包胆',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: false
    }
  },
  /* 前三其他 */
// 和值尾数
  101131210: {
    alias: 'HZWS',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '和值尾数',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 特殊号
  101131214: {
    alias: 'TSH3',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '特殊号',
        no: '豹子|顺子|对子',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: false
    }
  },
// 豹子
  101131211: {},
// 顺子
  101131212: {},
// 对子
  101131213: {},
  /* 前二直选 */
// 直选复式
  101141010: {
    selectarea: {
      type: 'digital',
      hcltPosition: [0, 1],
      layout: [{
        title: '万位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }, {
        title: '千位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 1,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 直选单式
  101141011: {
    alias: 'ZX2',
    selectarea: {
      type: 'input'
    }
  },
// 直选和值
  101141012: {
    alias: 'ZXHZ2',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '和值',
        no: '0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18',
        place: 0,
        cols: 1
      }],
      isButton: false
    }
  },
// 直选跨度
  101141013: {
    alias: 'ZXKD2',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '跨度',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
  /* 后二直选 */
// 直选复式
  101141110: {
    selectarea: {
      hcltPosition: [3, 4],
      type: 'digital',
      layout: [{
        title: '十位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }, {
        title: '个位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 1,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 直选单式
  101141111: {
    alias: 'ZX2',
    selectarea: {
      type: 'input'
    }
  },
// 直选和值
  101141112: {
    alias: 'ZXHZ2',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '和值',
        no: '0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18',
        place: 0,
        cols: 1
      }],
      isButton: false
    }
  },
// 直选跨度
  101141113: {
    alias: 'ZXKD2',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '跨度',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
  /* 前二组选 */
// 组选复式
  101141210: {
    alias: 'ZU2',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '组选',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 组选单式
  101141211: {
    alias: 'ZU2',
    selectarea: {
      type: 'input'
    }
  },
// 组选和值
  101141212: {
    alias: 'ZUHZ2',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '和值',
        no: '1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: false
    }
  },
// 组选包胆
  101141213: {
    alias: 'ZU2BD',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '包胆',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: false
    }
  },
  /* 后二组选 */
// 组选复式
  101141310: {
    alias: 'ZU2',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '组选',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 组选单式
  101141311: {
    alias: 'ZU2',
    selectarea: {
      type: 'input'
    }
  },
// 组选和值
  101141312: {
    alias: 'ZUHZ2',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '和值',
        no: '1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: false
    }
  },
// 组选包胆
  101141313: {
    alias: 'ZU2BD',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '包胆',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: false
    }
  },
  /* 定位胆 */
  101151010: {
    alias: 'DWD',
    selectarea: {
      type: 'digital',
      hcltPosition: [0, 1, 2, 3, 4],
      layout: [{
        title: '万位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }, {
        title: '千位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 1,
        cols: 1
      }, {
        title: '百位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 2,
        cols: 1
      }, {
        title: '十位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 3,
        cols: 1
      }, {
        title: '个位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 4,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
  /* 不定位前三 */
// 一码不定位
  101161010: {
    selectarea: {
      type: 'digital',
      layout: [{
        title: '不定位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 二码不定位
  101161011: {
    alias: 'BDW2',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '不定位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
  /* 不定位后三 */
// 一码不定位
  101161110: {
    selectarea: {
      type: 'digital',
      layout: [{
        title: '不定位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 二码不定位
  101161111: {
    alias: 'BDW2',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '不定位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
  /* 不定位前四 */
// 一码不定位
  101161210: {
    selectarea: {
      type: 'digital',
      layout: [{
        title: '不定位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 二码不定位
  101161211: {
    alias: 'BDW2',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '不定位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
  /* 不定位后四 */
// 一码不定位
  101161310: {
    selectarea: {
      type: 'digital',
      layout: [{
        title: '不定位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 二码不定位
  101161311: {
    alias: 'BDW2',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '不定位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
  /* 不定位五星 */
// 一码不定位
  101161410: {
    selectarea: {
      type: 'digital',
      layout: [{
        title: '不定位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 二码不定位
  101161411: {
    alias: 'BDW2',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '不定位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },

// 三码不定位
  101161412: {
    alias: 'BDW3',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '不定位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
  /* 大小单双后二 */
// 后二
  101171010: {
    alias: 'DXDS',
    selectarea: {
      type: 'dxds',
      isButton: false,
      layout: [{
        title: '十位',
        no: '大|小|单|双',
        place: 0,
        cols: 1
      }, {
        title: '个位',
        no: '大|小|单|双',
        place: 1,
        cols: 1
      }]
    }
  },
  /* 大小单双后三 */
// 后三
  101171011: {
    alias: 'DXDS',
    selectarea: {
      type: 'dxds',
      isButton: false,
      layout: [{
        title: '百位',
        no: '大|小|单|双',
        place: 0,
        cols: 1
      }, {
        title: '十位',
        no: '大|小|单|双',
        place: 1,
        cols: 1
      }, {
        title: '个位',
        no: '大|小|单|双',
        place: 2,
        cols: 1
      }]
    }
  },
  /* 大小单双前二 */
// 前二
  101171012: {
    alias: 'DXDS',
    selectarea: {
      type: 'dxds',
      isButton: false,
      layout: [{
        title: '万位',
        no: '大|小|单|双',
        place: 0,
        cols: 1
      }, {
        title: '千位',
        no: '大|小|单|双',
        place: 1,
        cols: 1
      }]
    }
  },
  /* 大小单双前三 */
// 前三
  101171013: {
    alias: 'DXDS',
    selectarea: {
      type: 'dxds',
      isButton: false,
      layout: [{
        title: '万位',
        no: '大|小|单|双',
        place: 0,
        cols: 1
      }, {
        title: '千位',
        no: '大|小|单|双',
        place: 1,
        cols: 1
      }, {
        title: '百位',
        no: '大|小|单|双',
        place: 2,
        cols: 1
      }]
    }
  },
  /* 大小单双第一球 */
// 第一球
  101171014: {
    alias: 'DXDS',
    selectarea: {
      type: 'dxds',
      noBigIndex: 5,
      isButton: false,
      layout: [{
        title: '第一球',
        no: '大|小|单|双',
        place: 0,
        cols: 1
      }]
    }
  },
  /* 大小单双第二球 */
// 第二球
  101171015: {
    alias: 'DXDS',
    selectarea: {
      type: 'dxds',
      noBigIndex: 5,
      isButton: false,
      layout: [{
        title: '第二球',
        no: '大|小|单|双',
        place: 0,
        cols: 1
      }]
    }
  },
  /* 大小单双第三球 */
// 第三球
  101171016: {
    alias: 'DXDS',
    selectarea: {
      type: 'dxds',
      noBigIndex: 5,
      isButton: false,
      layout: [{
        title: '第三球',
        no: '大|小|单|双',
        place: 0,
        cols: 1
      }]
    }
  },
  /* 大小单双第四球 */
// 第四球
  101171017: {
    alias: 'DXDS',
    selectarea: {
      type: 'dxds',
      noBigIndex: 5,
      isButton: false,
      layout: [{
        title: '第四球',
        no: '大|小|单|双',
        place: 0,
        cols: 1
      }]
    }
  },
  /* 大小单双第五球 */
// 第五球
  101171018: {
    alias: 'DXDS',
    selectarea: {
      type: 'dxds',
      noBigIndex: 5,
      isButton: false,
      layout: [{
        title: '第五球',
        no: '大|小|单|双',
        place: 0,
        cols: 1
      }]
    }
  },
  /* 大小单双总和 */
// 总和
  101171019: {
    alias: 'DXDS',
    selectarea: {
      type: 'dxds',
      noBigIndex: 5,
      isButton: false,
      layout: [{
        title: '总和',
        no: '大|小|单|双',
        place: 0,
        cols: 1
      }]
    }
  },
  /* 任二直选 */
// 直选复式
  101181010: {
    alias: 'RZX2',
    numcount: 2,
    selectarea: {
      hcltPosition: [0, 1, 2, 3, 4],
      type: 'digital',
      layout: [{
        title: '万位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }, {
        title: '千位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 1,
        cols: 1
      }, {
        title: '百位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 2,
        cols: 1
      }, {
        title: '十位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 3,
        cols: 1
      }, {
        title: '个位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 4,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 直选单式
  101181011: {
    alias: 'RZX2',
    numcount: 2,
    defaultposition: '00011',
    selectarea: {
      type: 'input',
      selPosition: true
    }
  },
// 直选和值
  101181012: {
    alias: 'ZXHZ2',
    numcount: 2,
    defaultposition: '00011',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '和值',
        no: '0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18',
        place: 0,
        cols: 1
      }],
      isButton: false,
      selPosition: true
    }
  },
  /* 任二组选 */
// 任二组选 组选复式
  101181110: {
    alias: 'ZU2',
    numcount: 2,
    defaultposition: '00011',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '组选',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true,
      selPosition: true
    }
  },
// 任二组选 组选单式
  101181111: {
    alias: 'ZU2',
    numcount: 2,
    defaultposition: '00011',
    selectarea: {
      type: 'input',
      selPosition: true
    }
  },
// 任二组选 组选和值
  101181112: {
    alias: 'ZUHZ2',
    numcount: 2,
    defaultposition: '00011',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '和值',
        no: '1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: false,
      selPosition: true
    }
  },
  /* 任三直选 */
// 直选复式
  101191010: {
    alias: 'RZX3',
    numcount: 3,
    selectarea: {
      hcltPosition: [0, 1, 2, 3, 4],
      type: 'digital',
      layout: [{
        title: '万位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }, {
        title: '千位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 1,
        cols: 1
      }, {
        title: '百位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 2,
        cols: 1
      }, {
        title: '十位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 3,
        cols: 1
      }, {
        title: '个位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 4,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 直选单式
  101191011: {
    alias: 'RZX3',
    numcount: 3,
    defaultposition: '00111',
    selectarea: {
      type: 'input',
      selPosition: true
    }
  },
// 直选和值
  101191012: {
    alias: 'ZXHZ',
    numcount: 3,
    defaultposition: '00111',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '和值',
        no: '0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27',
        place: 0,
        cols: 1
      }],
      isButton: false,
      selPosition: true
    }
  },
  /* 任三组选 */
// 任三组选 组三复式
  101191110: {
    alias: 'ZUS',
    numcount: 3,
    defaultposition: '00111',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '组三',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true,
      selPosition: true
    }
  },
// 任三组选 组三单式
  101191111: {
    alias: 'ZUS',
    numcount: 3,
    defaultposition: '00111',
    selectarea: {
      type: 'input',
      selPosition: true
    }
  },
// 任三组选 组六复式
  101191112: {
    alias: 'ZUL',
    numcount: 3,
    defaultposition: '00111',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '组六',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true,
      selPosition: true
    }
  },
// 任三组选 组六单式
  101191113: {
    alias: 'ZUL',
    numcount: 3,
    defaultposition: '00111',
    selectarea: {
      type: 'input',
      selPosition: true
    }
  },
// 混合组选组三
  101191114: {},
// 混合组选组六
  101191115: {},
// 任三组选 混合组选
  101191116: {
    alias: 'HHZX',
    numcount: 3,
    defaultposition: '00111',
    selectarea: {
      type: 'input',
      selPosition: true
    }
  },
// 组选和值组三
  101191117: {},
// 组选和值组六
  101191118: {},
// 任三组选 组选和值
  101191119: {
    alias: 'ZUHZ',
    numcount: 3,
    defaultposition: '00111',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '和值',
        no: '1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: false,
      selPosition: true
    }
  },
  /* 任四直选 */
// 任四直选 直选复式
  101201010: {
    alias: 'RZX4',
    numcount: 4,
    defaultposition: '01111',
    selectarea: {
      hcltPosition: [0, 1, 2, 3, 4],
      type: 'digital',
      layout: [{
        title: '万位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }, {
        title: '千位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 1,
        cols: 1
      }, {
        title: '百位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 2,
        cols: 1
      }, {
        title: '十位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 3,
        cols: 1
      }, {
        title: '个位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 4,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 任四直选 直选单式
  101201011: {
    alias: 'RZX4',
    numcount: 4,
    defaultposition: '01111',
    selectarea: {
      type: 'input',
      selPosition: true
    }
  },
  /* 任四组选 */
// 任四组选 组选24
  101201110: {
    numcount: 4,
    alias: 'SXZU24',
    defaultposition: '01111',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '组选24',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1,
        minchosen: 4
      }],
      noBigIndex: 5,
      isButton: true,
      selPosition: true
    }
  },
// 任四组选 组选12
  101201111: {
    numcount: 4,
    alias: 'SXZU12',
    defaultposition: '01111',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '二重号',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1,
        minchosen: 1
      }, {
        title: '单　号',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 1,
        cols: 1,
        minchosen: 2
      }],
      noBigIndex: 5,
      isButton: true,
      selPosition: true
    }
  },
// 任四组选 组选6
  101201112: {
    numcount: 4,
    alias: 'SXZU6',
    defaultposition: '01111',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '二重号',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1,
        minchosen: 2
      }],
      noBigIndex: 5,
      isButton: true,
      selPosition: true
    }
  },
// 任四组选 组选4
  101201113: {
    numcount: 4,
    alias: 'SXZU4',
    defaultposition: '01111',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '三重号',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1,
        minchosen: 1
      }, {
        title: '单　号',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 1,
        cols: 1,
        minchosen: 1
      }],
      noBigIndex: 5,
      isButton: true,
      selPosition: true
    }
  },
  /* 特殊玩法 */
// 一帆风顺
  101211010: {
    selectarea: {
      type: 'digital',
      layout: [{
        title: '一帆风顺',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 好事成双
  101211011: {
    selectarea: {
      type: 'digital',
      layout: [{
        title: '好事成双',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 三星报喜
  101211012: {
    selectarea: {
      type: 'digital',
      layout: [{
        title: '三星报喜',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 四季发财
  101211013: {
    selectarea: {
      type: 'digital',
      layout: [{
        title: '四季发财',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
  /* 中三直选 */
// 直选复式
  101221010: {
    selectarea: {
      type: 'digital',
      hcltPosition: [1, 2, 3],
      layout: [{
        title: '千位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }, {
        title: '百位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 1,
        cols: 1
      }, {
        title: '十位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 2,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 直选单式
  101221011: {
    alias: 'ZX3',
    selectarea: {
      type: 'input'
    }
  },
// 直选和值
  101221012: {
    alias: 'ZXHZ',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '和值',
        no: '0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27',
        place: 0,
        cols: 1
      }],
      isButton: false
    }
  },
// 直选跨度
  101221013: {
    alias: 'ZXKD',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '跨度',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 直选组合千百十
  101221014: {},
// 直选组合百十
  101221015: {},
// 直选组合十
  101221016: {},
// 直选组合
  101221017: {
    alias: 'ZH3',
    selectarea: {
      type: 'digital',
      hcltPosition: [1, 2, 3],
      layout: [{
        title: '千位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }, {
        title: '百位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 1,
        cols: 1
      }, {
        title: '十位',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 2,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
  /* 中三组选 */
// 组选组三
  101221110: {
    alias: 'ZUS',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '组三',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 组选组六
  101221111: {
    alias: 'ZUL',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '组六',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 混合组选组三
  101221112: {},
// 混合组选组六
  101221113: {},
// 混合组选
  101221114: {
    alias: 'HHZX',
    selectarea: {
      type: 'input'
    }
  },
// 组选和值组三
  101221115: {},
// 组选和值组六
  101221116: {},
// 组选和值
  101221117: {
    alias: 'ZUSHZ',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '和值',
        no: '1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: false
    }
  },
// 组选包胆组三
  101221118: {},
// 组选包胆组六
  101221119: {},
// 组选包胆
  101221120: {
    alias: 'ZU3BD',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '包胆',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: false
    }
  },
  /* 中三其他 */
// 和值尾数
  101221210: {
    alias: 'HZWS',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '和值尾数',
        no: '0|1|2|3|4|5|6|7|8|9',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: true
    }
  },
// 特殊号
  101221214: {
    alias: 'TSH3',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '特殊号',
        no: '豹子|顺子|对子',
        place: 0,
        cols: 1
      }],
      noBigIndex: 5,
      isButton: false
    }
  },
// 豹子
  101221211: {},
// 顺子
  101221212: {},
// 对子
  101221213: {}
}
