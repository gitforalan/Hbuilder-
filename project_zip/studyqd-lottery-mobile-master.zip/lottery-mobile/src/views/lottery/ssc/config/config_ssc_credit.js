// eslint-disable
export default [{
  'playTabName': '整合',
  'playTabId': 10210,
  'playTypeList': [{
    'playTypeId': 1021010,
    'playTypeName': '第一球',
    'playList': [{ 'playId': 102101010 }, { 'playId': 102101011 }, { 'playId': 102101012 }, { 'playId': 102101013 }, { 'playId': 102101014 }, { 'playId': 102101015 }, { 'playId': 102101016 }, { 'playId': 102101017 }, { 'playId': 102101018 }, { 'playId': 102101019 }, { 'playId': 102101020 }, { 'playId': 102101021 }, { 'playId': 102101022 }, { 'playId': 102101023 }]
  },
  {
    'playTypeId': 1021011,
    'playTypeName': '第二球',
    'playList': [{ 'playId': 102101110 }, { 'playId': 102101111 }, { 'playId': 102101112 }, { 'playId': 102101113 }, { 'playId': 102101114 }, { 'playId': 102101115 }, { 'playId': 102101116 }, { 'playId': 102101117 }, { 'playId': 102101118 }, { 'playId': 102101119 }, { 'playId': 102101120 }, { 'playId': 102101121 }, { 'playId': 102101122 }, { 'playId': 102101123 }]
  },
  {
    'playTypeId': 1021012,
    'playTypeName': '第三球',
    'playList': [{ 'playId': 102101210 }, { 'playId': 102101211 }, { 'playId': 102101212 }, { 'playId': 102101213 }, { 'playId': 102101214 }, { 'playId': 102101215 }, { 'playId': 102101216 }, { 'playId': 102101217 }, { 'playId': 102101218 }, { 'playId': 102101219 }, { 'playId': 102101220 }, { 'playId': 102101221 }, { 'playId': 102101222 }, { 'playId': 102101223 }]
  },
  {
    'playTypeId': 1021013,
    'playTypeName': '第四球',
    'playList': [{ 'playId': 102101310 }, { 'playId': 102101311 }, { 'playId': 102101312 }, { 'playId': 102101313 }, { 'playId': 102101314 }, { 'playId': 102101315 }, { 'playId': 102101316 }, { 'playId': 102101317 }, { 'playId': 102101318 }, { 'playId': 102101319 }, { 'playId': 102101320 }, { 'playId': 102101321 }, { 'playId': 102101322 }, { 'playId': 102101323 }]
  },
  {
    'playTypeId': 1021014,
    'playTypeName': '第五球',
    'playList': [{ 'playId': 102101410 }, { 'playId': 102101411 }, { 'playId': 102101412 }, { 'playId': 102101413 }, { 'playId': 102101414 }, { 'playId': 102101415 }, { 'playId': 102101416 }, { 'playId': 102101417 }, { 'playId': 102101418 }, { 'playId': 102101419 }, { 'playId': 102101420 }, { 'playId': 102101421 }, { 'playId': 102101422 }, { 'playId': 102101423 }]
  },
  {
    'playTypeId': 1021015,
    'playTypeName': '总和',
    'playList': [{ 'playId': 102101510 }, { 'playId': 102101511 }, { 'playId': 102101512 }, { 'playId': 102101513 }]
  },
  {
    'playTypeId': 1021016,
    'playTypeName': '前三',
    'playList': [{ 'playId': 102101610 }, { 'playId': 102101611 }, { 'playId': 102101612 }, { 'playId': 102101613 }, { 'playId': 102101614 }]
  },
  {
    'playTypeId': 1021017,
    'playTypeName': '中三',
    'playList': [{ 'playId': 102101710 }, { 'playId': 102101711 }, { 'playId': 102101712 }, { 'playId': 102101713 }, { 'playId': 102101714 }]
  },
  {
    'playTypeId': 1021018,
    'playTypeName': '后三',
    'playList': [{ 'playId': 102101810 }, { 'playId': 102101811 }, { 'playId': 102101812 }, { 'playId': 102101813 }, { 'playId': 102101814 }]
  }
  ]
},
{
  'playTabName': '龙虎斗',
  'playTabId': 10211,
  'playTypeList': [{
    'playTypeName': '第一球VS第二球',
    'playTypeId': 1021110,
    'playList': [{ 'playId': 102111010 }, { 'playId': 102111012 }, { 'playId': 102111011 }]
  },
  {
    'playTypeId': 1021111,
    'playTypeName': '第一球VS第三球',
    'playList': [{ 'playId': 102111110 }, { 'playId': 102111112 }, { 'playId': 102111111 }]
  },
  {
    'playTypeId': 1021112,
    'playTypeName': '第一球VS第四球',
    'playList': [{ 'playId': 102111210 }, { 'playId': 102111212 }, { 'playId': 102111211 }]
  },
  {
    'playTypeId': 1021113,
    'playTypeName': '第一球VS第五球',
    'playList': [{ 'playId': 102111310 }, { 'playId': 102111312 }, { 'playId': 102111311 }]
  },
  {
    'playTypeId': 1021114,
    'playTypeName': '第二球VS第三球',
    'playList': [{ 'playId': 102111410 }, { 'playId': 102111412 }, { 'playId': 102111411 }]
  },
  {
    'playTypeId': 1021115,
    'playTypeName': '第二球VS第四球',
    'playList': [{ 'playId': 102111510 }, { 'playId': 102111512 }, { 'playId': 102111511 }]
  },
  {
    'playTypeId': 1021116,
    'playTypeName': '第二球VS第五球',
    'playList': [{ 'playId': 102111610 }, { 'playId': 102111612 }, { 'playId': 102111611 }]
  },
  {
    'playTypeId': 1021117,
    'playTypeName': '第三球VS第四球',
    'playList': [{ 'playId': 102111710 }, { 'playId': 102111712 }, { 'playId': 102111711 }]
  },
  {
    'playTypeId': 1021118,
    'playTypeName': '第三球VS第五球',
    'playList': [{ 'playId': 102111810 }, { 'playId': 102111812 }, { 'playId': 102111811 }]
  },
  {
    'playTypeId': 1021119,
    'playTypeName': '第四球VS第五球',
    'playList': [{ 'playId': 102111910 }, { 'playId': 102111912 }, { 'playId': 102111911 }]
  }
  ]
},
{
  'playTabName': '全5中1',
  'playTabId': 10212,
  'playTypeList': [{
    'playTypeId': 1021210,
    'playTypeName': '全5中1',
    'playList': [{ 'playId': 102121010 }, { 'playId': 102121011 }, { 'playId': 102121012 }, { 'playId': 102121013 }, { 'playId': 102121014 }, { 'playId': 102121015 }, { 'playId': 102121016 }, { 'playId': 102121017 }, { 'playId': 102121018 }, { 'playId': 102121019 }]
  }]
}
]
