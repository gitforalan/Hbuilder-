 /* eslint-disable */
export default [{
  'playTabName': '整合',
  'playTabId': 19210,
  'playTypeList': [{
    'playTypeId': 1921010,
    'playTypeName': '第一球',
    'playList': [{ 'playId': 192101010 }, { 'playId': 192101011 }, { 'playId': 192101012 }, { 'playId': 192101013 }, { 'playId': 192101014 }, { 'playId': 192101015 }, { 'playId': 192101016 }, { 'playId': 192101017 }, { 'playId': 192101018 }, { 'playId': 192101019 }, { 'playId': 192101620 }, { 'playId': 192101621 }, { 'playId': 192101622 }, { 'playId': 192101623 }]
  },
    {
      'playTypeId': 1921011,
      'playTypeName': '第二球',
      'playList': [{ 'playId': 192101110 }, { 'playId': 192101111 }, { 'playId': 192101112 }, { 'playId': 192101113 }, { 'playId': 192101114 }, { 'playId': 192101115 }, { 'playId': 192101116 }, { 'playId': 192101117 }, { 'playId': 192101118 }, { 'playId': 192101119 }, { 'playId': 192101120 }, { 'playId': 192101121 }, { 'playId': 192101122 }, { 'playId': 192101123 }]
    },
    {
      'playTypeId': 1921012,
      'playTypeName': '第三球',
      'playList': [{ 'playId': 192101210 }, { 'playId': 192101211 }, { 'playId': 192101212 }, { 'playId': 192101213 }, { 'playId': 192101214 }, { 'playId': 192101215 }, { 'playId': 192101216 }, { 'playId': 192101217 }, { 'playId': 192101218 }, { 'playId': 192101219 }, { 'playId': 192101220 }, { 'playId': 192101221 }, { 'playId': 192101222 }, { 'playId': 192101223 }]
    },
    {
      'playTypeId': 1921013,
      'playTypeName': '第四球',
      'playList': [{ 'playId': 192101310 }, { 'playId': 192101311 }, { 'playId': 192101312 }, { 'playId': 192101313 }, { 'playId': 192101314 }, { 'playId': 192101315 }, { 'playId': 192101316 }, { 'playId': 192101317 }, { 'playId': 192101318 }, { 'playId': 192101319 }, { 'playId': 192101320 }, { 'playId': 192101321 }, { 'playId': 192101322 }, { 'playId': 192101323 }]
    },
    {
      'playTypeId': 1921014,
      'playTypeName': '第五球',
      'playList': [{ 'playId': 192101410 }, { 'playId': 192101411 }, { 'playId': 192101412 }, { 'playId': 192101413 }, { 'playId': 192101414 }, { 'playId': 192101415 }, { 'playId': 192101416 }, { 'playId': 192101417 }, { 'playId': 192101418 }, { 'playId': 192101419 }, { 'playId': 192101420 }, { 'playId': 192101421 }, { 'playId': 192101422 }, { 'playId': 192101423 }]
    },
    {
      'playTypeId': 1921015,
      'playTypeName': '总和',
      'playList': [{ 'playId': 192101510 }, { 'playId': 192101511 }, { 'playId': 192101512 }, { 'playId': 192101513 }]
    },
    {
      'playTypeId': 1921016,
      'playTypeName': '前三',
      'playList': [{ 'playId': 192101610 }, { 'playId': 192101611 }, { 'playId': 192101612 }, { 'playId': 192101613 }, { 'playId': 192101614 }]
    },
    {
      'playTypeId': 1921017,
      'playTypeName': '中三',
      'playList': [{ 'playId': 192101710 }, { 'playId': 192101711 }, { 'playId': 192101712 }, { 'playId': 192101713 }, { 'playId': 192101714 }]
    },
    {
      'playTypeId': 1921018,
      'playTypeName': '后三',
      'playList': [{ 'playId': 192101810 }, { 'playId': 192101811 }, { 'playId': 192101812 }, { 'playId': 192101813 }, { 'playId': 192101814 }]
    }
  ]
},
  {
    'playTabName': '龙虎斗',
    'playTabId': 19211,
    'playTypeList': [{
      'playTypeName': '第一球VS第二球',
      'playTypeId': 1921110,
      'playList': [{ 'playId': 192111010 }, { 'playId': 192111012 }, { 'playId': 192111011 }]
    },
      {
        'playTypeId': 1921111,
        'playTypeName': '第一球VS第三球',
        'playList': [{ 'playId': 192111110 }, { 'playId': 192111112 }, { 'playId': 192111111 }]
      },
      {
        'playTypeId': 1921112,
        'playTypeName': '第一球VS第四球',
        'playList': [{ 'playId': 192111210 }, { 'playId': 192111212 }, { 'playId': 192111211 }]
      },
      {
        'playTypeId': 1921113,
        'playTypeName': '第一球VS第五球',
        'playList': [{ 'playId': 192111310 }, { 'playId': 192111312 }, { 'playId': 192111311 }]
      },
      {
        'playTypeId': 1921114,
        'playTypeName': '第二球VS第三球',
        'playList': [{ 'playId': 192111410 }, { 'playId': 192111412 }, { 'playId': 192111411 }]
      },
      {
        'playTypeId': 1921115,
        'playTypeName': '第二球VS第四球',
        'playList': [{ 'playId': 192111510 }, { 'playId': 192111512 }, { 'playId': 192111511 }]
      },
      {
        'playTypeId': 1921116,
        'playTypeName': '第二球VS第五球',
        'playList': [{ 'playId': 192111610 }, { 'playId': 192111612 }, { 'playId': 192111611 }]
      },
      {
        'playTypeId': 1921117,
        'playTypeName': '第三球VS第四球',
        'playList': [{ 'playId': 192111710 }, { 'playId': 192111712 }, { 'playId': 192111711 }]
      },
      {
        'playTypeId': 1921118,
        'playTypeName': '第三球VS第五球',
        'playList': [{ 'playId': 192111810 }, { 'playId': 192111812 }, { 'playId': 192111811 }]
      },
      {
        'playTypeId': 1921119,
        'playTypeName': '第四球VS第五球',
        'playList': [{ 'playId': 192111910 }, { 'playId': 192111912 }, { 'playId': 192111911 }]
      }
    ]
  },
  {
    'playTabName': '全5中1',
    'playTabId': 19212,
    'playTypeList': [{
      'playTypeId': 1921210,
      'playTypeName': '全5中1',
      'playList': [{ 'playId': 192121010 }, { 'playId': 192121011 }, { 'playId': 192121012 }, { 'playId': 192121013 }, { 'playId': 192121014 }, { 'playId': 192121015 }, { 'playId': 192121016 }, { 'playId': 192121017 }, { 'playId': 192121018 }, { 'playId': 192121019 }]
    }]
  }
]
