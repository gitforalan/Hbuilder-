<!-- Created By fx on 2017/9/6.
  -- 六合彩玩法列表
  -- 根据配置文件生成
  -->

<template>
  <section v-click-outside="onClickedOutside" v-show="show">
    <div class="tab-con">
      <div class="play-type">
        <checker :value="currentTab" default-item-class="play-item" selected-item-class="play-item-selected" :radio-required="true">
          <checker-item v-for="tab in lhc" :value="tab" :key="tab.playTabName" @on-item-click="onPlayTabClick">
            {{ tab.playTabName }}
          </checker-item>
        </checker>
      </div>
      <div class="play-type-con" v-if="currentTab.children">
        <ul class="play-con-list">
          <checker default-item-class="play-item" selected-item-class="play-item-selected" :radio-required="true">
            <li flex="">
              <span flex-box="0">{{ currentTab.playTabName }}</span>
              <div class="type-list" flex-box="1">
                <checker-item v-for="t in currentTab.children" :value="t" :key="t.playTabName" @on-item-click="onSubPlayTabClick" :class="{'play-item-selected':t.playTabName==playTabName}">
                  {{ t.playTabName }}
                </checker-item>
              </div>
            </li>
          </checker>
        </ul>
      </div>
    </div>
  </section>
</template>

<script type="text/ecmascript-6">
import ClickOutside from 'vux/src/directives/click-outside'
import { mapState, mapMutations, mapActions } from 'vuex'
// import * as API from 'api/wapi/front'
import tabs from './tabs'

export default {
  name: 'playTabList',
  methods: {
    // 父级tab事件处理
    onPlayTabClick (item) {
      this.currentTab = item
      if (this.currentTab.children) {
        this.onSubPlayTabClick(this.currentTab.children[0], true)
        // this.lhc_playTabName({ playTabName: this.currentTab.children[0].playTabName })
        // this.lhc_playTabId({ playTabId: this.currentTab.children[0].playTabId })
      } else { // 如果没有子级，都当子菜单处理
        this.onSubPlayTabClick(item)
      }
    },
    // 子级tab事件处理
    onSubPlayTabClick (item, isDefaultCheck) {
      this.lhc_playTabName({ playTabName: item.playTabName })
      this.lhc_playTabId({ playTabId: item.playTabId })
      if (!isDefaultCheck) {
        this.$emit('on-hide')
      }
    },
    onClickedOutside () {
      if (this.show) {
        this.$emit('on-hide')
      }
    },
    ...mapMutations('lhc', [
      'lhc_playTabName',
      'lhc_playName',
      'lhc_playTabId'
    ]),
    ...mapActions('ui', ['ui_icon_rotate'])
  },
  computed: {
    ...mapState('ui', {
      rotate: state => state.icon_isRotate
    }),
    ...mapState('lhc', [
      'playTabName',
      'playTabId'
    ])
  },
  data () {
    return {
      lhc: tabs, // 玩法列表数据
      currentTab: null // 当前选中的玩法Tab，可能是父级，也可能是子级
    }
  },
  props: {
    show: {
      type: Boolean,
      default: false
    }
  },
  directives: {
    ClickOutside
  },
  created () {
    this.onPlayTabClick(this.lhc[0]) // 初始化第一个玩法为默认玩法
    this.ui_icon_rotate({ rotate: false }) // 刷新后重置图标状态
  },
  watch: {
    show (val) {
      this.ui_icon_rotate({ rotate: val })
    }
  }
}
</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"

  section
    position fixed
    z-index 22
    width 100%
    box-shadow 2px 3px 5px $color-gray-a
    .active
      setBottomLine()
    .vux-tab
      height rem(70)
      padding-top .5rem
      line-height rem(70)
      font-size rem(30)
      color #5c5c5c
      &:after
        border-color #ff5151
      .vux-tab-item.vux-tab-selected
        height rem(70)
        margin-left rem(32)
        margin-right rem(32)
        color $color-red
        background $color-el-bg
        border 1px solid #ff5151
        border-bottom none
        &:after
          border 3px solid $color-el-bg
          height 0
          bottom -1px
          opacity 1
          z-index 9999
      .vux-tab-item
        background: none
        line-height rem(70)
        border-top-left-radius 7px
        border-top-right-radius 7px
    .tab-con
      background $color-el-bg
      padding-top rem(22)
      max-height 80vh
      overflow-y auto
      .play-type
        padding rem(22) .5rem rem(15)
        color #5c5c5c
        ul
          padding-bottom rem(26)
      .play-type ul li:nth-chlid(last)
        margin-right 0
    .play-type-con
      background $color-white
      padding rem(9) 0 0

      background $color-white
      ul.play-con-list
        padding 0 .5rem
        border-bottom 2px solid $color-red
        li
          border-bottom 1px solid $color-border
          padding rem(38) 0 rem(10) 0
          font-size rem(28)
          span
            padding-right rem(18)
            color #5c5c5c
          .type-list
            margin-top -.5rem
          .play-item
            color #9b9b9b
            border 1px solid $color-border
            font-size rem(28)
            margin-right rem(15)
            padding rem(14) rem(12)
          .play-item-selected
            background $color-white
            border 1px solid $color-red
            color $color-red
        li:last-child
          border-bottom none
</style>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .play-item
    padding rem(21) rem(30)
    border-radius 4px
    margin-bottom rem(12)
    font-size rem(28)
    color #5C5C5C
    background $color-white
    margin-right rem(33)

  .play-item-selected
    background $color-red
    color $color-white

  .selected-icon .lott-icon .svg-icon
    width rem(44)
    height rem(44)
    vertical-align middle

</style>
