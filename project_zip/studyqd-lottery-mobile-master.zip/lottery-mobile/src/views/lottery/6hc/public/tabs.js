export default [{
  id: 1,
  playTabName: '特码',
  playTabId: 20210
}, {
  id: 2,
  playTabName: '生肖',
  children: [
    {
      playTabId: 20222,
      playTabName: '特肖'
    },
    {
      playTabId: 20219,
      playTabName: '平特一肖'
    },
    {
      playTabId: 20223,
      playTabName: '合肖'
    },
    {
      playTabId: 20224,
      playTabName: '连肖'
    }
  ]
}, {
  id: 3,
  playTabName: '半波',
  playTabId: 20218
}, {
  id: 4,
  playTabName: '正码',
  children: [
    {
      playTabId: 20211,
      playTabName: '正码'
    },
    {
      playTabId: 20213,
      playTabName: '正码1-6'
    },
    {
      playTabId: 20214,
      playTabName: '过关'
    }
  ]
}, {
  id: 5,
  playTabName: '正码特',
  playTabId: 20212
}, {
  id: 6,
  playTabName: '连码',
  playTabId: 20215
}, {
  id: 7,
  playTabName: '头尾数',
  children: [
    {
      playTabId: 20230,
      playTabName: '特码头尾数'
    },
    {
      playTabId: 20227,
      playTabName: '正特尾数'
    },
    {
      playTabId: 20225,
      playTabName: '连尾'
    }
  ]
}, {
  id: 8,
  playTabName: '多选中一',
  playTabId: 20228
}, {
  id: 9,
  playTabName: '自选不中',
  playTabId: 20226
}, {
  id: 10,
  playTabName: '正特任中',
  playTabId: 20229
}, {
  id: 11,
  playTabName: '五行',
  playTabId: 20217
}, {
  id: 12,
  playTabName: '七码',
  playTabId: 20216
}]
