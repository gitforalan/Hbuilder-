<template>
  <div class="mid-pop" v-click-outside="onClickedOutside">
    <div class="selected" flex="" @click="doToggleMenu">
      <span flex-box="1" class="value">{{defaultValue}}</span>
      <icon-svg icon-class="down" class="down" flex-box="0"></icon-svg>
    </div>
    <ul class="z-popover" align="center" v-show="show">
      <li v-for="(item, index) in types" :class="{active: defaultValue === item.name}" @click="doSelectOne(item)">
        <p> {{ item.name }}</p>
      </li>
    </ul>
  </div>
</template>

<script type="text/ecmascript-6">
import ClickOutside from 'vux/src/directives/click-outside'

export default {
  name: 'mid-pop',
  data () {
    return {
      show: false
    }
  },
  props: {
    types: Array,
    defaultValue: [String, Number]
  },
  computed: {
  },
  methods: {
    onClickedOutside () {
      this.$nextTick(() => {
        this.show = false
      })
    },
    doToggleMenu () {
      this.show = !this.show
    },
    doSelectOne (item) {
      if (item.name === this.defaultValue) return
      this.$emit('on-hide', item)
      this.show = false
    }
  },
  directives: {
    ClickOutside
  },
  created () {
  }
}
</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .mid-pop
    width 100%
    line-height 28px
    box-sizing border-box
    position relative
    .selected
      border 1px solid $color-border
      height rem(64)
      line-height rem(64)
      padding 0 3px
      .value
        text-align center
      i
        position absolute
        right rem(15)
        top rem(8)
        width 1.5rem
  ul.z-popover
    min-width rem(126)
    background-color rgba(0, 0, 0, .7)
    border-radius 0
    margin-top .75rem
    position absolute
    left 0
    right 0
    z-index 101
    border-radius 5px
    li
      width 100%
      height rem(55)
      line-height rem(55)
      font-size rem(28)
      color $color-white
      &:first-child
        border-top-left-radius 5px
        border-top-right-radius 5px
      &:last-child
        border-bottom-left-radius 5px
        border-bottom-right-radius 5px
      &.active
        background $color-red
        color: $color-white
        p
          border-bottom 0
      &.prev p
        border-bottom 0
      p
        margin 0 rem(9)
        border-bottom 1px solid $color-white
        box-sizing border-box
      &:last-child
          p
            border-bottom 0
    &:before
      content ""
      border-color rgba(0, 0, 0, .7) transparent
      border-style solid
      display block
      height 0
      font-size 0
      line-height 0
      width 0
      border-width 0 .75rem .75rem
      position absolute
      z-index 12
      top -.75rem
      right 7px
      zoom 1

    &.right:before
      transform translate3D(10%, 0, 0) rotate(180deg)

    &.left:before
      transform translate3D(-90%, 0, 0) rotate(180deg)

</style>
