import { mapState, mapMutations, mapActions } from 'vuex'
import PlayTabList from './public/playTabList'
import SubHeader from '@/views/common/subHeader'
import ZPopoverMenu from '@/views/common/zPopoverMenu'
import * as API from 'api/wapi/front'

// 特码
const tema = () => import('./all/tema')
// 生肖-特肖
const texiao = () => import('./all/shengxiaoTexiao')
// 生肖-平特一肖
const ptyx = () => import('./all/shengxiaoPtyx')
// 生肖-合肖
const hexiao = () => import('./all/shengxiaoHexiao')
// 生肖-连肖
const lianxiao = () => import('./all/shengxiaoLianxiao')
// 半波
const banbo = () => import('./all/banbo')
// 正码-正码
const zhengma = () => import('./all/zhengmaZhengma')
// 正码-正码1-6
const zhengma16 = () => import('./all/zhengmaZm16')
// 正码-正码过关
const zhengmaGg = () => import('./all/zhengmaZmgg')
// 正码特
const zhengmate = () => import('./all/zhengmate')
// 连码
const lianma = () => import('./all/lianma')
// 头尾数-特码头尾数
const touweishuTema = () => import('./all/touweishuTema')
// 头尾数-正特尾数
const touweishuZhengte = () => import('./all/touweishuZhengte')
// 头尾数-连尾
const touweishuLianwei = () => import('./all/touweishuLianwei')
// 多选中一
const duoxuanzhongyi = () => import('./all/duoxuanZhongyi')
// 自选不中
const zixuanbuzhong = () => import('./all/zixuanBuzhong')
// 正特任中
const zhengterenzhong = () => import('./all/zhengteRenzhong')
// 五行
const wuxing = () => import('./all/wuxing')
// 七码
const qima = () => import('./all/qima')

export default {
  name: 'LHC',
  methods: {
    ...mapMutations('lhc', [
      'lhc_shengxiao',
      'updateShowBetConfirm'
    ]),
    ...mapMutations('ui', ['set_singleRow']),
    ...mapActions('common', [
      'resetCommonState'
    ]),
    getLotteryCurrentInfo () {
      if (this.lotteryId === -1) return
      const query = {
        lotteryId: this.lotteryId
      }
      API.getLotteryCurrentInfo(query).then(res => {
        if (res.code === 0) {
          this.currentInfo = res.data
        } else {
          console.log('getLotteryCurrentInfo:', res.data.desc)
        }
      })
    },
    setCurrentPlay (playTabId) {
      if (playTabId === -1) return
      let map = {
        20210: tema, // 特码
        20222: texiao, // 生肖-特肖
        20219: ptyx, // 生肖-平特一肖
        20223: hexiao, // 生肖-合肖
        20224: lianxiao, // 生肖-连肖
        20218: banbo, // 半波
        20211: zhengma, // 正码-正码
        20213: zhengma16, // 正码-正码1-6
        20214: zhengmaGg, // 正码-正码过关
        20212: zhengmate, // 正码特
        20215: lianma, // 连码
        20230: touweishuTema, // 头尾数-特码头尾数
        20227: touweishuZhengte, // 头尾数-正特尾数
        20225: touweishuLianwei, // 头尾数-连尾
        20228: duoxuanzhongyi, // 多选中一
        20226: zixuanbuzhong, // 自选不中
        20229: zhengterenzhong, // 正特任中
        20217: wuxing, // 五行
        20216: qima // 七码
      }
      this.currentPlay = map[playTabId]
    },
    // 以下代码未动
    onClickTitle () {
      if (this.isShowBack) return // 在弹出页时屏蔽标题事件
      this.showPlayTabList = !this.showPlayTabList
    },
    showPopoverMenu () {
      this.isShowPopoverMenu = !this.isShowPopoverMenu
    },
    onPopoverMenuHide () {
      this.delayExec(() => {
        this.isShowPopoverMenu = false
      })
    },
    hidePlayTabList () {
      this.delayExec(() => {
        this.showPlayTabList = false
      })
    },
    delayExec (fn) {
      setTimeout(fn, 20)
    },
    // 未动代码结束
    getMarginTop () {
      this.marginTop = this.$refs.currentInfo.$el.offsetHeight
    }
  },
  watch: {
    shengxiaoAll (nval) {
      this.lhc_shengxiao({ shengxiaoAll: nval })
    },
    playTabId (nval) {
      this.setCurrentPlay(nval)
    },
    isShowBetConfirm (val) {
      if (val) {
        this.set_singleRow(true)
      } else {
        this.set_singleRow(false)
      }
    }
  },
  computed: {
    isShowBack () {
      // 弹出购票车隐藏左上角回退 '<' 按钮
      return this.isShowBetConfirm
    },
    ...mapState('lhc', [
      'playTabName',
      'playTabId',
      'isShowBetConfirm'
    ]),
    ...mapState('common', [
      'lotteryTypeId',
      'lotteryId'
    ]),
    ...mapState('common', {
      currentIssue: state => state.issue
    }),
    ...mapState('ui', {
      showPopoverPage: state => state.showPopoverPage
    }),
    // 根据当年生肖，生成生肖Map
    shengxiaoAll () {
      let all = ['鼠', '牛', '虎', '兔', '龙', '蛇', '马', '羊', '猴', '鸡', '狗', '猪']
      let curr = this.currentInfo && this.currentInfo.animals
      if (!curr) return {}
      let pos = all.indexOf(curr)
      let tmp = [].concat(all.slice(0, pos + 1).reverse()).concat(all.slice(pos + 1).reverse())
      let ret = {}
      for (let i = 0; i < 4; i++) {
        for (let j = 0; j < 12; j++) {
          if (Array.isArray(ret[tmp[j]])) {
            let s = i * 12 + parseInt(ret[tmp[j]][0])
            ret[tmp[j]].push(String(s))
          } else {
            ret[tmp[j]] = []
            let t = j + 1
            t = t < 10 ? '0' + t : String(t)
            ret[tmp[j]].push(t)
          }
        }
      }
      ret[curr].push('49')
      return ret
    }
    /* currentIssue () {
     return this.currentInfo && this.currentInfo.issue
     } */
  },
  data () {
    return {
      isShowPopoverMenu: false,
      showPlayTabList: false,
      rangeValue: 0,
      playTabList: [],
      value: [true],
      options: [],
      marginTop: 0,
      currentInfo: null, // 当前彩种详情
      currentPlay: null, // 当前玩法
      typeId: 20
    }
  },
  components: { SubHeader, PlayTabList, ZPopoverMenu },
  created () {
    this.getLotteryCurrentInfo()
    this.setCurrentPlay(20210)
    this.set_singleRow(false) // 彩期模块显示全
  },
  mounted () {
    this.$nextTick(() => {
      this.getMarginTop()
    })
    window.scrollTo(0, 0)
  },
  beforeDestroy () {
    // this.resetCommonState()
    this.updateShowBetConfirm(false)
  }
}
