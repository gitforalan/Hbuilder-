export default [{
  'playTabId': 20218,
  'playTabName': '半波',
  'playTypeList': [{
    'playTypeId': 2021812,
    'playTypeName': '半波',
    'playListGroup': [{
      'playListGroupName': '',
      'playList': [
        { 'playId': 202181203, 'name': '红大' },
        { 'playId': 202181204, 'name': '红小' },
        { 'playId': 202181201, 'name': '红单' },
        { 'playId': 202181202, 'name': '红双' },
        { 'playId': 202181213, 'name': '红合单' },
        { 'playId': 202181214, 'name': '红合双' },
        { 'playId': 202181207, 'name': '绿大' },
        { 'playId': 202181208, 'name': '绿小' },
        { 'playId': 202181205, 'name': '绿单' },
        { 'playId': 202181206, 'name': '绿双' },
        { 'playId': 202181215, 'name': '绿合单' },
        { 'playId': 202181216, 'name': '绿合双' },
        { 'playId': 202181211, 'name': '蓝大' },
        { 'playId': 202181212, 'name': '蓝小' },
        { 'playId': 202181209, 'name': '蓝单' },
        { 'playId': 202181210, 'name': '蓝双' },
        { 'playId': 202181217, 'name': '蓝合单' },
        { 'playId': 202181218, 'name': '蓝合双' }
      ]
    }
    ]
  }]
}]
