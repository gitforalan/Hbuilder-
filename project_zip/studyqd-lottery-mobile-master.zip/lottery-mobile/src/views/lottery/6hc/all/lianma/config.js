export default [{
  'playTabId': 20215,
  'playTabName': '连码',
  'playTypeList': [{
    'playTypeId': 202151001,
    'playTypeName': '三全中',
    'minChosen': 3,
    'maxChosen': 10,
    'playList': [
      { 'playId': 202151001 }
    ]
  },
  {
    'playTypeId': 202151002,
    'playTypeName': '三中二',
    'minChosen': 3,
    'maxChosen': 10,
    'playList': [
      { 'playId': 202151003 },
      { 'playId': 202151004 }
    ]
  },
  {
    'playTypeId': 202151005,
    'playTypeName': '二全中',
    'minChosen': 2,
    'maxChosen': 10,
    'playList': [
      { 'playId': 202151005 }
    ]
  },
  {
    'playTypeId': 202151006,
    'playTypeName': '二中特',
    'minChosen': 2,
    'maxChosen': 10,
    'playList': [
      { 'playId': 202151007 },
      { 'playId': 202151008 }
    ]
  },
  {
    'playTypeId': 202151009,
    'playTypeName': '特串',
    'minChosen': 2,
    'maxChosen': 10,
    'playList': [
      { 'playId': 202151009 }
    ]
  },
  {
    'playTypeId': 202151010,
    'playTypeName': '四中一',
    'minChosen': 4,
    'maxChosen': 10,
    'playList': [
      { 'playId': 202151010 }
    ]
  }
  ]
}]
