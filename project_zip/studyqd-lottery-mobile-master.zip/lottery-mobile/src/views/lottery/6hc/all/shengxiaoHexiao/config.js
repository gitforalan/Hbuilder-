export default [{
  'playTabId': 20223,
  'playTabName': '合肖',
  'playTypeList': [{
    'playTypeId': 2022310,
    'playTypeName': '二肖',
    'minChosen': 2,
    'playListGroup': [{
      'playListGroupName': '',
      'playList': [
        { 'playId': 202231088, 'name': '鼠' },
        { 'playId': 202231089, 'name': '牛' },
        { 'playId': 202231090, 'name': '虎' },
        { 'playId': 202231091, 'name': '兔' },
        { 'playId': 202231092, 'name': '龙' },
        { 'playId': 202231093, 'name': '蛇' },
        { 'playId': 202231094, 'name': '马' },
        { 'playId': 202231095, 'name': '羊' },
        { 'playId': 202231096, 'name': '猴' },
        { 'playId': 202231097, 'name': '鸡' },
        { 'playId': 202231098, 'name': '狗' },
        { 'playId': 202231099, 'name': '猪' }
      ]
    }]
  }, {
    'playTypeId': 2022311,
    'playTypeName': '三肖',
    'minChosen': 3,
    'playListGroup': [{
      'playListGroupName': '',
      'playList': [
        { 'playId': 202231188, 'name': '鼠' },
        { 'playId': 202231189, 'name': '牛' },
        { 'playId': 202231190, 'name': '虎' },
        { 'playId': 202231191, 'name': '兔' },
        { 'playId': 202231192, 'name': '龙' },
        { 'playId': 202231193, 'name': '蛇' },
        { 'playId': 202231194, 'name': '马' },
        { 'playId': 202231195, 'name': '羊' },
        { 'playId': 202231196, 'name': '猴' },
        { 'playId': 202231197, 'name': '鸡' },
        { 'playId': 202231198, 'name': '狗' },
        { 'playId': 202231199, 'name': '猪' }
      ]
    }]
  }, {
    'playTypeId': 2022312,
    'playTypeName': '四肖',
    'minChosen': 4,
    'playListGroup': [{
      'playListGroupName': '',
      'playList': [
        { 'playId': 202231288, 'name': '鼠' },
        { 'playId': 202231289, 'name': '牛' },
        { 'playId': 202231290, 'name': '虎' },
        { 'playId': 202231291, 'name': '兔' },
        { 'playId': 202231292, 'name': '龙' },
        { 'playId': 202231293, 'name': '蛇' },
        { 'playId': 202231294, 'name': '马' },
        { 'playId': 202231295, 'name': '羊' },
        { 'playId': 202231296, 'name': '猴' },
        { 'playId': 202231297, 'name': '鸡' },
        { 'playId': 202231298, 'name': '狗' },
        { 'playId': 202231299, 'name': '猪' }
      ]
    }]
  }, {
    'playTypeId': 2022313,
    'playTypeName': '五肖',
    'minChosen': 5,
    'playListGroup': [{
      'playListGroupName': '',
      'playList': [
        { 'playId': 202231388, 'name': '鼠' },
        { 'playId': 202231389, 'name': '牛' },
        { 'playId': 202231390, 'name': '虎' },
        { 'playId': 202231391, 'name': '兔' },
        { 'playId': 202231392, 'name': '龙' },
        { 'playId': 202231393, 'name': '蛇' },
        { 'playId': 202231394, 'name': '马' },
        { 'playId': 202231395, 'name': '羊' },
        { 'playId': 202231396, 'name': '猴' },
        { 'playId': 202231397, 'name': '鸡' },
        { 'playId': 202231398, 'name': '狗' },
        { 'playId': 202231399, 'name': '猪' }
      ]
    }]
  }, {
    'playTypeId': 2022314,
    'playTypeName': '六肖',
    'minChosen': 6,
    'playListGroup': [{
      'playListGroupName': '',
      'playList': [
        { 'playId': 202231488, 'name': '鼠' },
        { 'playId': 202231489, 'name': '牛' },
        { 'playId': 202231490, 'name': '虎' },
        { 'playId': 202231491, 'name': '兔' },
        { 'playId': 202231492, 'name': '龙' },
        { 'playId': 202231493, 'name': '蛇' },
        { 'playId': 202231494, 'name': '马' },
        { 'playId': 202231495, 'name': '羊' },
        { 'playId': 202231496, 'name': '猴' },
        { 'playId': 202231497, 'name': '鸡' },
        { 'playId': 202231498, 'name': '狗' },
        { 'playId': 202231499, 'name': '猪' }
      ]
    }]
  }, {
    'playTypeId': 2022315,
    'playTypeName': '七肖',
    'minChosen': 7,
    'playListGroup': [{
      'playListGroupName': '',
      'playList': [
        { 'playId': 202231588, 'name': '鼠' },
        { 'playId': 202231589, 'name': '牛' },
        { 'playId': 202231590, 'name': '虎' },
        { 'playId': 202231591, 'name': '兔' },
        { 'playId': 202231592, 'name': '龙' },
        { 'playId': 202231593, 'name': '蛇' },
        { 'playId': 202231594, 'name': '马' },
        { 'playId': 202231595, 'name': '羊' },
        { 'playId': 202231596, 'name': '猴' },
        { 'playId': 202231597, 'name': '鸡' },
        { 'playId': 202231598, 'name': '狗' },
        { 'playId': 202231599, 'name': '猪' }
      ]
    }]
  }, {
    'playTypeId': 2022316,
    'playTypeName': '八肖',
    'minChosen': 8,
    'playListGroup': [{
      'playListGroupName': '',
      'playList': [
        { 'playId': 202231688, 'name': '鼠' },
        { 'playId': 202231689, 'name': '牛' },
        { 'playId': 202231690, 'name': '虎' },
        { 'playId': 202231691, 'name': '兔' },
        { 'playId': 202231692, 'name': '龙' },
        { 'playId': 202231693, 'name': '蛇' },
        { 'playId': 202231694, 'name': '马' },
        { 'playId': 202231695, 'name': '羊' },
        { 'playId': 202231696, 'name': '猴' },
        { 'playId': 202231697, 'name': '鸡' },
        { 'playId': 202231698, 'name': '狗' },
        { 'playId': 202231699, 'name': '猪' }
      ]
    }]
  }, {
    'playTypeId': 2022317,
    'playTypeName': '九肖',
    'minChosen': 9,
    'playListGroup': [{
      'playListGroupName': '',
      'playList': [
        { 'playId': 202231788, 'name': '鼠' },
        { 'playId': 202231789, 'name': '牛' },
        { 'playId': 202231790, 'name': '虎' },
        { 'playId': 202231791, 'name': '兔' },
        { 'playId': 202231792, 'name': '龙' },
        { 'playId': 202231793, 'name': '蛇' },
        { 'playId': 202231794, 'name': '马' },
        { 'playId': 202231795, 'name': '羊' },
        { 'playId': 202231796, 'name': '猴' },
        { 'playId': 202231797, 'name': '鸡' },
        { 'playId': 202231798, 'name': '狗' },
        { 'playId': 202231799, 'name': '猪' }
      ]
    }]
  }, {
    'playTypeId': 2022318,
    'playTypeName': '十肖',
    'minChosen': 10,
    'playListGroup': [{
      'playListGroupName': '',
      'playList': [
        { 'playId': 202231888, 'name': '鼠' },
        { 'playId': 202231889, 'name': '牛' },
        { 'playId': 202231890, 'name': '虎' },
        { 'playId': 202231891, 'name': '兔' },
        { 'playId': 202231892, 'name': '龙' },
        { 'playId': 202231893, 'name': '蛇' },
        { 'playId': 202231894, 'name': '马' },
        { 'playId': 202231895, 'name': '羊' },
        { 'playId': 202231896, 'name': '猴' },
        { 'playId': 202231897, 'name': '鸡' },
        { 'playId': 202231898, 'name': '狗' },
        { 'playId': 202231899, 'name': '猪' }
      ]
    }]
  }, {
    'playTypeId': 2022319,
    'playTypeName': '十一肖',
    'minChosen': 11,
    'playListGroup': [{
      'playListGroupName': '',
      'playList': [
        { 'playId': 202231988, 'name': '鼠' },
        { 'playId': 202231989, 'name': '牛' },
        { 'playId': 202231990, 'name': '虎' },
        { 'playId': 202231991, 'name': '兔' },
        { 'playId': 202231992, 'name': '龙' },
        { 'playId': 202231993, 'name': '蛇' },
        { 'playId': 202231994, 'name': '马' },
        { 'playId': 202231995, 'name': '羊' },
        { 'playId': 202231996, 'name': '猴' },
        { 'playId': 202231997, 'name': '鸡' },
        { 'playId': 202231998, 'name': '狗' },
        { 'playId': 202231999, 'name': '猪' }
      ]
    }]
  }]
}]
