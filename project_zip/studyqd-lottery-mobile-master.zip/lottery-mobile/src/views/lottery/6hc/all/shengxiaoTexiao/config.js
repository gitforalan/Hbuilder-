export default [{
  'playTabId': 20222,
  'playTabName': '特肖',
  'playTypeList': [{
    'playTypeId': 2022210,
    'playTypeName': '特肖',
    'playListGroup': [{
      'playListGroupName': '特肖',
      'playList': [
        { 'playId': 202221088, 'name': '鼠' },
        { 'playId': 202221089, 'name': '牛' },
        { 'playId': 202221090, 'name': '虎' },
        { 'playId': 202221091, 'name': '兔' },
        { 'playId': 202221092, 'name': '龙' },
        { 'playId': 202221093, 'name': '蛇' },
        { 'playId': 202221094, 'name': '马' },
        { 'playId': 202221095, 'name': '羊' },
        { 'playId': 202221096, 'name': '猴' },
        { 'playId': 202221097, 'name': '鸡' },
        { 'playId': 202221098, 'name': '狗' },
        { 'playId': 202221099, 'name': '猪' }
      ]
    }]
  }]
} ]
