export default [{
  'playTabId': 20213,
  'playTabName': '正码1-6',
  'playTypeList': [{
    'playTypeId': 2021310,
    'playTypeName': '正码1',
    'playListGroup': [{
      'playTypeId': 2022310,
      'playListGroupName': '正码1',
      'playList': [
        { 'playId': 202131064, 'name': '单' },
        { 'playId': 202131065, 'name': '双' },
        { 'playId': 202131066, 'name': '大' },
        { 'playId': 202131067, 'name': '小' },
        { 'playId': 202131080, 'name': '红波' },
        { 'playId': 202131081, 'name': '蓝波' },
        { 'playId': 202131082, 'name': '绿波' },
        { 'playId': 202131055, 'name': '合大' },
        { 'playId': 202131056, 'name': '合小' },
        { 'playId': 202131057, 'name': '合单' },
        { 'playId': 202131058, 'name': '合双' },
        { 'playId': 202131054, 'name': '尾大' },
        { 'playId': 202131059, 'name': '尾小' }
      ]
    }]
  },
  {
    'playTypeId': 2021311,
    'playTypeName': '正码2',
    'playListGroup': [{
      'playTypeId': 2021311,
      'playListGroupName': '正码2',
      'playList': [
        { 'playId': 202131164, 'name': '单' },
        { 'playId': 202131165, 'name': '双' },
        { 'playId': 202131166, 'name': '大' },
        { 'playId': 202131167, 'name': '小' },
        { 'playId': 202131180, 'name': '红波' },
        { 'playId': 202131181, 'name': '蓝波' },
        { 'playId': 202131182, 'name': '绿波' },
        { 'playId': 202131155, 'name': '合大' },
        { 'playId': 202131156, 'name': '合小' },
        { 'playId': 202131157, 'name': '合单' },
        { 'playId': 202131158, 'name': '合双' },
        { 'playId': 202131154, 'name': '尾大' },
        { 'playId': 202131159, 'name': '尾小' }
      ]
    }]
  },
  {
    'playTypeId': 2021312,
    'playTypeName': '正码3',
    'playListGroup': [{
      'playTypeId': 2021312,
      'playListGroupName': '正码3',
      'playList': [
        { 'playId': 202131264, 'name': '单' },
        { 'playId': 202131265, 'name': '双' },
        { 'playId': 202131266, 'name': '大' },
        { 'playId': 202131267, 'name': '小' },
        { 'playId': 202131280, 'name': '红波' },
        { 'playId': 202131281, 'name': '蓝波' },
        { 'playId': 202131282, 'name': '绿波' },
        { 'playId': 202131255, 'name': '合大' },
        { 'playId': 202131256, 'name': '合小' },
        { 'playId': 202131257, 'name': '合单' },
        { 'playId': 202131258, 'name': '合双' },
        { 'playId': 202131254, 'name': '尾大' },
        { 'playId': 202131259, 'name': '尾小' }
      ]
    }]
  },
  {
    'playTypeId': 2021313,
    'playTypeName': '正码4',
    'playListGroup': [{
      'playTypeId': 2021313,
      'playListGroupName': '正码4',
      'playList': [
        { 'playId': 202131364, 'name': '单' },
        { 'playId': 202131365, 'name': '双' },
        { 'playId': 202131366, 'name': '大' },
        { 'playId': 202131367, 'name': '小' },
        { 'playId': 202131380, 'name': '红波' },
        { 'playId': 202131381, 'name': '蓝波' },
        { 'playId': 202131382, 'name': '绿波' },
        { 'playId': 202131355, 'name': '合大' },
        { 'playId': 202131356, 'name': '合小' },
        { 'playId': 202131357, 'name': '合单' },
        { 'playId': 202131358, 'name': '合双' },
        { 'playId': 202131354, 'name': '尾大' },
        { 'playId': 202131359, 'name': '尾小' }
      ]
    }]
  },
  {
    'playTypeId': 2021314,
    'playTypeName': '正码5',
    'playListGroup': [{
      'playTypeId': 2021314,
      'playListGroupName': '正码5',
      'playList': [
        { 'playId': 202131464, 'name': '单' },
        { 'playId': 202131465, 'name': '双' },
        { 'playId': 202131466, 'name': '大' },
        { 'playId': 202131467, 'name': '小' },
        { 'playId': 202131480, 'name': '红波' },
        { 'playId': 202131481, 'name': '蓝波' },
        { 'playId': 202131482, 'name': '绿波' },
        { 'playId': 202131455, 'name': '合大' },
        { 'playId': 202131456, 'name': '合小' },
        { 'playId': 202131457, 'name': '合单' },
        { 'playId': 202131458, 'name': '合双' },
        { 'playId': 202131454, 'name': '尾大' },
        { 'playId': 202131459, 'name': '尾小' }
      ]
    }]
  },
  {
    'playTypeId': 2021315,
    'playTypeName': '正码6',
    'playListGroup': [{
      'playTypeId': 2021315,
      'playListGroupName': '正码6',
      'playList': [
        { 'playId': 202131564, 'name': '单' },
        { 'playId': 202131565, 'name': '双' },
        { 'playId': 202131566, 'name': '大' },
        { 'playId': 202131567, 'name': '小' },
        { 'playId': 202131580, 'name': '红波' },
        { 'playId': 202131581, 'name': '蓝波' },
        { 'playId': 202131582, 'name': '绿波' },
        { 'playId': 202131555, 'name': '合大' },
        { 'playId': 202131556, 'name': '合小' },
        { 'playId': 202131557, 'name': '合单' },
        { 'playId': 202131558, 'name': '合双' },
        { 'playId': 202131554, 'name': '尾大' },
        { 'playId': 202131559, 'name': '尾小' }
      ]
    }]
  }
  ]
}]
