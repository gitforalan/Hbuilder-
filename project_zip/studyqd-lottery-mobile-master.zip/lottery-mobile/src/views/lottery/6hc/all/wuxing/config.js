export default [{
  'playTabId': 20217,
  'playTabName': '五行',
  'playTypeList': [{
    'playTypeId': 2021710,
    'playTypeName': '五行',
    'playListGroup': [{
      'playListGroupName': '五行',
      'playList': [
        { 'playId': 202171001, 'name': '金' },
        { 'playId': 202171002, 'name': '木' },
        { 'playId': 202171003, 'name': '水' },
        { 'playId': 202171004, 'name': '火' },
        { 'playId': 202171005, 'name': '土' }
      ]
    }]
  }]
}]
