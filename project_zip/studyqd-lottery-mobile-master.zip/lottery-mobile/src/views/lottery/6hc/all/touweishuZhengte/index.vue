<!-- Created By fx on 2017/9/19. -->
<template>
  <section class="lm-content" :style="{marginTop:marginTop+'px'}">
    <div flex="main:justify cross:center">
      <div flex-box="1" class="tips" align="center">
        <icon-svg icon-class="shou"></icon-svg>点击：筹码下注<span>长按：筹码删除</span>
      </div>
    </div>
    <div class="lm-selector" flex="" v-for="(item, row) in layout">
      <div class="title" flex-box="0" align="center">正特尾数</div>
      <div class="content" flex-box="1" align="center">
        <ul flex="main:left" class="num">
          <li v-for="t in item.playList">
            <v-touch @tap="doSelectBoal(t, 1)" @pressup="doSelectBoal(t, 0)" >
              <span class="circle" :class="{active: t.isactive}">
                <span>{{ t.name }}</span>
                <!-- <span class="shengxiao">{{doGenCodeNum(t.name)}}</span> -->
                <span class="prize">{{t.computedMaxPrize | formatF2Y}}</span>
                <span class="bet-pop" :class="{'rect':t.money > 9999}">{{t.money}}</span>
              </span>
            </v-touch>
          </li>
        </ul>
      </div>
    </div>
    <!-- 下注确认 -->
    <BetConfirm v-if="isShowBetConfirm" :top="marginTop" />
    <!-- 底部 -->
    <LHCFooter/>
  </section>
</template>

<script src="./script.js"></script>
<style scoped lang="stylus" src="./style.styl"></style>
