export default [{
  'playTabId': 20224,
  'playTabName': '连肖',
  'playTypeList': [{
    'playTypeId': 2022410,
    'playTypeName': '二肖连中',
    'minChosen': 2,
    'playListGroup': [{
      'playListGroupName': '',
      'playList': [
        { 'playId': 202241088, 'name': '鼠' },
        { 'playId': 202241089, 'name': '牛' },
        { 'playId': 202241090, 'name': '虎' },
        { 'playId': 202241091, 'name': '兔' },
        { 'playId': 202241092, 'name': '龙' },
        { 'playId': 202241093, 'name': '蛇' },
        { 'playId': 202241094, 'name': '马' },
        { 'playId': 202241095, 'name': '羊' },
        { 'playId': 202241096, 'name': '猴' },
        { 'playId': 202241097, 'name': '鸡' },
        { 'playId': 202241098, 'name': '狗' },
        { 'playId': 202241099, 'name': '猪' }
      ]
    }]
  }, {
    'playTypeId': 2022411,
    'playTypeName': '三肖连中',
    'minChosen': 3,
    'playListGroup': [{
      'playListGroupName': '',
      'playList': [
        { 'playId': 202241188, 'name': '鼠' },
        { 'playId': 202241189, 'name': '牛' },
        { 'playId': 202241190, 'name': '虎' },
        { 'playId': 202241191, 'name': '兔' },
        { 'playId': 202241192, 'name': '龙' },
        { 'playId': 202241193, 'name': '蛇' },
        { 'playId': 202241194, 'name': '马' },
        { 'playId': 202241195, 'name': '羊' },
        { 'playId': 202241196, 'name': '猴' },
        { 'playId': 202241197, 'name': '鸡' },
        { 'playId': 202241198, 'name': '狗' },
        { 'playId': 202241199, 'name': '猪' }
      ]
    }]
  }, {
    'playTypeId': 2022412,
    'playTypeName': '四肖连中',
    'minChosen': 4,
    'playListGroup': [{
      'playListGroupName': '',
      'playList': [
        { 'playId': 202241288, 'name': '鼠' },
        { 'playId': 202241289, 'name': '牛' },
        { 'playId': 202241290, 'name': '虎' },
        { 'playId': 202241291, 'name': '兔' },
        { 'playId': 202241292, 'name': '龙' },
        { 'playId': 202241293, 'name': '蛇' },
        { 'playId': 202241294, 'name': '马' },
        { 'playId': 202241295, 'name': '羊' },
        { 'playId': 202241296, 'name': '猴' },
        { 'playId': 202241297, 'name': '鸡' },
        { 'playId': 202241298, 'name': '狗' },
        { 'playId': 202241299, 'name': '猪' }
      ]
    }]
  }, {
    'playTypeId': 2022413,
    'playTypeName': '五肖连中',
    'minChosen': 5,
    'playListGroup': [{
      'playListGroupName': '',
      'playList': [
        { 'playId': 202241388, 'name': '鼠' },
        { 'playId': 202241389, 'name': '牛' },
        { 'playId': 202241390, 'name': '虎' },
        { 'playId': 202241391, 'name': '兔' },
        { 'playId': 202241392, 'name': '龙' },
        { 'playId': 202241393, 'name': '蛇' },
        { 'playId': 202241394, 'name': '马' },
        { 'playId': 202241395, 'name': '羊' },
        { 'playId': 202241396, 'name': '猴' },
        { 'playId': 202241397, 'name': '鸡' },
        { 'playId': 202241398, 'name': '狗' },
        { 'playId': 202241399, 'name': '猪' }
      ]
    }]
  }, {
    'playTypeId': 2022414,
    'playTypeName': '二肖连不中',
    'minChosen': 2,
    'playListGroup': [{
      'playListGroupName': '',
      'playList': [
        { 'playId': 202241488, 'name': '鼠' },
        { 'playId': 202241489, 'name': '牛' },
        { 'playId': 202241490, 'name': '虎' },
        { 'playId': 202241491, 'name': '兔' },
        { 'playId': 202241492, 'name': '龙' },
        { 'playId': 202241493, 'name': '蛇' },
        { 'playId': 202241494, 'name': '马' },
        { 'playId': 202241495, 'name': '羊' },
        { 'playId': 202241496, 'name': '猴' },
        { 'playId': 202241497, 'name': '鸡' },
        { 'playId': 202241498, 'name': '狗' },
        { 'playId': 202241499, 'name': '猪' }
      ]
    }]
  }, {
    'playTypeId': 2022415,
    'playTypeName': '三肖连不中',
    'minChosen': 3,
    'playListGroup': [{
      'playListGroupName': '',
      'playList': [
        { 'playId': 202241588, 'name': '鼠' },
        { 'playId': 202241589, 'name': '牛' },
        { 'playId': 202241590, 'name': '虎' },
        { 'playId': 202241591, 'name': '兔' },
        { 'playId': 202241592, 'name': '龙' },
        { 'playId': 202241593, 'name': '蛇' },
        { 'playId': 202241594, 'name': '马' },
        { 'playId': 202241595, 'name': '羊' },
        { 'playId': 202241596, 'name': '猴' },
        { 'playId': 202241597, 'name': '鸡' },
        { 'playId': 202241598, 'name': '狗' },
        { 'playId': 202241599, 'name': '猪' }
      ]
    }]
  }, {
    'playTypeId': 2022416,
    'playTypeName': '四肖连不中',
    'minChosen': 4,
    'playListGroup': [{
      'playListGroupName': '',
      'playList': [
        { 'playId': 202241688, 'name': '鼠' },
        { 'playId': 202241689, 'name': '牛' },
        { 'playId': 202241690, 'name': '虎' },
        { 'playId': 202241691, 'name': '兔' },
        { 'playId': 202241692, 'name': '龙' },
        { 'playId': 202241693, 'name': '蛇' },
        { 'playId': 202241694, 'name': '马' },
        { 'playId': 202241695, 'name': '羊' },
        { 'playId': 202241696, 'name': '猴' },
        { 'playId': 202241697, 'name': '鸡' },
        { 'playId': 202241698, 'name': '狗' },
        { 'playId': 202241699, 'name': '猪' }
      ]
    }]
  }]
}]
