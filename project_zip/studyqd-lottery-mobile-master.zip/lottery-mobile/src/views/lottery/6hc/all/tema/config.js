export default [{
  'playTabId': 20210,
  'playTabName': '特码',
  'playTypeList': [{
    'playTypeId': 2021010,
    'playTypeName': '特码',
    'playListGroup': [{
      'playListGroupName': '特码',
      'playList': [
        { 'playId': 202101001, 'name': '01' },
        { 'playId': 202101002, 'name': '02' },
        { 'playId': 202101003, 'name': '03' },
        { 'playId': 202101004, 'name': '04' },
        { 'playId': 202101005, 'name': '05' },
        { 'playId': 202101006, 'name': '06' },
        { 'playId': 202101007, 'name': '07' },
        { 'playId': 202101008, 'name': '08' },
        { 'playId': 202101009, 'name': '09' },
        { 'playId': 202101010, 'name': '10' },
        { 'playId': 202101011, 'name': '11' },
        { 'playId': 202101012, 'name': '12' },
        { 'playId': 202101013, 'name': '13' },
        { 'playId': 202101014, 'name': '14' },
        { 'playId': 202101015, 'name': '15' },
        { 'playId': 202101016, 'name': '16' },
        { 'playId': 202101017, 'name': '17' },
        { 'playId': 202101018, 'name': '18' },
        { 'playId': 202101019, 'name': '19' },
        { 'playId': 202101020, 'name': '20' },
        { 'playId': 202101021, 'name': '21' },
        { 'playId': 202101022, 'name': '22' },
        { 'playId': 202101023, 'name': '23' },
        { 'playId': 202101024, 'name': '24' },
        { 'playId': 202101025, 'name': '25' },
        { 'playId': 202101026, 'name': '26' },
        { 'playId': 202101027, 'name': '27' },
        { 'playId': 202101028, 'name': '28' },
        { 'playId': 202101029, 'name': '29' },
        { 'playId': 202101030, 'name': '30' },
        { 'playId': 202101031, 'name': '31' },
        { 'playId': 202101032, 'name': '32' },
        { 'playId': 202101033, 'name': '33' },
        { 'playId': 202101034, 'name': '34' },
        { 'playId': 202101035, 'name': '35' },
        { 'playId': 202101036, 'name': '36' },
        { 'playId': 202101037, 'name': '37' },
        { 'playId': 202101038, 'name': '38' },
        { 'playId': 202101039, 'name': '39' },
        { 'playId': 202101040, 'name': '40' },
        { 'playId': 202101041, 'name': '41' },
        { 'playId': 202101042, 'name': '42' },
        { 'playId': 202101043, 'name': '43' },
        { 'playId': 202101044, 'name': '44' },
        { 'playId': 202101045, 'name': '45' },
        { 'playId': 202101046, 'name': '46' },
        { 'playId': 202101047, 'name': '47' },
        { 'playId': 202101048, 'name': '48' },
        { 'playId': 202101049, 'name': '49' }
      ]
    },
    {
      'playListGroupName': '大小单双',
      'playList': [
        { 'playId': 202101052, 'name': '大' },
        { 'playId': 202101053, 'name': '小' },
        { 'playId': 202101050, 'name': '单' },
        { 'playId': 202101051, 'name': '双' },
        { 'playId': 202101055, 'name': '合单' },
        { 'playId': 202101056, 'name': '合双' },
        { 'playId': 202101057, 'name': '合大' },
        { 'playId': 202101058, 'name': '合小' },
        { 'playId': 202101054, 'name': '尾大' },
        { 'playId': 202101059, 'name': '尾小' }
      ]
    },
    {
      'playListGroupName': '生肖',
      'playList': [
        { 'playId': 202101088, 'name': '鼠' },
        { 'playId': 202101089, 'name': '牛' },
        { 'playId': 202101090, 'name': '虎' },
        { 'playId': 202101091, 'name': '兔' },
        { 'playId': 202101092, 'name': '龙' },
        { 'playId': 202101093, 'name': '蛇' },
        { 'playId': 202101094, 'name': '马' },
        { 'playId': 202101095, 'name': '羊' },
        { 'playId': 202101096, 'name': '猴' },
        { 'playId': 202101097, 'name': '鸡' },
        { 'playId': 202101098, 'name': '狗' },
        { 'playId': 202101099, 'name': '猪' }
      ]
    },
    {
      'playListGroupName': '家禽野兽',
      'playList': [
        { 'playId': 202101070, 'name': '家禽' },
        { 'playId': 202101071, 'name': '野兽' }
      ]
    },
    {
      'playListGroupName': '色波',
      'playList': [
        { 'playId': 202101080, 'name': '红波' },
        { 'playId': 202101081, 'name': '蓝波' },
        { 'playId': 202101082, 'name': '绿波' }
      ]
    }
    ]
  }]
}]
