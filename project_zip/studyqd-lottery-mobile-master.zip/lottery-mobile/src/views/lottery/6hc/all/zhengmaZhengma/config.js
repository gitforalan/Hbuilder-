export default [{
  'playTabId': 20211,
  'playTabName': '正码',
  'playTypeList': [{
    'playTypeId': 2021110,
    'playTypeName': '正码',
    'playListGroup': [{
      'playListGroupName': '正码',
      'playList': [
        { 'playId': 202111001, 'name': '01' },
        { 'playId': 202111002, 'name': '02' },
        { 'playId': 202111003, 'name': '03' },
        { 'playId': 202111004, 'name': '04' },
        { 'playId': 202111005, 'name': '05' },
        { 'playId': 202111006, 'name': '06' },
        { 'playId': 202111007, 'name': '07' },
        { 'playId': 202111008, 'name': '08' },
        { 'playId': 202111009, 'name': '09' },
        { 'playId': 202111010, 'name': '10' },
        { 'playId': 202111011, 'name': '11' },
        { 'playId': 202111012, 'name': '12' },
        { 'playId': 202111013, 'name': '13' },
        { 'playId': 202111014, 'name': '14' },
        { 'playId': 202111015, 'name': '15' },
        { 'playId': 202111016, 'name': '16' },
        { 'playId': 202111017, 'name': '17' },
        { 'playId': 202111018, 'name': '18' },
        { 'playId': 202111019, 'name': '19' },
        { 'playId': 202111020, 'name': '20' },
        { 'playId': 202111021, 'name': '21' },
        { 'playId': 202111022, 'name': '22' },
        { 'playId': 202111023, 'name': '23' },
        { 'playId': 202111024, 'name': '24' },
        { 'playId': 202111025, 'name': '25' },
        { 'playId': 202111026, 'name': '26' },
        { 'playId': 202111027, 'name': '27' },
        { 'playId': 202111028, 'name': '28' },
        { 'playId': 202111029, 'name': '29' },
        { 'playId': 202111030, 'name': '30' },
        { 'playId': 202111031, 'name': '31' },
        { 'playId': 202111032, 'name': '32' },
        { 'playId': 202111033, 'name': '33' },
        { 'playId': 202111034, 'name': '34' },
        { 'playId': 202111035, 'name': '35' },
        { 'playId': 202111036, 'name': '36' },
        { 'playId': 202111037, 'name': '37' },
        { 'playId': 202111038, 'name': '38' },
        { 'playId': 202111039, 'name': '39' },
        { 'playId': 202111040, 'name': '40' },
        { 'playId': 202111041, 'name': '41' },
        { 'playId': 202111042, 'name': '42' },
        { 'playId': 202111043, 'name': '43' },
        { 'playId': 202111044, 'name': '44' },
        { 'playId': 202111045, 'name': '45' },
        { 'playId': 202111046, 'name': '46' },
        { 'playId': 202111047, 'name': '47' },
        { 'playId': 202111048, 'name': '48' },
        { 'playId': 202111049, 'name': '49' }
      ]
    },
    {
      'playListGroupName': '大小单双',
      'playList': [
        { 'playId': 202111070, 'name': '总和大' },
        { 'playId': 202111071, 'name': '总和小' },
        { 'playId': 202111072, 'name': '总和单' },
        { 'playId': 202111073, 'name': '总和双' }
      ]
    }
    ]
  }]
}]
