<!-- Created By fx on 2017/9/19. -->
<template>
  <section class="lm-content" :style="{marginTop:marginTop+'px'}">
    <div flex="main:justify cross:center">
      <div flex-box="1" class="tips" align="center">
        <icon-svg icon-class="shou"></icon-svg>点击：筹码下注<span>长按：筹码删除</span>
      </div>
    </div>
    <div flex="main:justify" class="mid-bar">
      <div class="left" flex-box="1">
        <type-popover v-if="playMenus" :types="playMenus" :defaultValue="defaultPlayTypeName" @on-hide="onPlayMenuHide" />
      </div>
      <div class="right" flex-box="1">
        <type-popover :types="compuetedModes" :defaultValue="defaultSelectModeName" @on-hide="onSelectModeHide" />
      </div>
    </div>
    <div class="lm-selector">
      <div class="content" flex="dir:top" align="center" v-if="currentSelectMode==1 || currentSelectMode==2">
        <ul flex="main:left" class="num">
          <li v-for="t in playData">
            <v-touch @tap="doSelectBoal(t)" @pressup="doUnselectBoal(t)">
              <span class="circle" :class="{active: t.isactive,dan:t.isDan}">
                <span :class="doGenClass(t.name)">{{ t.name }}</span>
                <span class="prize" v-html="doFormat2Line(t.computedMaxPrize)"></span>
              </span>
            </v-touch>
          </li>
        </ul>
      </div>
      <div class="content" flex="dir:top" v-else>
        <ul v-for="t in playData" flex="main:left" class="num" flex-box="1">
          <li v-for="(item,index) in t.list">
            <v-touch @tap="doSelectBoalSX(item,t)" @pressup="doUnselectBoalSX(item)">
              <span class="circle" :class="{active: item.isactive}">
                <span :class="doGenClass(item.name)">{{ item.name }}</span>
                <span class="prize" v-html="doFormat2Line(item.computedMaxPrize)"></span>
              </span>
            </v-touch>
          </li>
        </ul>
      </div>
    </div>
    <!-- 下注确认 -->
    <BetConfirm v-if="isShowBetConfirm" :top="marginTop" />
    <!-- 底部 -->
    <LHCFooter/>
  </section>
</template>

<script src="./script.js"></script>
<style scoped lang="stylus" src="./style.styl"></style>
