export default [{
  'playTabId': 20219,
  'playTabName': '平特一肖',
  'playTypeList': [{
    'playTypeId': 2021910,
    'playTypeName': '平特一肖',
    'playListGroup': [{
      'playListGroupName': '平特一肖',
      'playList': [
        { 'playId': 202191088, 'name': '鼠' },
        { 'playId': 202191089, 'name': '牛' },
        { 'playId': 202191090, 'name': '虎' },
        { 'playId': 202191091, 'name': '兔' },
        { 'playId': 202191092, 'name': '龙' },
        { 'playId': 202191093, 'name': '蛇' },
        { 'playId': 202191094, 'name': '马' },
        { 'playId': 202191095, 'name': '羊' },
        { 'playId': 202191096, 'name': '猴' },
        { 'playId': 202191097, 'name': '鸡' },
        { 'playId': 202191098, 'name': '狗' },
        { 'playId': 202191099, 'name': '猪' }
      ]
    }]
  }]
}]
