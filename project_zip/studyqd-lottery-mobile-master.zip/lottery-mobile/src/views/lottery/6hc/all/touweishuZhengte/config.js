export default [{
  'playTabId': 20227,
  'playTabName': '正特尾数',
  'playTypeList': [{
    'playTypeId': 2022710,
    'playTypeName': '正特尾数',
    'playListGroup': [{
      'playListGroupName': '',
      'playList': [
        { 'playId': 202271010, 'name': ' 0尾' },
        { 'playId': 202271011, 'name': ' 1尾' },
        { 'playId': 202271012, 'name': ' 2尾' },
        { 'playId': 202271013, 'name': ' 3尾' },
        { 'playId': 202271014, 'name': ' 4尾' },
        { 'playId': 202271015, 'name': ' 5尾' },
        { 'playId': 202271016, 'name': ' 6尾' },
        { 'playId': 202271017, 'name': ' 7尾' },
        { 'playId': 202271018, 'name': ' 8尾' },
        { 'playId': 202271019, 'name': ' 9尾' }
      ]
    }]
  }]
}]
