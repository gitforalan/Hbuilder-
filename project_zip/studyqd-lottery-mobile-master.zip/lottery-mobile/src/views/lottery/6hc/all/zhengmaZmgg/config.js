// 正码过关的配置文件结构与其它玩法不同
export default [{
  'playTabId': 20214,
  'playTabName': '过关',
  'minChosen': 2,
  'maxChosen': 9,
  'playTypeList': [{
    'playTypeId': 2021410,
    'playTypeName': '正码一',
    'playListGroup': [{
      'playTypeId': 2021410,
      'playListGroupName': '正码1',
      'playList': [
        { 'playId': 202141064, 'alias': 'Z1_1', 'name': '单' },
        { 'playId': 202141065, 'alias': 'Z1_1', 'name': '双' },
        { 'playId': 202141066, 'alias': 'Z1_2', 'name': '大' },
        { 'playId': 202141067, 'alias': 'Z1_2', 'name': '小' },
        { 'playId': 202141080, 'alias': 'Z1_3', 'name': '红波' },
        { 'playId': 202141081, 'alias': 'Z1_3', 'name': '蓝波' },
        { 'playId': 202141082, 'alias': 'Z1_3', 'name': '绿波' }
      ]
    }, {
      'playTypeId': 2021411,
      'playListGroupName': '正码2',
      'playList': [
        { 'playId': 202141164, 'alias': 'Z2_1', 'name': '单' },
        { 'playId': 202141165, 'alias': 'Z2_1', 'name': '双' },
        { 'playId': 202141166, 'alias': 'Z2_2', 'name': '大' },
        { 'playId': 202141167, 'alias': 'Z2_2', 'name': '小' },
        { 'playId': 202141180, 'alias': 'Z2_3', 'name': '红波' },
        { 'playId': 202141181, 'alias': 'Z2_3', 'name': '蓝波' },
        { 'playId': 202141182, 'alias': 'Z2_3', 'name': '绿波' }
      ]
    }, {
      'playTypeId': 2021412,
      'playListGroupName': '正码3',
      'playList': [
        { 'playId': 202141264, 'alias': 'Z3_1', 'name': '单' },
        { 'playId': 202141265, 'alias': 'Z3_1', 'name': '双' },
        { 'playId': 202141266, 'alias': 'Z3_2', 'name': '大' },
        { 'playId': 202141267, 'alias': 'Z3_2', 'name': '小' },
        { 'playId': 202141280, 'alias': 'Z3_3', 'name': '红波' },
        { 'playId': 202141281, 'alias': 'Z3_3', 'name': '蓝波' },
        { 'playId': 202141282, 'alias': 'Z3_3', 'name': '绿波' }
      ]
    }, {
      'playTypeId': 2021413,
      'playListGroupName': '正码4',
      'playList': [
        { 'playId': 202141364, 'alias': 'Z4_1', 'name': '单' },
        { 'playId': 202141365, 'alias': 'Z4_1', 'name': '双' },
        { 'playId': 202141366, 'alias': 'Z4_2', 'name': '大' },
        { 'playId': 202141367, 'alias': 'Z4_2', 'name': '小' },
        { 'playId': 202141380, 'alias': 'Z4_3', 'name': '红波' },
        { 'playId': 202141381, 'alias': 'Z4_3', 'name': '蓝波' },
        { 'playId': 202141382, 'alias': 'Z4_3', 'name': '绿波' }
      ]
    }, {
      'playTypeId': 2021414,
      'playListGroupName': '正码5',
      'playList': [
        { 'playId': 202141464, 'alias': 'Z5_1', 'name': '单' },
        { 'playId': 202141465, 'alias': 'Z5_1', 'name': '双' },
        { 'playId': 202141466, 'alias': 'Z5_2', 'name': '大' },
        { 'playId': 202141467, 'alias': 'Z5_2', 'name': '小' },
        { 'playId': 202141480, 'alias': 'Z5_3', 'name': '红波' },
        { 'playId': 202141481, 'alias': 'Z5_3', 'name': '蓝波' },
        { 'playId': 202141482, 'alias': 'Z5_3', 'name': '绿波' }
      ]
    }, {
      'playTypeId': 2021415,
      'playListGroupName': '正码6',
      'playList': [
        { 'playId': 202141564, 'alias': 'Z6_1', 'name': '单' },
        { 'playId': 202141565, 'alias': 'Z6_1', 'name': '双' },
        { 'playId': 202141566, 'alias': 'Z6_2', 'name': '大' },
        { 'playId': 202141567, 'alias': 'Z6_2', 'name': '小' },
        { 'playId': 202141580, 'alias': 'Z6_3', 'name': '红波' },
        { 'playId': 202141581, 'alias': 'Z6_3', 'name': '蓝波' },
        { 'playId': 202141582, 'alias': 'Z6_3', 'name': '绿波' }
      ]
    }]
  }]
}]
