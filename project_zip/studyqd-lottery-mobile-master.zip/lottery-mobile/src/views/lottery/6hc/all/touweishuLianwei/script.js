import { mapState, mapMutations, mapGetters } from 'vuex'
import BetConfirm from '../../public/betConfirm'
import LHCFooter from '../../public/footer'
import typePopover from '../../public/typePopover'
import Layout from './config.js'
import dict from '../../public/dict.js'
import * as API from 'api/wapi/front'

export default {
  name: 'lian-wei',
  filters: {
    formatF2Y (num) {
      return (num / 100).toFixed(2)
    }
  },
  methods: {
    getLotterySixPlayOdds () {
      let query = {
        freqType: 2, // 六合彩的频率类型1-高频六合彩 2-低频六合彩 该属性为空或不传，默认获得低频六合彩
        playTabId: '20225'
      }
      API.getLotterySixPlayOdds(query).then(res => {
        if (res.code === 0) {
          this.layout = this.doMergeData(res.data.playTabList)
        } else {
          console.log('getLotterySixPlayOdds:', res.data.desc)
        }
      })
    },
    getLotteryUserBet () {
      let query = {
        lotteryId: this.lotteryId,
        issue: this.currentIssue,
        betList: JSON.stringify(this.flattenBetList)
      }
      API.getLotteryUserBet(query).then(res => {
        if (res.code === 0) {
          this.doUnselectAll() // 清空号码
          this.updateShowBetConfirm(false) // 关闭确认投注对话
          this.$vux.toast.show({
            type: 'success',
            isShowMask: false,
            text: '下注成功',
            time: 2000
          })
        }
      }).catch(err => {
        this.$vux.toast.show({
          type: 'warn',
          isShowMask: false,
          text: err.desc,
          time: 2000
        })
        console.log('getLotteryUserBet:', err.desc)
      })
    },
    // 处理配置文件数据
    doHandleData () {
      let tabName = Layout[0].playTabName
      return Layout[0].playTypeList.map(j => {
        let typeName = j.playTypeName
        j.playTypeNameFront = tabName + '-' + typeName
        j.playListGroup.map(k => {
          k.isactive = 0
          k.playList.map(m => {
            m.maxPrize = 0
            m.minPrize = 0
            m.rebateRate = 0
            m.computedMaxPrize = 0
            m.money = 0
            m.isactive = 0
            m.isDan = 0
            return m
          })
          return k
        })
        return j
      })
    },
    // 根据接口数据，更新本地数据
    doMergeData (data) {
      let p = data[0].playTypeList
      return this.layout.map(n => {
        let targetType = p.find(j => j.playTypeId === n.playTypeId)
        n.playListGroup[0].playList.map(m => {
          let targetPlay = targetType.playList.find(i => i.playId === m.playId)
          if (targetPlay) {
            m.maxPrize = targetPlay.maxPrize
            m.minPrize = targetPlay.minPrize
            m.rebateRate = targetPlay.rebateRate
            m.computedMaxPrize = targetPlay.maxPrize
          } else {
            // throw new Error(`${playId}: 玩法数据不存在`)
            console.log(`${m.playId}: 玩法数据不存在`)
          }
          return m
        })
        return n
      })
    },
    // 设置当前玩法类型
    doSetCurrentSubPlay (playTypeId) {
      this.doUnselectAll() // 清空选球
      if (!playTypeId) this.currentSubPlay = this.layout[0]
      else this.currentSubPlay = this.layout.find(i => i.playTypeId === playTypeId)
      this.currentSelectMode = 1
      this.defaultSelectModeName = '单式/复式'
    },
    doSetCurrentSelectMode (id) {
      this.doUnselectAll() // 清空选球
      this.currentSelectMode = id
    },
    // 生成色波class
    doGenClass (num) {
      let colors = dict.colors
      if (num === '红波') return { red: true }
      if (num === '蓝波') return { blue: true }
      if (num === '绿波') return { green: true }
      for (let i in colors) {
        if (colors[i].includes(num)) {
          return {
            [i]: true
          }
        }
      }
    },
    // 生成生肖
    doGenShengxiao (shengxiao) {
      return this.shengxiaoAll[shengxiao].join(' ')
    },
    // 选球
    doSelectBoal (item) {
      let selectedBoal = this.selectedBoal
      let playMode = this.currentSelectMode

      if (playMode === 1) {
        if (selectedBoal.length >= this.maxChosen) {
          let options = {
            type: 'warn',
            isShowMask: false,
            time: 2000
          }
          options.text = `最多只能选 ${this.maxChosen} 个`
          this.$vux.toast.show(options)
          return
        } else {
          item.isactive = 1
        }
      }
      if (playMode === 2) {
        if (selectedBoal.length < this.currentSubPlay.minChosen - 1) {
          item.isDan = 1
        }
        item.isactive = 1
      }
    },
    // 取消选球
    doUnselectBoal (item) {
      if (!item.isDan) {
        item.isactive = 0
      }
    },
    // 清空选球
    doUnselectAll () {
      this.layout.forEach(k => {
        k.playListGroup.forEach(i => {
          i.playList.forEach(j => {
            j.isactive = 0
            j.money = 0
            j.isDan = 0
          })
        })
      })
    },
    // 关闭玩法类型菜单
    onPlayMenuHide (data) {
      this.defaultPlayTypeName = data.name // 更新当前玩法菜单项名称
      this.doSetCurrentSubPlay(data.id) // 切换玩法类型
      this.updateResetRebateRateSlider(true) // 通知Footer复位返水滑动条
      this.doUpdateRebateRate(0) // 强制更新奖金赔率
    },
    // 关闭选球模式菜单
    onSelectModeHide (data) {
      this.defaultSelectModeName = data.name // 更新当前玩法菜单项名称
      this.doSetCurrentSelectMode(data.id) // 切换玩法类型
    },
    // 更新奖金赔率
    doUpdateRebateRate (nval) {
      this.currentSubPlay.playListGroup.forEach(i => {
        i.playList.forEach(j => {
          let max = j.maxPrize
          let diff = j.maxPrize - j.minPrize
          let t = (diff / this.maxSliderVal) * nval
          let b = (max - t).toFixed(0)
          j.computedMaxPrize = b
        })
      })
    },
    // 根据选号模式生成投注组合
    doGenFlattenBetList (selected, minChosen, playMode) {
      if (playMode === 1) { // 单式复式
        let combs = this.doCalcCombination(selected, minChosen)
        return combs.map(k => {
          return {
            playId: this.currentSubPlay.playTypeId, // 合肖传playTypeId
            imp: 0,
            moneyUnit: 3,
            singleMoney: this.singleBetMoney * 100, // 转分
            rebateRate: this.rebateRate,
            buyCode: k.map(i => String(i.playId).slice(-2)).join(','), // playId 后两位
            buyCodeFront: k.map(i => i.name).join(','), // 前端展示
            playTypeName: this.currentSubPlay.playTypeNameFront, // 父级分类名称,前端展示
            computedMaxPrize: Math.min.apply(null, k.map(i => i.computedMaxPrize)) // 前端显示
          }
        })
      }
      if (playMode === 2) { // 胆拖
        let dan = selected.filter(i => i.isDan)
        let rest = selected.filter(i => !i.isDan)
        // 找出胆位中最小赔率的项
        let tmp2 = dan.slice(0).sort((a, b) => a.computedMaxPrize - b.computedMaxPrize)[0]
        let tmp3 = JSON.parse(JSON.stringify(tmp2))
        tmp3.name = dan.map(i => i.name).join(',')
        let arr = []
        for (let i = 0; i < rest.length; i++) {
          let _arr = [tmp3].concat(rest[i])
          let tmp = {
            playId: this.currentSubPlay.playTypeId,
            imp: 0,
            moneyUnit: 3,
            singleMoney: this.singleBetMoney * 100, // 转分
            rebateRate: this.rebateRate,
            buyCode: _arr.map(i => i.name).join(','),
            buyCodeFront: _arr.map(i => i.name).join(','),
            playTypeName: this.currentSubPlay.playTypeNameFront, // 父级分类名称,用于用户侧展示
            computedMaxPrize: Math.min.apply(null, _arr.map(i => i.computedMaxPrize)) // 前端显示
          }
          arr.push(tmp)
        }
        return arr
      }
    },
    /**
     * 计算组合
     * @param  {Array} set 全部元素集合
     * @param  {Number} k  目标组合数
     * @return {Array}     二维数组
     *
     */
    doCalcCombination (set, k) {
      var i, j, combs, head, tailcombs
      if (k > set.length || k <= 0) return []
      if (k === set.length) return [set]
      if (k === 1) { // 递归出口
        combs = []
        for (i = 0; i < set.length; i++) {
          combs.push([set[i]])
        }
        return combs
      }
      combs = []
      for (i = 0; i < set.length - k + 1; i++) {
        head = set.slice(i, i + 1)
        tailcombs = this.doCalcCombination(set.slice(i + 1), k - 1)
        for (j = 0; j < tailcombs.length; j++) {
          combs.push(head.concat(tailcombs[j]))
        }
      }
      return combs
    },
    ...mapMutations('lhc', [
      'lhc_flattenBetList',
      'setClearNow',
      'setBetNow',
      'updateMaxSliderVal',
      'updateInputStyleFooter',
      'updateShowBetConfirm',
      'updateSelectedNumber',
      'updateMinChosen',
      'updateResetRebateRateSlider'
    ])
  },
  watch: {
    currentSubPlay (nval) {
      this.updateMinChosen(nval.minChosen)
      this.maxChosen = nval.maxChosen
    },
    // 根据选择的球，拼接号码
    selectedBoal (nval) {
      this.updateSelectedNumber(nval.map(i => i.name).join(','))
    },
    // 监听当前注单，推到store保存
    flattenBetList (nval) {
      this.lhc_flattenBetList({ flattenBetList: nval })
    },
    clearNow (nval) {
      if (nval) this.doUnselectAll()
      this.setClearNow(false)
    },
    betNow (nval) {
      if (nval) {
        this.getLotteryUserBet()
        this.setBetNow(false)
      }
    },
    maxSliderVal (nval) {
      this.updateMaxSliderVal(nval)
    },
    // 监测返水，实时计算前台奖金
    rebateRate (nval) {
      this.doUpdateRebateRate(nval)
    }
  },
  computed: {
    ...mapState('lhc', [
      'playTabId',
      'playTabName',
      'clearNow',
      'singleBetMoney',
      'rebateRate',
      'betNow',
      'isShowBetConfirm',
      'shengxiaoAll'
    ]),
    ...mapGetters('common', [
      'lotteryId'
    ]),
    // 已选择的球
    selectedBoal () {
      let ret = []
      if (!this.currentSubPlay) return []
      this.currentSubPlay.playListGroup.forEach(i => {
        let tmp = i.playList.filter(j => j.isactive === 1)
        if (tmp.length) ret.push(tmp)
      })
      return [].concat(...ret)
    },
    // 计算后的注单信息
    flattenBetList () {
      if (!this.currentSubPlay) return []
      let minChosen = this.currentSubPlay.minChosen
      let selectedBoal = this.selectedBoal
      let playMode = this.currentSelectMode // 1-单式复式 2-胆拖
      if (selectedBoal.length < minChosen) return []
      return this.doGenFlattenBetList(selectedBoal, minChosen, playMode)
    },
    totalBetNumbers () {
      return this.flattenBetList.length
    },
    totalBetMoney () {
      return this.selectedBoal.map(i => i.money).reduce((a, b) => a + b, 0)
    },
    // 返水点滚动条最大百分比
    maxSliderVal () {
      if (this.layout.length) {
        return +this.layout[0].playListGroup[0].playList[0].rebateRate
      }
    },
    // 玩法菜单
    playMenus () {
      if (!this.layout.length) return []
      return this.layout.map(i => ({
        name: i.playTypeName,
        id: i.playTypeId
      }))
    }
  },
  props: {
    marginTop: [Number, String],
    currentIssue: [Number, String]
  },
  data () {
    return {
      layout: [],
      currentSubPlay: null,
      defaultPlayTypeName: '二尾连中',
      selectModes: [{ id: 1, name: '单式/复式' }, { id: 2, name: '胆拖' }],
      defaultSelectModeName: '单式/复式',
      currentSelectMode: 1,
      maxChosen: 8
    }
  },
  created () {
    this.layout = this.doHandleData()
    this.doSetCurrentSubPlay()
    // 更新底部Footer的金额选择样式 true-筹码和输入 false-只有输入
    this.updateInputStyleFooter(true)
  },
  mounted () {
    this.getLotterySixPlayOdds()
  },
  components: { BetConfirm, typePopover, LHCFooter }
}
