export default [{
  'playTabId': 20216,
  'playTabName': '七码',
  'playTypeList': [{
    'playTypeId': 2021610,
    'playTypeName': '七码',
    'playListGroup': [{
      'playListGroupName': '单',
      'playList': [
        { 'playId': 202161001, 'name': '单0' },
        { 'playId': 202161002, 'name': '单1' },
        { 'playId': 202161003, 'name': '单2' },
        { 'playId': 202161004, 'name': '单3' },
        { 'playId': 202161005, 'name': '单4' },
        { 'playId': 202161006, 'name': '单5' },
        { 'playId': 202161007, 'name': '单6' },
        { 'playId': 202161008, 'name': '单7' }
      ]
    },
    {
      'playListGroupName': '双',
      'playList': [
        { 'playId': 202161009, 'name': '双0' },
        { 'playId': 202161010, 'name': '双1' },
        { 'playId': 202161011, 'name': '双2' },
        { 'playId': 202161012, 'name': '双3' },
        { 'playId': 202161013, 'name': '双4' },
        { 'playId': 202161014, 'name': '双5' },
        { 'playId': 202161015, 'name': '双6' },
        { 'playId': 202161016, 'name': '双7' }
      ]
    },
    {
      'playListGroupName': '大',
      'playList': [
        { 'playId': 202161017, 'name': '大0' },
        { 'playId': 202161018, 'name': '大1' },
        { 'playId': 202161019, 'name': '大2' },
        { 'playId': 202161020, 'name': '大3' },
        { 'playId': 202161021, 'name': '大4' },
        { 'playId': 202161022, 'name': '大5' },
        { 'playId': 202161023, 'name': '大6' },
        { 'playId': 202161024, 'name': '大7' }
      ]
    },
    {
      'playListGroupName': '小',
      'playList': [
        { 'playId': 202161025, 'name': '小0' },
        { 'playId': 202161026, 'name': '小1' },
        { 'playId': 202161027, 'name': '小2' },
        { 'playId': 202161028, 'name': '小3' },
        { 'playId': 202161029, 'name': '小4' },
        { 'playId': 202161030, 'name': '小5' },
        { 'playId': 202161031, 'name': '小6' },
        { 'playId': 202161032, 'name': '小7' }
      ]
    }
    ]
  }]
}]
