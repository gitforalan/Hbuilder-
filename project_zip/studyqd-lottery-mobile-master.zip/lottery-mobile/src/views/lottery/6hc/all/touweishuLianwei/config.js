export default [{
  'playTabId': 20225,
  'playTabName': '连尾',
  'playTypeList': [{
    'playTypeId': 2022510,
    'playTypeName': '二尾连中',
    'minChosen': 2,
    'maxChosen': 9,
    'playListGroup': [{
      'playListGroupName': '',
      'playList': [
        { 'playId': 202251010, 'name': '0尾' },
        { 'playId': 202251011, 'name': '1尾' },
        { 'playId': 202251012, 'name': '2尾' },
        { 'playId': 202251013, 'name': '3尾' },
        { 'playId': 202251014, 'name': '4尾' },
        { 'playId': 202251015, 'name': '5尾' },
        { 'playId': 202251016, 'name': '6尾' },
        { 'playId': 202251017, 'name': '7尾' },
        { 'playId': 202251018, 'name': '8尾' },
        { 'playId': 202251019, 'name': '9尾' }
      ]
    }]
  }, {
    'playTypeId': 2022511,
    'playTypeName': '三尾连中',
    'minChosen': 3,
    'maxChosen': 9,
    'playListGroup': [{
      'playListGroupName': '',
      'playList': [
        { 'playId': 202251110, 'name': '0尾' },
        { 'playId': 202251111, 'name': '1尾' },
        { 'playId': 202251112, 'name': '2尾' },
        { 'playId': 202251113, 'name': '3尾' },
        { 'playId': 202251114, 'name': '4尾' },
        { 'playId': 202251115, 'name': '5尾' },
        { 'playId': 202251116, 'name': '6尾' },
        { 'playId': 202251117, 'name': '7尾' },
        { 'playId': 202251118, 'name': '8尾' },
        { 'playId': 202251119, 'name': '9尾' }
      ]
    }]
  }, {
    'playTypeId': 2022512,
    'playTypeName': '四尾连中',
    'minChosen': 4,
    'maxChosen': 9,
    'playListGroup': [{
      'playListGroupName': '',
      'playList': [
        { 'playId': 202251210, 'name': '0尾' },
        { 'playId': 202251211, 'name': '1尾' },
        { 'playId': 202251212, 'name': '2尾' },
        { 'playId': 202251213, 'name': '3尾' },
        { 'playId': 202251214, 'name': '4尾' },
        { 'playId': 202251215, 'name': '5尾' },
        { 'playId': 202251216, 'name': '6尾' },
        { 'playId': 202251217, 'name': '7尾' },
        { 'playId': 202251218, 'name': '8尾' },
        { 'playId': 202251219, 'name': '9尾' }
      ]
    }]
  }, {
    'playTypeId': 2022513,
    'playTypeName': '二尾连不中',
    'minChosen': 2,
    'maxChosen': 9,
    'playListGroup': [{
      'playListGroupName': '',
      'playList': [
        { 'playId': 202251310, 'name': '0尾' },
        { 'playId': 202251311, 'name': '1尾' },
        { 'playId': 202251312, 'name': '2尾' },
        { 'playId': 202251313, 'name': '3尾' },
        { 'playId': 202251314, 'name': '4尾' },
        { 'playId': 202251315, 'name': '5尾' },
        { 'playId': 202251316, 'name': '6尾' },
        { 'playId': 202251317, 'name': '7尾' },
        { 'playId': 202251318, 'name': '8尾' },
        { 'playId': 202251319, 'name': '9尾' }
      ]
    }]
  }, {
    'playTypeId': 2022514,
    'playTypeName': '三尾连不中',
    'minChosen': 3,
    'maxChosen': 9,
    'playListGroup': [{
      'playListGroupName': '',
      'playList': [
        { 'playId': 202251410, 'name': '0尾' },
        { 'playId': 202251411, 'name': '1尾' },
        { 'playId': 202251412, 'name': '2尾' },
        { 'playId': 202251413, 'name': '3尾' },
        { 'playId': 202251414, 'name': '4尾' },
        { 'playId': 202251415, 'name': '5尾' },
        { 'playId': 202251416, 'name': '6尾' },
        { 'playId': 202251417, 'name': '7尾' },
        { 'playId': 202251418, 'name': '8尾' },
        { 'playId': 202251419, 'name': '9尾' }
      ]
    }]
  }, {
    'playTypeId': 2022515,
    'playTypeName': '四尾连不中',
    'minChosen': 4,
    'maxChosen': 9,
    'playListGroup': [{
      'playListGroupName': '',
      'playList': [
        { 'playId': 202251510, 'name': '0尾' },
        { 'playId': 202251511, 'name': '1尾' },
        { 'playId': 202251512, 'name': '2尾' },
        { 'playId': 202251513, 'name': '3尾' },
        { 'playId': 202251514, 'name': '4尾' },
        { 'playId': 202251515, 'name': '5尾' },
        { 'playId': 202251516, 'name': '6尾' },
        { 'playId': 202251517, 'name': '7尾' },
        { 'playId': 202251518, 'name': '8尾' },
        { 'playId': 202251519, 'name': '9尾' }
      ]
    }]
  }]
}]
