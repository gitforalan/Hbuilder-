export default [{
  'playTabId': 20230,
  'playTabName': '特码头尾数',
  'playTypeList': [{
    'playTypeId': 2023010,
    'playTypeName': '特码头尾数',
    'playListGroup': [{
      'playListGroupName': '',
      'playList': [
        { 'playId': 202301001, 'name': ' 0头' },
        { 'playId': 202301002, 'name': ' 1头' },
        { 'playId': 202301003, 'name': ' 2头' },
        { 'playId': 202301004, 'name': ' 3头' },
        { 'playId': 202301005, 'name': ' 4头' },
        { 'playId': 202301010, 'name': ' 0尾' },
        { 'playId': 202301011, 'name': ' 1尾' },
        { 'playId': 202301012, 'name': ' 2尾' },
        { 'playId': 202301013, 'name': ' 3尾' },
        { 'playId': 202301014, 'name': ' 4尾' },
        { 'playId': 202301015, 'name': ' 5尾' },
        { 'playId': 202301016, 'name': ' 6尾' },
        { 'playId': 202301017, 'name': ' 7尾' },
        { 'playId': 202301018, 'name': ' 8尾' },
        { 'playId': 202301019, 'name': ' 9尾' }
      ]
    }]
  }]
}]
