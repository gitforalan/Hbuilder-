/**
 * Created by fx on 2017/8/28.
 */
const filePath = 'lottery/ksan/credit/'
// 分包
const hotLoad = require('@/utils/import_' + process.env.NODE_ENV)
let ZhengHe = {}
ZhengHe.S = hotLoad(filePath + 'all/zhenghe/S/index')
ZhengHe.Q = hotLoad(filePath + 'all/zhenghe/Q/index')
ZhengHe.C = hotLoad(filePath + 'all/zhenghe/C/index')

export default {
  ZhengHe
}
