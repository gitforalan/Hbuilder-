<!--
  -- ksan 信用玩法
  -->
<template>
  <component :is="currentView" v-if="currentView" :currentPlay="currentPlay"></component>
</template>

<script type="text/ecmascript-6">
  import { mapState } from 'vuex'
  import playComps from './all/playComps'

  const TAB_ID = {
    ZHENGHE: {
      S: 122101,  // 三军/大小/点数
      Q: 122102,  // 全骰/围骰
      C: 122103  // 长牌/短牌
    }
  }

  export default {
    data () {
      return {
        currentView: null,
        currentPlay: null
      }
    },
    components: playComps,
    computed: {
      ...mapState('ksan', {
        currentTab: state => state.currentTab,
        playTabId: state => state.playTabId
      })
    },
    methods: {
      /* 设置玩法 */
      setCurrentView (playTabId) {
        switch (playTabId) {
          case TAB_ID.ZHENGHE.S:
            this.currentView = playComps.ZhengHe.S
            break
          case TAB_ID.ZHENGHE.Q:
            this.currentView = playComps.ZhengHe.Q
            break
          case TAB_ID.ZHENGHE.C:
            this.currentView = playComps.ZhengHe.C
            break
          default:
            this.currentView = playComps.ZhengHe.S // 默认 整合玩法->三军/大小/点数
        }
        this.currentPlay = this.currentPlays(playTabId) // 设置玩法数据
      },
      /* 获取玩法数据 */
      currentPlays (id) {
        const keys = Object.keys(this.currentTab)
        for (let key of keys) {
          const _key = this.currentTab[key].playTabId
          if (_key === id) {
            this.currentTab[key].isactive = false
            this.currentTab[key].playTypeList.forEach(j => {
              let playTypeName = j.playTypeName
              j.playList.forEach(k => {
                k.playTypeName = playTypeName
                k.isactive = false
                k.money = 0
                k.computedMaxPrize = k.maxPrize
              })
            })
            return this.currentTab[key]
          }
        }
      }
    },
    created () {
    },
    watch: {
      /* 监听玩法切换 */
      playTabId (nval) {
        this.setCurrentView(nval)
      }
    }
  }
</script>

<style scoped></style>
