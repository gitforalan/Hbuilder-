/**
 * Created by fx on 2017/10/11.
 */

import commonEd from '../../../public/mixin'

export default {
  name: 'zhengHe',
  mixins: [commonEd],
  data () {
    return {
      splitColNum: [5, 3]
    }
  },
  methods: {
    /* 短牌 UI数据处理 */
    _subRow (arr = []) {
      const _arr = [].concat(arr)
      if (_arr.length) {
        _arr.splice(1, 0, null)
        _arr.splice(_arr.length - 1, 0, null)
      }
      _arr
      return _arr
    }
  }
}

