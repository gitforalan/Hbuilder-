<!-- Created By fx on 2017/10/11. -->
<template>
  <div class="tips">
    <icon-svg icon-class="shou"></icon-svg>
    <span>点击：筹码下注</span>
    <span>长按：筹码删除</span>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
    name: 'tips'
  }
</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .tips
    text-align center
    color $color-black-b
    font-size rem(22)
    margin-bottom rem(20)
    span:last-child
      padding-left rem(26)
    .lott-icon
      width 1.5rem
      height 1.5rem
      vertical-align bottom
      padding-right rem(5)
</style>
