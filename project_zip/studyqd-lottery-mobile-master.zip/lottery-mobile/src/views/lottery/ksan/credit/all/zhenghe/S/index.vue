<template>
  <section class="lm-content">
    <div class="lm-selector">
      <!-- 提示 -->
      <tips></tips>
      <!-- 选号 -->
      <!-- 三军 -->
      <template v-for="(row, ri) in creditLayoutData">
        <template v-if="ri < 2">
          <div class="tag-top" flex="">
            <div class="tag-left" flex-box="0"></div>
            <div flex-box="1" class="tag-line line-down line-top">
              <span>赔 {{ row.playList[0][0].computedMaxPrize | formatF2Y }}</span>
            </div>
          </div>
          <div v-for="(subRow, sri) in row.playList" class="credit-wrap" flex="main:justify">
            <div flex-box="0" class="credit-unit">{{ sri === 0 ? row.playTypeName : '' }}</div>
            <div flex-box="1" class="credit-con">
              <ul flex="box:mean">
                <v-touch v-for="(play, index) in subRow"
                         tag="li"
                         @tap="doSelectBoal(play,1)"
                         @pressup="doSelectBoal(play,0)"

                         :key="index"
                         :class="{active: play.isactive}">
                  <span v-if="!isNaN(parseInt(play.playName))">
                    <img :src="touzi[+play.playName]" :alt="play.playName">
                  </span>
                  <span v-else>{{ play.playName }}</span>
                  <p class="bet-pop" :class="{'rect':play.money > 9999}">{{ play.money }}</p>
                </v-touch>
              </ul>
            </div>
          </div>
        </template>
        <template v-else>
          <div class="tag-top" flex="">
            <div class="tag-left" flex-box="0"></div>
            <!--<div flex-box="1" class="tag-line line-down line-top">-->
              <!--<span>{{ row.playList[0][0].computedMaxPrize | formatF2Y }}</span>-->
            <!--</div>-->
          </div>
          <div v-for="(subRow, sri) in row.playList" class="credit-wrap" flex="main:justify">
            <div flex-box="0" class="credit-unit">{{ sri === 0 ? row.playTypeName : '' }}</div>
            <div flex-box="1" class="credit-con point-con">
              <ul flex="box:mean">
                <template v-for="(play, index) in subRow">
                  <v-touch
                    v-if="!play.hasOwnProperty('empty')"
                    tag="li"
                    @tap="doSelectBoal(play,1)"
                    @pressup="doSelectBoal(play,0)"

                    :key="index"
                    :class="{active: play.isactive}">
                  <span>
                    {{ play.playName }}
                  </span>
                    <i>{{ play.computedMaxPrize | formatF2Y }}</i> <!-- todo  -->
                    <p class="bet-pop">{{ play.money }}</p>
                  </v-touch>
                  <li v-else></li>
                </template>
              </ul>
            </div>
          </div>
        </template>
      </template>
    </div>
    <!--底部区域-->
    <cfooter></cfooter>
  </section>
</template>


<script type="text/ecmascript-6">
  import ed from './script'

  export default ed
</script>

<style scoped lang="stylus">
  @import 'style.styl'
</style>
