/**
 * Created by fx on 2017/10/11.
 */

import commonEd from '../../../public/mixin'

export default {
  name: 'zhengHe',
  mixins: [commonEd],
  methods: {
    _creditLayoutData () {
      // const cols = 6
      const _layoutData = this.creditLayoutData
      if (_layoutData) {
        let playList = _layoutData[_layoutData.length - 1].playList
        playList[playList.length - 1].push({ empty: true }) // flex模板占位用
      }
      return this.creditLayoutData
    }
  },
  created () {
    this.creditLayoutData = this._creditLayoutData()
  }
}

