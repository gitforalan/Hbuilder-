/**
 * Created by fx on 2017/10/13.
 */
// public
import { mapState, mapMutations, mapGetters } from 'vuex'
// API
import * as API from 'api/wapi/front'
// public
import Cfooter from './cfooter'
import Tips from './tips'

// 混合相同的代码
const commonEd = {
  data () {
    return {
      touzi: {
        1: require('assets/image/touzi/1.png'),
        2: require('assets/image/touzi/2.png'),
        3: require('assets/image/touzi/3.png'),
        4: require('assets/image/touzi/4.png'),
        5: require('assets/image/touzi/5.png'),
        6: require('assets/image/touzi/6.png')
      },
      creditLayoutData: [], // 处理后的信用玩法数据
      splitColNum: [6, 4, 5] // 切片个数
    }
  },
  props: {
    currentPlay: {
      type: Object,
      required: true
    }
  },
  components: { Cfooter, Tips },
  filters: { // 分转元
    formatF2Y: (val) => (val / 100).toFixed(2)
  },
  computed: {
    ...mapState('ksan', [
      'playTabId',
      'playTabName',
      'clearNow',
      'singleBetMoney',
      'rebateRate',
      'betNow',
      'isShowBetConfirm',
      'shengxiaoAll'
    ]),
    ...mapState('common', ['issue']),
    ...mapGetters('common', ['lotteryId']),
    // 已选择的球
    selectedBoal () {
      let ret = []
      this.creditLayoutData.forEach(i => {
        let tmp = i.playList.map(item => item.filter(j => j.isactive === 1))
        tmp = [].concat.apply([], tmp) // 扁平化
        if (tmp.length) ret.push(tmp)
      })
      return [].concat(...ret)
    },
    // 计算后的注单信息
    flattenBetList () {
      return this.selectedBoal.map(j => ({
        playId: j.playId,
        imp: 0,
        moneyUnit: 3,
        singleMoney: j.money * 100, // 转分
        rebateRate: this.rebateRate,
        buyCode: j.playName, // 接口要求不能为空
        buyCodeFront: j.playName, // 用于返回用户选择的玩法名称
        playTypeName: this.playTabName, // 父级分类名称,用于用户侧展示
        computedMaxPrize: j.computedMaxPrize // 前端显示
      }))
    },
    totalBetNumbers () {
      return this.flattenBetList.length
    },
    totalBetMoney () {
      return this.selectedBoal.map(i => i.money).reduce((a, b) => a + b, 0)
    },
    // 返水点滚动条最大百分比
    maxSliderVal () {
      if (this.creditLayoutData.length) {
        return +this.creditLayoutData[0].playList[0][0].rebateRate
      }
    }
  },
  methods: {
    /* 生成模板数据 */
    generateUIData () {
      const data = JSON.parse(JSON.stringify(this.currentPlay.playTypeList)) // 玩法UI数据
      data.forEach((item, index) => {
        const size = this.splitColNum[index]
        item.playList = this.chunkArray(item.playList, size)
      })
      return data
    },
    /* 数组切片 */
    chunkArray (arr, size) {
      let newArr = []
      for (let i = 0; i < arr.length; i += size) {
        newArr.push(arr.slice(i, i + size))
      }
      return newArr
    },
    doSelectBoal (item, bool) {
      item.isactive = bool
      if (bool === 1) {
        if ((item.money + this.singleBetMoney) > 999999) {
          return
        } else {
          item.money += this.singleBetMoney
        }
      } else item.money = 0
    },
    doUnselectAll () {
      this.creditLayoutData.forEach(i => {
        i.playList.forEach(j => {
          j.forEach(p => {
            p.isactive = 0
            p.money = 0
          })
        })
      })
    },
    getLotteryUserBet () {
      let query = {
        lotteryId: this.lotteryId,
        issue: this.issue,
        betList: JSON.stringify(this.flattenBetList)
      }
      API.getLotteryUserBet(query).then(res => {
        this.doUnselectAll() // 清空号码
        this.$vux.toast.show({
          type: 'success',
          isShowMask: false,
          text: '下注成功',
          time: 2000
        })
      }).catch(err => {
        this.$vux.toast.show({
          type: 'warn',
          isShowMask: false,
          text: err.desc,
          time: 4000
        })
      })
    },
    ...mapMutations('ksan', [
      'saveFlattenBetList',
      'setClearNow',
      'setBetNow',
      'updateMaxSliderVal',
      'updateInputStyleFooter',
      'updateShowBetConfirm',
      'updateSelectedNumber'
    ])
  },
  created () {
    this.creditLayoutData = this.generateUIData() // 生成模板数据
    // 更新底部Footer的金额选择样式 true-筹码和输入 false-只有输入
    this.updateInputStyleFooter(false)
    // console.log('整合', this.creditLayoutData)
  },
  watch: {
    // 根据选择的球，拼接号码
    selectedBoal (nval) {
      let arr = [].concat.apply([], nval.map(i => i.playName))
      this.updateSelectedNumber(arr.join(','))
    },
    // 监听当前注单，推到store保存
    flattenBetList (nval) {
      this.saveFlattenBetList({ flattenBetList: nval })
    },
    clearNow (nval) {
      if (nval) this.doUnselectAll()
      this.setClearNow(false)
    },
    betNow (nval) {
      if (nval) {
        this.getLotteryUserBet()
        this.setBetNow(false)
      }
    },
    maxSliderVal (nval) {
      this.updateMaxSliderVal(nval)
    },
    // 监测返水，实时计算前台奖金
    rebateRate (nVal) {
      this.creditLayoutData.forEach(i => {
        i.playList.forEach(j => {
          j.forEach(p => {
            let max = p.maxPrize
            let diff = p.maxPrize - p.minPrize
            let t = (diff / this.maxSliderVal) * nVal
            let b = (max - t).toFixed(0)
            p.computedMaxPrize = b
          })
        })
      })
    }
  }
}

export default commonEd
