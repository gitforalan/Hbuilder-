/**
 * Created by fx on 2017/10/11.
 */

import commonEd from '../../../public/mixin'

export default {
  name: 'zhengHe',
  mixins: [commonEd],
  data () {
    return {
      splitColNum: [3, 1],
      // 全骰模板
      quanTou: {
        row: 3,
        col: 6
      }
    }
  }
}

