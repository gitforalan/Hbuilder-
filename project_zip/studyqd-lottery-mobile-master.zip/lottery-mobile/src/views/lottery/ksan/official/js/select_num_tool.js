/* eslint-disable */
const random = require('lodash/random')
export default {

  doSelectNumber (index, attribute, rowIndex) {
    switch (attribute) {
      case 'all':
        this.doSelectAll(index)
        break
      case 'big':
        this.doSelectBig(index)
        break
      case 'small':
        this.doSelectSmall(index)
        break
      case 'odd':
        this.doSelectOdd(index)
        break
      case 'even':
        this.doSelectEven(index)
        break
      case 'clear':
        this.doUnselectAll(index)
        break
      case 'single':
        this.doSelectSingle(index, rowIndex)
        break
    }
    // 计算注数
    this.calcNumber()
  },

  doSelectAll (index) {
    let row = this.currentLayout[index].no
    row.forEach(i => i.isSelected = 1)
  },
  doUnselectAll (index) {
    let row = this.currentLayout[index].no
    row.forEach(i => i.isSelected = 0)
  },
  doSelectBig (index) {
    this.doUnselectAll(index)
    let row = this.currentLayout[index].no
    let target = row.filter(i => i.number >= this.noBigIndex)
    target.forEach(i => i.isSelected = 1)
  },
  doSelectSmall (index) {
    this.doUnselectAll(index)
    let row = this.currentLayout[index].no
    let target = row.filter(i => i.number < this.noBigIndex)
    target.forEach(i => i.isSelected = 1)
  },
  doSelectOdd (index) {
    this.doUnselectAll(index)
    let row = this.currentLayout[index].no
    let target = row.filter((i, index) => index % 2 == 0)
    target.forEach(i => i.isSelected = 1)
  },
  doSelectEven (index) {
    this.doUnselectAll(index)
    let row = this.currentLayout[index].no
    let target = row.filter((i, index) => !(index % 2 == 0))
    target.forEach(i => i.isSelected = 1)
  },
  doSelectSingle (index, rowIndex) {
    let alias = this.currentPlay.alias
    let selected = this.currentLayout[index].no[rowIndex]
    // 针对胆拖玩法和二同号单选，特殊处理
    if (alias) {
      if (alias.slice(0, 2) == 'DT') {
        let limit = alias.slice(-1) // 胆码数量限制，小于此值
        let dan = []
        // 先获取已经选中的胆码
        for (let i of this.currentLayout[0].no) {
          if (i.isSelected) {
            dan.push(i)
          }
        }
        // 胆码处理，数量达到，并且继续选中之前未选中的胆码，则清除最先选中的#
        if (dan.length + 1 == limit && index == 0 && dan.indexOf(selected) == -1) {
          dan.shift().isSelected = 0
        }
      }
      if (alias.slice(0, 2) == 'DT' || alias == 'THDX') {
        selected.isSelected === 1 ? selected.isSelected = 0 : selected.isSelected = 1
        let i = 1 - index
        let cacheStatus = this.currentLayout[i].no[rowIndex]
        if (selected.isSelected === 1) { // 上下不同号处理
          cacheStatus.isSelected = 0
        }
        return
      }
    }
    selected.isSelected === 1 ? selected.isSelected = 0 : selected.isSelected = 1
  },
  doClearLayout () {
    let len = this.currentLayout.length
    for (let i = 0; i < len; i++) {
      this.doUnselectAll(i)
    }
  },
  doSelectRandom () {
    var mname = this.currentPlay.alias
    var otype = this.layoutType
    var data_sel = this.currentLayout
    var repeate = 0
    var repeatetmp = []

    this.doClearLayout() // 清除手动选择的号码
    this.betNumber = 0
    this.randomSelNum = []
    var nums = this.maxPlace
    var amin = []
    switch (mname) { // 根据玩法分类不同做不同处理
      case 'HZ':
        nums = 0
        amin[0] = 1
        break
      case 'ZU2': // 二不同号标准
      case 'ZU3': // 三不同号标准
        nums = 0
        amin[0] = mname.substring(mname.length - 1)
        break
      case 'DT2': // 二不同号胆拖
      case 'DT3': // 三不同号胆拖
        nums = 1
        amin[0] = 1
        amin[1] = mname.substring(mname.length - 1) - 1
        break
      default: // 默认情况,有多少位选择多少位
        for (var j = 0; j <= nums; j++) {
          amin[j] = 1
        }
        break
    }
    var _this = this

    function genTempCode () {
      var tmp = []
      var repeatetmp = [] // 用于检查重复的数组
      _this.randomSelNum = []
      for (let i = 0; i <= nums; i++) {
        /* 提取待选的号码 */
        var tmpNum = _this.currentLayoutNum[i]
        // console.log(tmpNum.length)
        var len = amin[i] ? Number(amin[i]) : 0 // 如果amin[i]为undefined，则初始len为0，不进入循环
        var rowCode // 数组，保存每一行上的号码
        rowCode = []
        for (let j = 0; j < len; j++) {
          let _random = Math.floor(Math.random() * tmpNum.length)
          rowCode.push(tmpNum[_random])
          repeatetmp.push(tmpNum[_random])
        }
        rowCode.sort((a, b) => a - b) // 排序
        tmp.push(rowCode)
        /* 处理每一行数据 结束 */
      }
      // 检查单注是否有重复号码 11与1
      if (repeate == 0) { // 都是有repeate标记的特殊玩法
        let flg = ''
        repeatetmp.sort((a, b) => a - b) // 先排序
        for (let i of repeatetmp) {
          if (!flg.includes(i)) {
            flg = i
          } else {
            return genTempCode()
          }
        }
      }
      // 生成用于注数计算的数组
      tmp.forEach((i, idx) => {
        if (i.length) {
          // _this.randomSelNum.push(i.split(','))
          _this.randomSelNum.push(i)
        } else {
          _this.randomSelNum.push([]) // 添加个空数据，否则注数计算出错
        }
      })

      // 处理随机号码的显示格式
      let finalName
      switch (mname) {
        case 'DWD':
        case 'ZX2':
        case 'ZX3':
          finalName = tmp.join(',')
          break
        case 'DT2':
        case 'DT3':
        case 'DT4':
        case 'DT5':
        case 'DT6':
        case 'DT7':
        case 'DT8':
          let _name = tmp.map(i => {
            if (i.length > 1) return i.join('')
            return i
          })
          finalName = _name.join(',')
          break
        default:
          finalName = tmp.join(',')
          break
      }
      // debugger
      // 返回购买的号码
      return finalName
    }

    return genTempCode()
  }
}
