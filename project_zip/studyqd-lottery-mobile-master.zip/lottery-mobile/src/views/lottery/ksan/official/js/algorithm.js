/* eslint-disable */
import { accMul, Combination, getCombination } from '@/utils/lotteryUtil.js'
import each from 'lodash/each'

export default {
  /* 计算实时注数 */
  calcNumber () {
    this.betNumber = this.checkSelectedNum()
    return this.betNumber
  },
  
  // 根据玩法，返回注数
  // 选择型注数计算
  checkSelectedNum (randomSelNum) {
    let tmp_nums = 1
    let mname = this.currentPlay.alias
    let data_sel = randomSelNum || this.currentSelNumArr
    // debugger
    let max_place = this.maxPlace
    let minchosen = this.minChosen
    // 根据玩法分类不同做不同处理
    let nums = 0
    switch (mname) {
      case 'HZ':
        tmp_nums = 0
        for (let i = 0; i <= max_place; i++) {
          tmp_nums += data_sel[i].length
        }
        nums = tmp_nums
        break
      case 'ZU3': // 三码前中后，组选
      case 'ZU2': // 二码前中后，组选
        if (data_sel[0].length >= minchosen[0]) { // C(n,m)
          nums += Combination(data_sel[0].length, minchosen[0])
        }
        break
      case 'DT2':
      case 'DT3': /* 任选胆拖 、所有胆拖玩法 */
        var danlen = data_sel[0].length // 胆码
        var tuolen = data_sel[1].length // 拖码
        var sellen = parseInt(mname.substring(mname.length - 1))
        if (danlen < 1 || tuolen < 1 || danlen >= sellen) {
          nums = 0
        } else {
          nums = Combination(tuolen, sellen - danlen)
        }
        break
      default: // 默认情况
        for (let i = 0; i <= max_place; i++) {
          if (data_sel[i].length == 0) { // 有位置上没有选择
            tmp_nums = 0
            break
          }
          tmp_nums = accMul(tmp_nums, data_sel[i].length)
        }
        nums = tmp_nums
        break
    }
    return nums
    //
  }
  
}
