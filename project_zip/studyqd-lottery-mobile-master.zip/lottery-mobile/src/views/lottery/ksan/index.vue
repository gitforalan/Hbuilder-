<template>
  <div class="app-main lm-ssc">
    <!-- 头部 -->
    <sub-header :title="title"
                :defalutBack="false"
                @on-click-back="onClickBack"
                @on-click-title="onClickTitle"
                @show-popover-menu="showPopoverMenu"
                ref="header"
    >
    </sub-header>
    <div class="popover-menu">
      <z-popover-menu
        placement="right"
        :show="isShowPopoverMenu"
        @on-hide="onPopoverMenuHide">
      </z-popover-menu>
    </div>
    <!-- 通用区 -->
    <!-- 彩期 -->
    <current-info :typeId="typeId" ref="currentInfo"></current-info>

    <!-- 主内容区 -->
    <div v-show="!showCart" class="app-body" ref="appBody">
      <!-- 玩法-->
      <play-tab-list :show="showPlayTabList" @on-hide="hidePlayTabList"></play-tab-list>
      <!-- 选号 -->
      <play-area v-if="MODE.OFFICIAL === playTabMode" ref="lotContent"></play-area>
      <credit-play-area v-if="MODE.CREDIT === playTabMode" ref="lotContent"></credit-play-area>
    </div>

    <!-- 底部 -->
    <ofooter v-if="MODE.OFFICIAL === playTabMode" v-show="!showCart" ref="footer"></ofooter>

    <!-- 购票车 -->
    <bet-cart v-if="showCart"></bet-cart>

    <!-- 弹出页 -->
    <popover-page v-show="showPopoverPage"></popover-page>
  </div>
</template>

<script type="text/ecmascript-6">
  import { mapState, mapMutations, mapActions } from 'vuex'
  /* common */
  import SubHeader from 'views/common/subHeader'
  import ZPopoverMenu from 'views/common/zPopoverMenu'
  import RightMenu from 'views/common/rightMenu'
  /* official */
  import PlayArea from './official/playArea'
  import Ofooter from './official/ofooter'
  /* credit */
  import creditPlayArea from './credit/index'
  /* public */
  import PlayTabList from './public/playTabList'

  const LANG = {
    confirmContent: '您尚有注单未提交，是否退出？',
    currentOver: '当前彩期已结束,待投注选号将自动进入下一期！'
  }
  export default {
    data () {
      return {
        MODE: {
          OFFICIAL: 1, // 官方
          CREDIT: 2    // 信用
        },
        typeId: 12,
        isShowPopoverMenu: false,
        showPlayTabList: false,
        showRightMenu: true
      }
    },
    components: {
      SubHeader,
      ZPopoverMenu,
      PlayArea,
      Ofooter,
      creditPlayArea,
      PlayTabList,
      RightMenu
    },
    computed: {
      title () {
        if (this.playTabName) {
          return this.playTabName + ' ' + this.playName
        }
        return ''
      },
      ...mapState('ksan', {
        playTabName: state => state.playTabName,
        playName: state => state.playName,
        playId: state => state.playId
      }),
      ...mapState('common', {
        playTabMode: state => state.playTabMode,
        cart: state => state.betList,
        showCart: state => state.showCart,
        lotteryId: state => state.lotteryId,
        noticeIssue: state => state.noticeIssue,
        rightMenu: state => state.rightMenu,
        lotteryName: state => state.lotteryName
      }),
      ...mapState('ui', {
        showPopoverPage: state => state.showPopoverPage,
        singleRow: state => state.singleRow
      })
    },
    methods: {
      // 离开此彩种前处理
      beforeLeave () {
        return new Promise((resolve, reject) => {
          if (this.cart.length) {
            this.$vux.confirm.show({
              content: LANG.confirmContent,
              onConfirm () {
                resolve()
              },
              onCancel () {
                reject()
              }
            })
          }
        })
      },
      onClickBack () {
        // 离开彩种前处理
        if (this.cart.length === 0) return this.$router.push({ name: 'home' }) // 回首页
        this.beforeLeave().then(() => {
          this.$router.push({ name: 'home' })
        }).catch(() => {
          this.open_cart(true) // 购票车
        })
      },
      onClickTitle () {
        this.showPlayTabList = !this.showPlayTabList
      },
      showPopoverMenu () {
        this.isShowPopoverMenu = !this.isShowPopoverMenu
      },
      onPopoverMenuHide () {
        this.delayExec(() => {
          this.isShowPopoverMenu = false
        })
      },
      hidePlayTabList () {
        this.delayExec(() => {
          this.showPlayTabList = false
        })
      },
      delayExec (fn) {
        setTimeout(fn, 20)
      },
      resetUI () { // 计算内容区域高度、投注列表高度
        this.delayExec(() => {
          const wH = window.innerHeight
          const wHeader = this.$refs.header.$el.offsetHeight
          const wFooter = this.$refs.footer.$el.offsetHeight
          this.$refs.appBody.style.minHeight = wH - (wHeader + wFooter) + 'px'
          this.$refs.lotContent.$el.style.marginTop = this.$refs.currentInfo.$el.offsetHeight + 'px'
        })
      },
      ...mapMutations('common', ['open_cart']),
      ...mapMutations('ui', ['set_singleRow']),
      ...mapActions('common', ['resetCommonState'])
    },
    created () {
      this.resetUI()
      this.set_singleRow(false) // 彩期模块显示全
    },
    mounted () {
      window.scrollTo(0, 0)
    },
    watch: {
      noticeIssue (val) {
        if (val) {
          this.$vux.alert.show({
            content: LANG.currentOver
          })
          setTimeout(() => {
            this.$vux.alert.hide()
          }, 5000)
        }
      },
      showCart (val) {
        if (val) {
          this.set_singleRow(true)
        } else {
          this.set_singleRow(false)
        }
      }
    },
    beforeDestroy () {
      // this.resetCommonState() // 清空store
    }
  }
</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .app-body
    background #fff

  .popover-menu
    position fixed
    top 4rem
    right .3rem
    z-index 102
</style>
