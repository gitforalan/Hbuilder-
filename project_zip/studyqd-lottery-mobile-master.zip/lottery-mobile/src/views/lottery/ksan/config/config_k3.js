export default {
  /* 和值 */
  121101010: {
    alias: 'HZ',
    hcltPosition: [0],
    selectarea: {
      type: 'digital',
      layout: [{
        title: '和值',
        no: '3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|大|小|单|双',
        place: 0,
        cols: 1,
        minchosen: 1
      }],
      noBigIndex: 8,
      isButton: true
    }
  },
  // 和值 3
  121101011: {},
  121101012: {},
  121101013: {},
  121101014: {},
  121101015: {},
  121101016: {},
  121101017: {},
  121101018: {},
  121101019: {},
  121101020: {},
  121101021: {},
  121101022: {},
  121101023: {},
  121101024: {},
  121101025: {},
  121101026: {},
  // 和值 大
  121101027: {},
  121101028: {},
  121101029: {},
  121101030: {},
  /* 三同号 */
  // 通选
  121111010: {
    alias: 'DZ',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '号码',
        no: '三同号通选',
        place: 0,
        cols: 1
      }],
      isButton: false
    }
  },
  // 单选
  121111011: {
    alias: 'DZ',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '号码',
        no: '111|222|333|444|555|666',
        place: 0,
        cols: 1
      }],
      isButton: false
    }
  },

  /* 三不同号 */
  // 标准
  121121010: {
    alias: 'ZU3',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '标准',
        no: '1|2|3|4|5|6',
        place: 0,
        cols: 1,
        minchosen: 3
      }]
    }
  },

  // 胆拖
  121121011: {
    alias: 'DT3',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '胆码',
        no: '1|2|3|4|5|6',
        place: 0,
        cols: 1
      }, {
        title: '拖码',
        no: '1|2|3|4|5|6',
        place: 1,
        cols: 1
      }],
      noBigIndex: 3,
      isButton: false
    }
  },
  /* 三连号 */
  121131010: {
    alias: 'DZ',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '号码',
        no: '三连号通选',
        place: 0,
        cols: 1
      }]
    }
  },
  /* 二同号 */
  // 复选
  121141010: {
    alias: 'DZ',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '号码',
        no: '11|22|33|44|55|66',
        place: 0,
        cols: 1,
        minchosen: 3
      }]
    }
  },
  // 单选
  121141011: {
    alias: 'THDX',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '同号',
        no: '11|22|33|44|55|66',
        place: 0,
        cols: 1
      }, {
        title: '不同号',
        no: '1|2|3|4|5|6',
        place: 1,
        cols: 1
      }]
    }
  },

  /* 二不同号 */
  // 标准
  121151010: {
    alias: 'ZU2',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '标准',
        no: '1|2|3|4|5|6',
        place: 0,
        cols: 1,
        minchosen: 2
      }]
    }
  },
  // 胆拖
  121151011: {
    alias: 'DT2',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '胆码',
        no: '1|2|3|4|5|6',
        place: 0,
        cols: 1
      }, {
        title: '拖码',
        no: '1|2|3|4|5|6',
        place: 1,
        cols: 1
      }]
    }
  }
}
