/**
 * 拆分 整合(12210) 玩法
 */
export default [{
  'playTabName': '三军/大小/点数',
  'playTabId': 122101,
  'playTypeList': [{
    'playTypeId': 1221010,
    'playTypeName': '三军',
    'playList': [{ 'playId': 122101010 }, { 'playId': 122101011 }, { 'playId': 122101012 }, { 'playId': 122101013 }, { 'playId': 122101014 }, { 'playId': 122101015 }]
  }, {
    'playTypeId': 1221016,
    'playTypeName': '总和',
    'playList': [{ 'playId': 122101610 }, { 'playId': 122101611 }, { 'playId': 122101612 }, { 'playId': 122101613 }]
  }, {
    'playTypeId': 1221013,
    'playTypeName': '点数',
    'playList': [{ 'playId': 122101310 }, { 'playId': 122101311 }, { 'playId': 122101312 }, { 'playId': 122101313 }, { 'playId': 122101314 }, { 'playId': 122101315 }, { 'playId': 122101316 }, { 'playId': 122101317 }, { 'playId': 122101318 }, { 'playId': 122101319 }, { 'playId': 122101320 }, { 'playId': 122101321 }, { 'playId': 122101322 }, { 'playId': 122101323 }]
  }],
  'sort': 1
}, {
  'playTabName': '围骰/全骰',
  'playTabId': 122102,
  'playTypeList': [{
    'playTypeId': 1221011,
    'playTypeName': '围骰',
    'playList': [{ 'playId': 122101110 }, { 'playId': 122101111 }, { 'playId': 122101112 }, { 'playId': 122101113 }, { 'playId': 122101114 }, { 'playId': 122101115 }]
  }, {
    'playTypeId': 1221012,
    'playTypeName': '全骰',
    'playList': [{ 'playId': 122101210 }]
  }],
  'sort': 2
}, {
  'playTabName': '长牌/短牌',
  'playTabId': 122103,
  'playTypeList': [{
    'playTypeId': 1221014,
    'playTypeName': '长牌',
    'playList': [{ 'playId': 122101410 }, { 'playId': 122101411 }, { 'playId': 122101412 }, { 'playId': 122101413 }, { 'playId': 122101414 }, { 'playId': 122101415 }, { 'playId': 122101416 }, { 'playId': 122101417 }, { 'playId': 122101418 }, { 'playId': 122101419 }, { 'playId': 122101420 }, { 'playId': 122101421 }, { 'playId': 122101422 }, { 'playId': 122101423 }, { 'playId': 122101424 }]
  }, {
    'playTypeId': 1221015,
    'playTypeName': '短牌',
    'playList': [{ 'playId': 122101510 }, { 'playId': 122101511 }, { 'playId': 122101512 }, { 'playId': 122101513 }, { 'playId': 122101514 }, { 'playId': 122101515 }]
  }],
  'sort': 3
}]
