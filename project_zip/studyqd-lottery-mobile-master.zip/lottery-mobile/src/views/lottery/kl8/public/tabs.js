export default [{
  playTabId: 21211,
  playTabName: '两面'
}, {
  playTabId: 21210,
  playTabName: '任选'
}]
