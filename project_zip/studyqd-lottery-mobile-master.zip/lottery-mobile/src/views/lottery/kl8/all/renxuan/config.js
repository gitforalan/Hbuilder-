// 复制自六合彩-连码
export default [{
  'playTabId': 21210,
  'playTabName': '任选',
  'playTypeList': [{
    'playTypeId': 2121010,
    'playTypeName': '一中一',
    'minChosen': 1,
    'maxChosen': 80,
    'playList': [
      { 'playId': 212101010 }
    ]
  },
  {
    'playTypeId': 2121011,
    'playTypeName': '二中二',
    'minChosen': 2,
    'maxChosen': 8,
    'playList': [
      { 'playId': 212101110 }
    ]
  },
  {
    'playTypeId': 2121012,
    'playTypeName': '三中三',
    'minChosen': 3,
    'maxChosen': 8,
    'playList': [
      { 'playId': 212101210 }
    ]
  },
  {
    'playTypeId': 2121013,
    'playTypeName': '四中四',
    'minChosen': 4,
    'maxChosen': 8,
    'playList': [
      { 'playId': 212101310 }
    ]
  },
  {
    'playTypeId': 2121014,
    'playTypeName': '五中五',
    'minChosen': 5,
    'maxChosen': 8,
    'playList': [
      { 'playId': 212101410 }
    ]
  },
  {
    'playTypeId': 2121015,
    'playTypeName': '六中六',
    'minChosen': 6,
    'maxChosen': 8,
    'playList': [
      { 'playId': 212101510 }
    ]
  },
  {
    'playTypeId': 2121016,
    'playTypeName': '七中七',
    'minChosen': 7,
    'maxChosen': 8,
    'playList': [
      { 'playId': 212101610 }
    ]
  }
  ]
}]
