import { mapState, mapMutations, mapGetters } from 'vuex'
import BetConfirm from '../../public/betConfirm'
import KL8Footer from '../../public/footer'
import typePopover from '../../public/typePopover'
import Layout from './config.js'
// import dict from '../../public/dict.js'
import * as API from 'api/wapi/front'

export default {
  name: 'ren-xuan',
  filters: {
    formatF2Y (num) {
      return (num / 100).toFixed(2)
    }
  },
  methods: {
    getLotteryPlayOdds () {
      let query = {
        playTabMode: 2,
        lotteryTypeId: 21
      }
      API.getLotteryPlayOdds(query).then(res => {
        if (res.code === 0) {
          this.layout = this.doMergeData(res.data.playTabList)
        } else {
          console.log('getLotteryPlayOdds:', res.data.desc)
        }
      })
    },
    getLotteryUserBet () {
      let query = {
        lotteryId: this.lotteryId,
        issue: this.currentIssue,
        betList: JSON.stringify(this.flattenBetList)
      }
      API.getLotteryUserBet(query).then(res => {
        if (res.code === 0) {
          this.doUnselectAll() // 清空号码
          this.updateShowBetConfirm(false) // 关闭确认投注对话
          this.$vux.toast.show({
            type: 'success',
            isShowMask: false,
            text: '下注成功',
            time: 2000
          })
        }
      }).catch(err => {
        this.$vux.toast.show({
          type: 'warn',
          isShowMask: false,
          text: err.desc,
          time: 2000
        })
        console.log('getLotteryUserBet:', err.desc)
      })
    },
    // 处理配置文件数据
    doHandleData () {
      return Layout[0].playTypeList.map(k => {
        k.isactive = 0
        k.playList.map(m => {
          m.maxPrize = 0
          m.minPrize = 0
          m.rebateRate = 0
          m.computedMaxPrize = 0
          m.isactive = false
          return m
        })
        return k
      })
    },
    // 根据接口数据，更新本地数据
    doMergeData (data) {
      let d = data.find(i => i.playTabId === 21210).playTypeList.map(i => i.playList)
      d = [].concat(...d)
      return this.layout.map(k => {
        k.playList.forEach(m => {
          let targetPlay = d.find(i => i.playId === m.playId)
          if (targetPlay) {
            m.maxPrize = targetPlay.maxPrize
            m.minPrize = targetPlay.minPrize
            m.rebateRate = targetPlay.rebateRate
            m.computedMaxPrize = targetPlay.maxPrize
          } else {
            // throw new Error(`${playId}: 玩法数据不存在`)
            console.log(`${m.playId}: 玩法数据不存在`)
          }
          return m
        })
        return k
      })
    },
    doCreatePlayData () {
      let arr = []
      for (let i = 1; i <= 80; i++) {
        let obj = { ...this.currentSubPlay.playList[0] }
        obj.name = i < 10 ? '0' + i : '' + i
        arr.push(obj)
      }
      this.playData = JSON.parse(JSON.stringify(arr))
    },
    // 设置当前玩法
    doSetCurrentSubPlay (playTypeId) {
      this.doUnselectAll() // 清空选球
      if (!playTypeId) this.currentSubPlay = this.layout[0]
      else this.currentSubPlay = this.layout.find(i => i.playTypeId === playTypeId)
      this.currentSelectMode = 1
      this.defaultSelectModeName = '单式/复式'
      this.doCreatePlayData(1)
    },
    // 选球
    doSelectBoal (item) {
      let selectedBoal = this.selectedBoal
      if (selectedBoal.length >= this.maxChosen) {
        let options = {
          type: 'warn',
          isShowMask: false,
          time: 2000
        }
        options.text = `最多只能选 ${this.maxChosen} 个`
        this.$vux.toast.show(options)
        return
      } else {
        item.isactive = 1
      }
    },
    // 取消选球
    doUnselectBoal (item) {
      if (!item.isDan) {
        item.isactive = 0
      }
    },
    // 清空选球
    doUnselectAll () {
      this.playData.forEach(j => {
        if (j.list) {
          j.list.forEach(k => {
            k.isactive = 0
            // k.money = 0
            k.isDan = false
          })
        } else {
          j.isactive = 0
          // j.money = 0
          j.isDan = false
        }

        // j.computedMaxPrize = j.maxPrize
      })
    },
    // 关闭玩法类型菜单
    onPlayMenuHide (data) {
      this.defaultPlayTypeName = data.name // 更新当前玩法菜单项名称
      this.doSetCurrentSubPlay(data.id) // 切换玩法类型
      this.updateResetRebateRateSlider(true) // 通知Footer复位返水滑动条
      this.doUpdateRebateRate(0) // 强制更新奖金赔率
    },
    // 更新奖金赔率
    doUpdateRebateRate (nval) {
      this.currentSubPlay.playList.forEach(j => {
        let max = j.maxPrize
        let diff = j.maxPrize - j.minPrize
        let t = (diff / this.maxSliderVal) * nval
        let b = (max - t).toFixed(0)
        j.computedMaxPrize = b
      })
    },
    // 根据选号模式生成投注组合
    doGenFlattenBetList (selected, minChosen, playMode) {
      let combs = this.doCalcCombination(selected, minChosen)
      return combs.map(k => {
        return {
          playId: this.currentPlayId,
          imp: 0,
          moneyUnit: 3,
          singleMoney: this.singleBetMoney * 100, // 转分
          rebateRate: this.rebateRate,
          buyCode: k.map(i => i.name).join(','),
          buyCodeFront: k.map(i => i.name).join(','), // 前端展示
          playTypeName: this.currentSubPlay.playTypeName, // 前端展示
          computedMaxPrize: this.currentPlayPrize // 前端显示
        }
      })
    },
    /**
     * 计算组合
     * @param  {Array} set 全部元素集合
     * @param  {Number} k  目标组合数
     * @return {Array}     二维数组
     *
     */
    doCalcCombination (set, k) {
      var i, j, combs, head, tailcombs
      if (k > set.length || k <= 0) return []
      if (k === set.length) return [set]
      if (k === 1) { // 递归出口
        combs = []
        for (i = 0; i < set.length; i++) {
          combs.push([set[i]])
        }
        return combs
      }
      combs = []
      for (i = 0; i < set.length - k + 1; i++) {
        head = set.slice(i, i + 1)
        tailcombs = this.doCalcCombination(set.slice(i + 1), k - 1)
        for (j = 0; j < tailcombs.length; j++) {
          combs.push(head.concat(tailcombs[j]))
        }
      }
      return combs
    },
    ...mapMutations('kl8', [
      'lhc_flattenBetList',
      'setClearNow',
      'setBetNow',
      'updateMaxSliderVal',
      'updateInputStyleFooter',
      'updateShowBetConfirm',
      'updateSelectedNumber',
      'updateMinChosen',
      'updateRebateRate',
      'updateResetRebateRateSlider'
    ])
  },
  watch: {
    currentSubPlay (nval) {
      this.updateMinChosen(nval.minChosen)
      this.maxChosen = nval.maxChosen
    },
    // 根据选择的球，拼接号码
    selectedBoal (nval) {
      this.updateSelectedNumber(nval.map(i => i.name).join(','))
    },
    // 监听当前注单，推到store保存
    flattenBetList (nval) {
      this.lhc_flattenBetList({ flattenBetList: nval })
    },
    clearNow (nval) {
      if (nval) this.doUnselectAll()
      this.setClearNow(false)
    },
    betNow (nval) {
      if (nval) {
        this.getLotteryUserBet()
        this.setBetNow(false)
      }
    },
    maxSliderVal (nval) {
      this.updateMaxSliderVal(nval)
    },
    // 监测返水，实时计算前台奖金
    rebateRate (nval) {
      this.doUpdateRebateRate(nval)
    }
  },
  computed: {
    ...mapState('kl8', [
      'playTabId',
      'playTabName',
      'clearNow',
      'singleBetMoney',
      'rebateRate',
      'betNow',
      'isShowBetConfirm'
    ]),
    ...mapGetters('common', [
      'lotteryId'
    ]),
    // 已选择的球
    selectedBoal () {
      let cMode = this.currentSelectMode
      if (cMode === 3 || cMode === 4 || cMode === 5) { // 生肖,尾数,生尾
        if (this.playData.length) {
          return this.playData.map(i => {
            let tmp = i.list.filter(j => j.isactive === 1)
            if (tmp.length) return tmp[0]
          }).filter(i => i !== undefined)
        } else {
          return []
        }
      } else {
        return this.playData.filter(i => i.isactive === 1)
      }
    },
    // 计算后的注单信息
    flattenBetList () {
      if (!this.currentSubPlay) return []
      let minChosen = this.currentSubPlay.minChosen
      let selectedBoal = this.selectedBoal
      if (selectedBoal.length < minChosen) return []
      return this.doGenFlattenBetList(selectedBoal, minChosen)
    },
    totalBetNumbers () {
      return this.flattenBetList.length
    },
    totalBetMoney () {
      let totalF = this.flattenBetList.map(i => i.singleMoney).reduce((a, b) => a + b, 0)
      return (totalF / 100).toFixed(0)
    },
    // 返水点滚动条最大百分比
    maxSliderVal () {
      if (this.layout.length) {
        return +this.currentSubPlay.playList[0].rebateRate
      }
    },
    // 玩法菜单
    playMenus () {
      if (!this.layout.length) return []
      return this.layout.map(i => ({
        name: i.playTypeName,
        id: i.playTypeId
      }))
    },
    currentPlayPrize () {
      if (this.currentSubPlay) {
        return this.currentSubPlay.playList[0].computedMaxPrize
      } else {
        return 0
      }
    },
    currentPlayId () {
      if (this.currentSubPlay) {
        return this.currentSubPlay.playList[0].playId
      }
    }
  },
  props: {
    marginTop: [Number, String],
    currentIssue: [Number, String]
  },
  data () {
    return {
      layout: [],
      currentSubPlay: null,
      defaultPlayTypeName: '一中一',
      maxChosen: 8,
      playData: [] // 动态创建的玩法数据
    }
  },
  created () {
    this.layout = this.doHandleData()
    this.doSetCurrentSubPlay()
    this.doCreatePlayData()
    // 更新底部Footer的金额选择样式 true-筹码和输入 false-只有输入
    this.updateInputStyleFooter(true)
  },
  mounted () {
    this.getLotteryPlayOdds()
  },
  components: { BetConfirm, typePopover, KL8Footer }
}
