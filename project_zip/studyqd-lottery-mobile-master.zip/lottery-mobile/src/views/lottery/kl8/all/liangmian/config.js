export default [{
  'playTabId': 21211,
  'playTabName': '两面',
  'playTypeList': [{
    'playTypeId': 2121110, // 没用
    'playTypeName': '两面',
    'playListGroup': [{
      'playListGroupName': '和值',
      'playList': [
        { 'playId': 212111010, 'name': '大' },
        { 'playId': 212111011, 'name': '小' },
        { 'playId': 212111012, 'name': '单' },
        { 'playId': 212111013, 'name': '双' },
        { 'playId': 212111014, 'name': '大单' },
        { 'playId': 212111015, 'name': '大双' },
        { 'playId': 212111016, 'name': '小单' },
        { 'playId': 212111017, 'name': '小双' }
      ]
    }, {
      'playListGroupName': '上下',
      'playList': [
        { 'playId': 212111110, 'name': '上盘' },
        { 'playId': 212111111, 'name': '和盘' },
        { 'playId': 212111112, 'name': '下盘' }
      ]
    }, {
      'playListGroupName': '奇偶',
      'playList': [
        { 'playId': 212111210, 'name': '奇盘' },
        { 'playId': 212111211, 'name': '和盘' },
        { 'playId': 212111212, 'name': '偶盘' }
      ]
    }, {
      'playListGroupName': '五行',
      'playList': [
        { 'playId': 212111310, 'name': '金' },
        { 'playId': 212111311, 'name': '木' },
        { 'playId': 212111312, 'name': '水' },
        { 'playId': 212111313, 'name': '火' },
        { 'playId': 212111314, 'name': '土' }
      ]
    }
    ]
  }]
}]
