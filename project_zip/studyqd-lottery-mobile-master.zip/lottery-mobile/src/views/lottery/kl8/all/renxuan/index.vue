<!-- Created By fx on 2017/9/19. -->
<template>
  <section class="lm-content" :style="{marginTop:marginTop+'px'}">
    <div flex="main:justify cross:center">
      <div flex-box="1" class="tips" align="center">
        <icon-svg icon-class="shou"></icon-svg>点击：筹码下注<span>长按：筹码删除</span>
      </div>
    </div>
    <div flex="main:justify" class="mid-bar">
      <div class="left" flex-box="1">
        <type-popover v-if="playMenus" :types="playMenus" :defaultValue="defaultPlayTypeName" @on-hide="onPlayMenuHide" />
      </div>
      <div class="right" flex-box="1">
        赔率: {{currentPlayPrize | formatF2Y}}
      </div>
    </div>
    <div class="lm-selector">
      <div class="content" flex="dir:left" align="center" >
        <div flex-box="0" class="credit-unit">上盘</div>
        <ul flex="main:left" class="num">
          <li v-for="(t,idx) in playData.slice(0,40)">
            <v-touch @tap="doSelectBoal(t)" @pressup="doUnselectBoal(t)">
              <span class="circle" :class="{active: t.isactive,dan:t.isDan}">
                <span>{{ t.name }}</span>
                <!-- <span class="prize">{{t.computedMaxPrize}}</span> -->
              </span>
            </v-touch>
          </li>
        </ul>
      </div>
      <!--  -->
      <div class="content" flex="dir:left" align="center" style="border-top:1px solid #eee;padding-top:10px" >
        <div flex-box="0" class="credit-unit">下盘</div>
        <ul flex="main:left" class="num">
          <li v-for="(t,idx) in playData.slice(40)">
            <v-touch @tap="doSelectBoal(t)" @pressup="doUnselectBoal(t)">
              <span class="circle" :class="{active: t.isactive,dan:t.isDan}">
                <span>{{ t.name }}</span>
                <!-- <span class="prize">{{t.computedMaxPrize}}</span> -->
              </span>
            </v-touch>
          </li>
        </ul>
      </div>
    </div>
    <!-- 下注确认 -->
    <BetConfirm v-if="isShowBetConfirm" :top="marginTop" />
    <!-- 底部 -->
    <KL8Footer/>
  </section>
</template>

<script src="./script.js"></script>
<style scoped lang="stylus" src="./style.styl"></style>
