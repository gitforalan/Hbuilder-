<!--
  -- 加 token验证
  -- @fx
  -->
<template>
  <!--<keep-alive>-->
  <component :is="currentView" v-if="currentView">
    <!-- 非活动组件将被缓存！ -->
  </component>
  <!--</keep-alive>-->
</template>

<script type="text/ecmascript-6">
  import Vue from 'vue'
  import { mapState, mapMutations, mapActions } from 'vuex'
  import { cookie } from 'vux'
  // API
  import * as API from 'api/wapi/front'
  // 组件
  import Comps from './lotteryComps'
  // 彩种类型
  import TYPE_NAME from '@/config/lottery/typeName'
  // 全局组件
  import CurrentInfo from 'views/common/currentInfo/' // 彩期模块
  import PopoverPage from 'views/common/popoverPage/' // 弹出页模块
  import BetCart from 'views/common/betCart/index.vue' // 购票车模块
  // 注册Lottery下的全局组件
  Vue.component(CurrentInfo.name, CurrentInfo) // 彩期
  Vue.component(PopoverPage.name, PopoverPage) // 弹出页
  Vue.component(BetCart.name, BetCart) // 购票车

  export default {
    data () {
      return {
        currentView: null
      }
    },
    components: Comps,
    computed: {
      ...mapState('common', {
        lotteryTypeId: state => state.lotteryTypeId,
        lotteryId: state => state.lotteryId
      })
    },
    methods: {
      // 验证接口
      UserAuthValidate () {
        const userInfo = {}
        if (!cookie.get('token')) { // 这里优先取url带过来的token todo
          userInfo.status = 0
          this.update_userInfo(userInfo)
          this.$nextTick(() => {
            this.$router.push({ name: 'login' }) // 关闭登录验证
          })
          return
        }
        // loading
        this.$vux.loading.show()
        API.getUserAuthValidate().then(res => {
          // fields {"uid":String","loginId": String,"balance":int}
          const userInfo = res.data
          userInfo.status = 1
          this.update_userInfo(userInfo)
          this.updateCurrrentView()
        }).catch(err => {
          userInfo.status = 0
          this.update_userInfo(userInfo)
          this.$vux.toast.show({
            type: 'warn',
            text: err.desc,
            time: 3000
          })
          this.$router.push({ name: 'login' })
        }).then(() => {
          setTimeout(this.$vux.loading.hide, 300)
        })
      },
      updateCurrrentView () {
        let sId = this.$route.params.sid                  // 根据参数判断显示哪个模板
        if (parseInt(sId) || sId === '0') {                 // 字符串number转number 并返回前两位
          this.com_lotteryId({ lotteryId: parseInt(sId) }) // 存 lotteryId
          sId = this.getTypeId(sId)                         // 转成 lotteryTypeId
          this.com_lotteryTypeId({ lotteryTypeId: sId })   // 存 lotteryTypeId
        }
        switch (sId) {
          case TYPE_NAME.SSC: // 时时彩
            this.currentView = Comps.Ssc
            break
          case TYPE_NAME.KSAN: // 快三
            this.currentView = Comps.Ksan
            break
          case TYPE_NAME.SYX5: // 11选5
            this.currentView = Comps.Syx5
            break
          case TYPE_NAME.SSL: // 时时乐
            this.currentView = Comps.Ssl
            break
          case TYPE_NAME.PL3: // 排列三
            this.currentView = Comps.Pl3
            break
          case TYPE_NAME.FC3D: // 福彩3D
            this.currentView = Comps.Fc3d
            break
          case TYPE_NAME.PK10: // pk拾
            this.currentView = Comps.Pk10
            break
          case TYPE_NAME.LHC: // 六合彩
            this.currentView = Comps.Lhc
            break
          case TYPE_NAME.PCDD: // pc蛋蛋
            this.currentView = Comps.Pcdd
            break
          case TYPE_NAME.KL8: // 快乐8
            this.currentView = Comps.Kl8
            break
          case TYPE_NAME.KLSF: // 快乐十分
            this.currentView = Comps.Kl10
            break
          case 'orderList':
            this.currentView = Comps.OrderList // 投注记录
            break
          case 'smartOrder':
            this.currentView = Comps.SmartOrder
            break
//          case 'betCart':
//            this.currentView = Comps.BetCart
//            break
//          case 'lhcBetCart':
//            this.currentView = Comps.LhcBetCart
//            break
//          case 'betDetail':
//            this.currentView = Comps.OrderDetail
//            break
          case 'betInput':
            this.currentView = Comps.BetInput
            break
          case 'yydb':
            const link = window.LINK_YYDB
            const spCode = cookie.get('sn')
            const token = cookie.get('token')
            const homeUrl = window.location.host + window.location.pathname
            this.$router.replace({ name: 'home' })
            window.location.href = link + `?spCode=${spCode}&token=${token}&homeUrl=${homeUrl}`
            break
          default:
            this.currentView = null
            this.$router.replace({ name: 'Err404' }) // 匹配不到 跳转到 404
        }
      },
      getTypeId (sid) {
        return parseInt(sid.toString().slice(0, 2))
      },
      ...mapMutations('common', ['update_userInfo', 'com_lotteryTypeId', 'com_lotteryId']),
      ...mapActions('common', ['resetCommonState'])
    },
    created () {
      this.UserAuthValidate() // 验证token
    },
    watch: {
      $route (to, from) {
        // 非彩种页切换时 不清store
        if (!isNaN(parseInt(to.params.sid)) && !isNaN(parseInt(from.params.sid))) {
          this.resetCommonState() // 清空store
          // this.destroy()
        }
        this.updateCurrrentView()
      }
    },
    beforeDestroy () {
      this.resetCommonState() // 清空store
      // debugger
    }
  }
</script>

<style scoped></style>
