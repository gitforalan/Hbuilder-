/**
 * Created by fx on 2017/10/11.
 */

import commonEd from '../../public/mixin'

export default {
  name: 'zhengHe',
  mixins: [commonEd],
  data () {
    return {
      splitColNum: [11, 11, 11, 11, 11, 3] // 切片个数
    }
  },
  methods: {
    _creditLayoutData () {
      // const cols = 6
      if (this.creditLayoutData) {
        for (let i = 0, len = this.creditLayoutData.length - 1; i < len; i++) {
          let playList = this.creditLayoutData[i].playList
          playList[0].push({ empty: true }) // flex模板占位用
          let digitArr = playList[0]
          playList.splice(0, 1, ...this.chunkArray(digitArr, digitArr.length >> 1)) // 数字球分两行
        }
      }
      return this.creditLayoutData
    }
  },
  created () {
    this.creditLayoutData = this._creditLayoutData()
  }
}
