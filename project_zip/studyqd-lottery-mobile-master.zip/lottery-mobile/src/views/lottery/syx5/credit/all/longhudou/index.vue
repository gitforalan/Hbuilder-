<template>
  <section class="lm-content">
    <div class="lm-selector">
      <!-- 提示 -->
      <tips></tips>
      <!-- 选号 -->
      <div flex="box:mean main:right">
        <div class="area-left">
          <template v-for="(row, ri) in creditLayoutData" v-if="ri % 2 === 0">
            <div v-for="(subRow, sri) in row.playList" class="credit-wrap">
              <div class="credit-con">
                <p class="title">{{ row.playTypeName }}</p>
                <ul flex="main:center">
                  <v-touch
                    tag="li"
                    v-for="(play, index) in subRow"
                    @tap="doSelectBoal(play,1)"
                    @pressup="doSelectBoal(play,0)"

                    :key="index"
                    :class="{active: play.isactive}">
                  <span>
                    <div>{{ play.playName }}</div>
                    <div class="rebate-text">赔 {{ play.computedMaxPrize | formatF2Y }}</div>
                    <p class="bet-pop" :class="{'rect':play.money > 9999}">{{ play.money }}</p>
                  </span>
                  </v-touch>
                </ul>
              </div>
            </div>
          </template>
        </div>
        <div class="area-right">
          <template v-for="(row, ri) in creditLayoutData" v-if="ri % 2 !== 0">
            <div v-for="(subRow, sri) in row.playList" class="credit-wrap">
              <div class="credit-con">
                <p class="title">{{ row.playTypeName }}</p>
                <ul flex="main:center">
                  <v-touch
                    tag="li"
                    v-for="(play, index) in subRow"
                    @tap="doSelectBoal(play,1)"
                    @pressup="doSelectBoal(play,0)"

                    :key="index"
                    :class="{active: play.isactive}">
                  <span>
                    <div>{{ play.playName }}</div>
                    <div class="rebate-text">赔 {{ play.computedMaxPrize | formatF2Y }}</div>
                    <p class="bet-pop">{{ play.money }}</p>
                  </span>
                  </v-touch>
                </ul>
              </div>
            </div>
          </template>
        </div>
      </div>
    </div>

    <!--底部区域-->
    <cfooter></cfooter>
  </section>
</template>

<script type="text/ecmascript-6">
  import ed from './script'

  export default ed
</script>

<style scoped lang="stylus">
  @import './style.styl'
</style>
