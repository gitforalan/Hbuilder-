<template>
  <section class="lm-content">
    <div class="lm-selector">
      <!-- 提示 -->
      <tips></tips>
      <!-- 选号 -->
      <template v-for="(row, ri) in creditLayoutData">
        <div class="tag-top" flex="">
          <div flex-box="1" class="tag-line line-down line-top">
            <span>赔 {{ row.playList[0][0].computedMaxPrize | formatF2Y }}</span>
          </div>
        </div>
        <div v-for="(subRow, sri) in row.playList" class="credit-wrap">
          <div class="credit-con">
            <ul flex="box:mean">
              <template v-for="(play, index) in subRow">
                <v-touch
                  v-if="!play.hasOwnProperty('empty')"
                  tag="li"
                  @tap="doSelectBoal(play,1)"
                  @pressup="doSelectBoal(play,0)"

                  :key="index"
                  :class="{active: play.isactive}"
                  style="height:100%">
                  <span>{{ play.playName }}</span>
                  <p class="bet-pop" :class="{'rect':play.money > 9999}">{{ play.money }}</p>
                </v-touch>
                <li v-else></li>
              </template>
            </ul>
          </div>
        </div>
        <div class="tag-bottom" flex="">
          <div flex-box="1" class="tag-line line-down line-top">
            <span>赔 {{ row.playList[0][0].computedMaxPrize | formatF2Y }}</span>
          </div>
        </div>
      </template>
    </div>

    <!--底部区域-->
    <cfooter></cfooter>
  </section>
</template>

<script type="text/ecmascript-6">
  import ed from './script'

  export default ed
</script>

<style scoped lang="stylus">
  @import './style.styl'
</style>
