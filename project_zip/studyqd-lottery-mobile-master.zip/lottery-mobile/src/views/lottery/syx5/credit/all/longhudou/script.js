/**
 * Created by fx on 2017/10/11.
 */
import commonEd from '../../public/mixin'

export default {
  name: 'longHuDou',
  mixins: [commonEd],
  data () {
    return {
      splitColNum: [2, 2, 2, 2, 2, 2, 2, 2, 2, 2] // 切片个数 Array(10).fill(2),
    }
  }
}
