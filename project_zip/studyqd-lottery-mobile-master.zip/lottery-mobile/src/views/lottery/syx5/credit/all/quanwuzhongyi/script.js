/**
 * Created by fx on 2017/10/11.
 */
import commonEd from '../../public/mixin'

export default {
  name: 'quanWuZhongYi',
  mixins: [commonEd],
  data () {
    return {
      splitColNum: [5, 5, 5] // 切片个数
    }
  },
  methods: {
    _creditLayoutData () {
      const emptyCols = Array.apply(null, { length: 4 }).map(item => (item = { empty: true }))
      this.creditLayoutData[0].playList[2].push(...emptyCols)
      return this.creditLayoutData
    }
  },
  created () {
    this.creditLayoutData = this._creditLayoutData()
  }
}

