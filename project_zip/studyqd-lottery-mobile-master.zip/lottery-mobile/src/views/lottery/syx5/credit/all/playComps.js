/**
 * Created by fx on 2017/8/28.
 */
const filePath = 'lottery/syx5/credit/'
// 分包
const hotLoad = require('@/utils/import_' + process.env.NODE_ENV)
const ZhengHe = hotLoad(filePath + 'all/zhenghe/index')
const QuanWuZhongYi = hotLoad(filePath + 'all/quanwuzhongyi/index')
const LongHuDou = hotLoad(filePath + 'all/longhudou/index')

export default {
  ZhengHe,
  QuanWuZhongYi,
  LongHuDou
}
