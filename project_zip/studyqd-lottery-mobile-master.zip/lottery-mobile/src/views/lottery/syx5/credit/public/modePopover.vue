<template>
  <ul v-click-outside="onClickedOutside" class="z-popover" align="center">
    <li v-for="(item, index) in modes" @click="doSelectMoney(item)" :class="{active:item==value}">
      <p> {{ item }}</p>
    </li>
  </ul>
</template>

<script type="text/ecmascript-6">
import ClickOutside from 'vux/src/directives/click-outside'

const modesData = [5, 10, 20, 50, 100, 200, 500, 1000].reverse()
export default {
  name: 'modePopover',
  data () {
    return {
      modes: modesData
    }
  },
  props: {
    value: Number,
    show: Boolean
  },
  computed: {},
  methods: {
    onClickedOutside () {
      if (this.show) {
        this.$emit('on-hide', this.value)
      }
    },
    doSelectMoney (money) {
      this.$emit('on-hide', money)
    }
  },
  directives: {
    ClickOutside
  },
  created () { }
}
</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"
  ul.z-popover
    min-width rem(126)
    background-color rgba(0, 0, 0, .7)
    border-radius 10px
    position absolute
    bottom 100%
    left 50%
    transform translateX(-50%)
    li
      width 100%
      height rem(55)
      line-height rem(55)
      font-size rem(28)
      color $color-white
      &:first-child
        border-top-left-radius 4px
        border-top-right-radius 4px
      &:last-child
        border-bottom-left-radius 10px
        border-bottom-right-radius 10px
      &.active
        background $color-red
        color: $color-white
        p
          border-bottom 0
      &.prev p
        border-bottom 0
      &:last-child
        p
          border-bottom none
      p
        margin 0 rem(9)
        border-bottom 1px solid $color-white
        box-sizing border-box
      &:first-child
        border-top-left-radius 4px
        border-top-right-radius 4px
      &:last-child
        border-bottom-left-radius 10px
        border-bottom-right-radius 10px
    &:before
      content ""
      border-color rgba(0, 0, 0, .7) transparent
      border-style solid
      display block
      height 0
      font-size 0
      line-height 0
      width 0
      border-width 0 .75rem .75rem
      position absolute
      z-index 12
      bottom -.74rem
      left 50%
      transform translate3D(-50%, 0, 0) rotate(180deg)
      zoom 12

    &.right:before
      transform translate3D(10%, 0, 0) rotate(180deg)

    &.left:before
      transform translate3D(-90%, 0, 0) rotate(180deg)

</style>
