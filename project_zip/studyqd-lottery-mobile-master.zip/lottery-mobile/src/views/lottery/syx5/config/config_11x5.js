export default {
  /*  后三直选  */
  // 后三直选复式
  111101410: {
    alias: 'ZX3',
    selectarea: {
      type: 'digital',
      hcltPosition: [2, 3, 4],
      layout: [{
        title: '第三位',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1
      }, {
        title: '第四位',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 1,
        cols: 1
      }, {
        title: '第五位',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 2,
        cols: 1
      }],
      noBigIndex: 6,
      isButton: true
    }
  },
  // 后三直选单式
  111101411: {
    alias: 'ZX3',
    selectarea: {
      type: 'input'
    }
  },

  /* 后三组选 */
  // 后三组选
  111101510: {
    alias: 'ZU3',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '复式',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1,
        minchosen: 3
      }],
      noBigIndex: 6,
      isButton: true
    }
  },
  // 组选单式
  111101511: {
    alias: 'ZX3',
    selectarea: {
      type: 'input'
    }
  },

  // 后三组选胆拖
  111101512: {
    alias: 'DT3',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '胆码',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 1,
        cols: 1
      }, {
        title: '拖码',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1
      }],
      noBigIndex: 6,
      isButton: false
    }
  },
  /* 中三直选 */
  // 直选复式
  111101210: {
    alias: 'ZX3',
    selectarea: {
      type: 'digital',
      hcltPosition: [1, 2, 3],
      layout: [{
        title: '第二位',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1
      }, {
        title: '第三位',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 1,
        cols: 1
      }, {
        title: '第四位',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 2,
        cols: 1
      }],
      noBigIndex: 6,
      isButton: true
    }
  },
  // 直选单式
  111101211: {
    alias: 'ZX3',
    selectarea: {
      type: 'input'
    }
  },

  /* 中三组选 */
  // 组选
  111101310: {
    alias: 'ZU3',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '复式',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1,
        minchosen: 3
      }],
      noBigIndex: 6,
      isButton: true
    }
  },
  // 组选单式
  111101311: {
    alias: 'ZX3',
    selectarea: {
      type: 'input'
    }
  },

  // 中三组选胆拖
  111101312: {
    alias: 'DT3',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '胆码',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1
      }, {
        title: '拖码',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 1,
        cols: 1
      }],
      noBigIndex: 6,
      isButton: false
    }
  },
  /* 前三直选 */
  // 直选复式
  111101010: {
    alias: 'ZX3',
    selectarea: {
      type: 'digital',
      hcltPosition: [0, 1, 2],
      layout: [{
        title: '第一位',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1
      }, {
        title: '第二位',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 1,
        cols: 1
      }, {
        title: '第三位',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 2,
        cols: 1
      }],
      noBigIndex: 6,
      isButton: true
    }
  },
  // 直选单式
  111101011: {
    alias: 'ZX3',
    selectarea: {
      type: 'input'
    }
  },

  /* 前三组选 */
  // 组选
  111101110: {
    alias: 'ZU3',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '复式',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1,
        minchosen: 3
      }],
      noBigIndex: 6,
      isButton: true
    }
  },
  // 组选单式
  111101111: {
    alias: 'ZX3',
    selectarea: {
      type: 'input'
    }
  },

  // 前三组选胆拖
  111101112: {
    alias: 'DT3',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '胆码',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1
      }, {
        title: '拖码',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 1,
        cols: 1
      }],
      noBigIndex: 6,
      isButton: false
    }
  },

  /* 前二直选 */
  // 直选复式
  111111010: {
    alias: 'ZX2',
    selectarea: {
      type: 'digital',
      hcltPosition: [0, 1],
      layout: [{
        title: '第一位',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1
      }, {
        title: '第二位',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 1,
        cols: 1
      }],
      noBigIndex: 6,
      isButton: true
    }
  },
  // 直选单式
  111111011: {
    alias: 'ZX2',
    selectarea: {
      type: 'input'
    }
  },
  /* 前二组选 */
  // 组选复式
  111111110: {
    alias: 'ZU2',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '组选',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1,
        minchosen: 2
      }],
      noBigIndex: 6,
      isButton: true
    }
  },
  // 组选单式
  111111111: {
    alias: 'ZX2',
    selectarea: {
      type: 'input'
    }
  },
  // 组选胆拖
  111111112: {
    alias: 'DT2',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '胆码',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1
      }, {
        title: '拖码',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 1,
        cols: 1
      }],
      noBigIndex: 6,
      isButton: false
    }
  },
  /* 后二直选 */
  // 直选复式
  111111210: {
    alias: 'ZX2',
    selectarea: {
      type: 'digital',
      hcltPosition: [3, 4],
      layout: [{
        title: '第四位',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1
      }, {
        title: '第五位',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 1,
        cols: 1
      }],
      noBigIndex: 6,
      isButton: true
    }
  },
  // 直选单式
  111111211: {
    alias: 'ZX2',
    selectarea: {
      type: 'input'
    }
  },
  /* 后二组选 */
  // 组选复式
  111111310: {
    alias: 'ZU2',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '组选',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1,
        minchosen: 2
      }],
      noBigIndex: 6,
      isButton: true
    }
  },
  // 组选单式
  111111311: {
    alias: 'ZX2',
    selectarea: {
      type: 'input'
    }
  },
  // 组选胆拖
  111111312: {
    alias: 'DT2',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '胆码',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1
      }, {
        title: '拖码',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 1,
        cols: 1
      }],
      noBigIndex: 6,
      isButton: false
    }
  },

  /* 定位胆 */
  111131010: {
    alias: 'DWD',
    selectarea: {
      type: 'digital',
      hcltPosition: [0, 1, 2, 3, 4],
      layout: [{
        title: '第一位',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1
      }, {
        title: '第二位',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 1,
        cols: 1
      }, {
        title: '第三位',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 2,
        cols: 1
      }, {
        title: '第四位',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 3,
        cols: 1
      }, {
        title: '第五位',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 4,
        cols: 1
      }],
      noBigIndex: 6,
      isButton: true
    }
  },

  /* 不定位前三 */
  // 一码不定位
  111121010: {
    alias: 'BDW',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '前三',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1,
        minchosen: 1
      }],
      noBigIndex: 6,
      isButton: true
    }
  },
  /* 不定位中三 */
  // 一码不定位
  111121011: {
    alias: 'BDW',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '中三',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1,
        minchosen: 1
      }],
      noBigIndex: 6,
      isButton: true
    }
  },
  /* 不定位后三 */
  // 一码不定位
  111121012: {
    alias: 'BDW',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '后三',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1,
        minchosen: 1
      }],
      noBigIndex: 6,
      isButton: true
    }
  },
  // 任选复式
  111141017: {
    alias: 'RX8',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '任选八中五',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1,
        minchosen: 8
      }],
      noBigIndex: 6,
      isButton: true
    }
  },
  111141016: {
    alias: 'RX7',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '任选七中五',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1,
        minchosen: 7
      }],
      noBigIndex: 6,
      isButton: true
    }
  },
  111141015: {
    alias: 'RX6',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '任选六中五',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1,
        minchosen: 6
      }],
      noBigIndex: 6,
      isButton: true
    }
  },
  111141014: {
    alias: 'RX5',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '任选五中五',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1,
        minchosen: 5
      }],
      noBigIndex: 6,
      isButton: true
    }
  },
  111141013: {
    alias: 'RX4',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '任选四中四',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1,
        minchosen: 4
      }],
      noBigIndex: 6,
      isButton: true
    }
  },
  111141012: {
    alias: 'RX3',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '任选三中三',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1,
        minchosen: 3
      }],
      noBigIndex: 6,
      isButton: true
    }
  },
  111141011: {
    alias: 'RX2',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '任选二中二',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1,
        minchosen: 2
      }],
      noBigIndex: 6,
      isButton: true
    }
  },
  111141010: {
    alias: 'RX1',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '任选一中一',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1,
        minchosen: 1
      }],
      noBigIndex: 6,
      isButton: true
    }
  },
  // 任选单式
  111151010: {
    alias: 'RX1',
    selectarea: {
      type: 'input'
    }
  },
  111151011: {
    alias: 'RX2',
    selectarea: {
      type: 'input'
    }
  },
  111151012: {
    alias: 'RX3',
    selectarea: {
      type: 'input'
    }
  },
  111151013: {
    alias: 'RX4',
    selectarea: {
      type: 'input'
    }
  },
  111151014: {
    alias: 'RX5',
    selectarea: {
      type: 'input'
    }
  },
  111151015: {
    alias: 'RX6',
    selectarea: {
      type: 'input'
    }
  },
  111151016: {
    alias: 'RX7',
    selectarea: {
      type: 'input'
    }
  },
  111151017: {
    alias: 'RX8',
    selectarea: {
      type: 'input'
    }
  },
  // 任选胆拖
  111161016: {
    alias: 'DT8',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '胆码',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1
      }, {
        title: '拖码',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 1,
        cols: 1
      }],
      noBigIndex: 6,
      isButton: false
    }
  },
  111161015: {
    alias: 'DT7',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '胆码',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1
      }, {
        title: '拖码',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 1,
        cols: 1
      }],
      noBigIndex: 6,
      isButton: false
    }
  },
  111161014: {
    alias: 'DT6',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '胆码',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1
      }, {
        title: '拖码',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 1,
        cols: 1
      }],
      noBigIndex: 6,
      isButton: false
    }
  },
  111161013: {
    alias: 'DT5',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '胆码',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1
      }, {
        title: '拖码',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 1,
        cols: 1
      }],
      noBigIndex: 6,
      isButton: false
    }
  },
  111161012: {
    alias: 'DT4',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '胆码',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1
      }, {
        title: '拖码',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 1,
        cols: 1
      }],
      noBigIndex: 6,
      isButton: false
    }
  },
  111161011: {
    alias: 'DT3',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '胆码',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1
      }, {
        title: '拖码',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 1,
        cols: 1
      }],
      noBigIndex: 6,
      isButton: false
    }
  },
  111161010: {
    alias: 'DT2',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '胆码',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 0,
        cols: 1
      }, {
        title: '拖码',
        no: '01|02|03|04|05|06|07|08|09|10|11',
        place: 1,
        cols: 1
      }],
      noBigIndex: 6,
      isButton: false
    }
  },
  // 趣味玩法
  // 猜中位
  111171017: {
    alias: 'CZW',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '猜中位',
        no: '03|04|05|06|07|08|09',
        place: 0,
        cols: 1
      }],
      isButton: false
    }
  },
  // 定单双
  111171010: {
    alias: 'DDS',
    selectarea: {
      type: 'digital',
      layout: [{
        title: '定单双',
        no: '0单5双|1单4双|2单3双|3单2双|4单1双|5单0双',
        place: 0,
        cols: 1
      }],
      isButton: false
    }
  }

}
