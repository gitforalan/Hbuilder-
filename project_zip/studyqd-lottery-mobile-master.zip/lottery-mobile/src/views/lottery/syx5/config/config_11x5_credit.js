/* eslint-disable */
export default [{
    'playTabName': '整合',
    'playTabId': 11210,
    'playTypeList': [{
        'playTypeId': 1121010,
        'playTypeName': '第一球',
        'playList': [{
          'playId': 112101011
        }, {
          'playId': 112101012
        }, {
          'playId': 112101013
        }, {
          'playId': 112101014
        }, {
          'playId': 112101015
        }, {
          'playId': 112101016
        }, {
          'playId': 112101017
        }, {
          'playId': 112101018
        }, {
          'playId': 112101019
        }, {
          'playId': 112101020
        }, {
          'playId': 112101021
        }, {
          'playId': 112101022
        }, {
          'playId': 112101023
        }, {
          'playId': 112101024
        }, {
          'playId': 112101025
        }]
      },
      {
        'playTypeId': 1121011,
        'playTypeName': '第二球',
        'playList': [{
          'playId': 112101111
        }, {
          'playId': 112101112
        }, {
          'playId': 112101113
        }, {
          'playId': 112101114
        }, {
          'playId': 112101115
        }, {
          'playId': 112101116
        }, {
          'playId': 112101117
        }, {
          'playId': 112101118
        }, {
          'playId': 112101119
        }, {
          'playId': 112101120
        }, {
          'playId': 112101121
        }, {
          'playId': 112101122
        }, {
          'playId': 112101123
        }, {
          'playId': 112101124
        }, {
          'playId': 112101125
        }]
      },
      {
        'playTypeId': 1121012,
        'playTypeName': '第三球',
        'playList': [{
          'playId': 112101211
        }, {
          'playId': 112101212
        }, {
          'playId': 112101213
        }, {
          'playId': 112101214
        }, {
          'playId': 112101215
        }, {
          'playId': 112101216
        }, {
          'playId': 112101217
        }, {
          'playId': 112101218
        }, {
          'playId': 112101219
        }, {
          'playId': 112101220
        }, {
          'playId': 112101221
        }, {
          'playId': 112101222
        }, {
          'playId': 112101223
        }, {
          'playId': 112101224
        }, {
          'playId': 112101225
        }]
      },
      {
        'playTypeId': 1121013,
        'playTypeName': '第四球',
        'playList': [{
          'playId': 112101311
        }, {
          'playId': 112101312
        }, {
          'playId': 112101313
        }, {
          'playId': 112101314
        }, {
          'playId': 112101315
        }, {
          'playId': 112101316
        }, {
          'playId': 112101317
        }, {
          'playId': 112101318
        }, {
          'playId': 112101319
        }, {
          'playId': 112101320
        }, {
          'playId': 112101321
        }, {
          'playId': 112101322
        }, {
          'playId': 112101323
        }, {
          'playId': 112101324
        }, {
          'playId': 112101325
        }]
      },
      {
        'playTypeId': 1121014,
        'playTypeName': '第五球',
        'playList': [{
          'playId': 112101411
        }, {
          'playId': 112101412
        }, {
          'playId': 112101413
        }, {
          'playId': 112101414
        }, {
          'playId': 112101415
        }, {
          'playId': 112101416
        }, {
          'playId': 112101417
        }, {
          'playId': 112101418
        }, {
          'playId': 112101419
        }, {
          'playId': 112101420
        }, {
          'playId': 112101421
        }, {
          'playId': 112101422
        }, {
          'playId': 112101423
        }, {
          'playId': 112101424
        }, {
          'playId': 112101425
        }]
      }, {
        'playTypeId': 1121015,
        'playTypeName': '总和',
        'playList': [{
          'playId': 112101510
        }, {
          'playId': 112101511
        }, {
          'playId': 112101512
        }, {
          'playId': 112101513
        }, {
          'playId': 112101514
        }, {
          'playId': 112101515
        }]
      }
    ]
  },
  {
    'playTabName': '龙虎斗',
    'playTabId': 11211,
    'playTypeList': [{
        'playTypeName': '第一球VS第二球',
        'playTypeId': 1121110,
        'playList': [{
          'playId': 112111010
        }, {
          'playId': 112111011
        }]
      },
      {
        'playTypeId': 1121111,
        'playTypeName': '第一球VS第三球',
        'playList': [{
          'playId': 112111110
        }, {
          'playId': 112111111
        }]
      },
      {
        'playTypeId': 1121112,
        'playTypeName': '第一球VS第四球',
        'playList': [{
          'playId': 112111210
        }, {
          'playId': 112111211
        }]
      },
      {
        'playTypeId': 1121113,
        'playTypeName': '第一球VS第五球',
        'playList': [{
          'playId': 112111310
        }, {
          'playId': 112111311
        }]
      },
      {
        'playTypeId': 1121114,
        'playTypeName': '第二球VS第三球',
        'playList': [{
          'playId': 112111410
        }, {
          'playId': 112111411
        }]
      },
      {
        'playTypeId': 1121115,
        'playTypeName': '第二球VS第四球',
        'playList': [{
          'playId': 112111510
        }, {
          'playId': 112111511
        }]
      },
      {
        'playTypeId': 1121116,
        'playTypeName': '第二球VS第五球',
        'playList': [{
          'playId': 112111610
        }, {
          'playId': 112111611
        }]
      },
      {
        'playTypeId': 1121117,
        'playTypeName': '第三球VS第四球',
        'playList': [{
          'playId': 112111710
        }, {
          'playId': 112111711
        }]
      },
      {
        'playTypeId': 1121118,
        'playTypeName': '第三球VS第五球',
        'playList': [{
          'playId': 112111810
        }, {
          'playId': 112111811
        }]
      },
      {
        'playTypeId': 1121119,
        'playTypeName': '第四球VS第五球',
        'playList': [{
          'playId': 112111910
        }, {
          'playId': 112111911
        }]
      }
    ]
  },
  {
    'playTabName': '全5中1',
    'playTabId': 11212,
    'playTypeList': [{
      'playTypeId': 1121210,
      'playTypeName': '全5中1',
      'playList': [{
        'playId': 112121010
      }, {
        'playId': 112121011
      }, {
        'playId': 112121012
      }, {
        'playId': 112121013
      }, {
        'playId': 112121014
      }, {
        'playId': 112121015
      }, {
        'playId': 112121016
      }, {
        'playId': 112121017
      }, {
        'playId': 112121018
      }, {
        'playId': 112121019
      }, {
        'playId': 112121020
      }]
    }]
  }
]
