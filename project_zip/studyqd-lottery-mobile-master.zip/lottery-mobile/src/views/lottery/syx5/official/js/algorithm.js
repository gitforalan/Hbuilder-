/* eslint-disable */
import { accMul, Combination, getCombination } from '@/utils/lotteryUtil.js'
import each from 'lodash/each'

export default {
  /* 计算实时注数 */
  calcNumber () {
    let loType = this.layoutType
    if (loType == 'input') {
      this._input_deal()
      this.betNumber = this.checkInputNum()
    } else {
      this.betNumber = this.checkSelectedNum()
    }
    return this.betNumber
  },
  // 输入号码合法性检测
  _input_deal () { // all the original input in here
    // debugger
    var s = this.currentLayout
    var methodname = this.currentPlay.alias
    
    let quanjiao = (obj) => {
      if (obj.length > 0) {
        for (var i = obj.length - 1; i >= 0; i--) {
          let unicode = obj.charCodeAt(i)
          if (unicode > 65280 && unicode < 65375) {
            this.$common.toast('不能输入全角字符，请输入半角字符', 'warning')
            s = obj.substr(0, i)
          }
        }
      }
    }
    quanjiao(s)
    // s = s.replace(/[^\s\r,;，；　０１２３４５６７８９0-9]/g, "").trim();
    s = s.replace(/[^\s\r,;，；　０１２３４５６７８９0-9]/g, '')
    this.currentLayout = s
    // var m = s;
    switch (methodname) {
      default:
        s = s.replace(/[\s\r,;，；　]/g, '|').replace(/(\|)+/g, '|')
        break
    }
    s = s.replace(/０/g, '0')
      .replace(/１/g, '1')
      .replace(/２/g, '2')
      .replace(/３/g, '3')
      .replace(/４/g, '4')
      .replace(/５/g, '5')
      .replace(/６/g, '6')
      .replace(/７/g, '7')
      .replace(/８/g, '8')
      .replace(/９/g, '9')
    if (s == '') {
      this.currentLayout = '' // 清空数据
      this.allInputCode[0] = ''
    } else {
      this.allInputCode[0] = s.split('|')
    }
    // return m;
  },
  
  /**
   * 号码检测
   * @param  {Number} l     [号码长度]
   * @param  {Boolean} e    [是否返回非法号码，true是,false返回合法注数]
   * @param  {Function} fun [对每个号码的附加检测]
   * @param  {Boolean} sort [是否对每个号码排序]
   * @return {Number}
   * 注意：这个函数有一个额外的作用，记录了当前输入的合法和不合法的号码
   */
  _inputCheck_Num (l, e, fun, sort) {
    var data_sel = this.allInputCode
    var nums = data_sel[0].length
    var error = []
    var newsel = []
    var partn = ''
    
    l = parseInt(l, 10)
    // debugger
    switch (l) {
      case 2:
        partn = /^[0-9]{2}$/
        break
      case 4:
        partn = /^[0-9]{4}$/
        break
      case 6:
        partn = /^[0-9]{6}$/
        break
      case 8:
        partn = /^[0-9]{8}$/
        break
      case 10:
        partn = /^[0-9]{10}$/
        break
      case 12:
        partn = /^[0-9]{12}$/
        break
      case 14:
        partn = /^[0-9]{14}$/
        break
      case 16:
        partn = /^[0-9]{16}$/
        break
      default:
        partn = /^[0-9]{3}$/
        break
    }
    
    var _this = this
    each(data_sel[0], function(n, i) {
      n = n.trim()
      if (partn.test(n)) { // 位数合格号码
        if (_this._CheckNum(n)) { // 校验号码
          data_sel[0][i] = n
          newsel.push(n)
        } else { // 号码不合格则注数减
          error.push(n)
          nums = nums - 1
        }
      } else { // 位数不合格则注数减
        error.push(n)
        nums = nums - 1
      }
    })
    // 保存临时数据，
    // 下注时，直接提交有效号码
    _this.validInputCode = [].concat(newsel)
    _this.invalidInputCode = [].concat(error)
    return nums
  },
  _CheckNum (n) { // 检测单注输入号码是否重复
    let tmp = []
    for (let i = 0; i < n.length / 2; i++) {
      let a = n.substr(i * 2, 2)
      if (a > 11 || a <= 0) {
        return false
      }
      if (tmp.includes(a)) {
        return false
      }
      tmp.push(a)
    }
    return true
  },
  // 根据玩法，返回注数
  checkInputNum () {
    let tmp_nums = 1
    let mname = this.currentPlay.alias
    let data_sel = this.allInputCode
    let max_place = this.maxPlace
    let minchosen = this.minChosen
    // debugger
    
    /** ******** 根据玩法返回注数 ***********/
    if (data_sel[0].length > 0) { // 如果输入的有值
      switch (mname) {
        case 'ZX3': // 前中后三码，单组选，单式
          return this._inputCheck_Num(6, false)
          break
        case 'ZX2': // 前中后二码，单组选，单式
          return this._inputCheck_Num(4, false)
          break
        case 'RX1':
          /* 以下是任选单式 */
          return this._inputCheck_Num(2, false)
          break
        case 'RX2':
          return this._inputCheck_Num(4, false)
          break
        case 'RX3':
          return this._inputCheck_Num(6, false)
          break
        case 'RX4':
          return this._inputCheck_Num(8, false)
          break
        case 'RX5':
          return this._inputCheck_Num(10, false) // 任选五中五
          break
        case 'RX6':
          return this._inputCheck_Num(12, false) // 任选六中五
          break
        case 'RX7':
          return this._inputCheck_Num(14, false)
          break
        case 'RX8':
          return this._inputCheck_Num(16, false)
          break
        default:
          break
      }
    } else {
      return 0
    }
  },
  /*  以上是输入型注数的检测和计算 */
  
  // 选择型注数计算
  checkSelectedNum (randomSelNum) {
    let tmp_nums = 1
    let mname = this.currentPlay.alias
    let data_sel = randomSelNum || this.currentSelNumArr
    // debugger
    let max_place = this.maxPlace
    let minchosen = this.minChosen
    // 根据玩法分类不同做不同处理
    let nums = 0
    switch (mname) {
      case 'ZX3': // 三码前中后直选复式
        if (data_sel[0].length > 0 && data_sel[1].length > 0 && data_sel[2].length > 0) {
          for (let i = 0; i < data_sel[0].length; i++) {
            for (let j = 0; j < data_sel[1].length; j++) {
              for (let k = 0; k < data_sel[2].length; k++) {
                if (data_sel[0][i] != data_sel[1][j] && data_sel[0][i] != data_sel[2][k] && data_sel[1][j] != data_sel[2][k]) {
                  nums++
                }
              }
            }
          }
        }
        // alert(JSON.stringify(data_sel));
        break
      case 'ZX2': // 二码前中后直选复式
        if (data_sel[0].length > 0 && data_sel[1].length > 0) {
          var h = Array.intersect(data_sel[0], data_sel[1]).length
          nums = data_sel[0].length * data_sel[1].length - h
        }
        break
      case 'DWD': // 定位胆
      case 'DDS': // 定单双
        for (let i = 0; i <= max_place; i++) {
          nums = parseInt(nums + data_sel[i].length)
        }
        break
      case 'ZU3': // 三码前中后，组选
      case 'ZU2': // 二码前中后，组选
      case 'BDW': // 不定位
      case 'CZW': // 猜中位 修复注数计算 by sjf
        tmp_nums = 0
        for (let i = 0; i <= max_place; i++) {
          tmp_nums += data_sel[i].length
        }
        nums = tmp_nums
        break;
      case 'RX1':
      case 'RX2':
      case 'RX3':
      case 'RX4':
      case 'RX5':
      case 'RX6':
      case 'RX7':
      case 'RX8': // 任选复式
        if (data_sel[0].length >= minchosen[0]) { // C(n,m)
          nums += Combination(data_sel[0].length, minchosen[0])
        }
        break
      case 'DT2':
      case 'DT3':
      case 'DT4':
      case 'DT5':
      case 'DT6':
      case 'DT7':
      case 'DT8':
        /* 任选胆拖 、所有胆拖玩法 */
        var danlen = data_sel[0].length // 胆码
        var tuolen = data_sel[1].length // 拖码
        var sellen = parseInt(mname.substring(mname.length - 1))
        if (danlen < 1 || tuolen < 1 || danlen >= sellen) {
          nums = 0
        } else {
          nums = Combination(tuolen, sellen - danlen)
        }
        break
      default: // 默认情况
        for (let i = 0; i <= max_place; i++) {
          if (data_sel[i].length == 0) { // 有位置上没有选择
            tmp_nums = 0
            break
            break
          }
          tmp_nums = accMul(tmp_nums, data_sel[i].length)
        }
        nums = tmp_nums
        break
    }
    return nums
    //
  }
  
}
