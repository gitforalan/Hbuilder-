<!--
  -- Created By fx on 2017/9/19.
  -- ps. 逻辑添加中 todo 购彩车跨组件提交
-->
<template>
  <section class="lm-content">
    <div flex="main:justify cross:center">
      <!--摇一摇-->
      <shake></shake>
      <!--返回购彩车-->
      <cart-badge></cart-badge>
    </div>
    <!-- 玩法帮助 -->
    <div class="playDesc"><p v-if="currentPlay">{{ currentPlay.exampleDesc || currentPlay.helpDesc || '' }}</p></div>
    <div v-if="!isInput"
         v-for="(item, row) in currentLayout"
         class="lm-selector" flex=""
    >
      <!-- 冷热切换 -->
      <hcs-lts v-if="hcltPosition && row === 0" class="hcs-lts"></hcs-lts>
      <div class="title" flex-box="0" align="center">{{ item.title }}</div>
      <div class="content" flex-box="1" align="center">
        <ul flex="main:justify" class="num qu-wei" v-if="playId === 111171010 || playId === 111171017"
            style="width: 100%;margin-left: 0;padding-left: 0.1em">
          <li v-for="(n, col) in item.no" style="width: 25%;padding: 0 0.5em;">
            <span :class="{active: n.isSelected}"
                  @click="doSelectNumber(row, 'single', col)" class="fang">
              {{ n.number }}
              <p style="width: 100%">赔 {{n.b}}</p>
            </span>
            <p v-if="hcsLts.open && hcs.length">
              {{ hcsLtsFlag ? lts[hcsLts.pos[row]].list[col].cnt : hcs[hcsLts.pos[row]].list[col].cnt }}
            </p>
          </li>
        </ul>
        <ul flex="main:left" class="num" v-else>
          <li v-for="(n, col) in item.no">
            <span :class="{active: n.isSelected}" @click="doSelectNumber(row, 'single', col)">{{ n.number }}</span>
            <p v-if="hcsLts.open && hcs.length">
              {{ hcsLtsFlag ? lts[hcsLts.pos[row]].list[col].cnt : hcs[hcsLts.pos[row]].list[col].cnt }}
            </p>
          </li>
        </ul>
        <ul v-if="showButton" flex="box:mean" class="action">
          <li @click="doSelectNumber(row,'big')">大</li>
          <li @click="doSelectNumber(row,'small')">小</li>
          <li @click="doSelectNumber(row,'odd')">单</li>
          <li @click="doSelectNumber(row,'even')">双</li>
          <li @click="doSelectNumber(row,'all')">全</li>
          <li @click="doSelectNumber(row,'clear')">清</li>
        </ul>
      </div>
    </div>
    <bet-input v-if="isInput"
               :currentLayout.sync="currentLayout"
               :currentPlay="currentPlay"
               @on-input="calcNumber"
               @on-clear="clearInputNum"
    ></bet-input>
  </section>
</template>

<script type="text/ecmascript-6">
  //  import Layout from '../config/config_pl3.js'
  import { mapState, mapGetters, mapMutations } from 'vuex'

  // common
  import Shake from 'views/common/shake'
  import HcsLts from 'views/common/hcsLts'
  import CartBadge from 'views/common/cartBadge'
  import RightMenu from 'views/common/rightMenu' // todo
  import BetInput from 'views/common/betInput'

  import algorithm from './js/algorithm.js' // 主要的注数算法
  import selectNumTool from './js/select_num_tool.js' // 选号方法
  import { Combination } from '@/utils/lotteryUtil.js' // 精确乘法 组合算法 accMul

  export default {
    name: 'playArea',
    data () {
      return {
        rangeValue: 0,
        layout: [],     // this.playLayout.selectarea.layout,
        currentLayout: [], // 选号区布局数据
        selectArea: {},  // 选区基础数据
        hcsLts: {           // 冷热遗漏
          open: false,
          pos: []
        },
        showButton: false,   // 是否显示操作按钮
        hcltDisplay: { // 冷热遗漏显示控制
          lts: true, // 默认显示遗漏
          ltsMax: false, // 最大遗漏
          hcs: false // 冷热
        },
        helpDisplay: { // 帮助描述显示控制
          example: false,
          prize: false
        },
        defaultPosition: [], // 任选玩法，默认选择位置 1
        validInputCode: [],   // 用于保存输入型合法号码
        invalidInputCode: [], // 用于保存输入型无效号码
        allInputCode: [
          []
        ], // 全部输入的号码
        selectedMode: '200',
        selectedTimes: 1,
        betNumber: 0,
        selectObj: { // 单注金额
          label: '2元',
          options: [['2元', '200'], ['1元', '100'], ['2角', '20'], ['1角', '10'], ['2分', '2']]
        },
        selectObjTimes: { // 倍数
          selectShow: false,
          options: [['5'], ['10'], ['20'], ['50'], ['100'], ['200'], ['500'], ['1000']]
        },
        randomSelNum: [], // 临时保存选择型随机产生的号码，用于计算注数
        randomInputNum: [], // 用于保存输入型随机产生的号码，用于计算注数
        buyCodeDetail: false,
        buyCodeData: null,
        showConfirm: false, // --
        confirmTitle: '' // --
      }
    },
    components: { Shake, HcsLts, BetInput, CartBadge, RightMenu },
    computed: {
      layoutType () { // 玩法布局类型，选择型、输入型、大小单双
        if (this.selectArea === null) {
          console.log('没有该玩法配置数据: ', this.playId)
          return
        }
        return this.selectArea.type
      },
      noBigIndex () { // 数字型：大小选择分界位置
        return this.selectArea.noBigIndex
      },
      // 数字型：每个位置上最少选择的数字个数
      minChosen () {
        let layout = this.selectArea.layout
        if (!layout) return []
        let map = layout.map(i => {
          if (typeof i.minchosen === 'undefined') {
            return 0
          } else {
            return i.minchosen
          }
        })
        return map
      },
      // 数字型：总共的排列数
      maxPlace () {
        let layout = this.selectArea.layout
        if (!layout) return 0
        let max = 0
        layout.forEach(i => {
          max = i.place > max ? i.place : max
        })
        return max
      },
      // 选择型：过滤出每个位置上，已选择的号码
      currentSelNum () {
        if (this.layoutType === 'input') return {}
        let _all = this.currentLayout
        let _obj = {}
        _all.forEach((i, idx) => {
          var _o = {}
          _o.title = i.title
          if (i.no) {
            var _selected = i.no.filter(j => j.isSelected)
            var _selectedMap = _selected.map(i => i.number)
            _o.numbers = [..._selectedMap]
            _obj[idx] = _o
          }
        })
        return _obj
      },
      // 选择型：根据过滤出的号码，生成一个数组，供注数计算使用
      currentSelNumArr () {
        if (this.layoutType === 'input') return []
        var _num = this.currentSelNum
        let _curr = Object.keys(_num)
        let arr = []
        _curr.forEach(i => {
          arr.push(_num[i].numbers)
        })
        return arr
      },
      // 任意玩法的方案数统计
      planCount () {
        let currSel = this.selectedPosition
        let numcount = this.currentPlay.numcount
        if (currSel.length === 0) {
          return 0
        } else {
          return Combination(currSel.length, numcount)
        }
      },
      // 任意玩法当前选择的位置
      selectedPosition () {
        let currDP = this.defaultPosition
        let selPos = []
        for (let i = 0; i < currDP.length; i++) {
          if (currDP[i]) {
            selPos.push(i)
          }
        }
        return selPos
      },
      hcltPosition () { // 是否显示冷热遗漏
        if (this.currentPlay.selectarea) {
          return this.currentPlay.selectarea.hcltPosition
        }
      },
      ...mapState('common', {
        cart: state => state.betList,
        issue: state => state.issue,
        buyDouble: state => state.buyDouble,
        modeA: state => state.modeA,
        hcs: state => state.hcs,
        lts: state => state.lts,
        hcsLtsFlag: state => state.hcsLtsFlag,
        randomBetListSync: state => state.randomBetList, // 监听传过来的点击
        showCart: state => state.showCart, // 是否打开了购票车
        noticeAddToCart: state => state.noticeAddToCart // 派发添加购票车事件
      }),
      ...mapState('syx5', {
        currentPlay: state => state.currentPlay,
        isInput: state => state.isInput,
        playId: state => state.playId,
        playTabName: state => state.playTabName,
        playName: state => state.playName,
        clearLayout: state => state.doClearLayout,
        rebateRate: state => state.rebateRate
      }),
      ...mapGetters('common', [
        'totalMoney',
        'totalCounts',
        'willSubmitData'
      ]),
      // 用于随机一注，获取每一行的最大值和最小值
      currentLayoutNum () {
        if (this.layoutType === 'input') return []
        let layout = this.currentPlay.selectarea.layout
        let map = layout.map((i, idx) => {
          if (this.currentPlay.alias === 'DXDS') { // 大小单双：0123
            let _no = i.no
            _no = _no.replace(/大/g, '0').replace(/小/g, '1').replace(/单/g, '2').replace(/双/g, '3')
            return _no.split('|')
          } else {
            return i.no.split('|')
          }
        })
        return map
      },
      isInput () {
        if (this.layoutType === 'input') return true
        return false
      }
    },
    filters: {
      formatBuyCode (code, maxLen) {
        if (code.length > maxLen) {
          return code.slice(0, maxLen) + '...'
        } else {
          return code
        }
      },
      formatMode (num) {
        num = num.toString()
        if (num.length > 2) {
          let mode = num.slice(0, -2)
          return mode + '元'
        } else {
          let mode = num.length > 1 ? num.replace('0', '角') : num.concat('分')
          return mode
        }
      }
    },
    methods: {
      updateHcsLts (data) {
        // 从基础数据取冷热遗漏位置
        if (data.hcltPosition) {
          this.hcsLts.open = true
          this.hcsLts.pos = data.hcltPosition
        } else {
          this.hcsLts.open = false
          this.hcsLts.pos = []
        }
      },
      isButton (data) {
        this.showButton = data.hasOwnProperty('isButton') && data.isButton
      },
      getDigitalLayout () {
        const layout = this.selectArea.layout
        layout.forEach((i, index) => {
          let arr = [] // 临时保存每一行合并后的数据
          let s = (this.rangeValue / 10).toFixed(0) * 10
          let singleRow = i.no.split('|')
          for (let j = 0; j < singleRow.length; j++) {
            arr[j] = {
              number: singleRow[j],
              b: ((this.currentPlay.maxPrize[j] -
                (((this.currentPlay.maxPrize[j] - this.currentPlay.minPrize[j]) / this.currentPlay.rebateRate) * s)) / 100).toFixed(2),
              isSelected: 0 // 添加是否被选择的标记位
            }
          }
          i.no = arr
        })
        return layout
      },
      getLayout () {
        const type = this.selectArea.type.toLowerCase()
        let _layout = {}
        if (type === 'undefined') return
        switch (type) {
          case 'digital':
          case 'dxds':
            _layout = this.getDigitalLayout()
            break
          case 'input':
            _layout = null
            break
        }
        return _layout
      },
      init (data) {
        this.selectArea = JSON.parse(JSON.stringify(data.selectarea))
        this.layout = data.selectarea.layout
        if (this.layoutType === 'input') {
          this.currentLayout = ''
        } else {
          this.currentLayout = this.getLayout()
          this.isButton(this.selectArea)
          this.updateHcsLts(this.selectArea)
        }
      },
      // 任选玩法，获取默认位置
      getDefaultPosition () {
        let dpStr = this.currentPlay.defaultposition
        let dpArr = dpStr.split('').map(i => i === 1)
        this.defaultPosition = [...dpArr]
      },
      // 输入型：找出重复号码
      findRepeatCode () {
        let curr = [].concat(this.allInputCode[0])
        let ret = [] // 保存重复项
        curr.sort((a, b) => a - b)
        curr.sort((a, b) => { // 找出重复项
          if ((a === b) && !ret.includes(a)) {
            ret.push(a)
          }
        })
        return ret
      },
      // 输入型：删除重复号码
      dumpNum () {
        let ret = this.findRepeatCode()
        // debugger
        if (ret.length === 0) {
          alert('没有重复号码')
        } else {
          alert('已删除重复号码：' + ret.join(','))
        }
        // 删除重复项
        let curr = [].concat(this.allInputCode[0])
        let unique = Array.from(new Set(curr))
        this.allInputCode = [unique]
        this.currentLayout = this.allInputCode[0].join(' ')
        this.calcNumber()
      },
      // 输入型：清空输入的号码
      clearInputNum () {
        this.currentLayout = ''
        this.validInputCode = []
        this.invalidInputCode = []
        this.allInputCode = [
          []
        ]
        this.calcNumber()
      },
      // 随机一注
      addOneBet () {
        const betNumber = 1
        // var isrx = this.currentPlay.isrx === 1
        // var selectedPosition = this.selectedPosition
        var _buycode = this.doSelectRandom()
        const singleMoneyTotal = this.buyDouble * (this.modeA / 100) * betNumber
        let bet = {
          // 接口必传
          playId: this.currentPlay.playId,
          imp: 0,
          singleMoney: this.modeA,
          buyDouble: this.buyDouble,
          moneyUnit: 3,
          rebateRate: this.rebateRate,
          buyCodeFront: _buycode,
          buyCode: _buycode,
          // 模板用
          playTabName: this.playTabName,
          playName: this.playName,
          buyCount: betNumber,
          singleMoneyTotal: singleMoneyTotal,
          tempSingleMoneyTotal: (this.modeA / 100) * betNumber
        }
        // 针对定单双的号码转换
        if (this.currentPlay.alias === 'DDS') {
          bet.buyCode =
            _buycode
              .replace(/0单5双/g, '5')
              .replace(/1单4双/g, '4')
              .replace(/2单3双/g, '3')
              .replace(/3单2双/g, '2')
              .replace(/4单1双/g, '1')
              .replace(/5单0双/g, '0')
        }
        // 重新计算注数 todo
        let counts
        if (this.layoutType !== 'input') {
          counts = this.checkSelectedNum(this.randomSelNum)
        } else {
          this.currentLayout = ''
          this.betNumber = 0
          counts = this.checkInputNum(this.allInputCode)
        }
        bet.buyCount = counts
        bet.singleMoneyTotal = singleMoneyTotal * counts
        console.log('随机数据', bet)
        // 添加到购票车
        this.add_bet(bet)
        this.doClearLayout()

        // 清空随机号码,否则手动输入号码会出错
        this.validInputCode = []
      },
      // 随机N注
      addMoreBet (n) {
        for (let i = 0; i < n; i++) {
          this.addOneBet()
        }
        this.open_cart(true) // 显示购票车
      },
      addBetToCart () {
        const betNumber = this.calcNumber()
        if (betNumber < 1) {
          alert('号码选择不完整，请重新选择')
          this.open_cart(false)
          return
        }
        if (this.layoutType === 'input') {
          if (this.validInputCode.length < 1) {
            alert('没有有效号码')
            return
          }
          let repeatCodes = this.findRepeatCode()

          if (this.invalidInputCode.length > 0 && repeatCodes.length > 0) { // 既有重复号，也有无效号
            // 删除重复项
            let curr = [].concat(this.allInputCode[0])
            let unique = Array.from(new Set(curr))
            this.allInputCode = [unique]
            this.currentLayout = this.allInputCode[0].join(' ')
            this.calcNumber()

            const tips = `
            已为您过滤无效号码： ${this.invalidInputCode.join(',')}
            <br>
            已为您删除重复号码： ${repeatCodes.join(',')}
            <br>
            `
            alert(tips)
          } else if (this.invalidInputCode.length > 0) { // 只有无效号
            alert('已为您过滤无效号码：' + this.invalidInputCode.join(','))
          } else if (repeatCodes.length > 0) { // 只有重复号
            // 删除重复项
            let curr = [].concat(this.allInputCode[0])
            let unique = Array.from(new Set(curr))
            this.allInputCode = [unique]
            this.currentLayout = this.allInputCode[0].join(' ')
            this.calcNumber()
            alert('已删除重复号码：' + repeatCodes.join(','))
          }
          const singleMoneyTotal = this.buyDouble * betNumber * (this.modeA / 100)
          let bet = {
            // 接口必传
            playId: this.currentPlay.playId,
            imp: 0,
            singleMoney: this.modeA,
            buyDouble: this.buyDouble,
            moneyUnit: 3,
            rebateRate: this.rebateRate,
            // 模板用
            playTabName: this.playTabName,
            playName: this.playName,
            buyCount: betNumber,
            singleMoneyTotal: singleMoneyTotal,
            tempSingleMoneyTotal: (this.modeA / 100) * betNumber
          }
          bet.buyCode = bet.buyCodeFront = this.validInputCode.join(',')
          // 添加到购票车
          this.add_bet(bet)
          this.clearInputNum() // 清空输入型临时数据
          this.open_cart(true) // 显示购票车
          // this.$router.push({ params: { sid: 'betCart' } }) // 跳转到购彩车
        } else {
          const singleMoneyTotal = this.buyDouble * (this.modeA / 100) * betNumber
          let bet = {
            // 接口必传
            playId: this.currentPlay.playId,
            imp: 0,
            singleMoney: this.modeA,
            buyDouble: this.buyDouble,
            moneyUnit: 3,
            rebateRate: this.rebateRate,
            // 模板用
            playTabName: this.playTabName,
            playName: this.playName,
            buyCount: betNumber,
            singleMoneyTotal: singleMoneyTotal,
            tempSingleMoneyTotal: (this.modeA / 100) * betNumber
          }
          let mname = this.currentPlay.alias
          if (mname === 'DWD') {
            bet.buyCode = bet.buyCodeFront = this.currentSelNumArr.map(i => {
              return i.join('')
            }).join(',')
          } else {
            let tmp = this.currentSelNumArr.filter(j => j.length > 0)
            if (tmp.length === 1) {
              bet.buyCode = bet.buyCodeFront = tmp.join(',')
            } else {
              bet.buyCode = bet.buyCodeFront = tmp.map(i => {
                if (i.length > 1) {
                  switch (mname) {
                    case 'ZU2':
                      return i.join(',')
                    default:
                      return i.join('')
                  }
                } else {
                  return i
                }
              }).join(',')
            }
          }
          // 针对定单双的号码转换
          if (this.currentPlay.alias === 'DDS') {
            bet.buyCode =
              bet.buyCode
                .replace(/0单5双/g, '5')
                .replace(/1单4双/g, '4')
                .replace(/2单3双/g, '3')
                .replace(/3单2双/g, '2')
                .replace(/4单1双/g, '1')
                .replace(/5单0双/g, '0')
          }
          // 添加到购票车
          this.add_bet(bet)
          // this.$store.commit('cart/ADD_BET', bet)
          // 清空选号区
          // this.doClearLayout()
          // betNumber = 0 // 注数清零
          // this.$router.push({ params: { sid: 'betCart' } }) // 跳转到购彩车
          this.open_cart(true) // 显示购票车
        }
      },
      scrollTop () {
        window.scrollTo(0, 0)
      },
      ...mapMutations('syx5', ['set_playId', 'is_input', 'is_selNum', 'set_betNumber', 'set_singleBetMoney']),
      ...mapMutations('common', ['add_bet', 'clear_bet', 'update_issue', 'open_cart', 'update_tracelist']),
      ...algorithm,
      ...selectNumTool

    },
    created () {
      // this.init()
      // this.getDefaultPosition() // 获取"万千百十个"默认位置
    },
    watch: {
      rebateRate (val) {
        this.rangeValue = val
        let s = (this.rangeValue / 10).toFixed(0) * 10
        this.currentLayout.map(i => {
          i.no.map((j, k) => {
            j.b = ((this.currentPlay.maxPrize[k] -
              (((this.currentPlay.maxPrize[k] - this.currentPlay.minPrize[k]) / this.currentPlay.rebateRate) * s)) / 100).toFixed(2)
          })
        })
      },
      randomBetListSync (n) {
        if (n === -1) return
        return this.addMoreBet(n) // 随机N注
      },
      currentSelNumArr (val) {
        this.is_selNum(val) // 触发是否选号的判断
        this.set_betNumber(this.calcNumber())
      },
      currentPlay (data) {
        this.init(data) // 数据变化 界面重新渲染
        // this.getDefaultPosition() // 重新获取“万千百十个”位数
        this.calcNumber() // 重新计算注数
        this.randomSelNum = [] // 重置随机选择的号码临时数组
        this.allInputCode = []
        this.scrollTop()
      },
      isInput (val) {
        this.is_input({ isInput: val })
      },
      playLayout (data) {
        this.noActive = {} // 重置选号
      },

      selectedTimes (newVal, oldVal) { // 监听选择倍数，限制最大值和最小值
        if (newVal < 1) this.selectedTimes = 1
        if (newVal > 9999) this.selectedTimes = 9999
      },
      $route (to, from) {
        // 废弃
        if (from.params.sid === 'betCart') {
          this.open_cart(false) // 关闭购物车
        }
        // this.clear_bet() // 清空购票车
      },
      // 监听待下注数据
      willSubmitData (nVal) {
        if (nVal.length === 0) {
          this.update_tracelist([]) // 清空追号数据
          // this.$emit('update:showTrace', false) // 关闭追号
        }
      },
      doTrace (newVal) {
        if (newVal) {
          this.doConfirm()
          this.$emit('update:doTrace', false)
        }
      },
      clearLayout (val) {
        this.doClearLayout()
      },
      noticeAddToCart (val) {
        if (val) {
          this.addBetToCart()
        } else {
          this.doClearLayout() // 清界面
        }
      }
    },
    beforeDestroy () {
      // 清购票车放在彩种组件离开时候 ps 2017-11-7 11:24:17 fx
      // this.clear_bet() // 清购票车
      console.log('playArea:', '销毁')
    }
  }
</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .fang
    border-radius 0.2em !important
    width 100% !important
    height 5rem !important
  .lm-content
    background $color-white
    padding-bottom $BottomBarHeight
    .hcs-lts
      position absolute
      width rem(164)
      min-height rem(48)
      top rem(90)
      z-index 1
    .lm-selector
      margin 0 .5rem
      padding-top 1rem
      border-bottom 1px solid $color-border
      box-sizing border-box
      position relative
      .title
        font-size rem(25)
        margin-right 0
        padding-top 1rem
        color $color-black-c
        font-weight 700
      .content
        ul
          margin-left rem(20)
          li
            width rem(64)
            padding-left .7em
            padding-right .7em
            margin-bottom 0.5rem
            span
              width 2.3em
              height 2.3em
              line-height 2.3em
              font-size rem(35)
              font-style normal
              display inline-block
              background $color-el-bg
              color $color-red
              text-align center
              border-radius 100%
              margin-bottom .5rem
              border 1px solid $color-border
              box-sizing border-box
              &.active
                background $color-red
                color $color-white
                border none
                p
                  color $color-white
            p
              width 4.2em
              font-size rem(20)
              color $color-black-b
          &.num
            flex-wrap: wrap
            -webkit-flex-wrap wrap
          &.qu-wei
            li
              span
                line-height 2.8em
            p
              line-height .2em
          &.action
            font-size rem(28)
            color $color-gray-b

        ul:nth-child(2)
          background $color-eee
          padding rem(13) 0
          border-radius 25px
          color $color-black-b
          margin-bottom rem(31)
          li
            padding 0 .3rem
            border-right 1px solid $color-black-b
            height rem(28)
            line-height rem(28)
            font-size rem(28)
            margin-bottom 0
            position relative
            &:last-child
              border-right none
            &:before
              content: ''
              position: absolute
              top: -10px
              left: 0
              right: 0
              bottom: -10px
</style>
