export default [{
  playTabId: 13210,
  playTabName: '整合'
}, {
  playTabId: 13213,
  playTabName: '两面'
}, {
  playTabId: 13211,
  playTabName: '龙虎斗'
}, {
  playTabId: 13212,
  playTabName: '任选'
}]
