<template>
  <div class="bet-confirm" :style="{top:top+'px'}" flex="dir:top bottom">
    <div class="cart-wrap" flex-box="1" >
      <div class="cart-con" flex="main:justify" v-for="t in flattenBetList">
        <div class="lot-tit-wrap" flex="">
          <div class="lot-tit-con">
            <p>
              <i>{{t.buyCodeFront}}</i>
            </p>
            <p>{{t.playTypeName}}</p>
          </div>
        </div>
        <div class="money" flex="cross:bottom">
          <span>赔率/返点: </span>
          <span>{{(t.computedMaxPrize/100).toFixed(2)}}/{{(t.rebateRate/100).toFixed(1)}}%</span>
        </div>
        <div flex="dir:right cross:bottom" class="btn">
          <span>金额 <i>{{t.singleMoney /100}}</i> 元</span>
        </div>
      </div>
    </div>
    <!-- 底部 -->
    <footer ref="footer" flex-box="0">
      <div class="btn-group" flex="main:justify cross:center">
        <div class="btn btn-chase" @click="updateShowBetConfirm(false)">
          <span>取消</span>
        </div>
        <div class="notes" flex="main:justify">
          <p>共 <span>{{totalBetNumbers}}</span> 注</p>
          <p>共 <span>{{totalBetMoney}}</span> 元</p>
        </div>
        <div class="btn btn-betting" @click="setBetNow(true)">
          <span >确认投注</span>
        </div>
      </div>
    </footer>
  </div>
</template>

<script type="text/ecmascript-6">
import { mapMutations, mapState, mapGetters } from 'vuex'

export default {
  name: 'kl10-bet-confirm',
  methods: {
    ...mapMutations('kl10', [
      'updateShowBetConfirm',
      'setBetNow'
    ])
  },
  computed: {
    ...mapState('kl10', [
      'flattenBetList',
      'playTabId'
    ]),
    ...mapGetters('kl10', [
      'totalBetNumbers',
      'totalBetMoney'
    ])
  },
  props: {
    top: Number
  },
  data () {
    return {}
  },
  created () {
    // 阻止父容器滚动
    this.$root.$el.style.overflow = 'hidden'
  },
  beforeDestroy () {
    // 取消阻止
    this.$root.$el.style.overflow = 'auto'
  }
}
</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .bet-confirm
    margin-top rem(44)
    background $color-white
    position fixed
    left 0
    right 0
    bottom 0
    z-index 21
    .cart-wrap
      width 100%
      overflow-y auto
      font-size $size-small-x
      padding-bottom rem(100)
      box-sizing border-box
      .cart-con
        width 95%
        margin 0 auto
        padding 2.5% 2.5%
        border-bottom 1px dotted $color-border
        .btn
          span
            i
              color $color-red
          .lott-icon
            display inline
            color $color-red
      .money
        span
          color $color-gray
          &:nth-child(3)
            display inline-block
            margin-left rem(20)
      .lot-tit-wrap
        .lot-tit-con
          font-size rem(28)
          color #5c5c5c
          text-align center
          p
            i
              display inline-block
            &:first-child
              font-size $size-small-x
              color $color-red
              padding-bottom rem(10)
        .btn-delete
          i
            color $color-gray-a
            width rem(30)
            height rem(30)

    footer
      color $color-black
      font-size $size-medium
      background $color-el-bg
      border-top 1px solid $color-border
      height $BottomBarHeight
      .btn-group
        box-sizing border-box
        padding .5rem rem(29)
        .btn
          width rem(180)
          height rem(70)
          line-height rem(70)
          background $color-red
          border-radius 5px
          color $color-white
          font-size rem(36)
          text-align center
        .btn-betting
          width rem(200)
          height rem(70)
      .notes
        background none
        font-size rem(28)
        color $color-black-c
        p
          span
            color $color-red
          &:nth-child(1)
            margin-right rem(40)
</style>
