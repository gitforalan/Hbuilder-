import { mapState, mapMutations, mapGetters } from 'vuex'
import KL8Footer from '../../public/footer'
import BetConfirm from '../../public/betConfirm'
import Layout from './config.js'
import * as API from 'api/wapi/front'

export default {
  name: 'liang-mian',
  filters: {
    formatF2Y (num) {
      return (num / 100).toFixed(2)
    }
  },
  methods: {
    getLotteryPlayOdds () {
      let query = {
        playTabMode: 2,
        lotteryTypeId: 13
      }
      API.getLotteryPlayOdds(query).then(res => {
        if (res.code === 0) {
          this.layout = this.doMergeData(res.data.playTabList)
        } else {
          console.log('getLotteryPlayOdds:', res.data.desc)
        }
      })
    },
    getLotteryUserBet () {
      let query = {
        lotteryId: this.lotteryId,
        issue: this.currentIssue,
        betList: JSON.stringify(this.flattenBetList)
      }
      API.getLotteryUserBet(query).then(res => {
        if (res.code === 0) {
          this.doUnselectAll() // 清空号码
          this.updateShowBetConfirm(false) // 关闭确认投注对话
          this.$vux.toast.show({
            type: 'success',
            isShowMask: false,
            text: '下注成功',
            time: 2000
          })
        }
      }).catch(err => {
        this.$vux.toast.show({
          type: 'warn',
          isShowMask: false,
          text: err.desc,
          time: 2000
        })
        console.log('getLotteryUserBet:', err.desc)
      })
    },
    // 处理配置文件数据
    doHandleData () {
      return Layout[0].playTypeList.map(j => {
        j.playListGroup.map(k => {
          k.isactive = 0
          k.playList.map(m => {
            m.maxPrize = 0
            m.minPrize = 0
            m.rebateRate = 0
            m.computedMaxPrize = 0
            m.money = 0
            m.isactive = false
            return m
          })
          return k
        })
        return j
      })[0].playListGroup
    },
    // 根据接口数据，更新本地数据
    doMergeData (data) {
      let d = data.find(i => i.playTabId === 13213).playTypeList.map(i => i.playList)
      d = [].concat(...d)
      return this.layout.map(i => {
        i.playList.map(m => {
          let targetPlay = d.find(i => i.playId === m.playId)
          if (targetPlay) {
            m.maxPrize = targetPlay.maxPrize
            m.minPrize = targetPlay.minPrize
            m.rebateRate = targetPlay.rebateRate
            m.computedMaxPrize = targetPlay.maxPrize
          } else {
            // throw new Error(`${playId}: 玩法数据不存在`)
            console.log(`${m.playId}: 玩法数据不存在`)
          }
          return m
        })
        return i
      })
    },
    doSelectBoal (item, bool) {
      item.isactive = bool
      if (bool === 1) {
        if ((item.money + this.singleBetMoney) > 999999) {
          return
        } else {
          item.money += this.singleBetMoney
        }
      } else item.money = 0
    },
    doUnselectAll () {
      this.layout.forEach(k => {
        k.playList.forEach(j => {
          j.isactive = 0
          j.money = 0
        })
      })
    },
    ...mapMutations('kl10', [
      'lhc_flattenBetList',
      'setClearNow',
      'setBetNow',
      'updateMaxSliderVal',
      'updateInputStyleFooter',
      'updateShowBetConfirm',
      'updateSelectedNumber'
    ])
  },
  watch: {
    // 根据选择的球，拼接号码
    selectedBoal (nval) {
      this.updateSelectedNumber(nval.map(i => i.name).join(','))
    },
    // 监听当前注单，推到store保存
    flattenBetList (nval) {
      this.lhc_flattenBetList({ flattenBetList: nval })
    },
    clearNow (nval) {
      if (nval) this.doUnselectAll()
      this.setClearNow(false)
    },
    betNow (nval) {
      if (nval) {
        this.getLotteryUserBet()
        this.setBetNow(false)
      }
    },
    maxSliderVal (nval) {
      this.updateMaxSliderVal(nval)
    },
    // 监测返水，实时计算前台奖金
    rebateRate (nVal) {
      this.layout.forEach(i => {
        i.playList.forEach(j => {
          let max = j.maxPrize
          let diff = j.maxPrize - j.minPrize
          let t = (diff / this.maxSliderVal) * nVal
          let b = (max - t).toFixed(0)
          j.computedMaxPrize = b
        })
      })
    }
  },
  computed: {
    ...mapState('kl10', [
      'playTabId',
      'playTabName',
      'clearNow',
      'singleBetMoney',
      'rebateRate',
      'betNow',
      'isShowBetConfirm'
    ]),
    ...mapGetters('common', [
      'lotteryId'
    ]),
    // 已选择的球
    selectedBoal () {
      let ret = []
      this.layout.forEach(i => {
        let tmp = i.playList.filter(j => j.isactive === 1)
        if (tmp.length) ret.push(tmp)
      })
      return [].concat(...ret)
    },
    // 计算后的注单信息
    flattenBetList () {
      return this.selectedBoal.map(j => ({
        playId: j.playId,
        imp: 0,
        moneyUnit: 3,
        singleMoney: j.money * 100, // 转分
        rebateRate: this.rebateRate,
        buyCode: j.name, // 接口要求不能为空
        buyCodeFront: j.name, // 用于返回用户选择的玩法名称
        playTypeName: this.playTabName, // 父级分类名称,用于用户侧展示
        computedMaxPrize: j.computedMaxPrize // 前端显示
      }))
    },
    totalBetNumbers () {
      return this.flattenBetList.length
    },
    totalBetMoney () {
      return this.selectedBoal.map(i => i.money).reduce((a, b) => a + b, 0)
    },
    // 返水点滚动条最大百分比
    maxSliderVal () {
      if (this.layout.length) {
        return +this.layout[0].playList[0].rebateRate
      }
    }
  },
  props: {
    marginTop: [Number, String],
    currentIssue: [Number, String]
  },
  data () {
    return {
      layout: []
    }
  },
  created () {
    this.layout = this.doHandleData()
    // 更新底部Footer的金额选择样式 true-筹码和输入 false-只有输入
    this.updateInputStyleFooter(false)
  },
  mounted () {
    this.getLotteryPlayOdds()
  },
  components: { KL8Footer, BetConfirm }
}
