// 复制自六合彩-连码
export default [{
  'playTabId': 13212,
  'playTabName': '任选',
  'playTypeList': [{
    'playTypeId': 1321210,
    'playTypeName': '任一中一',
    'minChosen': 1,
    'maxChosen': 20,
    'playList': [
      { 'playId': 132121010 }
    ]
  },
  {
    'playTypeId': 1321211,
    'playTypeName': '任二中二',
    'minChosen': 2,
    'maxChosen': 8,
    'playList': [
      { 'playId': 132121110 }
    ]
  },
  {
    'playTypeId': 1321212,
    'playTypeName': '任三中三',
    'minChosen': 3,
    'maxChosen': 8,
    'playList': [
      { 'playId': 132121210 }
    ]
  },
  {
    'playTypeId': 1321213,
    'playTypeName': '任四中四',
    'minChosen': 4,
    'maxChosen': 8,
    'playList': [
      { 'playId': 132121310 }
    ]
  },
  {
    'playTypeId': 1321214,
    'playTypeName': '任五中五',
    'minChosen': 5,
    'maxChosen': 8,
    'playList': [
      { 'playId': 132121410 }
    ]
  }
  ]
}]
