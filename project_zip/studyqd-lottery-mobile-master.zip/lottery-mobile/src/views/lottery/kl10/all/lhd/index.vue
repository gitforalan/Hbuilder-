<template>
  <section class="lm-content" :style="{marginTop:marginTop+'px'}">
    <div flex="main:justify cross:center">
    </div>
    <!--长牌-->
    <div class="lm-selector">
      <div class="tips">
        <icon-svg icon-class="shou"></icon-svg>
        点击：筹码下注
        <span>长按：筹码删除</span>
      </div>
      <div class="credit-wrap">
        <template v-for="r in layout" v-if="layout.length">
          <div class="credit-con">
            <div class="group-name">{{r.playTypeName}}</div>
            <div v-for="t in r.playList" class="play-group">
              <v-touch @tap="doSelectBoal(t,1)" @pressup="doSelectBoal(t,0)"  style="height:100%">
                <span class="boal" :class="{active:t.isactive}">
                  <div>{{t.name}}</div>
                  <div class="prize">{{t.computedMaxPrize | formatF2Y}}</div>
                  <span class="bet-pop" :class="{'rect':t.money > 9999}">{{t.money}}</span>
                </span>
              </v-touch>
            </div>
          </div>
        </template>
      </div>

    </div>
    <!-- 底部 -->
    <KL8Footer/>
    <!-- 下注确认 -->
    <BetConfirm v-if="isShowBetConfirm" :top="marginTop" />
  </section>
</template>

<script src="./script.js"></script>
<style scoped lang="stylus" src="./style.styl"></style>
