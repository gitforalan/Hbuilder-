<template>
  <section class="lm-content" :style="{marginTop:marginTop+'px'}">
    <div flex="main:justify cross:center">
    </div>
    <!--长牌-->
    <div class="lm-selector">
      <div class="tips">
        <icon-svg icon-class="shou"></icon-svg>
        点击：筹码下注
        <span>长按：筹码删除</span>
      </div>
      <template v-for="r in layout" v-if="layout.length">
        <div class="credit-wrap" flex="main:justify">
          <div flex-box="0" class="credit-unit">{{r.playListGroupName}}</div>
          <div flex-box="1" class="credit-con">
            <ul >
              <li v-for="t in r.playList">
                <v-touch @tap="doSelectBoal(t,1)" @pressup="doSelectBoal(t,0)"  style="height:100%">
                  <span class="boal" :class="{active:t.isactive}">
                    <div>{{t.name}}</div>
                    <div class="prize">{{t.computedMaxPrize | formatF2Y}}</div>
                    <span class="bet-pop" :class="{'rect':t.money > 9999}">{{t.money}}</span>
                  </span>
                </v-touch>
              </li>
            </ul>
          </div>
        </div>

      </template>

    </div>
    <!-- 底部 -->
    <KL8Footer/>
    <!-- 下注确认 -->
    <BetConfirm v-if="isShowBetConfirm" :top="marginTop" />
  </section>
</template>

<script src="./script.js"></script>
<style scoped lang="stylus" src="./style.styl"></style>
