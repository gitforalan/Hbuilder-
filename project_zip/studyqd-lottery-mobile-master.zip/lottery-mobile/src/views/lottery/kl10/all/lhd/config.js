// 配置文件不同于六合彩
export default [{
  'playTabId': 13211,
  'playTabName': '龙虎斗',
  'playTypeList': [{
    'playTypeId': 1321110,
    'playTypeName': '第一球VS第二球',
    'playList': [{ 'playId': 132111010, 'name': '龙' }, { 'playId': 132111011, 'name': '虎' }]
  }, {
    'playTypeId': 1321111,
    'playTypeName': '第一球VS第三球',
    'playList': [{ 'playId': 132111110, 'name': '龙' }, { 'playId': 132111111, 'name': '虎' }]
  }, {
    'playTypeId': 1321112,
    'playTypeName': '第一球VS第四球',
    'playList': [{ 'playId': 132111210, 'name': '龙' }, { 'playId': 132111211, 'name': '虎' }]
  }, {
    'playTypeId': 1321113,
    'playTypeName': '第一球VS第五球',
    'playList': [{ 'playId': 132111310, 'name': '龙' }, { 'playId': 132111311, 'name': '虎' }]
  }, {
    'playTypeId': 1321114,
    'playTypeName': '第一球VS第六球',
    'playList': [{ 'playId': 132111410, 'name': '龙' }, { 'playId': 132111411, 'name': '虎' }]
  }, {
    'playTypeId': 1321115,
    'playTypeName': '第一球VS第七球',
    'playList': [{ 'playId': 132111510, 'name': '龙' }, { 'playId': 132111511, 'name': '虎' }]
  }, {
    'playTypeId': 1321116,
    'playTypeName': '第一球VS第八球',
    'playList': [{ 'playId': 132111610, 'name': '龙' }, { 'playId': 132111611, 'name': '虎' }]
  }, {
    'playTypeId': 1321117,
    'playTypeName': '第二球VS第三球',
    'playList': [{ 'playId': 132111710, 'name': '龙' }, { 'playId': 132111711, 'name': '虎' }]
  }, {
    'playTypeId': 1321118,
    'playTypeName': '第二球VS第四球',
    'playList': [{ 'playId': 132111810, 'name': '龙' }, { 'playId': 132111811, 'name': '虎' }]
  }, {
    'playTypeId': 1321119,
    'playTypeName': '第二球VS第五球',
    'playList': [{ 'playId': 132111910, 'name': '龙' }, { 'playId': 132111911, 'name': '虎' }]
  }, {
    'playTypeId': 1321120,
    'playTypeName': '第二球VS第六球',
    'playList': [{ 'playId': 132112010, 'name': '龙' }, { 'playId': 132112011, 'name': '虎' }]
  }, {
    'playTypeId': 1321121,
    'playTypeName': '第二球VS第七球',
    'playList': [{ 'playId': 132112110, 'name': '龙' }, { 'playId': 132112111, 'name': '虎' }]
  }, {
    'playTypeId': 1321122,
    'playTypeName': '第二球VS第八球',
    'playList': [{ 'playId': 132112210, 'name': '龙' }, { 'playId': 132112211, 'name': '虎' }]
  }, {
    'playTypeId': 1321123,
    'playTypeName': '第三球VS第四球',
    'playList': [{ 'playId': 132112310, 'name': '龙' }, { 'playId': 132112311, 'name': '虎' }]
  }, {
    'playTypeId': 1321124,
    'playTypeName': '第三球VS第五球',
    'playList': [{ 'playId': 132112410, 'name': '龙' }, { 'playId': 132112411, 'name': '虎' }]
  }, {
    'playTypeId': 1321125,
    'playTypeName': '第三球VS第六球',
    'playList': [{ 'playId': 132112510, 'name': '龙' }, { 'playId': 132112511, 'name': '虎' }]
  }, {
    'playTypeId': 1321126,
    'playTypeName': '第三球VS第七球',
    'playList': [{ 'playId': 132112610, 'name': '龙' }, { 'playId': 132112611, 'name': '虎' }]
  }, {
    'playTypeId': 1321127,
    'playTypeName': '第三球VS第八球',
    'playList': [{ 'playId': 132112710, 'name': '龙' }, { 'playId': 132112711, 'name': '虎' }]
  }, {
    'playTypeId': 1321128,
    'playTypeName': '第四球VS第五球',
    'playList': [{ 'playId': 132112810, 'name': '龙' }, { 'playId': 132112811, 'name': '虎' }]
  }, {
    'playTypeId': 1321129,
    'playTypeName': '第四球VS第六球',
    'playList': [{ 'playId': 132112910, 'name': '龙' }, { 'playId': 132112911, 'name': '虎' }]
  }, {
    'playTypeId': 1321130,
    'playTypeName': '第四球VS第七球',
    'playList': [{ 'playId': 132113010, 'name': '龙' }, { 'playId': 132113011, 'name': '虎' }]
  }, {
    'playTypeId': 1321131,
    'playTypeName': '第四球VS第八球',
    'playList': [{ 'playId': 132113110, 'name': '龙' }, { 'playId': 132113111, 'name': '虎' }]
  }, {
    'playTypeId': 1321132,
    'playTypeName': '第五球VS第六球',
    'playList': [{ 'playId': 132113210, 'name': '龙' }, { 'playId': 132113211, 'name': '虎' }]
  }, {
    'playTypeId': 1321133,
    'playTypeName': '第五球VS第七球',
    'playList': [{ 'playId': 132113310, 'name': '龙' }, { 'playId': 132113311, 'name': '虎' }]
  }, {
    'playTypeId': 1321134,
    'playTypeName': '第五球VS第八球',
    'playList': [{ 'playId': 132113410, 'name': '龙' }, { 'playId': 132113411, 'name': '虎' }]
  }, {
    'playTypeId': 1321135,
    'playTypeName': '第六球VS第七球',
    'playList': [{ 'playId': 132113510, 'name': '龙' }, { 'playId': 132113511, 'name': '虎' }]
  }, {
    'playTypeId': 1321136,
    'playTypeName': '第六球VS第八球',
    'playList': [{ 'playId': 132113610, 'name': '龙' }, { 'playId': 132113611, 'name': '虎' }]
  }, {
    'playTypeId': 1321137,
    'playTypeName': '第七球VS第八球',
    'playList': [{ 'playId': 132113710, 'name': '龙' }, { 'playId': 132113711, 'name': '虎' }]
  }]
}]
