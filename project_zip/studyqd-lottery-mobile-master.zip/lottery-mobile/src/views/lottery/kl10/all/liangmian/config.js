export default [{
  'playTabId': 13213,
  'playTabName': '两面',
  'playTypeList': [{
    'playTypeId': 2121110, // 没用
    'playTypeName': '两面',
    'playListGroup': [{
      'playListGroupName': '和值',
      'playList': [
        { 'playId': 132131010, 'name': '大' },
        { 'playId': 132131011, 'name': '小' },
        { 'playId': 132131012, 'name': '单' },
        { 'playId': 132131013, 'name': '双' },
        { 'playId': 132131014, 'name': '尾大' },
        { 'playId': 132131015, 'name': '尾小' }
      ]
    }, {
      'playListGroupName': '上下',
      'playList': [
        { 'playId': 132131110, 'name': '上盘' },
        { 'playId': 132131111, 'name': '和盘' },
        { 'playId': 132131112, 'name': '下盘' }
      ]
    }, {
      'playListGroupName': '奇偶',
      'playList': [
        { 'playId': 132131210, 'name': '奇盘' },
        { 'playId': 132131211, 'name': '和盘' },
        { 'playId': 132131212, 'name': '偶盘' }
      ]
    }
    ]
  }]
}]
