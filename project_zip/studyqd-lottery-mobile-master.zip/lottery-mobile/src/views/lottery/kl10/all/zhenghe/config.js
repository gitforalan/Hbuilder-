export default [{
  'playTabId': 13210,
  'playTabName': '整合',
  'playTypeList': [{
    'playTypeId': 1321010,
    'playTypeName': '第一球',
    'minChosen': 1,
    'maxChosen': 30,
    'playListGroup': [{
      'copy': true,
      'playListGroupName': '单码',
      'playList': [
        { 'playId': 132101010, 'name': '第一球' }
      ]
    }, {
      'playListGroupName': '两面',
      'playList': [
        { 'playId': 132101011, 'name': '大' },
        { 'playId': 132101012, 'name': '小' },
        { 'playId': 132101013, 'name': '单' },
        { 'playId': 132101014, 'name': '双' },
        { 'playId': 132101015, 'name': '合单' },
        { 'playId': 132101016, 'name': '合双' },
        { 'playId': 132101017, 'name': '尾大' },
        { 'playId': 132101018, 'name': '尾小' }
      ]
    }
    ]
  },
  {
    'playTypeId': 1321011,
    'playTypeName': '第二球',
    'minChosen': 2,
    'maxChosen': 8,
    'playListGroup': [{
      'copy': true,
      'playListGroupName': '单码',
      'playList': [
        { 'playId': 132101110, 'name': '第二球' }
      ]
    }, {
      'playListGroupName': '两面',
      'playList': [
        { 'playId': 132101111, 'name': '大' },
        { 'playId': 132101112, 'name': '小' },
        { 'playId': 132101113, 'name': '单' },
        { 'playId': 132101114, 'name': '双' },
        { 'playId': 132101115, 'name': '合单' },
        { 'playId': 132101116, 'name': '合双' },
        { 'playId': 132101117, 'name': '尾大' },
        { 'playId': 132101118, 'name': '尾小' }
      ]
    }
    ]
  },
  {
    'playTypeId': 1321012,
    'playTypeName': '第三球',
    'minChosen': 3,
    'maxChosen': 8,
    'playListGroup': [{
      'copy': true,
      'playListGroupName': '单码',
      'playList': [
        { 'playId': 132101210, 'name': '第三球' }
      ]
    }, {
      'playListGroupName': '两面',
      'playList': [
        { 'playId': 132101211, 'name': '大' },
        { 'playId': 132101212, 'name': '小' },
        { 'playId': 132101213, 'name': '单' },
        { 'playId': 132101214, 'name': '双' },
        { 'playId': 132101215, 'name': '合单' },
        { 'playId': 132101216, 'name': '合双' },
        { 'playId': 132101217, 'name': '尾大' },
        { 'playId': 132101218, 'name': '尾小' }
      ]
    }
    ]
  },
  {
    'playTypeId': 1321013,
    'playTypeName': '第四球',
    'minChosen': 4,
    'maxChosen': 8,
    'playListGroup': [{
      'copy': true,
      'playListGroupName': '单码',
      'playList': [
        { 'playId': 132101310, 'name': '第四球' }
      ]
    }, {
      'playListGroupName': '两面',
      'playList': [
        { 'playId': 132101311, 'name': '大' },
        { 'playId': 132101312, 'name': '小' },
        { 'playId': 132101313, 'name': '单' },
        { 'playId': 132101314, 'name': '双' },
        { 'playId': 132101315, 'name': '合单' },
        { 'playId': 132101316, 'name': '合双' },
        { 'playId': 132101317, 'name': '尾大' },
        { 'playId': 132101318, 'name': '尾小' }
      ]
    }
    ]
  },
  {
    'playTypeId': 1321014,
    'playTypeName': '第五球',
    'minChosen': 5,
    'maxChosen': 8,
    'playListGroup': [{
      'copy': true,
      'playListGroupName': '单码',
      'playList': [
        { 'playId': 132101410, 'name': '第五球' }
      ]
    }, {
      'playListGroupName': '两面',
      'playList': [
        { 'playId': 132101411, 'name': '大' },
        { 'playId': 132101412, 'name': '小' },
        { 'playId': 132101413, 'name': '单' },
        { 'playId': 132101414, 'name': '双' },
        { 'playId': 132101415, 'name': '合单' },
        { 'playId': 132101416, 'name': '合双' },
        { 'playId': 132101417, 'name': '尾大' },
        { 'playId': 132101418, 'name': '尾小' }
      ]
    }
    ]
  },
  {
    'playTypeId': 1321015,
    'playTypeName': '第六球',
    'minChosen': 5,
    'maxChosen': 8,
    'playListGroup': [{
      'copy': true,
      'playListGroupName': '单码',
      'playList': [
        { 'playId': 132101510, 'name': '第六球' }
      ]
    }, {
      'playListGroupName': '两面',
      'playList': [
        { 'playId': 132101511, 'name': '大' },
        { 'playId': 132101512, 'name': '小' },
        { 'playId': 132101513, 'name': '单' },
        { 'playId': 132101514, 'name': '双' },
        { 'playId': 132101515, 'name': '合单' },
        { 'playId': 132101516, 'name': '合双' },
        { 'playId': 132101517, 'name': '尾大' },
        { 'playId': 132101518, 'name': '尾小' }
      ]
    }
    ]
  },
  {
    'playTypeId': 1321016,
    'playTypeName': '第七球',
    'minChosen': 5,
    'maxChosen': 8,
    'playListGroup': [{
      'copy': true,
      'playListGroupName': '单码',
      'playList': [
        { 'playId': 132101610, 'name': '第五球' }
      ]
    }, {
      'playListGroupName': '两面',
      'playList': [
        { 'playId': 132101611, 'name': '大' },
        { 'playId': 132101612, 'name': '小' },
        { 'playId': 132101613, 'name': '单' },
        { 'playId': 132101614, 'name': '双' },
        { 'playId': 132101615, 'name': '合单' },
        { 'playId': 132101616, 'name': '合双' },
        { 'playId': 132101617, 'name': '尾大' },
        { 'playId': 132101618, 'name': '尾小' }
      ]
    }
    ]
  },
  {
    'playTypeId': 1321017,
    'playTypeName': '第八球',
    'minChosen': 5,
    'maxChosen': 8,
    'playListGroup': [{
      'copy': true,
      'playListGroupName': '单码',
      'playList': [
        { 'playId': 132101710, 'name': '第五球' }
      ]
    }, {
      'playListGroupName': '两面',
      'playList': [
        { 'playId': 132101711, 'name': '大' },
        { 'playId': 132101712, 'name': '小' },
        { 'playId': 132101713, 'name': '单' },
        { 'playId': 132101714, 'name': '双' },
        { 'playId': 132101715, 'name': '合单' },
        { 'playId': 132101716, 'name': '合双' },
        { 'playId': 132101717, 'name': '尾大' },
        { 'playId': 132101718, 'name': '尾小' }
      ]
    }
    ]
  }
  ]
}]
