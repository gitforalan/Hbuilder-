import { mapState, mapMutations, mapActions } from 'vuex'
import PlayTabList from './public/playTabList'
import SubHeader from '@/views/common/subHeader'
import ZPopoverMenu from '@/views/common/zPopoverMenu'
// import * as API from 'api/wapi/front'

// 整合
const zhenghe = () => import('./all/zhenghe')
// 两面
const liangmian = () => import('./all/liangmian')
// 龙虎斗
const lhd = () => import('./all/lhd')
// 任选
const renxuan = () => import('./all/renxuan')

export default {
  name: 'KL10',
  methods: {
    setCurrentPlay (id) {
      let map = {
        13210: zhenghe, // 整合
        13213: liangmian, // 两面
        13211: lhd, // 龙虎斗
        13212: renxuan // 任选
      }
      this.currentPlay = map[id]
    },
    onClickTitle () {
      if (this.isShowBack) return // 在弹出页时屏蔽标题事件
      this.showPlayTabList = !this.showPlayTabList
    },
    showPopoverMenu () {
      this.isShowPopoverMenu = !this.isShowPopoverMenu
    },
    onPopoverMenuHide () {
      this.delayExec(() => {
        this.isShowPopoverMenu = false
      })
    },
    hidePlayTabList () {
      this.delayExec(() => {
        this.showPlayTabList = false
      })
    },
    delayExec (fn) {
      setTimeout(fn, 20)
    },
    getMarginTop () {
      this.marginTop = this.$refs.currentInfo.$el.offsetHeight
    },
    ...mapActions('common', [
      'resetCommonState'
    ]),
    ...mapMutations('ui', ['set_singleRow']),
    ...mapMutations('kl10', [
      'updateShowBetConfirm'
    ])
  },
  watch: {
    playTabId (nval) {
      this.setCurrentPlay(nval)
    },
    noticeIssue (nval) {
      if (nval) {
        let options = {
          type: 'text',
          isShowMask: false,
          time: 2000,
          text: `第 ${this.currentIssue} 期已停止销售`
        }
        this.$vux.toast.show(options)
      }
    },
    isShowBetConfirm (val) {
      if (val) {
        this.set_singleRow(true)
      } else {
        this.set_singleRow(false)
      }
    }
  },
  computed: {
    isShowBack () {
      // 弹出购票车隐藏左上角回退 '<' 按钮
      return this.isShowBetConfirm
    },
    ...mapState('kl10', [
      'playTabName',
      'playTabId',
      'isShowBetConfirm'
    ]),
    ...mapState('common', [
      'lotteryTypeId',
      'lotteryId',
      'issue',
      'noticeIssue'
    ]),
    ...mapState('ui', {
      showPopoverPage: state => state.showPopoverPage
    })
  },
  data () {
    return {
      isShowPopoverMenu: false,
      showPlayTabList: false,
      marginTop: 0,
      currentPlay: null, // 当前玩法
      typeId: 13
    }
  },
  components: { SubHeader, PlayTabList, ZPopoverMenu },
  created () {
    this.setCurrentPlay(13210) // 初始化加载指定玩法
    this.set_singleRow(false) // 彩期模块显示全
  },
  mounted () {
    this.$nextTick(() => {
      this.getMarginTop()
    })
    window.scrollTo(0, 0)
  },
  beforeDestroy () {
    // this.resetCommonState()
    this.updateShowBetConfirm(false)
  }
}
