<!-- Created By fx on 2017/9/4. -->
<template>
  <div class="app-main">
    <div class="oldUser">
      <div class="old-user-txt">
        <span>账号登陆</span>
      </div>
      <div class="app-body">
        <group class="input-group" label-margin-right=".5em" label-align="right" gutter="-1px">
          <x-input v-model="loginForm.userName" placeholder="请输入用户名" name="userName" type="text">
            <icon-svg slot="label" icon-class="yonghu"></icon-svg>
          </x-input>
          <x-input v-model="loginForm.password" placeholder="请输入登录密码" type="password">
            <icon-svg slot="label" icon-class="ttpodicon"></icon-svg>
          </x-input>
        </group>
      </div>
      <div class="btn">
        <x-button type="warn" class="btn-submit" @click.native="submitForm()">登录</x-button>
        <x-button @click.native="goNoteLogin">手机短信登录</x-button>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import Vue from 'vue'
  import * as API from 'api/wapi/user'
  import { ConfirmPlugin, cookie } from 'vux'
  import { mapMutations } from 'vuex'
  import Encode from '@/utils/sha1'
  Vue.use(ConfirmPlugin)
  export default {
    data () {
      return {
        codeImg: '',
        loginForm: {
          userName: '',
          password: ''
        }
      }
    },
    created () {
      // 存在toKen 跳转到
      if (this.isToken()) {
        this.$router.push({ path: '/' })
      }
    },
    mounted () {
      // 设置样式
      document.querySelector('#app').style.background = '#f7f7f7'
      document.querySelector('#app').style.height = '100%'
      document.querySelector('body').style.height = '100%'
      document.querySelector('html').style.height = '100%'
    },
    methods: {
      // 是否存在token
      isToken () {
        return !!cookie.get('token')
      },

      // 短信登录
      goNoteLogin () {
        this.$router.push({ path: '/moldUser' })
      },

      // 登录
      submitForm () {
        if (this.validateForm()) {
          var encodePsw = new Encode().encodePsw(this.loginForm.password)
          var params = {
            'host': window.location.hostname,
            'loginId': this.loginForm.userName,
            'saltedPassword': encodePsw.token,
            'salt': encodePsw.salt
          }
          API.login(params).then(res => {
            if (!res.error && res.result) {
              this.setCookieToken({ 'token': res.result.sessionId })
              this.setCookieUserId({ 'userId': res.result.userId })
              this.setCookieUserName({ 'userName': this.loginForm.userName })
              this.setCookieLoginType({ 'loginType': res.result.regType === 'a' ? 'agent' : 'user' })

              // 绑定用户
              this.oauthUserBind(res.result)
            } else {
              sessionStorage.setItem('newUser', 'new')
              this.$vux.toast.show({
                type: 'warn',
                text: res.error.message
              })
            }
          })
        }
      },

      // 用户是否登录
      saveState (result) {
        var params = {
          userId: result.userId,
          loginId: result.loginId,
          sessionId: result.sessionId,
          openId: result.openId,
          openToken: result.openToken,
          regType: result.regType,
          expiry: result.expiry,
          sessionType: result.sessionType
        }
        API.saveState(params).then(res => {
        })
      },

      // 绑定用户
      oauthUserBind (loginResult) {
        var authUser = JSON.parse(sessionStorage.getItem('authUser'))
        var params = {
          openId: authUser.openId,
          host: window.location.hostname,
          sessionId: loginResult.sessionId
        }
        params.userId = loginResult.userId
        if (authUser.openToken) {
          params.openToken = authUser.openToken
        }
        API.userBind(params).then(res => {
          if (!res.error) {
            this.$vux.toast.show({
              type: `${+res.result === 1 ? 'success' : 'warn'}`,
              text: `${+res.result === 1 ? '绑定成功' : '绑定失败'}`
            })
            if (+res.result === 1) {
              // 用户是否登录
              this.saveState(loginResult)
              // toKen存入localStroage中后台使用
              localStorage.setItem('openToken', authUser.openToken)
              setTimeout(() => {
                this.$router.push({ path: '/' })  // 登录后跳回首页
              }, 30)
            }
          } else {
            this.$vux.toast.show({
              type: 'warn',
              text: res.error.message
            })
          }
        })
      },

      validateForm () {
        if (!/\S/.test(this.loginForm.userName)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '请输入用户名'
          })
          return false
        }
        if (!/\S/.test(this.loginForm.password)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '请输入登录密码'
          })
          return false
        }
        return true
      },
      ...mapMutations(['setCookieToken', 'setCookieUserId', 'setCookieUserName', 'setCookieLoginType'])
    }
  }
</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .app-main
    display flex
    justify-content center
    align-items center
    height 100%
    .oldUser
      background $color-gray-e
      padding rem(30) rem(10)
      .old-user-txt
        text-align center
        line-height rem(80)  
  .other-login
    margin 0 auto
    margin-top rem(200)
    padding-top rem(20)
    padding-left rem(20)
    padding-right rem(20)
    text-align center
  .other-txt
    setTopLine()
    position relative
    margin-bottom rem(30)
    span
      position absolute
      top 50%
      left 50%
      padding 0 rem(20)
      background $color-white
      transform translate(-50%, -50%)
  .other-icon
    margin-top rem(20)
    i
      margin-left rem(20)
  div
    .input-group
      width 90%
      margin-left 5%
      .weui-cell__hd i
        width 1.8rem
        height 1.8rem
        padding-right .5rem
        color $color-gray

    .btn
      width rem(630)
      // height rem(72)
      line-height rem(72)
      // background $color-red
      color $color-white
      margin 0 auto
      border-radius 5px
      margin-top rem(100)
      font-size $size-medium
      button
        font-size $size-small
        overflow visible
        height 100%
    .register-btn
      margin-top rem(54)
      button
        color $color-red
    .forget
      width 90%
      margin 0 auto
      font-size $size-medium
      color #4933f8
      padding-top rem(16)
      cursor: pointer
    .btn-submit {
      background-color: #f55
    }
</style>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .input-group .weui-cells
    font-size $size-medium
    .weui-cell:before
      left 0

  .is-agree
    .vux-check-icon .weui-icon-success, .vux-check-icon .weui-icon-circle
      font-size $size-medium
</style>
