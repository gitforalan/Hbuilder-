<!-- Created By fx on 2017/9/4. -->
<template>
  <div class="app-main">
    <div class="moldUser">
      <div class="old-user-txt">
        <span>账号登陆</span>
      </div>
      <div class="app-body">
        <group class="input-group" label-margin-right=".5em" label-align="right" gutter="-1px">
          <x-input v-model="loginForm.mobile" placeholder="手机号码" name="mobile" type="text">
            <icon-svg slot="label" icon-class="icon-test"></icon-svg>
          </x-input>
          <x-input v-model="loginForm.sms" :max="6" placeholder="短信验证" type="text" class="sms">
            <!-- <icon-svg slot="label" icon-class="ttpodicon"></icon-svg> -->
          </x-input>
          <span class="ver-code" v-if="timeShow">{{No}}秒之后再试</span>
          <span class="ver-code" v-else @click="getSmsSend">获取验证码</span>
        </group>
      </div>
      <div class="btn">
        <x-button type="warn" class="btn-submit" @click.native="submitLogin()">登录</x-button>
        <x-button @click.native="goPassLogin">用户密码登录</x-button>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import Vue from 'vue'
  import * as API from 'api/wapi/user'
  import { ConfirmPlugin, cookie } from 'vux'
  import { mapMutations } from 'vuex'
  Vue.use(ConfirmPlugin)
  export default {
    data () {
      return {
        codeImg: '',
        timeShow: false,
        timer: '',
        No: 60,
        loginForm: {
          sms: '',
          mobile: ''
        }
      }
    },
    created () {
      // 存在toKen 跳转到
      if (this.isToken()) {
        this.$router.push({ path: '/' })
      }
    },
    mounted () {
      // 设置样式
      document.querySelector('#app').style.background = '#f7f7f7'
      document.querySelector('#app').style.height = '100%'
      document.querySelector('body').style.height = '100%'
      document.querySelector('html').style.height = '100%'
    },
    methods: {

      // 发送验证码
      getSmsSend () {
        var reg = /\d+/
        if (!reg.test(this.loginForm.mobile)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '请输入正确手机号'
          })
          return false
        }
        var params = {
          mobile: this.loginForm.mobile
        }
        API.smsSend(params).then(res => {
          if (!res.error) {
            if (res.result && +res.result === 1) {
              this.timeShow = true
              this.smsTime()
            }
          } else {
            this.$vux.toast.show({
              type: 'warn',
              text: res.error.message
            })
          }
        })
      },

      // 验收手机验证码
      checkSms () {
        var params = {
          mobile: this.loginForm.mobile,
          authcode: this.loginForm.sms
        }
        API.smsCheck(params).then(res => {
          if (!res.error) {
            if (res.result && +res.result === 1) {
              this.submitForm()
            }
          } else {
            this.$vux.toast.show({
              type: 'warn',
              text: res.error.message
            })
          }
        })
      },

      // 设置时间
      smsTime () {
        this.timer = setInterval(() => {
          this.No--
          if (this.No === 0) {
            this.No = 60
            clearInterval(this.timer)
            this.timeShow = false
          }
        }, 1000)
      },

      // 是否存在token
      isToken () {
        return !!cookie.get('token')
      },

      // 用户密码登录
      goPassLogin () {
        this.$router.push({ path: '/oldUser' })
      },

      submitLogin () {
        if (this.validateForm('loginParent')) {
          this.checkSms()
        }
      },

      // 登录
      submitForm () {
        if (this.validateForm('loginParent')) {
          var params = {
            'host': window.location.hostname,
            'loginMobile': this.loginForm.mobile,
            'authCode': this.loginForm.sms
          }
          API.mobileLogin(params).then(res => {
            if (!res.error && res.result) {
              this.setCookieToken({ 'token': res.result.sessionId })
              this.setCookieUserId({ 'userId': res.result.userId })
              this.setCookieUserName({ 'userName': this.loginForm.userName })
              this.setCookieLoginType({ 'loginType': res.result.regType === 'a' ? 'agent' : 'user' })

              // 绑定用户
              this.oauthUserBind(res.result)
            } else {
              sessionStorage.setItem('newUser', 'new')
              this.$vux.toast.show({
                type: 'warn',
                text: res.error.message
              })
            }
          })
        }
      },

      // 绑定用户
      oauthUserBind (loginResult) {
        var authUser = JSON.parse(sessionStorage.getItem('authUser'))
        var params = {
          openId: authUser.openId
        }
        params.userId = loginResult.userId
        if (authUser.openToken) {
          params.openToken = authUser.openToken
        }
        if (this.loginForm.mobile) {
          params.mobile = this.loginForm.mobile
        }
        API.userBind(params).then(res => {
          if (!res.error) {
            this.$vux.toast.show({
              type: `${+res.result === 1 ? 'success' : 'warn'}`,
              text: `${+res.result === 1 ? '绑定成功' : '绑定失败'}`
            })
            if (+res.result === 1) {
              // toKen存入localStroage中后台使用
              localStorage.setItem('openToken', authUser.openToken)
              setTimeout(() => {
                this.$router.push({ path: '/' })  // 登录后跳回首页
              }, 30)
            }
          } else {
            this.$vux.toast.show({
              type: 'warn',
              text: res.error.message
            })
          }
        })
      },

      validateForm (loginParent) {
        var reg = /\d+/
        if (!reg.test(this.loginForm.mobile)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '请输入正确手机号'
          })
          return false
        }
        if (!reg.test(this.loginForm.sms)) {
          this.$vux.toast.show({
            type: 'warn',
            text: `${loginParent === 'loginParent' ? '请输入验证码' : '请输入正确验证码'}`
          })
          return false
        }
        return true
      },
      ...mapMutations(['setCookieToken', 'setCookieUserId', 'setCookieUserName', 'setCookieLoginType'])
    }
  }
</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .app-main
    display flex
    justify-content center
    align-items center
    height 100%
    .moldUser
      background $color-gray-e
      padding rem(30) rem(10)
      .old-user-txt
        text-align center
        line-height rem(80)
      .ver-code
        position absolute
        right 15px
        bottom rem(20)
        serLine()
        border 1px solid #ccc
        padding rem(2) rem(6)
  .other-login
    margin 0 auto
    margin-top rem(200)
    padding-top rem(20)
    padding-left rem(20)
    padding-right rem(20)
    text-align center
  .other-txt
    setTopLine()
    position relative
    margin-bottom rem(30)
    span
      position absolute
      top 50%
      left 50%
      padding 0 rem(20)
      background $color-white
      transform translate(-50%, -50%)
  .other-icon
    margin-top rem(20)
    i
      margin-left rem(20)
  div
    .input-group
      width 92%
      margin-left 3%
      .weui-cell__hd i
        width 1.8rem
        height 1.8rem
        padding-right .5rem
        color $color-gray

    .btn
      width rem(630)
      // height rem(72)
      line-height rem(72)
      // background $color-red
      color $color-white
      margin 0 auto
      border-radius 5px
      margin-top rem(100)
      font-size $size-medium
      button
        font-size $size-small
        overflow visible
        height 100%
    .register-btn
      margin-top rem(54)
      button
        color $color-red
    .forget
      width 90%
      margin 0 auto
      font-size $size-medium
      color #4933f8
      padding-top rem(16)
      cursor: pointer
    .btn-submit {
      background-color: #f55
    }
</style>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .input-group .weui-cells
    font-size $size-medium
    .weui-cell:before
      left 0
  .app-main
    .sms
      .weui-cell__ft
        margin-right rem(190)
    .vux-x-input .weui-icon
      padding-left 0    
 
  .is-agree
    .vux-check-icon .weui-icon-success, .vux-check-icon .weui-icon-circle
      font-size $size-medium
</style>
