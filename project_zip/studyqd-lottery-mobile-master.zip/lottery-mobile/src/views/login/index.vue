<!-- Created By fx on 2017/9/4. -->
<template>
  <div class="app-main">
    <div class="app-body">
      <group class="input-group" label-margin-right=".5em" label-align="right" gutter="-1px">
        <x-input v-model.trim="loginForm.userName" placeholder="请输入用户名" name="userName" type="text">
          <icon-svg slot="label" icon-class="yonghu"></icon-svg>
        </x-input>
        <x-input v-model="loginForm.password" placeholder="请输入登录密码" type="password">
          <icon-svg slot="label" icon-class="ttpodicon"></icon-svg>
        </x-input>
        <x-input v-model="loginForm.code" placeholder="请输入验证码" type="tel">
          <icon-svg slot="label" icon-class="yanzhengma"></icon-svg>
          <img slot="right" :src="codeImg" alt="" @click="getCodeImg" width="80" height="30" style="vertical-align: middle">
        </x-input>
      </group>
    </div>
    <div class="flex">
      <a v-if="showAgentReg" class="forget" align="left" href="javascript:;" @click="$router.push({path: '/agentReg'})">代理注册</a>
      <div class="forget" align="right" @click="forgetPassowrd()">忘记密码？</div>
    </div>
    <div class="btn">
      <x-button type="warn" class="btn-submit" @click.native="submitForm()">登录</x-button>
    </div>
    <div class="btn register-btn">
      <x-button type="default" @click.native="$router.push({ path: '/register' })">立即注册</x-button>
    </div>
    <!-- <div class="btn register-btn">
      <x-button type="default">免费试玩</x-button>
    </div> -->

    <div class="other-login">
      <div class="other-txt">
        <span>其它登录方式</span>
      </div>
      <div class="other-icon">
        <icon-svg icon-class="qq" @click.native="qqLogin"></icon-svg>
        <icon-svg v-if="isWeChat" icon-class="weixin1" @click.native="weChatLogin"></icon-svg>
      </div>
    </div>

  </div>
</template>

<script type="text/ecmascript-6">
  import Vue from 'vue'
  import * as API from 'api/wapi/user'
  import { cookie, ConfirmPlugin } from 'vux'
  import { mapMutations } from 'vuex'
  import Encode from '@/utils/sha1'
  Vue.use(ConfirmPlugin)
  export default {
    data () {
      return {
        sn: '',
        showAgentReg: false,
        isWeChat: true,
        codeImg: '',
        loginForm: {
          userName: '',
          password: '',
          code: '',
          captchaKey: ''
        }
      }
    },
    created () {
      this.getCodeImg()
      this.getSn().then(res => {
        if (!res.error && res.result) {
          this.sn = res.result
          this.getShowAgentReg()
        }
      })
    },
    mounted () {
      document.querySelector('#app').style.background = '#fff'
      this.isWeChat = this.isWeixin()
    },
    methods: {
      getSn () {
        return API.getSn({ host: window.location.hostname })
      },
      getShowAgentReg () {
        API.showAgentReg({sn: this.sn}).then(res => {
          if (!res.error && res.result) {
            if (+res.result.agentRegFlag === 1) {
              this.showAgentReg = false
            } else {
              this.showAgentReg = false
            }
            this.showAgentReg = true
          } else {
            this.showAgentReg = false
          }
        })
      },
      // 微信登录
      weChatLogin () {
        var params = {
          oauthType: 1, // 认证类型 1、微信公众平台 2、微信开放平台 3、qq 默认为1
          host: window.location.hostname
        }
        // window.location.href = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx95d3cbf76035802a&redirect_uri=http%3A%2F%2Ffangfumin1985.oicp.net%2Factivity%2Fwxlogin.html&response_type=code&scope=snsapi_userinfo&state=122#wechat_redirect'
        API.oauthConfig(params).then(res => {
          if (!res.error) {
            if (res.result) {
              // 登录
              window.location.href = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${res.result.item.appId}&redirect_uri=${encodeURIComponent(res.result.item.redirectUri)}&response_type=code&scope=snsapi_userinfo&state=122#wechat_redirect`
              // window.location.href = `https://open.weixin.qq.com/sns/explorer_broker?appid=${res.result.item.appId}&redirect_uri=${encodeURIComponent(res.result.item.redirectUri)}&response_type=code&scope=snsapi_userinfo&state=122&connect_redirect=1#wechat_redirect`
            }
          } else {
            this.$vux.toast.show({
              type: 'warn',
              text: res.error.message
            })
          }
        })
      },

      // QQ登录
      qqLogin () {
        var params = {
          oauthType: 3 // 认证类型 1、微信公众平台 2、微信开放平台 3、qq 默认为1
        }
        API.oauthConfig(params).then(res => {
          if (!res.error) {
            if (res.result) {
            }
          }
        })
      },

      // 获取验证码
      getCodeImg () {
        this.loginForm.captchaKey = parseInt(Math.random() * 100000000)
        this.codeImg = window.API_PATH + '/cloud/api.do?pa=captcha.next&key=' + this.loginForm.captchaKey
      },
      // 登录
      submitForm () {
        if (this.validateForm()) {
          var encodePsw = new Encode().encodePsw(this.loginForm.password)
          var params = {
            'host': window.location.hostname,
            'loginId': this.loginForm.userName,
            'saltedPassword': encodePsw.token,
            'salt': encodePsw.salt,
            'captchaKey': this.loginForm.captchaKey,
            'captchaCode': this.loginForm.code
          }
          API.login(params).then(res => {
            if (!res.error && res.result) {
              this.setCookieToken({ 'token': res.result.sessionId })
              this.setCookieUserId({ 'userId': res.result.userId })
              this.setCookieUserName({ 'userName': this.loginForm.userName })
              this.setCookieLoginType({ 'loginType': res.result.regType === 'a' ? 'agent' : 'user' })
              this.setCookieSn({sn: res.result.sn})
              this.$route.query.flag === 0
                ? this.$router.push({ path: '/home' }) // 首页
                : this.$router.back() // 原页面
            } else {
              this.$vux.toast.show({
                type: 'warn',
                text: res.error.message
              })
            }
          })
        }
      },

      // 判断是否是微信
      isWeixin () {
        var ua = window.navigator.userAgent.toLowerCase()
        return `${ua.match(/MicroMessenger/i)}` === 'micromessenger'
      },
      validateForm () {
        if (!/\S/.test(this.loginForm.userName)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '请输入用户名'
          })
          return false
        }
        if (!/\S/.test(this.loginForm.password)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '请输入登录密码'
          })
          return false
        }
        if (!/\S/.test(this.loginForm.code)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '请输入验证码'
          })
          return false
        }
        return true
      },
      // 忘记密码
      forgetPassowrd () {
        var self = this
        this.$vux.confirm.show({
          title: '请联系客服',
          onConfirm () {
            var onlineCustomerServiceUrl = cookie.get('onlineCustomerServiceUrl')
            if (!onlineCustomerServiceUrl || !/\S/.test(onlineCustomerServiceUrl)) {
              var params = {
                'domain': window.location.hostname
              }
              API.snInfo(params).then(res => {
                if (!res.error && res.result) {
                  self.setCustomerServiceUrl({ 'onlineCustomerServiceUrl': res.result.onlineCustomerServiceUrl })
                  window.location.href = res.result.onlineCustomerServiceUrl
                } else {
                  self.$vux.toast.show({
                    type: 'warn',
                    text: res.error.message
                  })
                }
              })
            } else {
              window.location.href = onlineCustomerServiceUrl
            }
          }
        })
      },
      ...mapMutations(['setCookieSn', 'setCookieToken', 'setCookieUserId', 'setCookieUserName', 'setCookieLoginType', 'setCustomerServiceUrl'])
    }
  }
</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .other-login
    margin 0 auto
    margin-top rem(200)
    padding-top rem(20)
    padding-left rem(20)
    padding-right rem(20)
    text-align center
  .other-txt
    setTopLine()
    position relative
    margin-bottom rem(30)
    span
      position absolute
      top 50%
      left 50%
      padding 0 rem(20)
      background $color-white
      transform translate(-50%, -50%)
  .other-icon
    margin-top rem(20)
    i
      margin-left rem(20)
  div
    .input-group
      border 1px solid $color-border
      border-bottom none
      margin-top 3rem
      width 90%
      margin-left 5%
      .weui-cell__hd i
        width 1.8rem
        height 1.8rem
        padding-right .5rem
        color $color-gray

    .btn
      width rem(546)
      height rem(72)
      line-height rem(72)
      background $color-red
      color $color-white
      margin 0 auto
      border-radius 5px
      margin-top rem(124)
      font-size $size-medium
      button
        font-size $size-small
        overflow visible
        height 100%
    .register-btn
      margin-top rem(54)
      button
        color $color-red
    .forget
      font-size $size-medium
      color #4933f8
      padding-top rem(16)
      cursor: pointer
      flex 1
    .btn-submit {
      background-color: #f55
    }
    .flex
      display flex
      width 90%
      margin 0 auto
</style>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .input-group .weui-cells
    font-size $size-medium
    .weui-cell:before
      left 0

  .is-agree
    .vux-check-icon .weui-icon-success, .vux-check-icon .weui-icon-circle
      font-size $size-medium
</style>
