<template>
  <div class="app-main page-login" v-if="userState">
    <group class="login-state-icon">
      <x-button @click.native="newUser">
        <icon-svg icon-class="yonghu"></icon-svg>
        我是新用户
      </x-button>
      <x-button @click.native="oldUser">
        <icon-svg icon-class="yonghu"></icon-svg>
        我是老用户
      </x-button>
    </group>
  </div>
</template>

<script>
import * as API from 'api/wapi/user'
import { mapMutations } from 'vuex'
import { cookie } from 'vux'
const qs = require('querystring')

export default {
  data () {
    return {
      userState: false,
      authUser: {}
    }
  },
  created () {
    this.checkOauthLogin()
  },
  mounted () {
    // 设置样式
    document.querySelector('#app').style.background = '#f7f7f7'
    document.querySelector('#app').style.height = '100%'
    document.querySelector('body').style.height = '100%'
    document.querySelector('html').style.height = '100%'
  },
  methods: {
    // 新用户
    newUser () {
      // 注册用户
      var params = {
        openId: this.authUser.openId,
        host: window.location.hostname
      }
      if (this.authUser.nickName) {
        params.nickName = this.authUser.nickName
      }
      if (this.authUser.openToken) {
        params.openToken = this.authUser.openToken
      }
      API.userRegiest(params).then(res => {
        if (!res.error && res.result) {
          if (res.result.user) {
            this.setCookieToken({ 'token': res.result.user.sessionId })
            this.setCookieUserId({ 'userId': res.result.user.userId })
            this.setCookieLoginType({ 'loginType': res.result.user.regType === 'a' ? 'agent' : 'user' })
            cookie.set('sn', res.result.sn)

            this.getProfile(res.result.user.sessionId)
            // 用户是否登录
            this.saveState(res.result)
          } else {
            this.$vux.toast.show({
              type: 'warn',
              text: '新用户注册失败'
            })
            // 跳转到登录注册界面
            this.$router.push({ path: '/login' })
          }
        } else {
          this.$vux.toast.show({
            type: 'warn',
            text: res.error.message
          })
        }
      })
    },
    // 老用户
    oldUser () {
      // this.checkOauthLogin()
      this.$router.push({ path: '/oldUser' })
    },
    // 用户基本信息
    getProfile (sessionId) {
      var params = {
        sessionId: sessionId
      }
      API.getUserProfile(params).then(res => {
        if (!res.error) {
          this.setCookieUserName({ 'userName': this.authUser.nickName })
          this.$router.push({ path: '/' })
        }
      })
    },

    // 用户是否登录
    saveState (result) {
      var params = {
        userId: result.userId,
        loginId: result.loginId,
        sessionId: result.sessionId,
        openId: result.openId,
        openToken: result.openToken,
        regType: result.regType,
        expiry: result.expiry,
        sessionType: result.sessionType
      }
      API.saveState(params).then(res => {
      })
    },

    checkOauthLogin () {
      var params = {
        host: window.location.hostname
      }
      var serchParamObj = qs.parse(window.location.search.substring(1, window.location.search.length))
      params.oauthType = 1 // 认证类型 1、微信公众平台 2、微信开放平台 3、qq 默认为1
      if (serchParamObj && serchParamObj.code) {
        params.code = serchParamObj.code
      }
      if (serchParamObj && serchParamObj.state) {
        params.state = serchParamObj.state
      }
      API.oauthLogin(params).then(res => {
        if (!res.error) {
          if (res.result) {
            cookie.set('sn', res.result.sn)
            this.authUser = res.result.authUser // authUser 认证用户信息
            sessionStorage.setItem('authUser', JSON.stringify(res.result.authUser))
            if (res.result.user && Object.keys(res.result.user).length > 0) { // 老用户
              if (res.result.user.sessionId) {
                // 存在sessionId 表示已经登录跳转到首页
                this.setCookieToken({ 'token': res.result.user.sessionId })
                this.setCookieUserId({ 'userId': res.result.user.userId })
                this.setCookieLoginType({ 'loginType': res.result.user.regType === 'a' ? 'agent' : 'user' })
                cookie.set('sn', res.result.sn)

                this.$router.push({ path: '/home' })
              } else {
                // 跳转老用户登录界面
                this.$router.push({ path: '/oldUser' })
              }
            } else {  // 新用户
              this.userState = true
            }
          }
        }
      })
    },
    ...mapMutations(['setCookieToken', 'setCookieUserId', 'setCookieUserName', 'setCookieLoginType', 'setCustomerServiceUrl'])
  }
}
</script>

<style lang="stylus">
@import "~@/assets/baseStylus/variable"

.page-login
  height 100%
  .login-state-icon
    display flex
    justify-content center
    align-items center
    height 100%
  .weui-cells
    width rem(628)
    height rem(480)
    padding 0 rem(30)
    background $color-gray-e
    button.weui-btn:first-child
      background #feb300
      margin-top rem(120)
    button.weui-btn:last-child
      background #ff5151
      margin-top rem(40)
    button.weui-btn
      color $color-white
      display flex
      justify-content center
      align-items center
    .lott-icon
      margin-right rem(10)
</style>
