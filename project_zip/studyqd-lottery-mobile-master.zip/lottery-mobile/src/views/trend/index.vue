<template>
  <div class="app-main page-trend" ref="appMain">
    <x-header :title="title" class="is-fixed" style="z-index:300"></x-header>
    <div class="app-body">
      <div class="menuArea" v-show="menuAreaReady">
        <div class="lotteryMenu">
          <selector :options="lotteryList"
                    v-model="defaultValue"
                    class="select"
                    @on-change="change"
                    resetstyle></selector>
          <!--<span>重庆时时彩-->
          <!--</span>-->
        </div>
        <icon-svg icon-class="down" class="icon_down"></icon-svg>
        <div class="set" @click="openSet">
          <icon-svg icon-class="shezhi" class="icon"></icon-svg>
          <div class="font">
            设置
          </div>
        </div>
      </div>




      <div class="listMain">
        <div class="listTitle" v-show="result">
          <div class="leftPart">
            <!--选项卡区域-->
            <v-touch @panstart="onPanstart"
                     @panmove="onPanMove"
                     @panend="onPanend"
                     class="vTouch"
                     tag="div">
              <tab bar-active-color="#ff5151"
                   :line-width="1"
                   active-color="#ff5151"
                   ref="tab" style="left:0">
                <tab-item :selected="firstTable || sixTable"
                          class="tabItem"
                          @on-item-click="openFirstTable"
                          ref="firstTabItem">开奖结果</tab-item>
                <tab-item :selected="!firstTable && !sixTable && index === 0"
                          class="tabItem"
                          v-for="(t, index) in headInfo"
                          @on-item-click="openSecondTable(index)"
                          :key="index"
                          ref="tabItems">
                  {{t.name}}走势
                </tab-item>
              </tab>
            </v-touch>
            <!--选项卡结束-->
          </div>
          <div class="rightPart" ref="right">
            <div class="iconBox">
              <icon-svg icon-class="right" class="icon" @click.native="moveTab"></icon-svg>
            </div>
          </div>
        </div>

        <!--通用开奖结果表-->
        <div class="shishicai_table" ref="table" v-if="firstTable">
          <div class="leftTable" ref="leftTable" :class="{'xbox-1':lotteryType === 16 || lotteryType === 14 || lotteryType === 12 || lotteryType === 15 || lotteryType === 18 || lotteryType === 19 || lotteryType === 13}">
            <div class="leftTitle">
              <div :class="{'ssc_issue':lotteryType === 10 || lotteryType === 11,
                            'ssl_issue':lotteryType === 16 || lotteryType === 12 || lotteryType === 18 || lotteryType === 19,
                            'pks_issue':lotteryType === 14 || lotteryType === 15 || lotteryType === 13}" v-if="ttIssue">期号
              </div>
              <div :class="{'ssc_openNum':lotteryType === 10 || lotteryType === 11,
                            'ssl_openNum':lotteryType === 16 || lotteryType === 12 || lotteryType === 18 || lotteryType === 19,
                            'pks_openNum':lotteryType === 14 || lotteryType === 15 || lotteryType === 13}" v-if="ttOpenNum">开奖号码
              </div>
              <div :class="{'ssc_weishu':lotteryType === 10 || lotteryType === 11,
                            'ssl_weishu':lotteryType === 16 || lotteryType === 12 || lotteryType === 18 || lotteryType === 19 || lotteryType === 13}"
                            v-for="x in headInfo"
                            v-if="lotteryType === 10 || lotteryType === 16 || lotteryType === 11 || lotteryType === 12 || lotteryType === 18 || lotteryType === 19">{{x.name}}
              </div>
            </div>
            <div class="tableBox" ref="tableBox">
              <table ref="shishicai_table" :class="{'xbox-1':lotteryType === 16 || lotteryType === 14 || lotteryType === 12 || lotteryType === 15 || lotteryType === 18 || lotteryType === 19 || lotteryType === 13}">
                <tr align="center"
                    v-for="(item, row) in trendList"
                    :class="{'bgc':!((row % 2) === 0)}"
                    class="tr_title">
                  <td :class="{'ssc_issue':lotteryType === 10 || lotteryType === 11,
                               'ssl_issue':lotteryType === 16 || lotteryType === 12 || lotteryType === 18 || lotteryType === 19,
                               'pks_issue':lotteryType === 14 || lotteryType === 15 || lotteryType === 13}">{{item.issue}}期</td>
                  <td :class="{'ssc_openNum':lotteryType === 10 || lotteryType === 11,
                               'ssl_openNum':lotteryType === 16 || lotteryType === 12 || lotteryType === 18 || lotteryType === 19,
                               'pks_openNum':lotteryType === 14 || lotteryType === 15}" v-if="lotteryType === 10 || lotteryType === 16 || lotteryType === 11 || lotteryType === 12 || lotteryType === 18 || lotteryType === 19">{{item.openNum}}</td>
                  <td class="openNum" v-if="lotteryType === 20">
                    <div flex="cross:center">
                      <div v-for="t in item.resultStr" style="margin: auto">{{t}}</div>
                    </div>
                  </td>
                  <td :class="{'ssc_weishu':lotteryType === 10 || lotteryType === 11,
                               'ssl_weishu':lotteryType === 16 || lotteryType === 12 || lotteryType === 18}" v-for="x in item.resultStr">{{x}}
                  </td>
                </tr>
              </table>
            </div>
          </div>
        </div>
        <!--通用开奖结果表结束-->

        <!--六合彩统计表-->
        <div class="sixTable" ref="table" v-if="sixTable">
          <table width="300%">
            <tr>
              <th>期数</th>
              <th>时间</th>
              <th>正码一</th>
              <th>正码二</th>
              <th>正码三</th>
              <th>正码四</th>
              <th>正码五</th>
              <th>正码六</th>
              <th>特码</th>
              <th class="sumBox">
                <div class="sum">
                  总和
                </div>
                <div class="sumList">
                  <div>总数</div>
                  <div>单双</div>
                  <div>大小</div>
                </div>
              </th>
              <th class="temaBox">
                <div class="tema">
                  特码
                </div>
                <div class="temaList">
                  <div>单双</div>
                  <div>大小</div>
                  <div>合单双</div>
                  <div>合大小</div>
                  <div>大小尾</div>
                </div>
              </th>
            </tr>
            <tr v-for="(item, row) in trendList">
              <td>{{item.issue}}</td>
              <td>{{item.resultTime}}</td>
              <td v-for="t in item.resultStr">{{t}}</td>
              <td class="sumList">
                <div v-for="t in item.sumList">{{t}}</div>
              </td>
              <td class="temaList">
                <div v-for="t in item.temaList">{{t}}</div>
              </td>
              <!--<td>-->
                <!--<div v-for="t in item.temaList">{{t}}</div>-->
              <!--</td>-->
            </tr>
          </table>
        </div>

        <!--通用走势表-->
        <div class="secondTable" v-if="secondTable">
          <!--表头-->
          <table class="tableTiele">
            <tr>
              <td :class="{'issue':lotteryType === 10 || lotteryType === 14 ||
                  lotteryType === 16 || lotteryType === 12 || lotteryType === 15 || lotteryType === 18 || lotteryType === 19, 'xuanIssue':lotteryType === 11}"></td>
              <td v-for="x in headerNum" :class="{'tw':lotteryType === 10 || lotteryType === 14 ||
                  lotteryType === 16 || lotteryType === 12 || lotteryType === 15 || lotteryType === 18 || lotteryType === 19, 'xuanW':lotteryType === 11}">{{x}}</td>
            </tr>
          </table>
          <!--数据区域-->
          <div class="posAreaBox">
            <div class="posArea">
              <!--遗漏数据层-->
              <div class="tabArea" ref="tabArea">
                <table>
                  <tr v-for="(item, row) in trendList" :class="{'bgc':((row % 2) === 0)}" :key="row">
                    <td :class="{'issue':lotteryType === 10 || lotteryType === 14 ||
                                         lotteryType === 16 || lotteryType === 12 || lotteryType === 18 || lotteryType === 19, 'xuanIssue':lotteryType === 11}"
                        ref="issueBox">
                    {{item.issue}}期</td>
                    <td v-for="(data, i) in datas[row]"
                        ref="numBox"
                        :class="{'tw':lotteryType === 10 || lotteryType === 14 || lotteryType === 16 ||
                                      lotteryType === 12 || lotteryType === 18 || lotteryType === 19, 'xuanW':lotteryType === 11}">
                      <div v-if="data==0" ref="bgNum"></div>
                      <div v-if="data!=0 && is_showLost">{{data}}</div>
                    </td>
                  </tr>
                  <tr v-for="(item, row) in statisticsList" v-if="is_showStatistics">
                    <td :class="{'issue':lotteryType === 10 || lotteryType === 14 ||
                                         lotteryType === 16 || lotteryType === 12 || lotteryType === 18, 'xuanIssue':lotteryType === 11}">
                    {{item.listName}}</td>
                    <td :class="{'tw':lotteryType === 10 || lotteryType === 14 ||
                                      lotteryType === 16 || lotteryType === 12 || lotteryType === 18, 'xuanW':lotteryType === 11}"
                        v-for="x in item.list">
                    {{x}}</td>
                  </tr>
                </table>
              </div>

              <!--折线数据层-->
              <div class="map" v-show="is_showLine">
                <svg version="1.1" width="100%" ref="svgBox">
                  <polyline points=""
                            style="fill:rgba(0,0,0,0);stroke:#ff5151;stroke-width:2" ref="polyline"/>
                </svg>
              </div>

              <!--中奖号码层-->
              <div class="tabAreaUp">
                <table>
                  <tr v-for="(item, row) in trendList">
                    <td :class="{'issue':lotteryType === 10 || lotteryType === 14 ||
                  lotteryType === 16 || lotteryType === 12 || lotteryType === 18 || lotteryType === 19, 'xuanIssue':lotteryType === 11}"></td>
                    <td v-for="(data, i) in datas[row]" :class="{'tw':lotteryType === 10 || lotteryType === 14 ||
                  lotteryType === 16 || lotteryType === 12 || lotteryType === 18 || lotteryType === 19, 'xuanW':lotteryType === 11}">
                      <div v-if="data==0" :class="{'colRed':data==0 && !double, 'colSkyBull':data==0 && double}">{{ headerNum[i] }}</div>
                      <div v-if="data!=0"></div>
                    </td>
                  </tr>
                </table>
              </div>
            </div>
          </div>
        </div>
        <!--通用走势表结束-->

        <!--lotteryType=15独立走势表-->
        <div class="pcddBox" v-if="pcddTable">
          <div class="pcddTable">
            <table class="pcddTableTitle" ref="pcddLeftTable">
              <tr>
                <th class="issue" style="border-top: none;"></th>
              </tr>
              <tr v-for="(item, row) in trendList">
                <td class="issue" ref="pcddissueBox">{{item.issue + '期'}}</td>
              </tr>
              <tr v-for="x in statisticsList">
                <td class="issue">{{x.listName}}</td>
              </tr>
            </table>
            <div style="overflow-x: auto;position: relative" ref="pcddArea">
              <table class="pcddTableTitle" style="position: absolute;z-index: 200;" ref="pcddTabArea">
                <tr>
                  <th v-for="x in headerNum">{{x}}</th>
                </tr>
                <tr v-for="(item, row) in trendList">
                  <td v-for="(data, i) in item.datas">
                    <div v-if="data==0" :class="{'colRed':data==0}"></div>
                    <div v-if="data!=0 && is_showLost">{{data}}</div>
                  </td>
                </tr>
                <tr v-for="x in statisticsList" v-if="is_showStatistics">
                  <td v-for="t in x.list">
                    <div>{{t}}</div>
                  </td>
                </tr>
              </table>
              <svg version="1.1" ref="pcddSvg" style="position: absolute;z-index: 300" v-if="is_showLine">
                <polyline points="200,200 100,100"
                          style="fill:rgba(0,0,0,0);stroke:#ff5151;stroke-width:2" ref="pcddPolyline"/>
              </svg>
              <table class="pcddTableTitle" style="position: absolute;z-index: 400;">
                <tr>
                  <th style="border: 1px solid transparent" v-for="x in headerNum"></th>
                </tr>
                <tr v-for="(item, row) in trendList">
                  <td v-for="(data, i) in item.datas" ref="pcddnumBox" style="border: 1px solid transparent">
                    <div v-if="data==0" :class="{'colRed':data==0}">{{ headerNum[i] }}</div>
                    <div v-if="data!=0"></div>
                  </td>
                </tr>
              </table>
            </div>
          </div>
        </div>
      </div>

      <div class="setWindow" v-if="setWindow">
        <div class="title">
          走势图设置
        </div>
        <div class="checkArea">
          <checklist :title="'期数'"
                     :options="issueCheckList"
                     v-model="issueCheckListFirst"
                     :min="1" :max="1" :required="true"
                     @on-change="setIssueChange"></checklist>
          <checklist :title="'折线'" :options="lineCheckList" v-model="lineCheckListFirst" :max="1" :min=1 @on-change="setLineChange"></checklist>
          <checklist :title="'遗漏'" :options="lostCheckList" v-model="lostCheckListFirst" :max="1" :min=1 @on-change="setLostChange"></checklist>
          <checklist :title="'统计'" :options="statisticsCheckList" v-model="statisticsCheckListFirst" :max="1"
                     :min="1" @on-change="setStatisticsChange"></checklist>
        </div>
        <div class="btnArea">
          <x-button class="cancel" @click.native="setCanel">取消</x-button>
          <x-button class="confirm" @click.native="setConfirm">确定</x-button>
        </div>
      </div>

      <div class="foot" v-show="footReady">
        <div class="countdown">
          距<span>{{newIssue}}</span>期投注截止:
          <span>{{countTime}}</span>
        </div>
        <div class="operation">
          <div class="btnBox">
            <x-button class="jumpBtn" @click.native="jump">再来一注</x-button>
          </div>
          <div class="refreshIcon" @click="refresh">
            <span>
              <icon-svg icon-class="shuaxin" class="icon"></icon-svg>
            </span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import ed from './script'

  export default ed
</script>

<style scoped lang="stylus">
  @import './style.styl'
</style>
<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .page-trend
    *[resetstyle].select
    .weui-select
      height rem(65)
      line-height rem(65)
      color red
    .weui-cell__bd:after
      border-style none!important

    *[resetstyle].checkArea
    .weui-cells__title
      width 20%
      line-height rem(70)
      margin-top 0
      margin-bottom 0
      padding-left 0
      padding-right 0
      font-size rem(30)
    .weui-cells
      width 80%
      padding 0 rem(10)
      background transparent
      font-size rem(30)
      .weui-cell
        width 50%
        float left
        height rem(70)
        line-height rem(70)
        padding 0
        .weui-cell__hd
          .weui-icon-checked:before
            font-size rem(40)
      .weui-cell:before
        border none!important
    .weui-cells:before
      border none!important
    .weui-cells:after
      border none!important
</style>
