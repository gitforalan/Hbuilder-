import SubHeader from 'views/common/subHeader'
import * as API from 'api/wapi/front'
import IconSvg from '@/components/icon-svg/index.vue'
import { dateConversions } from '@/utils/date'
import { xTimer } from '@/utils/timer/'
import { Checklist, cookie } from 'vux'
import { mapMutations } from 'vuex'

let nowTabLeft // 当前选项卡条的左浮动值
let winW = window.screen.width // 屏幕宽度
let rightW // 选项卡区最右边小箭头宽度
let tabW // 每一个选项卡的宽度
let criticalV // 左侧临界值
let tabBoxW // 当前一个选项的长度
let timeCount // 倒计时方法储存变量

export default {
  data () {
    return {
      result: false,
      ttIssue: false,
      ttOpenNum: false,
      menuAreaReady: false,
      footReady: false,
      defaultValue: '', // 彩种选择列表默认选项,默认在接口返回数据后使用时时彩一号位
      lotteryList: [], // 当前所有的彩种列表
      headInfo: [], // 选项卡区列表，默认只有一个开奖结果
      trendList: [], // 开奖结果列表,接口返回开奖期数、开奖号码、以及当期所有号码的遗漏信息,默认从最新一期开始查询30期
      reverseTrendList: [], // 开奖结果列表的颠倒数组,用于展示从第一期开始的开奖结果
      headerNum: [], // 走势表表头数组
      datas: [], // 走势表遗漏数据及开奖号码
      newIssue: '', // 当前彩种最新一期期号
      countTime: '', // 倒计时
      time: 0, // 当前彩种最新一期剩余开奖的时间,接口返回秒数
      firstTable: true, // 开奖结果表显示开关变量
      secondTable: false, // 通用走势表显示开关变量
      sixTable: false, // 六合彩走势表显示开关变量
      pcddTable: false, // PC蛋蛋走势表显示开关变量
      lotteryId: 0, // 当前彩种的ID
      lotteryType: 0, // 当前彩类的ID
      periods: 30, // 当前查询的期数
      statisticsList: [], // 统计区渲染数组
      winTotalNum: [], // '出现总次数'渲染数组
      avgMissNum: [], // '平均遗漏值'渲染数组
      maxMissNum: [], // '最大遗漏值'渲染数组
      maxSeriesNum: [], // '最大连出值'渲染数组
      setWindow: false, // 设置窗口显示开关变量
      double: false, // 折线颜色切换变量
      issueCheckList: [
        { key: '1', value: '近30期', num: '30' },
        { key: '2', value: '近50期', num: '50' },
        { key: '3', value: '近100期', num: '100' },
        { key: '4', value: '近200期', num: '200' }
      ], // 彩期数选择列表
      issueCheckListFirst: ['1'], // 彩期数选择列表默认的key
      lineCheckList: [
        { key: '1', value: '显示' },
        { key: '2', value: '隐藏' }
      ], // 折线选择列表
      lineCheckListFirst: ['1'], // 折线选择列表默认的key
      lostCheckList: [
        { key: '1', value: '显示' },
        { key: '2', value: '隐藏' }
      ], // 遗漏选择列表
      lostCheckListFirst: ['1'], // 遗漏选择列表默认的key
      statisticsCheckList: [
        { key: '1', value: '显示' },
        { key: '2', value: '隐藏' }
      ], // 统计选择列表
      statisticsCheckListFirst: ['1'], // 统计选择列表默认的key
      IssueChange: 1, // 彩期数选择结果
      LineChange: 1, // 折线选择结果
      LostChange: 1, // 遗漏选择结果
      StatisticsChange: 1, // 统计选择结果
      is_showLine: true, // 折线区显示开关变量
      is_showLost: true, // 遗漏显示开关变量
      is_showStatistics: true // 统计区显示开关变量
    }
  },
  components: {
    IconSvg,
    SubHeader,
    Checklist
  },
  computed: {
    title () {
      return '开奖走势' // 页面标题
    }
  },
  methods: {
    // 设置窗口彩期数选择 1 30期 2 50期 3 100期 4 200期
    setIssueChange (val) {
      if (val[0]) {
        this.IssueChange = parseInt(val[0])
      } else {
        this.issueCheckListFirst = [this.IssueChange.toString()]
      }
    },
    // 设置窗口折线显示开关 1 显示 2 关闭
    setLineChange (val) {
      if (val[0]) {
        this.LineChange = parseInt(val[0])
      } else {
        this.lineCheckListFirst = [this.LineChange.toString()]
      }
    },
    // 设置窗口遗漏显示开关 1 显示 2 关闭
    setLostChange (val) {
      if (val[0]) {
        this.LostChange = parseInt(val[0])
      } else {
        this.lostCheckListFirst = [this.LostChange.toString()]
      }
    },
    // 设置窗口统计显示开关 1 显示 2 关闭
    setStatisticsChange (val) {
      if (val[0]) {
        this.StatisticsChange = parseInt(val[0])
      } else {
        this.statisticsCheckListFirst = [this.StatisticsChange.toString()]
      }
    },
    // 设置窗口取消按钮
    setCanel () {
      // 全部选项返回默认项
      this.issueCheckListFirst = ['1']
      this.lineCheckListFirst = ['1']
      this.lostCheckListFirst = ['1']
      this.statisticsCheckListFirst = ['1']
      this.setIssueChange(this.issueCheckListFirst)
      this.setLineChange(this.lineCheckListFirst)
      this.setLostChange(this.lostCheckListFirst)
      this.setStatisticsChange(this.statisticsCheckListFirst)
      this.setConfirm()
    },
    // 设置窗口确认按钮
    setConfirm () {
      // 判断各选项的值,统一设置
      if (this.IssueChange === '') {
        this.IssueChange = 1 // 如果没有选择,使用默认选项
      }
      if (this.LineChange === '') {
        this.LineChange = 1
      }
      if (this.LostChange === '') {
        this.LostChange = 1
      }
      if (this.StatisticsChange === '') {
        this.StatisticsChange = 1
      }
      // 彩期选择结果
      switch (this.IssueChange) {
        case 1:
          this.periods = 30
          break
        case 2:
          this.periods = 50
          break
        case 3:
          this.periods = 100
          break
        case 4:
          this.periods = 200
          break
        default:
          this.periods = 30
      }
      // 折线选择结果
      switch (this.LineChange) {
        case 1:
          this.is_showLine = true
          break
        case 2:
          this.is_showLine = false
          break
        default:
          this.is_showLine = true
      }
      // 遗漏选择结果
      switch (this.LostChange) {
        case 1:
          this.is_showLost = true
          break
        case 2:
          this.is_showLost = false
          break
        default:
          this.is_showLost = true
      }
      // 统计选择结果
      switch (this.StatisticsChange) {
        case 1:
          this.is_showStatistics = true
          break
        case 2:
          this.is_showStatistics = false
          break
        default:
          this.is_showStatistics = true
      }
      if (this.lotteryType === 20) {
        this.getLotterySixTrend(this.lotteryId, this.periods) // 针对六合彩单独使用六合彩走势接口方法
      } else {
        this.getLotteryTrend(this.lotteryId, this.periods) // 通用走势接口方法
        this.openFirstTable()
        this.$refs.tab.$el.style.left = 0 + 'px'
      }
      this.setWindow = false // 关闭设置窗口
    },
    // 打开设置窗口
    openSet () {
      this.setWindow = true
    },
    // 彩种选择列表变动监控方法
    change (val) {
      console.log(val)
      let value = JSON.parse(val) // 返回的数据为字符串类型,需要转换成对象
      this.lotteryId = value.lotteryId
      this.lotteryType = value.lotteryTypeId
      if (this.lotteryType === 20) {
        // console.log(this.headInfo)
        this.getLotterySixTrend(this.lotteryId, this.periods) // 针对六合彩单独使用六合彩走势接口方法
      } else {
        this.getLotteryTrend(this.lotteryId, this.periods) // 通用走势接口方法
        this.getLotteryCurrentInfo(this.lotteryId)
        this.openFirstTable()
        this.$refs.tab.$el.style.left = 0 + 'px'
      }
    },
    // 计算界面元素动态样式
    Scroll_bar_calculation () {
      this.$refs.tab.$el.style.width = (this.headInfo.length + 1) * (winW * 0.3) + 'px'
      tabW = parseInt(this.$refs.tab.$el.style.width)
      tabBoxW = this.$refs.tab.$el.getElementsByTagName('*')[0].offsetWidth
      rightW = this.$refs.right.offsetWidth
      criticalV = -(tabW - winW + rightW)
      if (criticalV > 0) {
        criticalV = 0
      }
      // console.log('tabW=>' + tabW)
      // console.log('rightW=>' + rightW)
      // console.log('tabBoxW=>' + tabBoxW)
      // console.log('criticalV=>' + criticalV)
    },
    // 通用彩票走势接口方法
    getLotteryTrend (lotteryId, periods) {
      const query = {
        lotteryId: lotteryId,
        periods: periods
      }
      API.getLotteryTrend(query).then(res => {
        // console.log(res.data)
        // 清空所有列表数据
        this.trendList = []
        this.headInfo = []
        this.winTotalNum = []
        this.avgMissNum = []
        this.maxMissNum = []
        this.maxSeriesNum = []
        this.statisticsList = []
        this.headerNum = []
        // 选项卡数组拼数据
        res.data.headerInfo.position.map(i => {
          let obj = {}
          obj.name = i
          this.headInfo.push(obj)
        })
        this.result = true
        // 走势表表头数组拼数据
        for (let i = 0, b = res.data.headerInfo.beginNum; i < res.data.headerInfo.codeNum; i++) {
          this.headerNum.push(i + b)
        }
        // 计算选项卡宽度及各类样式
        this.Scroll_bar_calculation()
        this.trendList = res.data.trendList
        this.ttIssue = true
        this.ttOpenNum = true
        this.winTotalNum = res.data.winTotalNum
        this.avgMissNum = res.data.avgMissNum
        this.maxMissNum = res.data.maxMissNum
        this.maxSeriesNum = res.data.maxSeriesNum
        // 开奖结果表拼数据
        this.trendList.map(i => {
          i.openNum = i.resultStr.join(' ')
          i.issue = this.arrayOper(i.issue)
          i.resList = []
          i.resultStr.map((j, k) => {
            j = parseInt(j)
            if (j < 6) {
              if (j % 2 === 0) {
                i.resList.push('小双')
              } else {
                i.resList.push('小单')
              }
            } else {
              if (j % 2 === 0) {
                i.resList.push('大双')
              } else {
                i.resList.push('大单')
              }
            }
          })
        })
        // 选项卡默认使用第一个选项
        this.$refs.firstTabItem.selected = true
      }).catch(err => {
        // 无数据时隐藏所有表格
        this.sixTable = false
        this.headInfo = []
        this.firstTable = false
        this.secondTable = false
        this.pcddTable = false
        this.Scroll_bar_calculation()
        this.$vux.toast.show({
          type: 'warn',
          text: err.desc // 接口返回的错误信息
        })
      })
    },
    // 六合彩独立走势表接口
    getLotterySixTrend (lotteryId, periods) {
      const query = {
        lotteryId: lotteryId,
        periods: periods
      }
      API.getLotterySixTrend(query).then(res => {
        // console.log(res.data)
        this.trendList = []
        this.headInfo = []
        this.trendList = res.data.trendList
        this.trendList.map((i, k) => {
          let sumArr = []
          let temaList = []
          sumArr.push(i.totalNum) // totalNum => 总和总数
          // 根据接口返回信息使用特殊字符代替接口的数字
          if (i.gzds === 0) { // gzds => 总和单双
            sumArr.push('和')
          } else if (i.gzds === 1) {
            sumArr.push('单')
          } else if (i.gzds === 2) {
            sumArr.push('双')
          }
          if (i.gzdx === 0) { // gzdx => 总和大小
            sumArr.push('和')
          } else if (i.gzdx === 1) {
            sumArr.push('小')
          } else if (i.gzdx === 2) {
            sumArr.push('大')
          }
          if (i.gds === 0) { // gds => 特码单双
            temaList.push('和')
          } else if (i.gds === 1) {
            temaList.push('单')
          } else if (i.gds === 2) {
            temaList.push('双')
          }
          if (i.gdx === 0) { // gdx => 特码大小
            temaList.push('和')
          } else if (i.gdx === 1) {
            temaList.push('小')
          } else if (i.gdx === 2) {
            temaList.push('大')
          }
          if (i.ghds === 0) { // ghds => 特码合单双
            temaList.push('和')
          } else if (i.ghds === 1) {
            temaList.push('合单')
          } else if (i.ghds === 2) {
            temaList.push('合双')
          }
          if (i.ghdx === 0) { // ghdx => 特码合大小
            temaList.push('和')
          } else if (i.ghdx === 1) {
            temaList.push('合小')
          } else if (i.ghdx === 2) {
            temaList.push('合大')
          }
          if (i.gwdx === 0) { // gwdx => 特码大小尾
            temaList.push('和')
          } else if (i.gwdx === 1) {
            temaList.push('尾小')
          } else if (i.gwdx === 2) {
            temaList.push('尾大')
          }
          this.trendList[k].sumList = sumArr // 总和渲染数组
          this.trendList[k].temaList = temaList // 特码渲染数组
        })
        this.Scroll_bar_calculation()
        // 隐藏六合彩以外所有表
        this.sixTable = true
        this.firstTable = false
        this.secondTable = false
        this.pcddTable = false
      }).catch(err => {
        this.$vux.toast.show({
          type: 'warn',
          text: err.desc
        })
      })
    },
    // 当前彩种的各类信息,用于底部展示期数和倒计时以及跳转的目标页面
    getLotteryCurrentInfo (lotteryId) {
      const query = {
        lotteryId: lotteryId
      }
      API.getLotteryCurrentInfo(query).then(res => {
        this.footReady = true
        let lotteryInfo = res.data
        this.newIssue = this.arrayOper(lotteryInfo.issue) // 彩期转换后3位
        this.time = parseInt(lotteryInfo.time) // 剩余时间
        xTimer.clearInterval(timeCount) // 清空所有倒计时
        timeCount = xTimer.setInterval(this.countdown, 1000) // 开始倒计时
      }).catch(err => {
        // 接口故障,清空倒计时并显示默认数据
        xTimer.clearInterval(timeCount)
        this.newIssue = '000'
        this.time = 0
        this.countTime = dateConversions(this.time)
        this.$vux.toast.show({
          type: 'warn',
          text: err.desc
        })
      })
    },
    // 彩种列表接口方法
    getLotteryList () {
      API.getLotteryList().then(res => {
        // console.log(res.data.lotteryTypeList)
        let lotteryTypeList = []
        let lotteryList = []
        if (res.data.lotteryTypeList) {
          lotteryTypeList = res.data.lotteryTypeList
          lotteryTypeList.map(i => {
            i.lotteryList.map(j => {
              lotteryList.push(j) // 二维数组转换一维
            })
          })
          lotteryList.map((i, k) => {
            // 拼数据
            let obj = {}
            let val = {}
            val.lotteryId = i.lotteryId
            val.lotteryTypeId = i.lotteryTypeId
            obj.key = JSON.stringify(val) // VUX插件只接受字符串
            obj.value = i.lotteryName
            this.lotteryList.push(obj)
            if (i.lotteryId === 1001) {
              this.defaultValue = this.lotteryList[k].key // 默认时时彩的第一个彩种
            }
          })
        }
        this.menuAreaReady = true
      })
    },
    // 点击右箭头滚动tab
    moveTab () {
      tabBoxW = this.$refs.tab.$el.getElementsByTagName('*')[0].offsetWidth
      let left = parseInt(this.$refs.tab.$el.style.left)
      if (parseInt(this.$refs.tab.$el.style.left) <= (criticalV)) {
        return
      }
      this.$refs.tab.$el.style.left = left - tabBoxW + 'px'
    },
    // 滑动开始
    onPanstart (e) {
      nowTabLeft = parseInt(this.$refs.tab.$el.style.left)
      this.$refs.tab.$el.style.transition = 'none'
      tabBoxW = this.$refs.tab.$el.getElementsByTagName('*')[0].offsetWidth
    },
    // 滑动中
    onPanMove (e) {
      let eX = e.deltaX
      // 右滑处理
      if (eX > 0) {
        if (this.$refs.tab.$el.offsetLeft >= 0) {
          this.$refs.tab.$el.style.left = 0 + 'px'
        } else {
          this.$refs.tab.$el.style.left = nowTabLeft + e.deltaX + 'px'
        }
      }
      // 左滑处理
      if (eX < 0) {
        if (parseInt(this.$refs.tab.$el.style.left) <= (criticalV)) {
          this.$refs.tab.$el.style.left = (criticalV) + 'px'
        } else {
          this.$refs.tab.$el.style.left = nowTabLeft + e.deltaX + 'px'
        }
      }
    },
    // 滑动结束
    onPanend () {
      this.$refs.tab.$el.style.transition = 'all .3s ease'
    },
    // 剪切彩期数长度
    arrayOper (arr) {
      let string = arr.split('').reverse()
      string.length = 3
      string = string.reverse().join('')
      return string
    },
    // 倒计时方法
    countdown () {
      if (this.time === 0) {
        xTimer.clearInterval(timeCount)
      }
      if (this.time > 0) {
        this.time--
        this.countTime = dateConversions(this.time)
      }
    },
    // 刷新页面数据
    refresh () {
      xTimer.clearInterval(timeCount)
      this.getLotteryCurrentInfo(this.lotteryId)
    },
    // 开奖结果表打开方法
    openFirstTable () {
      if (this.lotteryType === 20) {
        this.sixTable = true
        this.firstTable = false
        this.secondTable = false
        this.pcddTable = false
      } else {
        this.firstTable = true
        this.secondTable = false
        this.pcddTable = false
        this.sixTable = false
      }
    },
    // 走势表打开方法
    openSecondTable (index) {
      // 确定当前选项是双数还是单数选项
      if (index % 2 === 0) {
        this.double = false // 用于确定折线的颜色
      } else {
        this.double = true
      }
      this.statisticsList = [] // 清空统计表的数据
      let numDigits = 0 // 开奖号码的位数
      switch (this.lotteryType) { // 根据彩种类型确定位数
        case 10:
          numDigits = 10
          break
        case 11:
          numDigits = 11
          break
        case 12:
          numDigits = 6
          break
        case 13:
          numDigits = 20
          break
        case 14:
          numDigits = 10
          break
        case 15:
          numDigits = 28
          break
        case 16:
          numDigits = 10
          break
        case 17:
          numDigits = 10
          break
        case 18:
          numDigits = 10
          break
        case 19:
          numDigits = 10
          break
        case 20:
          numDigits = 10
          break
        case 21:
          numDigits = 10
          break
        default:
          numDigits = 10
      }
      // 统计表数据
      for (let i = 0; i < 4; i++) {
        let objt = {}
        objt.list = []
        switch (i) {
          case 0:
            objt.listName = '出现总次数'
            for (let j = index * numDigits; j < (index * numDigits) + numDigits; j++) {
              objt.list.push(this.winTotalNum[j])
            }
            this.statisticsList.push(objt)
            break
          case 1:
            objt.listName = '平均遗漏值'
            for (let j = index * numDigits; j < (index * numDigits) + numDigits; j++) {
              objt.list.push(this.avgMissNum[j])
            }
            this.statisticsList.push(objt)
            break
          case 2:
            objt.listName = '最大遗漏值'
            for (let j = index * numDigits; j < (index * numDigits) + numDigits; j++) {
              objt.list.push(this.maxMissNum[j])
            }
            this.statisticsList.push(objt)
            break
          case 3:
            objt.listName = '最大连出值'
            for (let j = index * numDigits; j < (index * numDigits) + numDigits; j++) {
              objt.list.push(this.maxSeriesNum[j])
            }
            this.statisticsList.push(objt)
            break
        }
      }
      // 针对PCDD的特殊处理
      if (this.lotteryType === 15 || this.lotteryType === 13) {
        this.firstTable = false
        this.pcddTable = true
        let bgNumArr = []
        // console.log(this.trendList)
        // 13使用PCDD表
        this.trendList.map(i => {
          i.datas.map((j, k) => {
            if (j.toString() === '0') {
              bgNumArr.push(this.headerNum[k]) // 表头数据
            }
          })
        })
        // 计算折线数据
        this.$nextTick(() => {
          this.$refs.pcddArea.style.width = winW - parseFloat(window.getComputedStyle(this.$refs.pcddLeftTable).width) + 'px'
          let numBoxW = parseFloat(window.getComputedStyle(this.$refs.pcddnumBox[0]).width)
          let numBoxH = parseFloat(window.getComputedStyle(this.$refs.pcddnumBox[0]).height)
          let svgMapArr = []
          bgNumArr.map((i, k) => {
            let x = ((numBoxW) * i) + (numBoxW / 2)
            let y = numBoxH + (numBoxH / 2) + (numBoxH * k)
            let str = x + ',' + y
            svgMapArr.push(str)
          })
          let pointsString = svgMapArr.join(' ')
          this.$refs.pcddSvg.setAttribute('height', this.$refs.pcddTabArea.offsetHeight)
          this.$refs.pcddSvg.setAttribute('width', this.$refs.pcddTabArea.offsetWidth)
          this.$refs.pcddPolyline.setAttribute('points', pointsString)
        })
      } else {
        // 对通用走势表的处理
        this.firstTable = false
        this.secondTable = true
        this.datas = []
        this.trendList.map(i => {
          let arr = []
          for (let j = index * numDigits; j < (index * numDigits) + numDigits; j++) {
            arr.push(i.datas[j])
          }
          this.datas.push(arr)
        })
        let bgNumArr = []
        this.datas.map(i => {
          i.map((j, k) => {
            if (j.toString() === '0') {
              bgNumArr.push(this.headerNum[k]) // 表头数据
            }
          })
        })
        // 计算通用走势表折线数据
        this.$nextTick(() => {
          // 获取单个格子的宽高数据
          let issueBoxW
          let issueBoxH
          let numBoxW
          // 针对每一个彩种进行响应式处理
          switch (this.lotteryType) {
            case 10:
              issueBoxW = winW * 0.15
              numBoxW = winW * 0.085
              issueBoxH = parseFloat(window.getComputedStyle(this.$refs.issueBox[0]).height)
              break
            case 11:
              issueBoxW = winW * 0.12
              numBoxW = winW * 0.08
              issueBoxH = parseFloat(window.getComputedStyle(this.$refs.issueBox[0]).height)
              break
            default:
              issueBoxW = parseFloat(window.getComputedStyle(this.$refs.issueBox[0]).width)
              numBoxW = parseFloat(window.getComputedStyle(this.$refs.numBox[0]).width)
              issueBoxH = parseFloat(window.getComputedStyle(this.$refs.issueBox[0]).height)
          }
          // console.log('issueBoxW=>' + issueBoxW)
          // console.log('issueBoxH=>' + issueBoxH)
          // console.log('numBoxW=>' + numBoxW)
          let svgMapArr = []
          bgNumArr.map((i, k) => {
            // 针对type => 10、16的折线处理
            if (this.lotteryType === 10 || this.lotteryType === 16 ||
              this.lotteryType === 19 || this.lotteryType === 18) {
              let x = (issueBoxW + ((numBoxW) * i) + (numBoxW / 2)) // x轴坐标
              let y = (issueBoxH / 2) + (issueBoxH * k) // y轴坐标
              let str = x + ',' + y
              svgMapArr.push(str)
            }
            // 针对type => 14、11、12的折线处理
            if (this.lotteryType === 14 || this.lotteryType === 11 || this.lotteryType === 12) {
              let x = (issueBoxW + (numBoxW * (i - 1)) + (numBoxW / 2))
              let y = (issueBoxH / 2) + (issueBoxH * k)
              let str = x + ',' + y
              svgMapArr.push(str)
            }
            // 针对其他type的折线处理......(待补充)
          })
          // 折线坐标数据加入SVG标签
          let pointsString = svgMapArr.join(' ')
          this.$refs.svgBox.setAttribute('height', this.$refs.tabArea.offsetHeight)
          this.$refs.polyline.setAttribute('points', pointsString)
          if (index % 2 === 0) {
            this.$refs.polyline.style.stroke = '#ea5051' // 双数选项卡折线红色
          } else {
            this.$refs.polyline.style.stroke = '#009bac' // 单数选项卡折线天蓝色
          }
        })
      }
    },
    jump () {
      this.$router.push({ name: 'chunkComp', params: { sid: this.lotteryId } })
    },
    // 验证是否登录
    UserAuthValidate () {
      const userInfo = {}
      if (!cookie.get('token')) { // 这里优先取url带过来的token todo
        userInfo.status = 0
        this.update_userInfo(userInfo)
        this.$nextTick(() => {
          this.$router.push({ name: 'login' }) // 关闭登录验证
        })
        return
      }
      // loading
      this.$vux.loading.show()
      API.getUserAuthValidate().then(res => {
        // fields {"uid":String","loginId": String,"balance":int}
        const userInfo = res.data
        userInfo.status = 1
        this.update_userInfo(userInfo)
        this.init()
      }).catch(err => {
        userInfo.status = 0
        this.update_userInfo(userInfo)
        this.$router.push({ name: 'login' })
      }).then(() => {
        setTimeout(this.$vux.loading.hide, 300)
      })
    },
    init () {
      this.getLotteryList() // 首次创建页面时加载所有彩种数据
      this.countTime = dateConversions(this.time) // 返回默认倒计时数据
    },
    ...mapMutations('common', ['update_userInfo'])
  },
  created () {
    this.UserAuthValidate() // 验证是否登录
  },
  mounted () {
  },
  beforeRouteLeave (to, from, next) {
    xTimer.clearInterval(timeCount) // 离开路由清除所有定时器
    next()
  },
  watch: {}
}
