<!-- Created By fx on 2017/9/16. -->
<template>
  <div class="app-layout page-user page-user__findDetail">
    <div class="app-main">
      <x-header :title="title" class="is-fixed"></x-header>
      <div class="app-body">
        <h1 class="title">绝世双球 大乐透125期实战投注 上期中1+1</h1>
        <div class="slide"><time>2017-10-10 20:02</time><span>来源：转载500万</span><span>点击数：<b>1000</b></span></div>
        <article>
                 超级大乐透“35选5加12选2”投注方式多样，除单式投注外，也可
以进行胆拖投注、复式投注，每一基本投注金额为2元人民币。
       超级大乐透“35选5加12选2”最大的亮点是，购买者在基本投注的
基础上，可进行追加投注，每注可追加1元人民币。
       这样，体彩超级大乐透玩法单张彩票形成了2+1投注模式，即一张彩
票可以投注2元一注的基本投注，和1元的追加投注。
       规则中规定，超级大乐透单张彩票基本投注的最大投注金额不超过
20000元，基本投注加追加投注的最大投注金额不超过30000元。
       开奖日期：每周一、三、六开奖，
      上期开奖号码:03 29 30 32 35-03 08

        </article>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
    data () {
      return {
        title: '彩票资讯'
      }
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user__findDetail {
    line-height 1.5
    .title {
      color #434343
      font-size rem(28)
      text-align center
      padding rem(20) 0
      border-bottom solid 1px #eaeaea
    }
    .slide {
      color #9b9b9b
      text-align center
      font-size rem(22)
      padding rem(20) 0
      time {
        margin-right rem(50)
      }
      span:nth-of-type(1) {
        margin-right rem(50)
      }
      b {
        color $color-red
      }
    }
    .app-body {
      padding-bottom 0
      padding-left rem(20)
      padding-right rem(20)
    }
    article {
      color #434343
      font-size rem(22)
    }
  }
</style>
