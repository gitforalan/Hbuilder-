<template>
  <div class="app-layout page-user page-user__findList">
    <div class="app-main">
      <x-header :title="title" class="is-fixed"></x-header>
      <div class="app-body">
        <ul>
          <li v-for="row in 20" :key="row.key">
            <router-link to="/find/detail/1" class="ellipsis"><span>[推荐]</span>彩民命中8.76亿露脸称奖金要用来帮助亲戚</router-link>
          </li>
        </ul>
        <div class="getMore" v-if="pageData.total != 0"><span v-html="page.text"></span></div>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
    data () {
      return {
        title: '彩票资讯',
        page: {
          text: '更多&gt;&gt;',
          noMore: false
        },
        pageData: {
          pageIndex: 1,
          pageSize: 10,
          total: 0
        }
      }
    },
    created () {
      let name = this.$route.params.type
      if (name === 'lottery') {
        this.title = '彩票资讯'
      } else if (name === 'win') {
        this.title = '中奖快讯'
      }
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user__findList {
    .app-body {
      padding-bottom 0
    }
    ul {
      padding 0 rem(15)
    }
    li {
      a {
        padding 0 rem(30)
        font-size rem(24)
        color #434343
        display block
        line-height rem(70)
        span {
          margin-right rem(10)
          color $color-gray-b
        }
        border-bottom dashed 1px #eaeaea
      }
    }
  }
</style>
