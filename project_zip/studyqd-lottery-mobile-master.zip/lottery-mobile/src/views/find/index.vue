<!-- Created By fx on 2017/9/16. -->
<template>
  <div class="app-layout page-user page-user__find">
    <div class="app-main">
      <x-header :title="title" class="is-fixed"></x-header>
      <div class="app-body">
        <group class="user-menu" stylereset>
          <cell
            v-for="item in userMenuList"
            v-if="!item.isShow"
            :key="item.name"
            :title="item.name"
            :link="item.link"
            :is-link="item.isLink">
            <icon-svg slot="icon" :iconClass="item.iconCls" :style="{ 'color': item.iconColor }"></icon-svg>
          </cell>
        </group>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
    data () {
      return {
        title: '发现',
        userMenuList: [
          { name: '彩票资讯', link: '/find/list/lottery', isLink: true, iconCls: 'xiaoxi', iconColor: '#a792f8' },
          { name: '中奖快讯', link: '/find/list/win', isLink: true, iconCls: 'zhongjiangjilu', iconColor: '#f794c5' }
        ]
      }
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user__find {
    .vux-no-group-title {
      margin-top: 0 !important
    }
  }
</style>
