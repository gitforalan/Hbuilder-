<template>
  <div class="app-main page-user page-user_help">
    <x-header :title="title" :left-options="{ backText: '' }" class="is-fixed">
    </x-header>
    <div class="app-body" style="padding-bottom:0">
      <div id="notice">
         <group>
          <cell
            title="新手指引"
            is-link
            :border-intent="false"
            class="vux-1px-b"
            :arrow-direction="show0 ? 'down' : 'right'"
            @click.native="show0 = !show0">
              <div slot="value">
                <time></time>
              </div>
            </cell>
            <div class="slide panel" :class="show0 ?'animate':''">
              <div>
                <x-button type="default" class="btn">注册登录</x-button>
                <icon-svg icon-class="icon-copy-copy" style="color: #ccc"></icon-svg>
                <x-button type="default" class="btn">网上充值</x-button>
                <icon-svg icon-class="icon-copy-copy" style="color: #ccc"></icon-svg>
                <x-button type="default" class="btn">购买彩票</x-button>
                <icon-svg icon-class="icon-copy-copy" style="color: #ccc"></icon-svg>
                <x-button type="default" class="btn">账户查询</x-button>
                <icon-svg icon-class="icon-copy-copy" style="color: #ccc"></icon-svg>
                <x-button type="default" class="btn">中奖查询</x-button>
                <icon-svg icon-class="icon-copy-copy" style="color: #ccc"></icon-svg>
                <x-button type="default" class="btn">兑奖提款</x-button>
              </div>
            </div>
        </group>
        <group>
          <cell
            title="注册"
            is-link
            :border-intent="false"
            class="vux-1px-b"
            :arrow-direction="show1 ? 'down' : 'right'"
            @click.native="show1 = !show1">
              <div slot="value">
                <time></time>
              </div>
            </cell>
            <template v-if="show1">
              <cell-box :border-intent="false" class="sub-item" @click.native="show11 = !show11"><span>如何注册</span></cell-box>
              <div v-if="show11" class="sub-item-content vux-1px-t">
                <ul>
                  <li>·点击网站上的＂注册＂按钮，进入用户注册页面，阅读并同意《服务协议》；</li>
                  <li>·账号为4-15位字符，支持数字和字母，禁止以0开头, 密码为6-16位字符，支持数字、字母、符号，为了您的帐户，密码建议用大小写混合；</li>
                  <li>·按提示填写注册信息，即可完成注册；</li>
                  <li>·注册成功后，您可以马上充值购彩，也可以完善您的个人资料，设置你喜欢的头像、昵称，提升账户安全级别。</li>
                </ul>
              </div>
              <cell-box class="sub-item"  @click.native="show12 = !show12"><span>注册要收费吗</span></cell-box>
              <div v-if="show12" class="sub-item-content vux-1px-t">
                注册新用户是免费的，不收取任何费用。
              </div>
              <cell-box class="sub-item"  @click.native="show13 = !show13"><span>注意事项</span></cell-box>
              <div v-if="show13" class="sub-item-content vux-1px-t">
                <ul>
                  <li>用户名一旦提交，不可更改，请选择容易记忆且安全级别高的用户名，并妥善保管。</li>
                  <li>为确保用户的权益，请务必注册后，在“我的账户”设置提款密码和绑定银行卡真实信息。</li>
                </ul>
              </div>
            </template>
        </group>
        <group>
          <cell
            title="充值"
            is-link
            :border-intent="false"
            class="vux-1px-b"
            :arrow-direction="show2 ? 'down' : 'right'"
            @click.native="show2 = !show2">
              <div slot="value">
                <time></time>
              </div>
            </cell>
            <template v-if="show2">
              <cell-box :border-intent="false" class="sub-item" @click.native="show21 = !show21"><span>如何充值</span></cell-box>
              <div v-if="show21" class="sub-item-content vux-1px-t">
                <ul>
                  <li>·账号登录后，点击网站上＂充值＂按钮，就可以进入充值页面；</li>
                  <li>·请选择您的充值方式，按充值流程提示如实填写充值信息，成功提交充值订单后2-5分钟左右，刷新账户余额，即可到账；</li>
                  <li>·进入＂我的账户>充值记录＂可查看充值是否成功、查看充值明细；</li>
                  <li>·若已成功扣款，未到帐，请及时联系我们的在线客服。</li>
                </ul>
              </div>
              <cell-box class="sub-item"  @click.native="show22 = !show22"><span>支持哪些充值通道</span></cell-box>
              <div v-if="show22" class="sub-item-content vux-1px-t">
                <ul>
                  <li>·本站支持＂支付宝支付＂＂微信支付＂＂支付宝转帐＂＂微信转帐＂＂银行转账＂＂网银在线支付＂＂快速充值＂等多种充值通道，但视实际开通情况而定，请在充值页面查看；</li>
                  <li>·小额充值(0-5000元)建议使用＂支付宝支付＂＂微信支付＂＂支付宝转帐＂和＂微信转帐＂,大额充值(5000元以上)建议使用＂网银在线支付＂和＂银行转账＂；</li>
                </ul>
              </div>
              <cell-box class="sub-item"  @click.native="show23 = !show23"><span>充值要手续费吗</span></cell-box>
              <div v-if="show23" class="sub-item-content vux-1px-t">
                本站提供的充值方式方便、快捷，不收取任何手续费。
              </div>
              <cell-box class="sub-item"  @click.native="show24 = !show24"><span>如何开通网银在线支付</span></cell-box>
              <div v-if="show24" class="sub-item-content vux-1px-t">
                <ul>
                  <li>·开通银行卡网上支付功能，可网上开通、现场开通：</li>
                  <li>·网上开通：登录各大银行的官方网站在线开通。</li>
                  <li>·现场开通：前往各大银行的营业网点现场开通。</li>
                </ul>
              </div>
            </template>
        </group>
        <group>
          <cell
            title="提款"
            is-link
            :border-intent="false"
            class="vux-1px-b"
            :arrow-direction="show3 ? 'up' : 'right'"
            @click.native="show3 = !show3">
              <div slot="value">
                <time></time>
              </div>
            </cell>
            <template v-if="show3">
              <cell-box :border-intent="false" class="sub-item" @click.native="show31 = !show31"><span>如何提款</span></cell-box>
              <div v-if="show31" class="sub-item-content vux-1px-t">
                <ul>
                  <li>·点击＂提款＂按钮，进入提现页面，如果是第一次提款，请先绑定您的银行帐号信息，支持全国所有大小银行；</li>
                  <li>·填写您要提现的金额，并输入＂取款密码＂；</li>
                  <li>·提款订单提交后，3-5分钟左右即可到账，可登陆银行查看银行账户余额；</li>
                  <li>·点击＂我的账户>帐户明细＂可查看每日的交易明细；</li>
                  <li>·为了保障您的资金安全，公司提供7X24小时一对一服务。</li>
                </ul>
              </div>
              <cell-box class="sub-item"  @click.native="show32 = !show32"><span>提款需要手续费吗</span></cell-box>
              <div v-if="show32" class="sub-item-content vux-1px-t">
                <ul>
                  <li>·若达不到打码量要求的条件，提款需要扣除行政费用；</li>
                  <li>·根据不同设定，可能需要支付一定比例的出手续费；</li>
                  <li>·提款时所产生的银行转账手续费则由本网站承担。</li>
                </ul>
              </div>
              <cell-box class="sub-item"  @click.native="show33 = !show33"><span>提款次数有没有限制</span></cell-box>
              <div v-if="show33" class="sub-item-content vux-1px-t">
                当天内不限制提款次数，但有提款时间间隔要求，若有疑问请联系我们的在线客服。
              </div>
              <cell-box class="sub-item"  @click.native="show34 = !show34"><span>注意事项</span></cell-box>
              <div v-if="show34" class="sub-item-content vux-1px-t">
                <ul>
                  <li>·确认提款时提交的的银行信息的正确性。</li>
                  <li>·为了防止少数用户利用信用卡套现和洗钱的行为，保护正常用户的资金安全，本站针对提款做出如下规定：</li>
                  <li>1、用户需要达到一定的打码量（打码量指用户的有效投注金额，不含和局退款、撤单退款），才能正常办理提款，否则需扣除行政费用。</li>
                  <li>2、发现有异常的提款，要经过审核才能出款。</li>
                </ul>
              </div>
              <cell-box class="sub-item"  @click.native="show35 = !show35"><span>提款不成功怎么办</span></cell-box>
              <div v-if="show35" class="sub-item-content vux-1px-t">
                <ul>
                  <li>·提款不成功分两种情况：</li>
                  <li>·提款申请未成功：</li>
                  <li>1、提款金额大于账户实有金额。</li>
                  <li>2、提款时填写的提款密码与用账户信息设置的密码不一致。</li>
                  <li>3、银行卡信息不符合规定格式。</li>
                  <li>申请提款成功，但款项没有到达指定账户：</li>
                  <li>1、银行卡卡号填写错误，与用户姓名不符，银行退单。</li>
                  <li>一旦发生上述现象，请及时联系客服，由客服人员为您服务。</li>
                </ul>
              </div>
            </template>
        </group>
         <group>
          <cell
            title="我的账户"
            is-link
            :border-intent="false"
            class="vux-1px-b"
            :arrow-direction="show4 ? 'down' : 'right'"
            @click.native="show4 = !show4">
              <div slot="value">
                <time></time>
              </div>
            </cell>
            <template v-if="show4">
              <cell-box :border-intent="false" class="sub-item" @click.native="show41 = !show41"><span>忘记登录密码怎么办</span></cell-box>
              <div v-if="show41" class="sub-item-content vux-1px-t">
                请及时提供相应的信息给客服。系统将重置一个新密码，并把新密码发送到用户注册时提交的电子邮箱中，为保障账户安全，建议用户登录后立即修改密码。
              </div>
              <cell-box class="sub-item"  @click.native="show42 = !show42"><span>修改登录密码</span></cell-box>
              <div v-if="show42" class="sub-item-content vux-1px-t">
                <ul>
                  <li>操作流程如下：</li>
                  <li>在“我的账户>安全中心>修改密码”。</li>
                  <li>用户输入旧密码，并设置新密码。</li>
                  <li>提交信息，修改密码成功，系统提示成功信息。</li>
                </ul>
              </div>
              <cell-box class="sub-item"  @click.native="show43 = !show43"><span>充值要手续费吗</span></cell-box>
              <div v-if="show43" class="sub-item-content vux-1px-t">
                本站提供的充值方式方便、快捷，不收取任何手续费。
              </div>
              <cell-box class="sub-item"  @click.native="show44 = !show44"><span>什么是取款密码</span></cell-box>
              <div v-if="show44" class="sub-item-content vux-1px-t">
                <ul>
                  <li>·取款密码不同于登陆密码，是另外要设置的一个密码；</li>
                  <li>·取款密码一般用于提款、绑定银行卡等操作，可以保障账户资金安全；</li>
                  <li>·为了账户安全，设置取款密码时不能跟登陆密码相同；</li>
                </ul>
              </div>
              <cell-box class="sub-item"  @click.native="show45 = !show45"><span>真实姓名如何修改</span></cell-box>
              <div v-if="show45" class="sub-item-content vux-1px-t">
                <ul>
                  <li>·一经绑定，用户本人无法直接修改真实姓名，但可以联系客服人员进行修改。操作流程如下：</li>
                  <li>·联系客服人，说明修改的原因；</li>
                  <li>·客服部收到授权后，由专员核实信息，交上级主管批准；</li>
                  <li>主管批准后，技术专员在有人监督的情况下，才可修改用户的真实姓名。</li>
                </ul>
              </div>
              <cell-box class="sub-item"  @click.native="show46 = !show46"><span>登录时看不到验证码或提示验证码不正确</span></cell-box>
              <div v-if="show46" class="sub-item-content vux-1px-t">
                <ul>
                  <li>·看不到验证码或者总是提示验证码输入错误，可能的原因有：</li>
                  <li>·网速过慢，请多刷新几次页面。</li>
                  <li>·输入错误，数字有全角和半角之分，请换用半角方式输入。</li>
                  <li>·安全级别设置过高，请将IE的安全级别设为“默认级别”。</li>
                  <li>·网页没有自动更新，请先设置浏览器的“Internet临时文件”为“自动”更新。</li>
                </ul>
              </div>
              <cell-box class="sub-item"  @click.native="show47 = !show47"><span>帐户安全的注意事项</span></cell-box>
              <div v-if="show47" class="sub-item-content vux-1px-t">
                <ul>
                  <li>平时应注意检查电脑是否有中毒；</li>
                  <li>尽量不要在公共场所（如网吧）等登录本网站；</li>
                  <li>牢记密码，如作记录则应妥善保管；</li>
                  <li>密码不得告诉他人；</li>
                  <li>在登录或网上支付密码输入时，应防止左右可疑的人窥视；</li>
                  <li>预留密码时不要选用您的身份证、生日、电话、重复或连续等易被他人破译的数字。建议选用不易被他人猜到，又方便记忆的密码；</li>
                  <li>发现泄密时，应及时更换密码，并不定期更换密码。</li>
                </ul>
              </div>
            </template>
        </group>
        <group>
          <cell
            title="如何购彩"
            is-link
            :border-intent="false"
            class="vux-1px-b"
            :arrow-direction="show5 ? 'down' : 'right'"
            @click.native="show5 = !show5">
              <div slot="value">
                <time></time>
              </div>
            </cell>
            <template v-if="show5">
              <cell-box :border-intent="false" class="sub-item" @click.native="show51 = !show51"><span>购彩流程</span></cell-box>
              <div v-if="show51" class="sub-item-content vux-1px-t">
                <ul>
                  <li>购彩前需要先进行充值，账户有余额才可以进行购彩投注；</li>
                  <li>充值完成后，可进入＂购彩大厅＂选择您喜欢的彩票进行投注；</li>
                  <li>＂玩法规则＂和＂走势图＂，可以帮您更快上手和投注哪个号码；</li>
                  <li>投注完成后，可以进入＂我的账户>投注记录＂，查看您的投注明细，查看是否中奖；</li>
                  <li>投注完成后，需等开奖后，才能查看是否中奖；</li>
                  <li>投注成功后，系统将自动从您的账户余额扣除对应的投注金额，如果中奖，奖金会自动添加到您的账户余额；</li>
                  <li>可以进入＂我的账户>帐户明细＂，查看您的账户交易明细；</li>
                </ul>
              </div>
              <cell-box class="sub-item"  @click.native="show52 = !show52"><span>如何查询购彩记录</span></cell-box>
              <div v-if="show52" class="sub-item-content vux-1px-t">
                在"我的账户>投注记录"，即可查看购买彩票的记录，也可按注单的类型（已中奖，未中奖，未开奖）分别查询。
              </div>
              <cell-box class="sub-item"  @click.native="show53 = !show53"><span>如何查询追号记录</span></cell-box>
              <div v-if="show53" class="sub-item-content vux-1px-t">
                进入会员中心，进入“投注记录”，即可查看追号记录，可以对状态为“可撤单”的注单进行撤单。
              </div>
              <cell-box class="sub-item"  @click.native="show54 = !show54"><span>网上购彩的优势</span></cell-box>
              <div v-if="show54" class="sub-item-content vux-1px-t">
                <ul>
                  <li>·安全便捷：安全、方便、快捷，足不出户，轻松购彩。</li>
                  <li>·随时随地：无地域限制，除开奖时间外24小时投注。</li>
                  <li>·信息服务：提供全方位、多样化的彩票信息服务。</li>
                </ul>
              </div>
              <cell-box class="sub-item"  @click.native="show55 = !show55"><span>网上购彩如何保证彩民利益</span></cell-box>
              <div v-if="show55" class="sub-item-content vux-1px-t">
                <ul>
                  <li>·自动返奖："自动兑奖，自动返奖"，所有奖金均由网站系统自动开兑并自动返还到用户的账户中。</li>
                  <li>·公开查询：用户可以查询自己的投注记录、中奖记录以及资金明细记录，一切做到有据可查，数据公开。</li>
                  <li>·数据安全：投注数据及相关资料时时备份，网络系统独立设置、隔离并安装有大型硬、软防火墙，安全级别高，确保数据绝对安全。</li>
                </ul>
              </div>
              <cell-box class="sub-item"  @click.native="show56 = !show56"><span>在本站购彩安全吗</span></cell-box>
              <div v-if="show56" class="sub-item-content vux-1px-t">
                <ul>
                  <li>本站是福彩中心与体彩中心授权的合法的网上投注平台，所售彩票都是福彩中心与体彩中心正规发行的彩票。</li>
                  <li>本站彩票已在工信部备案，是真实有效合法的网上购彩平台。</li>
                </ul>
              </div>
            </template>
        </group>
        <group>
          <cell
            title="玩法规则"
            is-link
            :border-intent="false"
            class="vux-1px-b"
            arrow-direction="right"
            @click.native="$router.push({ path: '/user/more'})">
            </cell>
        </group>
        <group>
          <cell
          title="手机APP下载帮助"
          is-link
          :border-intent="false"
          class="vux-1px-b"
          :arrow-direction="show7 ? 'down' : 'right'"
          @click.native="show7 = !show7">
            <div slot="value">
              <time></time>
            </div>
          </cell>
          <template v-if="show7">
            <cell-box :border-intent="false" class="sub-item" @click.native="show71 = !show71"><span>IOS版APP授权教程</span></cell-box>
            <div v-if="show71" class="sub-item-content vux-1px-t">
              1
            </div>
            <cell-box class="sub-item"  @click.native="show72 = !show72"><span>客户端教程</span></cell-box>
            <div v-if="show72" class="sub-item-content vux-1px-t">
              2
            </div>
          </template>
        </group>
        <group>
          <cell
            title="专门术语"
            is-link
            :border-intent="false"
            class="vux-1px-b"
            :arrow-direction="show6 ? 'down' : 'right'"
            @click.native="show6 = !show6">
              <div slot="value">
                <time></time>
              </div>
            </cell>
            <template v-if="show6">
              <cell-box :border-intent="false" class="sub-item" @click.native="show61 = !show61"><span>什么是单式投注</span></cell-box>
              <div v-if="show61" class="sub-item-content vux-1px-t">
                单式投注即用户选择一注号码进行投注。
              </div>
              <cell-box class="sub-item"  @click.native="show62 = !show62"><span>什么是复式投注</span></cell-box>
              <div v-if="show62" class="sub-item-content vux-1px-t">
                复式投注即用户将两注以上号码的组合方式作为一组投注号码同时投注。
              </div>
              <cell-box class="sub-item"  @click.native="show63 = !show63"><span>什么是机选投注</span></cell-box>
              <div v-if="show63" class="sub-item-content vux-1px-t">
                机选指由系统随机产生投注号码进行投注。
              </div>
              <cell-box class="sub-item"  @click.native="show64 = !show64"><span>什么是直选投注</span></cell-box>
              <div v-if="show64" class="sub-item-content vux-1px-t">
                直选指将所选号码以唯一的排列方式进行投注。
              </div>
              <cell-box class="sub-item"  @click.native="show65 = !show65"><span>什么是组选投注</span></cell-box>
              <div v-if="show65" class="sub-item-content vux-1px-t">
                组选指将所选号码的所有排列方式作为一注号码进行投注。如一注3D组选号码的 3个数字有两个数字相同，则有3种不同的排列方式，因而就有3个中奖机会，这种组选投注方式简称组选3。如一注3D组选号码的3个数字各不相同，则有6种 不同的排列方式，因而就有6个中奖机会，这种组选投注方式简称组选6。
              </div>
              <cell-box class="sub-item"  @click.native="show67 = !show67"><span>什么是追号投注</span></cell-box>
              <div v-if="show67" class="sub-item-content vux-1px-t">
                追号指将一注或一组号码进行两期或两期以上的投注。追号可分为连续追号和间隔追号，连续追号指追号的期数是连续的，间隔追号指追号的期数不连续。
              </div>
              <cell-box class="sub-item"  @click.native="show68 = !show68"><span>什么是和值投注</span></cell-box>
              <div v-if="show68" class="sub-item-content vux-1px-t">
                和值指投注各号码相加之和，如3D号码123，其和值为6。和值投注即用该和值的所有号码进行投注，如用户选择3D直选和值1，共3注：001、010和100。
              </div>
              <cell-box class="sub-item"  @click.native="show69 = !show69"><span>什么是包号投注</span></cell-box>
              <div v-if="show69" class="sub-item-content vux-1px-t">
                包号投注指将用户所选择号码的所有组合形式进行投注。如3D组三包号01，共2注：001和110。
              </div>
              <cell-box class="sub-item"  @click.native="show610 = !show610"><span>什么是胆拖投注</span></cell-box>
              <div v-if="show610" class="sub-item-content vux-1px-t">
                胆拖投注也叫基数组合投注，通常由胆码和拖码组成。胆码是用户认为出现机会非常大的号码，在所投注的每一注彩票里都固定出现；拖码即用户补充的其他不同的号码。拖码与胆码共同组成一注完整的投注号码。
              </div>
              <cell-box class="sub-item"  @click.native="show611 = !show611"><span>什么是打码量</span></cell-box>
              <div v-if="show611" class="sub-item-content vux-1px-t">
                打码量是指用户的有效投注金额，不包含和局退款、撤单退款的金额
              </div>
            </template>
          </group>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { ButtonTab, ButtonTabItem, CellBox, Cell } from 'vux'
  export default {
    data () {
      return {
        title: '帮助中心',
        show0: false,
        show1: false,
        show11: false,
        show12: false,
        show13: false,
        show2: false,
        show21: false,
        show22: false,
        show23: false,
        show24: false,
        show3: false,
        show31: false,
        show32: false,
        show33: false,
        show34: false,
        show35: false,
        show4: false,
        show41: false,
        show42: false,
        show43: false,
        show44: false,
        show45: false,
        show46: false,
        show47: false,
        show5: false,
        show51: false,
        show52: false,
        show53: false,
        show54: false,
        show55: false,
        show56: false,
        show6: false,
        show61: false,
        show62: false,
        show63: false,
        show64: false,
        show65: false,
        show66: false,
        show67: false,
        show68: false,
        show69: false,
        show610: false,
        show611: false,
        show612: false,
        show7: false,
        show71: false,
        show72: false
      }
    },
    components: {
      ButtonTab,
      ButtonTabItem,
      CellBox,
      Cell
    },
    methods: {
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user_help
    .radius
      content: " "
      width rem(12)
      height rem(12)
      background #c6c6c6
      display inline-block
      margin-right rem(20)
      border-radius 100%
    #notice > div .weui-cells .sub-item:nth-of-type(2):before
      border-top-style solid !important
    .sub-item
      background #f7f7f7 !important
      padding-left rem(86) !important
      &:before
        left 0 !important
        border-top-style dashed
      span
        font-size rem(28)
        &:before
          @extend .page-user_help .radius
    .panel
      text-align center
      .lott-icon
        margin rem(10) 0
        width rem(50)
    .weui-cells
     margin 0
    .slide {
      overflow: hidden;
      max-height: 0;
      transition: max-height .5s cubic-bezier(0, 1, 0, 1) -.1s;
    }
    .animate {
      max-height: 9999px;
      transition-timing-function: cubic-bezier(0.5, 0, 1, 0);
      transition-delay: 0s;
    }
    line-height 1.5
    .weui-cell 
      background $color-white
      padding 0 rem(24) 0 rem(34)
      line-height rem(100)
      .weui-cell__hd
        @extend .page-user_help .radius
      .vux-label, time
        font-size rem(28)
      time
       display inline-block
       margin-right rem(20)
       color #000000
      .weui-cell__ft:after
        border-color #858585
    .slide > div
      padding rem(20) rem(34) rem(20) rem(34)
      background $color-white
      font-size rem(22)
    .btn {
      width rem(200)
      font-size $size-small
      background #fff   
      &:after{
        border-color $color-red
      }
      color $color-red
    }
    .sub-item
      font-size rem(22)
    .sub-item-content
      padding rem(20) rem(34) rem(20) rem(34)
      font-size rem(22)
      li
        margin-bottom rem(10)
</style>
