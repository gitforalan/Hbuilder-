<template>
  <div class="app-main page-user page-user__aboutUs">
    <x-header :title="title" :left-options="{ backText: '' }" class="is-fixed">
    </x-header>
    <div class="app-body">
      <div class="flex">
        <img src="../../../assets/image/more_logo.png" class="logo">
        <x-button type="default" class="btn" @click.native="$router.push({path: '/clause'})">服务条款</x-button>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
    data () {
      return {
        title: '关于我们'
      }
    },
    created () {
    },
    methods: {
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user__aboutUs {
    .app-body {
      .flex{
        padding-top rem(350)
      }
    }
    text-align: center
    .logo {
      border-radius: 50%
      width rem(200)
      height rem(200)
    }
    .btn {
      margin-top: rem(40)
      width rem(200)
      font-size $size-small   
      &:after{
        border-color $color-red
      }
      color $color-red
    }
  }
</style>
