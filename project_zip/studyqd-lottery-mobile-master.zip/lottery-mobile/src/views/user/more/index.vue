<template>
  <div class="app-main page-user page-user__more">
    <x-header :title="title" :left-options="{ backText: '' }" class="is-fixed">
    </x-header>
    <div class="app-body">
      <!-- <group>
      <cell title="开启按键音效" class="yinxiao">
         <icon-svg slot="icon" iconClass="gonggao" :style="{ 'color': '#ff592c' }"></icon-svg>
          <x-switch title=""></x-switch>
      </cell>
        </group> -->
      <group class="user-menu" stylereset>
        <cell
          v-for="item in userMenuList"
          v-if="!item.isShow"
          :key="item.name"
          :title="item.name"
          :link="item.link"
          :is-link="item.isLink" @click.native="go(item.link, 'logout')">
          <icon-svg slot="icon" :iconClass="item.iconCls" :style="{ 'color': item.iconColor }"></icon-svg>
        </cell>
      </group>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import Vue from 'vue'
  import { Group, Cell, ConfirmPlugin, XSwitch } from 'vux'
  import { mapMutations } from 'vuex'
  import * as API from 'api/wapi/user'
  Vue.use(ConfirmPlugin)
  export default {
    data () {
      return {
        title: '会员中心',
        userMenuList: [
          { name: '帮助中心', link: '/user/help', isLink: true, iconCls: 'wenhao', iconColor: '#10aeff' },
          { name: '关于我们', link: '/user/aboutUs', isLink: true, iconCls: 'guanyuwomen', iconColor: '#ff592c' },
          { name: '退出登录', link: '', isLink: true, iconCls: 'tuichudenglu', iconColor: '#24c18f' }
        ]
      }
    },
    components: {
      Group, Cell, XSwitch
    },
    created () {
    },
    methods: {// 退出
      go (url, name) {
        if (url === '' && name === 'logout') {
          this.logout()
        }
      },
      logout () {
        var self = this
        this.$vux.confirm.show({
          title: '您确定退出当前账户?',
          onConfirm () {
            API.logout().then(res => {
              if (!res.error && Number(res.result) === 1) {
                self.delCookieToken()
                self.$router.push({ path: '/home' })
              } else {
                self.$vux.toast.show({
                  type: 'warn',
                  text: res.error.message
                })
              }
            })
          }
        })
      },
      ...mapMutations(['delCookieToken'])
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user__more {
    .vux-label {
      font-size rem(24)
    }
    .vux-no-group-title {
      margin-top rem(20)
    }
    .yinxiao {
      padding-left rem(50)
      padding-top 0
      padding-bottom 0
      font-size rem(24)
      color #000
      .lott-icon {
        width rem(40) !important
        margin-right rem(30)
      }
      .weui-cell_switch {
        padding-right 0
      }
    }
  }
</style>
