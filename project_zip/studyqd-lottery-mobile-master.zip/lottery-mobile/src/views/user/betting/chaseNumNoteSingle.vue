<!-- Created By fx on 2017/9/16. -->
<template>
  <div class="app-main page-user page-user_chaseNumNoteSingle">
    <x-header :left-options="{backText: ''}" :title="title" class="is-fixed"></x-header>
    <div class="app-body">
      <div class="wrap title">
        <ul class="ul-title">
          <li style="width: 30%;">期号</li>
          <li style="width: 30%;">开奖结果</li>
          <li>中奖金额</li>
          <li style="width: 15%;">详情</li>
        </ul>
        <ul class="ul-content" v-show="isUser" @click="openInfo(index)" v-for="(item, index) in recordData" :key="index">
          <li style="width: 30%;">{{item.issue}}</li>
          <li style="width: 30%;">{{item.openCode}}</li>
          <li>{{item.winMoney}}</li>
          <li style="width: 15%;">
            <icon-svg class="right-icon" :icon-class="item.expand ? 'up' : 'down'"></icon-svg>
          </li>
          <template v-if="item.expand">
            <p>
              <span>追号时间：<span style="color: #636363;">{{item.createTime}}</span></span>
              <span>投注金额：<span class="font-red">{{item.buyMoney}}</span>元</span>
              <span>状态：<span class="font-red">{{item.status == 0 ? '未开奖' : item.status == 1 ? '已撤单' : item.status == 2 ? '已中奖' : item.status == 3 ? '未中奖' : ''}}</span></span>
            </p>
            <p style="text-align: right; width: 38%;">
              <span>追号倍数：{{item.buyDouble}}倍</span>
              <span>投注返点：<span class="font-red">{{item.rebateMoney}}</span>元</span>
              <span v-if="item.status == 0" style="color: #0096ff;">可撤单</span>
            </p>
          </template>
        </ul>
        <ul class="ul-content" v-show="isAgent" @click="openInfo(index)" v-for="(item, index) in recordData" :key="index">
          <li style="width: 30%;">{{item.issue}}</li>
          <li style="width: 30%;">{{item.openCode}}</li>
          <li>{{item.winMoney}}</li>
          <li style="width: 15%;">
            <icon-svg class="right-icon" :icon-class="item.expand ? 'up' : 'down'"></icon-svg>
          </li>
          <template v-if="item.expand">
            <p>
              <span>用户：{{item.loginId}}</span>
              <span>追号时间：<span style="color: #636363;">{{item.createTime}}</span></span>
              <span>投注金额：<span class="font-red">{{item.buyMoney}}</span>元</span>
              <span>状态：<span class="font-red">{{item.status == 0 ? '未开奖' : item.status == 1 ? '已撤单' : item.status == 2 ? '已中奖' : item.status == 3 ? '未中奖' : ''}}</span></span>
            </p>
            <p style="text-align: right; width: 38%;">
              <span>所属组：{{item.regType == 'a' ? '代理' : '会员'}}</span>
              <span>追号倍数：{{item.buyDouble}}倍</span>
              <span>投注返点：<span class="font-red">{{item.rebateMoney}}</span>元</span>
              <span v-if="item.status == 0" style="color: #0096ff;">可撤单</span>
            </p>
          </template>
        </ul>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
import { ButtonTab, ButtonTabItem, Grid, GridItem, Flexbox, FlexboxItem, cookie } from 'vux'
import * as API from 'api/wapi/user'
export default {
  data () {
    return {
      title: '追号注单',
      isUser: false,
      isAgent: false,
      recordData: [],
      userOrAgent: ''
    }
  },
  components: {
    ButtonTab,
    ButtonTabItem,
    Grid,
    GridItem,
    Flexbox,
    FlexboxItem
  },
  created () {
  },
  watch: {
  },
  mounted () {
    this.getChaseNumNoteSingleData()
    this.userOrAgent = cookie.get('loginType')
    if (this.userOrAgent === 'agent') {
      this.isAgent = true
      this.isUser = false
    } else {
      this.isAgent = false
      this.isUser = true
    }
  },
  methods: {
    // 获取追号注单列表
    getChaseNumNoteSingleData () {
      var params = {
        traceCode: this.$route.params.num
      }
      API.GetLChaseNumRecordDetail(params).then(res => {
        if (!res.error && res.result) {
          var result = res.result
          if (result !== null && result !== '' && result !== '0') {
            this.recordData = result.traceList
            for (var i = 0; i < this.recordData.length; i++) {
              this.$set(this.recordData[i], 'expand', false)
            }
          }
        }
      })
    },
    openInfo (index) {
      this.recordData[index].expand = !this.recordData[index].expand
    }
  }
}
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user_chaseNumNoteSingle
    .search
      text-align left
      margin-left rem(20)
      .weui-btn_warn
        display inline-block
    .app-body
      color #000
      font-weight bold
      font-size rem(30)
    .right-icon 
      width rem(40) !important
      vertical-align middle
    ul 
      font-size rem(28)
      li
        width 25%
        display inline-block
        float left
        text-align center
        background-color $color-eee
        line-height rem(80)
    .ui-title 
      li
        line-height rem(90)
    .ul-content
      display inline-block
      width 100%
      li
        background-color white
        line-height rem(90)
        font-size rem(28)
    p 
      display grid
      float left
      padding rem(30) rem(0) rem(30) rem(26)
    .ul-content
      P:last-child
        padding rem(30) rem(0) rem(30) rem(10)
    p>span
      font-size rem(28)
      display block
      line-height rem(60)
    p .right-icon
      top rem(60)
</style>
