<template>
  <div class="app-main page-user page-user_betting">
    <x-header :left-options="{backText: ''}" class="is-fixed">
      <button-tab v-model="tabActive" stylereset>
        <button-tab-item @on-item-click="btnClick()"><icon-svg iconClass="duihao"></icon-svg>注单查询</button-tab-item>
        <button-tab-item @on-item-click="btnClick()"><icon-svg iconClass="duihao"></icon-svg>追号查询</button-tab-item>
        <button-tab-item @on-item-click="btnClick()"><icon-svg iconClass="duihao"></icon-svg>1元夺奖</button-tab-item>
      </button-tab>
    </x-header>
    <div class="app-body">
      <div id="note-single" v-show="showNoteSingle">
        <tab active-color='#ff5151'>
          <tab-item selected @on-item-click="noteSingleClickItem('')">全部</tab-item>
          <tab-item @on-item-click="noteSingleClickItem(0)">未开奖</tab-item>
          <tab-item @on-item-click="noteSingleClickItem(2)">已中奖</tab-item>
          <tab-item @on-item-click="noteSingleClickItem(3)">未中奖</tab-item>
          <tab-item @on-item-click="noteSingleClickItem(1)">已撤单</tab-item>
        </tab>
        <div class="condition userCondition" v-show="isUser">
          <flexbox class="selectWrap">
            <flexbox-item>
              <span class="selectItem"><selector v-model="ltypens" :options="ltypeList"></selector><icon-svg iconClass="bg-down" class="up"></icon-svg></span>
            </flexbox-item>
            <flexbox-item>
              <dateRange ref="noteSingleRange"></dateRange>
            </flexbox-item>
            <x-button stylereset type="warn" @click.native="searchNoteSingle()" :show-loading="queryLoading"><template v-if="!queryLoading">查询</template></x-button>
          </flexbox>
        </div>
        <div class="condition agentCondition" v-show="isAgent">
          <flexbox class="selectWrap">
            <flexbox-item>
              <span class="selectItem"><selector v-model="ltypens" :options="ltypeList"></selector><icon-svg iconClass="bg-down" class="up"></icon-svg></span>
            </flexbox-item>
            <flexbox-item>
              <dateRange ref="noteSingleRange"></dateRange>
            </flexbox-item>
          </flexbox>
          <flexbox :gutter="0">
            <x-input title='用户名：' placeholder="请输入用户名" v-model="nsUserLoginId"></x-input>
            <x-button stylereset type="warn" @click.native="searchNoteSingle()" :show-loading="queryLoading"><template v-if="!queryLoading">查询</template></x-button>
          </flexbox>
        </div>
        <div>
          <div class="wrap title">
            <ul>
              <li v-show="isUser" v-for="(item, index) in noteSingleData" :key="index">
                <p style="width: 55%;">
                  <span>{{item.lotteryName}}</span>
                  <span><span style="color: #636363;">{{item.createTime}}</span></span>
                  <span>第{{item.issue}}期</span>
                </p>
                <p style="width: 35%; text-align: right;">
                  <span>{{item.playName}}</span>
                  <span><span class="font-red">{{item.orderMoney}}</span>元</span>
                  <span>状态：<span class="font-red">{{item.status == 0 ? '未开奖' : item.status == 1 ? '已撤单' : item.status == 2 || item.status == 5 ? '已中奖' : item.status == 3 ? '未中奖' : ''}}</span></span>
                </p>
                <p style="width: 10%;">
                  <router-link :to="'noteSingleDetail/' + item.orderCode"><icon-svg class="right-icon" icon-class="right"></icon-svg></router-link>
                </p>
              </li>
              <li v-show="isAgent" v-for="(item, index) in noteSingleData" :key="index">
                <p style="width: 55%;">
                  <span>用户：{{item.loginId}}</span>
                  <span>{{item.lotteryName}}</span>
                  <span><span style="color: #636363;">{{item.createTime}}</span></span>
                  <span>第{{item.issue}}期</span>
                </p>
                <p style="width: 35%; text-align: right;">
                  <span>所属组：{{item.regType == 'a' ? '代理' : '会员'}}</span>
                  <span>{{item.playName}}</span>
                  <span><span class="font-red">{{item.orderMoney}}</span>元</span>
                  <span>状态：<span class="font-red">{{item.status == 0 ? '未开奖' : item.status == 1 ? '已撤单' : item.orderStatus == 2 || item.status == 5 ? '已中奖' : item.status == 3 ? '未中奖' : ''}}</span></span>
                </p>
                <p style="width: 10%;">
                  <router-link :to="'noteSingleDetail/' + item.orderCode"><icon-svg class="right-icon" icon-class="right"></icon-svg></router-link>
                </p>
              </li>
            </ul>
            <div class="getMore" v-if="noteSingleParams.showMore" @click="getMoreNoteSingle()">更多>></div>
          </div>
        </div>
      </div>
      <div id="chase-number" v-show="showChaseNum">
        <tab active-color='#ff5151'>
          <tab-item selected @on-item-click="chaseNumClickItem('')">全部</tab-item>
          <tab-item @on-item-click="chaseNumClickItem('0')">未开始</tab-item>
          <tab-item @on-item-click="chaseNumClickItem('1')">已开始</tab-item>
          <tab-item @on-item-click="chaseNumClickItem('8')">已结束</tab-item>
        </tab>
        <div class="condition userCondition" v-show="isUser">
          <flexbox class="selectWrap">
            <flexbox-item>
              <span class="selectItem"><selector v-model="ltypecn" :options="ltypeList"></selector><icon-svg iconClass="bg-down" class="up"></icon-svg></span>
            </flexbox-item>
            <flexbox-item>
              <dateRange ref="chaseNumRange"></dateRange>
            </flexbox-item>
            <x-button stylereset type="warn" @click.native="searchChaseNum()" :show-loading="queryLoading"><template v-if="!queryLoading">查询</template></x-button>
          </flexbox>
        </div>
        <div class="condition agentCondition" v-show="isAgent">
          <flexbox class="selectWrap">
            <flexbox-item>
              <span class="selectItem"><selector v-model="ltypecn" :options="ltypeList"></selector><icon-svg iconClass="bg-down" class="up"></icon-svg></span>
            </flexbox-item>
            <flexbox-item>
              <dateRange ref="chaseNumRange"></dateRange>
            </flexbox-item>
          </flexbox>
          <flexbox :gutter="0">
            <x-input title='用户名：' placeholder="请输入用户名" v-model="cnUserLoginId"></x-input>
            <x-button stylereset type="warn" @click.native="searchChaseNum()" :show-loading="queryLoading"><template v-if="!queryLoading">查询</template></x-button>
          </flexbox>
        </div>
        <div>
          <div class="wrap title">
            <ul>
              <li v-show="isUser" v-for="(item, index) in chaseNumData" :key="index">
                <p style="width: 55%;">
                  <span>{{item.lotteryName}}</span>
                  <span><span style="color: #636363;">{{item.createTime}}</span></span>
                  <span>第{{item.beginIssue}}期起追</span>
                  <span>已追<span class="font-red">{{item.alreadyTraceNum}}</span>期/总共<span class="font-red">{{item.totalTraceNum}}</span>期</span>
                </p>
                <p style="width: 35%; text-align: right;">
                  <span>{{item.playName}}</span>
                  <span>已投<span class="font-red">{{item.alreadyBuyMoney}}</span>元</span>
                  <span>共<span class="font-red">{{item.totalBuyMoney}}</span>元</span>
                  <span>状态：<span v-if="item.traceStatus != 8" class="font-red">{{item.traceStatus == 0 ? '未开始' : item.traceStatus == 1 ? '已开始' : ''}}</span><span v-else style="color: #636363;">已结束</span></span>
                </p>
                <p style="width: 10%;">
                  <router-link :to="'chaseNumDetail/' + item.traceCode"><icon-svg class="right-icon" icon-class="right"></icon-svg></router-link>
                </p>
              </li>
              <li v-show="isAgent" v-for="(item, index) in chaseNumData" :key="index">
                <p style="width: 55%;">
                  <span>用户：{{item.loginId}}</span>
                  <span>{{item.lotteryName}}</span>
                  <span><span style="color: #636363;">{{item.createTime}}</span></span>
                  <span>第{{item.beginIssue}}期起追</span>
                  <span>已追<span class="font-red">{{item.alreadyTraceNum}}</span>期/总共<span class="font-red">{{item.totalTraceNum}}</span>期</span>
                </p>
                <p style="width: 35%; text-align: right;">
                  <span>所属组：{{item.regType == 'a' ? '代理' : '会员'}}</span>
                  <span>{{item.playName}}</span>
                  <span>已投<span class="font-red">{{item.alreadyBuyMoney}}</span>元</span>
                  <span>共<span class="font-red">{{item.totalBuyMoney}}</span>元</span>
                  <span>状态：<span v-if="item.traceStatus != 8" class="font-red">{{item.traceStatus == 0 ? '未开始' : item.traceStatus == 1 ? '已开始' : ''}}</span><span v-else style="color: #636363;">已结束</span></span>
                </p>
                <p style="width: 10%;">
                  <router-link :to="'chaseNumDetail/' + item.traceCode"><icon-svg class="right-icon" icon-class="right"></icon-svg></router-link>
                </p>
              </li>
            </ul>
            <div class="getMore" v-if="chaseNumParams.showMore" @click="getMoreChaseNum()">更多>></div>
          </div>
        </div>
      </div>
      <div id="one-win" v-show="showOneWin">
        <tab active-color='#ff5151'>
          <tab-item selected @on-item-click="oneWinClickItem('')">全部</tab-item>
          <tab-item @on-item-click="oneWinClickItem('0')">未开始</tab-item>
          <tab-item @on-item-click="oneWinClickItem('1')">已开始</tab-item>
          <tab-item @on-item-click="oneWinClickItem('8')">已结束</tab-item>
        </tab>
        <div class="condition userCondition" v-show="isUser">
          <flexbox class="selectWrap">
            <flexbox-item>
              <dateRange ref="oneWinRange"></dateRange>
            </flexbox-item>
            <x-button stylereset type="warn" @click.native="searchOneWin()" :show-loading="queryLoading"><template v-if="!queryLoading">查询</template></x-button>
          </flexbox>
        </div>
        <div class="condition agentCondition" v-show="isAgent">
          <flexbox class="selectWrap">
            <flexbox-item>
              <dateRange ref="oneWinRange"></dateRange>
            </flexbox-item>
            <x-input title='用户名：' placeholder="请输入用户名" v-model="cnUserLoginId"></x-input>
            <x-button stylereset type="warn" @click.native="searchOneWin()" :show-loading="queryLoading"><template v-if="!queryLoading">查询</template></x-button>
          </flexbox>
        </div>
        <div>
          <div class="wrap title">
            <ul>
              <li v-show="isUser" v-for="(item, index) in oneWinData" :key="index">
                <p style="width: 55%;">
                  <span>订单编号：{{item.lotteryName}}</span>
                  <span><span style="color: #636363;">{{item.createTime}}</span></span>
                  <span>第{{item.beginIssue}}期</span>
                </p>
                <p style="width: 45%; text-align: right;">
                  <span><span class="font-red">{{item.playName}}</span>元</span>
                  <span>状态：<span v-if="item.status != 8" class="font-red">{{item.status == 0 ? '未开始' : item.status == 1 ? '已开始' : ''}}</span><span v-else style="color: #636363;">已结束</span></span>
                  <span>中奖金额：<span class="font-red">{{item.totalBuyMoney}}</span>元</span>
                </p>
              </li>
              <li v-show="isAgent" v-for="(item, index) in oneWinData" :key="index">
                <p style="width: 55%;">
                  <span>订单编号：{{item.lotteryName}}</span>
                  <span>用户：{{item.loginId}}</span>
                  <span><span style="color: #636363;">{{item.createTime}}</span></span>
                  <span>第{{item.beginIssue}}期</span>
                </p>
                <p style="width: 45%; text-align: right;">
                  <span>所属组：{{item.regType == 'a' ? '代理' : '会员'}}</span>
                  <span><span class="font-red">{{item.playName}}</span>元</span>
                  <span>状态：<span v-if="item.status != 8" class="font-red">{{item.status == 0 ? '未开始' : item.status == 1 ? '已开始' : ''}}</span><span v-else style="color: #636363;">已结束</span></span>
                  <span>中奖金额：<span class="font-red">{{item.totalBuyMoney}}</span>元</span>
                </p>
              </li>
            </ul>
            <div class="getMore" v-if="oneWinParams.showMore" @click="getMoreOneWin()">更多>></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { Toast, ButtonTab, ButtonTabItem, Grid, GridItem, Checklist, Flexbox, FlexboxItem, cookie } from 'vux'
  import dateRange from '../components/range-select'
  import * as API from 'api/wapi/user'
  export default {
    data () {
      return {
        tabActive: 0,
        showNoteSingle: true,
        showChaseNum: false,
        showOneWin: false,
        userOrAgent: '',
        isUser: false,
        isAgent: false,
        ltypens: '',
        nsType: '',
        ltypecn: '',
        cnType: '',
        ltypeList: [],
        nsUserLoginId: '',
        cnUserLoginId: '',
        orderStatus: '',
        queryLoading: false,
        noteSingleParams: {
          pageSize: 15,
          pageIndex: 1,
          total: 0,
          showMore: false
        },
        chaseNumParams: {
          pageSize: 15,
          pageIndex: 1,
          total: 0,
          showMore: false
        },
        oneWinParams: {
          pageSize: 15,
          pageIndex: 1,
          total: 0,
          showMore: false
        },
        beginTime: '',
        endTime: '',
        noteSingleData: [],
        chaseNumData: [],
        oneWinData: []
      }
    },
    components: {
      Toast,
      ButtonTab,
      ButtonTabItem,
      Grid,
      GridItem,
      Checklist,
      Flexbox,
      FlexboxItem,
      dateRange
    },
    created () {
    },
    watch: {
    },
    mounted () {
      this.userOrAgent = cookie.get('loginType')
      this.getLotteryTypeData()
      if (this.userOrAgent === 'agent') {
        this.isAgent = true
        this.isUser = false
        this.getAgentLotteryNoteSingleData()
        this.getAgentLotteryChaseNumData()
        this.getAgentLotteryOneWinData()
      } else {
        this.isAgent = false
        this.isUser = true
        this.getUserLotteryNoteSingleData()
        this.getUserLotteryChaseNumData()
        this.getUserLotteryOneWinData()
      }
    },
    methods: {
      // 选择注单tab状态
      noteSingleClickItem (index) {
        this.orderStatus = index
        if (this.userOrAgent === 'agent') {
          this.isAgent = true
          this.isUser = false
          this.noteSingleData = []
          this.getAgentLotteryNoteSingleData()
        } else {
          this.isAgent = false
          this.isUser = true
          this.noteSingleData = []
          this.getUserLotteryNoteSingleData()
        }
      },
      // 选择追号tab状态
      chaseNumClickItem (index) {
        this.orderStatus = index
        if (this.userOrAgent === 'agent') {
          this.isAgent = true
          this.isUser = false
          this.chaseNumData = []
          this.getAgentLotteryChaseNumData()
        } else {
          this.isAgent = false
          this.isUser = true
          this.chaseNumData = []
          this.getUserLotteryChaseNumData()
        }
      },
      // 选择一元tab状态
      oneWinClickItem (index) {
        this.orderStatus = index
        if (this.userOrAgent === 'agent') {
          this.isAgent = true
          this.isUser = false
          this.oneWinData = []
          this.getAgentLotteryOneWinData()
        } else {
          this.isAgent = false
          this.isUser = true
          this.oneWinData = []
          this.getUserLotteryOneWinData()
        }
      },
      // 获取彩种类型
      getLotteryTypeData () {
        var params = {}
        API.getLotteryType(params).then(res => {
          if (!res.error && res.result) {
            var result = res.result
            if (result !== null && result !== '' && result !== '0') {
              this.ltypeList = result.items
              this.ltypeList = this.ltypeList.map(item => {
                return {
                  key: item.id,
                  value: item.name
                }
              })
            }
            var arr = {
              key: '',
              value: '彩种选择'
            }
            this.ltypeList.unshift(arr)
          }
        })
      },
      // 获取会员投注记录信息
      getUserLotteryNoteSingleData () {
        this.beginTime = this.$refs['noteSingleRange'].dateRange[0]
        this.endTime = this.$refs['noteSingleRange'].dateRange[1]
        var params = {
          userId: cookie.get('userId'),
          lotteryId: this.nsType,
          orderStatus: this.orderStatus,
          beginTime: this.beginTime,
          endTime: this.endTime,
          pageSize: this.noteSingleParams.pageSize,
          pageNo: this.noteSingleParams.pageIndex
        }
        this.queryLoading = true
        API.getBettingRecordList(params).then(res => {
          this.queryLoading = false
          if (!res.error && res.result) {
            var result = res.result
            if (result !== null && result !== '' && result !== '0') {
              this.noteSingleParams.total = Math.ceil(result.items.totalPages / this.noteSingleParams.pageSize)
              if (this.noteSingleParams.pageIndex > this.noteSingleParams.total) {
                this.noteSingleParams.showMore = false
              } else {
                this.noteSingleParams.showMore = true
                this.noteSingleData = this.noteSingleData.concat(result.items.elements)
              }
            }
          }
          // this.noteSingleData = [
          //   {lotteryName: '重庆时时彩', createTime: '2017/08/08 12:12:12', issue: '2054897356', playName: '定位胆', orderMoney: '10000', orderStatus: 0},
          //   {lotteryName: '快乐十分', createTime: '2017/08/08 12:12:12', issue: '2054897356', playName: '定位胆', orderMoney: '20000', orderStatus: 2},
          //   {lotteryName: '北京赛车', createTime: '2017/08/08 12:12:12', issue: '2054897356', playName: '定位胆', orderMoney: '30000', orderStatus: 3}
          // ]
        })
      },
      // 获取会员追号记录信息
      getUserLotteryChaseNumData () {
        this.beginTime = this.$refs['chaseNumRange'].dateRange[0]
        this.endTime = this.$refs['chaseNumRange'].dateRange[1]
        var params = {
          userId: cookie.get('userId'),
          lotteryId: this.cnType,
          traceStatus: this.orderStatus,
          beginTime: this.beginTime,
          endTime: this.endTime,
          pageSize: this.chaseNumParams.pageSize,
          pageNo: this.chaseNumParams.pageIndex
        }
        this.queryLoading = true
        API.getChaseNumRecordList(params).then(res => {
          this.queryLoading = false
          if (!res.error && res.result) {
            var result = res.result
            if (result !== null && result !== '' && result !== '0') {
              this.chaseNumParams.total = Math.ceil(result.totalPages / this.chaseNumParams.pageSize)
              if (this.chaseNumParams.pageIndex > this.chaseNumParams.total) {
                this.chaseNumParams.showMore = false
              } else {
                this.noteSingleParams.showMore = true
                this.chaseNumData = this.chaseNumData.concat(result.elements)
              }
            }
          }
          // this.chaseNumData = [
          //   {lotteryName: '重庆时时彩', createTime: '2017/08/08 12:12:12', issue: '2054897356', goIssus: '3', allIssus: '5', playName: '定位胆', orderMoney: '10000', traceStatus: 8},
          //   {lotteryName: '快乐十分', createTime: '2017/08/08 12:12:12', issue: '2054897356', goIssus: '4', allIssus: '8', playName: '定位胆', orderMoney: '20000', traceStatus: 0},
          //   {lotteryName: '北京赛车', createTime: '2017/08/08 12:12:12', issue: '2054897356', goIssus: '5', allIssus: '9', playName: '定位胆', orderMoney: '10000', traceStatus: 1}
          // ]
        })
      },
      // 获取会员一元夺宝信息
      getUserLotteryOneWinData () {
        this.beginTime = this.$refs['oneWinRange'].dateRange[0]
        this.endTime = this.$refs['oneWinRange'].dateRange[1]
        var params = {
          userId: cookie.get('userId'),
          lotteryId: '9999',
          orderStatus: this.orderStatus,
          beginTime: this.beginTime,
          endTime: this.endTime,
          pageSize: this.oneWinParams.pageSize,
          pageNo: this.oneWinParams.pageIndex
        }
        this.queryLoading = true
        API.getBettingRecordList(params).then(res => {
          this.queryLoading = false
          if (!res.error && res.result) {
            var result = res.result
            if (result !== null && result !== '' && result !== '0') {
              this.oneWinParams.total = Math.ceil(result.items.totalPages / this.oneWinParams.pageSize)
              if (this.oneWinParams.pageIndex > this.oneWinParams.total) {
                this.oneWinParams.showMore = false
              } else {
                this.oneWinParams.showMore = true
                this.oneWinData = this.oneWinData.concat(result.items.elements)
              }
            }
          }
          // this.oneWinData = [
          //   {lotteryName: '重庆时时彩', createTime: '2017/08/08 12:12:12', issue: '2054897356', playName: '定位胆', orderMoney: '10000', orderStatus: 0},
          //   {lotteryName: '快乐十分', createTime: '2017/08/08 12:12:12', issue: '2054897356', playName: '定位胆', orderMoney: '20000', orderStatus: 2},
          //   {lotteryName: '北京赛车', createTime: '2017/08/08 12:12:12', issue: '2054897356', playName: '定位胆', orderMoney: '30000', orderStatus: 3}
          // ]
        })
      },
      // 获取代理投注记录信息
      getAgentLotteryNoteSingleData () {
        this.beginTime = this.$refs['noteSingleRange'].dateRange[0]
        this.endTime = this.$refs['noteSingleRange'].dateRange[1]
        var params = {
          agentId: cookie.get('userId'),
          lotteryId: this.nsType,
          userLoginId: this.nsUserLoginId,
          orderStatus: this.orderStatus,
          beginTime: this.beginTime,
          endTime: this.endTime,
          pageSize: this.noteSingleParams.pageSize,
          pageNo: this.noteSingleParams.pageIndex
        }
        this.queryLoading = true
        API.getBettingRecordList(params).then(res => {
          this.queryLoading = false
          if (!res.error && res.result) {
            var result = res.result
            if (result !== null && result !== '' && result !== '0') {
              this.noteSingleParams.total = Math.ceil(result.items.totalPages / this.noteSingleParams.pageSize)
              if (this.noteSingleParams.pageIndex > this.noteSingleParams.total) {
                this.noteSingleParams.showMore = false
              } else {
                this.noteSingleParams.showMore = true
                this.noteSingleData = this.noteSingleData.concat(result.items.elements)
              }
            }
          }
          // this.noteSingleData = [
          //   {loginId: 'TFboy', lotteryName: '重庆时时彩', createTime: '2017/08/08 12:12:12', issue: '2054897356', group: '代理', playName: '定位胆', orderMoney: '10000', orderStatus: 3},
          //   {loginId: 'TFboy1', lotteryName: '快乐十分', createTime: '2017/08/08 12:12:12', issue: '2054897356', group: 'vip', playName: '定位胆', orderMoney: '20000', orderStatus: 4},
          //   {loginId: 'TFboy2', lotteryName: '北京赛车', createTime: '2017/08/08 12:12:12', issue: '2054897356', group: '会员', playName: '定位胆', orderMoney: '10000', orderStatus: 5}
          // ]
        })
      },
      // 获取代理追号记录信息
      getAgentLotteryChaseNumData () {
        this.beginTime = this.$refs['chaseNumRange'].dateRange[0]
        this.endTime = this.$refs['chaseNumRange'].dateRange[1]
        var params = {
          agentId: cookie.get('userId'),
          lotteryId: this.cnType,
          userLoginId: this.cnUserLoginId,
          traceStatus: this.orderStatus,
          beginTime: this.beginTime,
          endTime: this.endTime,
          pageSize: this.chaseNumParams.pageSize,
          pageNo: this.chaseNumParams.pageIndex
        }
        this.queryLoading = true
        API.getChaseNumRecordList(params).then(res => {
          this.queryLoading = false
          if (!res.error && res.result) {
            var result = res.result
            if (result !== null && result !== '' && result !== '0') {
              this.chaseNumParams.total = Math.ceil(result.totalPages / this.chaseNumParams.pageSize)
              if (this.chaseNumParams.pageIndex > this.chaseNumParams.total) {
                this.chaseNumParams.showMore = false
              } else {
                this.noteSingleParams.showMore = true
                this.chaseNumData = this.chaseNumData.concat(result.elements)
              }
            }
          }
          // this.chaseNumData = [
          //   {loginId: 'TFboy', lotteryName: '重庆时时彩', createTime: '2017/08/08 12:12:12', issue: '2054897356', goIssus: '3', allIssus: '5', group: '代理', playName: '定位胆', orderMoney: '10000', traceStatus: 8},
          //   {loginId: 'TFboy1', lotteryName: '快乐十分', createTime: '2017/08/08 12:12:12', issue: '2054897356', goIssus: '4', allIssus: '8', group: 'vip', playName: '定位胆', orderMoney: '20000', traceStatus: 0},
          //   {loginId: 'TFboy2', lotteryName: '北京赛车', createTime: '2017/08/08 12:12:12', issue: '2054897356', goIssus: '5', allIssus: '9', group: '会员', playName: '定位胆', orderMoney: '10000', traceStatus: 1}
          // ]
        })
      },
      // 获取代理一元夺宝信息
      getAgentLotteryOneWinData () {
        this.beginTime = this.$refs['oneWinRange'].dateRange[0]
        this.endTime = this.$refs['oneWinRange'].dateRange[1]
        var params = {
          agentId: cookie.get('userId'),
          lotteryId: '9999',
          userLoginId: this.nsUserLoginId,
          orderStatus: this.orderStatus,
          beginTime: this.beginTime,
          endTime: this.endTime,
          pageSize: this.oneWinParams.pageSize,
          pageNo: this.oneWinParams.pageIndex
        }
        this.queryLoading = true
        API.getBettingRecordList(params).then(res => {
          this.queryLoading = false
          if (!res.error && res.result) {
            var result = res.result
            if (result !== null && result !== '' && result !== '0') {
              this.oneWinParams.total = Math.ceil(result.items.totalPages / this.oneWinParams.pageSize)
              if (this.oneWinParams.pageIndex > this.oneWinParams.total) {
                this.oneWinParams.showMore = false
              } else {
                this.oneWinParams.showMore = true
                this.oneWinData = this.oneWinData.concat(result.items.elements)
              }
            }
          }
          // this.oneWinData = [
          //   {loginId: 'TFboy', lotteryName: '重庆时时彩', createTime: '2017/08/08 12:12:12', issue: '2054897356', group: '代理', playName: '定位胆', orderMoney: '10000', orderStatus: 3},
          //   {loginId: 'TFboy1', lotteryName: '快乐十分', createTime: '2017/08/08 12:12:12', issue: '2054897356', group: 'vip', playName: '定位胆', orderMoney: '20000', orderStatus: 4},
          //   {loginId: 'TFboy2', lotteryName: '北京赛车', createTime: '2017/08/08 12:12:12', issue: '2054897356', group: '会员', playName: '定位胆', orderMoney: '10000', orderStatus: 5}
          // ]
        })
      },
      btnClick () {
        if (this.tabActive === 0) {
          this.orderStatus = ''
          this.showNoteSingle = true
          this.showChaseNum = false
          this.showOneWin = false
          if (this.userOrAgent === 'agent') {
            this.isAgent = true
            this.isUser = false
          } else {
            this.isAgent = false
            this.isUser = true
          }
        } else if (this.tabActive === 1) {
          this.orderStatus = ''
          this.showNoteSingle = false
          this.showChaseNum = true
          this.showOneWin = false
          if (this.userOrAgent === 'agent') {
            this.isAgent = true
            this.isUser = false
          } else {
            this.isAgent = false
            this.isUser = true
          }
        } else if (this.tabActive === 2) {
          this.orderStatus = ''
          this.showNoteSingle = false
          this.showChaseNum = false
          this.showOneWin = true
          if (this.userOrAgent === 'agent') {
            this.isAgent = true
            this.isUser = false
          } else {
            this.isAgent = false
            this.isUser = true
          }
        }
      },
      // 查询注单列表
      searchNoteSingle () {
        this.nsType = this.ltypens
        if (this.ltypens === '') {
          this.nsType = undefined
        }
        if (this.userOrAgent === 'agent') {
          this.isAgent = true
          this.isUser = false
          this.noteSingleData = []
          this.noteSingleParams.pageIndex = 1
          this.getAgentLotteryNoteSingleData()
        } else {
          this.isAgent = false
          this.isUser = true
          this.noteSingleData = []
          this.noteSingleParams.pageIndex = 1
          this.getUserLotteryNoteSingleData()
        }
      },
      // 查询追号列表
      searchChaseNum () {
        this.cnType = this.ltypecn
        if (this.ltypecn === '') {
          this.cnType = undefined
        }
        if (this.userOrAgent === 'agent') {
          this.isAgent = true
          this.isUser = false
          this.chaseNumData = []
          this.chaseNumParams.pageIndex = 1
          this.getAgentLotteryChaseNumData()
        } else {
          this.isAgent = false
          this.isUser = true
          this.chaseNumData = []
          this.chaseNumParams.pageIndex = 1
          this.getUserLotteryChaseNumData()
        }
      },
      // 查询一元夺宝
      searchOneWin () {
        if (this.userOrAgent === 'agent') {
          this.isAgent = true
          this.isUser = false
          this.chaseNumData = []
          this.chaseNumParams.pageIndex = 1
          this.getAgentLotteryOneWinData()
        } else {
          this.isAgent = false
          this.isUser = true
          this.chaseNumData = []
          this.chaseNumParams.pageIndex = 1
          this.getUserLotteryOneWinData()
        }
      },
      // 更多投注记录
      getMoreNoteSingle () {
        this.oneWinParams.pageIndex = this.oneWinParams.pageIndex + 1
        if (this.oneWinParams.pageIndex > this.oneWinParams.total && this.oneWinParams.total !== 0) {
          this.oneWinParams.showMore = false
          return false
        }
        if (this.userOrAgent === 'agent') {
          this.getAgentLotteryOneWinData()
        } else {
          this.getUserLotteryOneWinData()
        }
      },
      // 更多追号记录
      getMoreChaseNum () {
        this.chaseNumParams.pageIndex = this.chaseNumParams.pageIndex + 1
        if (this.chaseNumParams.pageIndex > this.chaseNumParams.total && this.chaseNumParams.total !== 0) {
          this.noteSingleParams.showMore = false
          return false
        }
        if (this.userOrAgent === 'agent') {
          this.getAgentLotteryNoteSingleData()
        } else {
          this.getUserLotteryNoteSingleData()
        }
      },
      // 更多一元夺宝
      getMoreOneWin () {
        this.noteSingleParams.pageIndex = this.noteSingleParams.pageIndex + 1
        if (this.noteSingleParams.pageIndex > this.noteSingleParams.total && this.noteSingleParams.total !== 0) {
          this.noteSingleParams.showMore = false
          return false
        }
        if (this.userOrAgent === 'agent') {
          this.getAgentLotteryNoteSingleData()
        } else {
          this.getUserLotteryNoteSingleData()
        }
      }
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user_betting
    .vux-button-group > a
      max-width rem(196) !important
    .vux-tab 
      background-color $color-el-bg
    #one-win
      .selectWrap 
        .vux-selector
          width rem(160)
      .vux-flexbox:last-child
        padding-top: 0 !important
      .vux-x-input
        margin-right rem(10)
    #one-win
    #note-single
    #chase-number
      .vux-tab-item
        font-size rem(30)
      .userCondition
        .vux-selector
          width rem(240)
        .weui-btn
          margin-left rem(40)
        .vux-flexbox:last-child
          padding-top 0 !important
      .condition
        padding rem(30) rem(28) rem(30) rem(28)
        background-color $color-white
        .changeChecklist
          .weui-cell
            padding 0
          .weui-cells:before
            border-top 0
          .weui-cells:after  
            border-bottom 0      
          .weui-cells_checkbox .weui-check:checked + .vux-checklist-icon-checked:before, .weui-cells_checkbox .weui-check:checked + .vux-checklist-icon-checked:before, .weui-cells_checkbox .weui-check:checked + .weui-icon-checked:before
            color $color-red
          .weui-cells_checkbox .weui-cell__hd
            margin-right 0
            padding-right 0
        .vux-flexbox:last-child
          padding-top rem(30)
          .weui-input
            width rem(180)
            background-color $color-white
          .weui-cell__ft
            position absolute
            right rem(5)
      .right-icon
        position: relative;
    #chase-number
      .right-icon
        top: rem(90)
    .weui-cell
      padding 0
    .app-body
      color #000
      font-weight bold
      font-size rem(30)
    .selectItem
      position relative
    .lott-icon.up
      width rem(40)
      height rem(60)
      position absolute
      top 50%
      margin-top rem(-30)
      right rem(10)
    .selectWrap
      background $color-white
      width auto
      .vux-flexbox-item
        display table
      .weui-cell:before
        display none
      .vux-selector
        display inline-flex
        width rem(334)
        border solid 1px #ccc
        border-radius rem(4)
      .vux-x-input
        padding 0
        vertical-align middle
      .vux-x-input .weui-label
        width rem(120) !important
        margin-left rem(10)
      .vux-x-input:last-child .weui-label
        width rem(40) !important
        margin-left rem(10)
      .weui-input
        width rem(100)
      .weui-select
        height rem(60)
        line-height rem(60)
        padding 0 rem(24)
    line-height 1.5
    .weui-input
      border solid 1px $color-ccc
      height rem(60)
      padding 0 rem(44) 0 rem(12)
      border-radius rem(4)
    .weui-cell_select
      .weui-cell__bd:after
        display none
    ul li
      display flex
      margin 0rem 0.5rem
      border-top 1px solid #EAEAEA
    ul li:last-child
      border-bottom 1px solid #EAEAEA
    ul li p 
      display grid
      float left
      padding rem(30) rem(10) rem(30) rem(30)
    ul li p>span
      font-size rem(28)
      display block
      line-height rem(60)
    ul li p .right-icon
      top rem(60)
      position relative
</style>