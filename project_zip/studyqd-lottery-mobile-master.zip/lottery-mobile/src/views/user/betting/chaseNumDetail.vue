<template>
  <div class="app-main page-user page-user_chaseNumDetail">
    <x-header :left-options="{backText: ''}" :title="title" class="is-fixed"></x-header>
    <div class="app-body">
      <div>
        <ul v-show="isUser">
          <li>
            <span>追号编号：</span>
            <span>{{detailInfoData.traceCode}}<span class="copy" v-clipboard="detailInfoData.orderCode"  @success="handleSuccess" @error="handleError">复制</span></span>
          </li>
          <li>
            <span>彩种：</span>
            <span>{{detailInfoData.lotteryName}}</span>
          </li>
          <li>
            <span>玩法：</span>
            <span>{{detailInfoData.playName}}</span>
          </li>
          <li>
            <span>单注金额：</span>
            <span><span class="font-red">{{detailInfoData.singleMoney}}</span>元</span>
          </li>
          <li>
            <span>倍数/注数：</span>
            <span>{{detailInfoData.buyDouble}}倍/{{detailInfoData.buyNumber}}注</span>
          </li>
          <li>
            <span>奖金/返点：</span>
            <span>{{detailInfoData.prize}}/{{detailInfoData.rebateRate}}</span>
          </li>
          <li>
          <li>
            <span>投注内容：</span>
            <span>{{detailInfoData.buyCodeCase}}</span>
          </li>
          
          <li>
            <span>起追时间：</span>
            <span>{{detailInfoData.createTime}}</span>
          </li>
          <li>
            <span>起追期号：</span>
            <span>{{detailInfoData.beginIssue}}</span>
          </li>
          <li>
            <span>已追/总期数：</span>
            <span><span class="font-red">{{detailInfoData.alreadyTraceNum}}</span>期/<span class="font-red">{{detailInfoData.totalTraceNum}}</span>期</span>
          </li>
          <li>
            <span>已投/总金额：</span>
            <span><span class="font-red">{{detailInfoData.alreadyBuyMoney}}</span>元/<span class="font-red">{{detailInfoData.totalBuyMoney}}</span>元</span>
          </li>
          <li>
            <span>中奖停追</span>
            <span>{{detailInfoData.winningToStop == 0 ? '否' : '是'}}</span>
          </li>
          <li>
            <span>订单状态：</span>
            <span><span v-if="detailInfoData.traceStatus != 8" class="font-red">{{detailInfoData.traceStatus == 0 ? '未开始' : detailInfoData.traceStatus == 1 ? '已开始' : ''}}</span><span v-else style="color: #636363;">已结束</span></span>
          </li>
        </ul>
        <ul v-show="isAgent">
          <li>
            <span>用户：</span>
            <span>{{detailInfoData.loginId}}</span>
          </li>
          <li>
            <span>所属组：</span>
            <span>{{detailInfoData.regType == 'a' ? '代理' : '会员'}}</span>
          </li>
          <li>
            <span>追号编号：</span>
            <span>{{detailInfoData.traceCode}}<span class="copy" v-clipboard="detailInfoData.orderCode"  @success="handleSuccess" @error="handleError">复制</span></span>
          </li>
          <li>
            <span>彩种：</span>
            <span>{{detailInfoData.lotteryName}}</span>
          </li>
          <li>
            <span>玩法：</span>
            <span>{{detailInfoData.playName}}</span>
          </li>
          <li>
            <span>单注金额：</span>
            <span><span class="font-red">{{detailInfoData.singleMoney}}</span>元</span>
          </li>
          <li>
            <span>倍数/注数：</span>
            <span>{{detailInfoData.buyDouble}}倍/{{detailInfoData.buyNumber}}注</span>
          </li>
          <li>
            <span>赔率/返点：</span>
            <span>{{detailInfoData.prize}}/{{detailInfoData.rebateRate}}</span>
          </li>
          <li>
          <li>
            <span>投注内容：</span>
            <span>{{detailInfoData.buyCodeCase}}</span>
          </li>
          
          <li>
            <span>起追时间：</span>
            <span>{{detailInfoData.createTime}}</span>
          </li>
          <li>
            <span>起追期号：</span>
            <span>{{detailInfoData.beginIssue}}</span>
          </li>
          <li>
            <span>已追/总期数：</span>
            <span><span class="font-red">{{detailInfoData.alreadyTraceNum}}</span>期/<span class="font-red">{{detailInfoData.totalTraceNum}}</span>期</span>
          </li>
          <li>
            <span>已投/总金额：</span>
            <span><span class="font-red">{{detailInfoData.alreadyBuyMoney}}</span>元/<span class="font-red">{{detailInfoData.totalBuyMoney}}</span>元</span>
          </li>
          <li>
            <span>中奖停追</span>
            <span>{{detailInfoData.winningToStop == 0 ? '否' : '是'}}</span>
          </li>
          <li>
            <span>订单状态：</span>
            <span><span v-if="detailInfoData.traceStatus != 8" class="font-red">{{detailInfoData.traceStatus == 0 ? '未开始' : detailInfoData.traceStatus == 1 ? '已开始' : ''}}</span><span v-else style="color: #636363;">已结束</span></span>
          </li>
        </ul>
        <router-link :to="'../chaseNumNoteSingle/' + detailInfoData.traceCode"><x-button type="primary" style="background-color: #FF5152;" action-type="button">查看追号注单</x-button></router-link>
        <x-button type="primary" style="background-color: #858585;margin-top: 15px;" action-type="button" @click.native="withdrawSingle()">撤单</x-button>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import Vue from 'vue'
  import { ButtonTab, ButtonTabItem, cookie } from 'vux'
  import VueClipboards from 'vue-clipboards'
  import * as API from 'api/wapi/user'
  Vue.use(VueClipboards)
  export default {
    data () {
      return {
        title: '追号方案详情',
        userOrAgent: '',
        isUser: false,
        isAgent: false,
        detailInfoData: []
      }
    },
    components: {
      ButtonTab,
      ButtonTabItem
    },
    created () {
    },
    watch: {
    },
    mounted () {
      this.userOrAgent = cookie.get('loginType')
      this.getChaseNumDetailData()
      if (this.userOrAgent === 'agent') {
        this.isAgent = true
        this.isUser = false
      } else {
        this.isAgent = false
        this.isUser = true
      }
    },
    methods: {
      // 复制功能
      handleSuccess (e) {
        this.$vux.toast.show({
          text: '复制成功',
          position: 'middle'
        })
      },
      handleError (e) {
        this.$vux.toast.show({
          type: 'warn',
          text: '复制失败',
          position: 'middle'
        })
      },
      // 查询投注记录详情
      getChaseNumDetailData () {
        var params = {
          traceCode: this.$route.params.sid
        }
        API.GetLChaseNumRecordDetail(params).then(res => {
          if (!res.error && res.result) {
            this.detailInfoData = res.result
          }
        })
      },
      // 撤单
      withdrawSingle () {
        const _this = this
        this.$vux.confirm.show({
          title: '提示',
          content: '是否执行撤单操作？',
          onCancel () {
            _this.$vux.toast.show({
              text: '已取消撤单',
              position: 'middle'
            })
          },
          onConfirm () {
            var params = {
              orderCode: _this.$route.params.sid,
              issue: _this.detailInfoData.issue,
              lotteryId: _this.detailInfoData.lotteryId
            }
            API.doOrderCancel(params).then(res => {
              if (!res.error && res.result) {
                _this.$vux.toast.show({
                  text: '撤单成功',
                  position: 'middle'
                })
                this.getNoteSingleDetailData()
              } else {
                _this.$vux.toast.show({
                  type: 'warn',
                  width: '10em',
                  text: res.error.message,
                  position: 'middle'
                })
              }
            })
          }
        })
      }
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user_chaseNumDetail
    .app-body
      font-size rem(30)
      >div
        padding rem(40)
        ul
          margin-bottom rem(40)
          li
            line-height rem(50)
            .copy
              color #0096ff
              margin-left rem(40)
            span
              font-size rem(28)
              display inline-block
            >span
              display inline-block
            >span:last-child
              width 60%
              float right
</style>