<template>
  <div class="app-main page-user page-user__information-setting">
    <x-header :title="title" class="is-fixed">
      <a href="javascript:;" @click="$router.push({ path: '/user/information' })" slot="overwrite-left">取消</a>
      <a href="javascript:;" @click="submitHandle" slot="right">完成</a>
    </x-header>
    <div class="app-body">
      <!-- 头像 -->
      <group v-if="menuType === 'portrait'" class="handle-form" :class="'handle-form__' + menuType" stylereset>
        <div class="portrait-active">
          <img class="portrait-active__pic" :src="menuValue.full">
          <p class="portrait-active__title">当前头像</p>
        </div>
        <div class="portrait-all">
          <grid :cols="4">
            <grid-item
              v-for="(item, i) in portrait.list"
              :key="i"
              :class="item.face === menuValue.face ? 'is-active' : ''"
              @click.native="menuValue = item">
              <img slot="default" :src="item.full">
            </grid-item>
          </grid>
        </div>
      </group>
      <!-- 昵称 -->
      <group v-if="menuType === 'nickname'" class="handle-form" :class="'handle-form__' + menuType" stylereset>
        <x-input v-model="menuValue" placeholder="请输入昵称"></x-input>
      </group>
      <!-- 手机号 -->
      <group v-if="menuType === 'telephone'" class="handle-form" :class="'handle-form__' + menuType" stylereset>
        <x-input v-model="menuValue" placeholder="请输入手机号"></x-input>
      </group>
      <!-- 邮箱 -->
      <group v-if="menuType === 'email'" class="handle-form" :class="'handle-form__' + menuType" stylereset>
        <x-input v-model="menuValue" placeholder="请输入邮箱"></x-input>
      </group>
      <!-- 性别 -->
      <group v-if="menuType === 'sex'" class="handle-form" :class="'handle-form__' + menuType" stylereset>
        <radio v-model="menuValue" :options="sexList"></radio>
      </group>
      <!-- 生日 -->
      <group v-if="menuType === 'birthday'" class="handle-form" :class="'handle-form__' + menuType" stylereset>
        <datetime v-model="menuValue" :start-date="startDate" :end-date="endDate" placeholder="请选择生日"></datetime>
      </group>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import Vue from 'vue'
  import { Group, Cell, Grid, GridItem, Radio, Datetime, ConfirmPlugin, cookie, dateFormat } from 'vux'
  import { mapMutations } from 'vuex'
  import * as API from 'api/wapi/user'
  Vue.use(ConfirmPlugin)
  export default {
    data () {
      return {
        title: '设置',
        menuType: '',
        menuValue: '',
        portrait: {
          list: []
        },
        sexList: [
          { key: 0, value: '保密' },
          { key: 1, value: '男' },
          { key: 2, value: '女' }
        ],
        startDate: '1970-01-01',
        endDate: dateFormat(new Date(), 'YYYY-MM-DD')
      }
    },
    components: {
      Group, Cell, Grid, GridItem, Radio, Datetime
    },
    created () {
      this.showActiveMenuContent()
      if (this.menuType === 'portrait') {
        this.getPortraitList()
      }
    },
    methods: {
      // 展示对应的菜单内容
      showActiveMenuContent () {
        var activeMenu = this.$store.state.userInformation.activeMenu
        if (!activeMenu) {
          return this.$router.push({ path: '/user/information' })
        }
        this.title += activeMenu.name
        this.menuType = activeMenu.type
        this.menuValue = activeMenu.value
      },
      // 获取全部头像
      getPortraitList () {
        // 头像处理
        var imgFilePath = cookie.get('imgFilePath')
        if (!imgFilePath || !/\S/.test(imgFilePath)) {
          // 获取图片文件展示路径
          API.getImgFilePath().then(data => {
            imgFilePath = !data.error ? data.result : ''
            for (var i = 1; i <= 20; i++) {
              this.portrait.list.push({
                'face': '/images/head/' + i + '.png',
                'full': imgFilePath + '/images/head/' + i + '.png'
              })
            }
            this.setCookieImgFilePath({ 'imgFilePath': imgFilePath })
          })
        } else {
          for (var i = 1; i <= 20; i++) {
            this.portrait.list.push({
              'face': '/images/head/' + i + '.png',
              'full': imgFilePath + '/images/head/' + i + '.png'
            })
          }
        }
      },
      // 确定
      submitHandle () {
        var params = {}
        if (this.menuType === 'portrait') { // 头像
          params['userImage'] = this.menuValue.face
        } else if (this.menuType === 'nickname') { // 昵称
          if (!this.menuValue || !/\S/.test(this.menuValue)) {
            this.$vux.toast.show({
              type: 'warn',
              text: '昵称不能为空'
            })
            return false
          }
          if (!/^[0-9a-zA-Z\u4e00-\u9fa5\-_]{4,30}$/.test(this.menuValue)) {
            this.$vux.toast.show({
              type: 'warn',
              text: '昵称只能输入4-30位数字/字母/汉字/-_或组合'
            })
            return false
          }
          params['nickname'] = this.menuValue
        } else if (this.menuType === 'telephone') { // 手机号
          if (!this.menuValue || !/\S/.test(this.menuValue)) {
            this.$vux.toast.show({
              type: 'warn',
              text: '手机号不能为空'
            })
            return false
          }
          if (!/^(0|86|17951)?(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$/.test(this.menuValue)) {
            this.$vux.toast.show({
              type: 'warn',
              text: '手机号格式错误'
            })
            return false
          }
          params['mobile'] = this.menuValue
        } else if (this.menuType === 'email') { // 邮箱
          if (!this.menuValue || !/\S/.test(this.menuValue)) {
            this.$vux.toast.show({
              type: 'warn',
              text: '邮箱不能为空'
            })
            return false
          }
          if (!/^[A-Za-z\d]+([-_.][A-Za-z\d]+)*@([A-Za-z\d]+[-.])+[A-Za-z\d]{2,4}$/.test(this.menuValue)) {
            this.$vux.toast.show({
              type: 'warn',
              text: '邮箱格式错误'
            })
            return false
          }
          params['email'] = this.menuValue
        } else if (this.menuType === 'sex') { // 性别
          params['gender'] = this.menuValue
        } else if (this.menuType === 'birthday') { // 生日
          if (!this.menuValue || !/\S/.test(this.menuValue)) {
            this.$vux.toast.show({
              type: 'warn',
              text: '生日不能为空'
            })
            return false
          }
          params['birthday'] = this.menuValue
        }
        var self = this
        this.$vux.confirm.show({
          title: '您确定进行此操作?',
          onConfirm () {
            API.updateUserProfile(params).then(res => {
              if (!res.error && Number(res.result) === 1) {
                self.$vux.toast.show({
                  type: 'success',
                  text: '操作成功',
                  onHide () {
                    self.$router.push({ path: '/user/information' })
                  }
                })
              } else {
                self.$vux.toast.show({
                  type: 'warn',
                  text: res.error.message
                })
              }
            })
          }
        })
      },
      ...mapMutations(['setCookieImgFilePath'])
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user__information-setting {
    .handle-form__portrait {
      padding-top: rem(336)
      .weui-cells {
        margin-top: 0
        &:after {
          display: none
        }
      }
      .portrait-active {
        position: fixed
        top: $topBarHeight
        left: 0
        right: 0
        z-index: 9
        height: rem(336)
        text-align: center
        background-color: #fff
        &__pic {
          box-sizing: border-box
          width: rem(237)
          height: rem(233)
          margin-top: rem(26)
          vertical-align: middle
          border: 3px solid #14b2b5
          border-radius: 3px
          overflow: hidden
        }
        &__title {
          margin-top: rem(20)
          font-size: rem(24)
          color: #434343
        }
      }
      .portrait-all {
        background-color: #f7f7f7
        .weui-grids {
          padding: rem(10)
          &:before,
          &:after {
            display: none
          }
        }
        .weui-grid {
          width: 25% !important
          padding: rem(10)
          &:before,
          &:after {
            display: none
          }
          img {
            width: 100%
            box-sizing: border-box
            border-radius: 3px
            vertical-align: middle
            overflow: hidden
          }
          &.is-active img {
            border: 3px solid #14b2b5
          }
        }
      }
    }
    .handle-form__birthday {
      .vux-datetime-value {
        text-align: left
        &:after {
          display: none !important
        }
      }
    }
  }
</style>
