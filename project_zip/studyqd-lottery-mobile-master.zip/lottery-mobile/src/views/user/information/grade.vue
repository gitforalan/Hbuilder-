<template>
  <div class="app-main page-user page-user__information-grade">
    <x-header
      :left-options="{ backText: '', preventGoBack: true }"
      @on-click-back="$router.push({ path: '/user/information' })"
      class="is-fixed">
      <button-tab v-model="tabActive" stylereset>
        <button-tab-item @on-item-click="tabSwitchHandle('/user/information')"><icon-svg iconClass="duihao"></icon-svg>个人信息</button-tab-item>
        <button-tab-item @on-item-click="tabSwitchHandle('/user/information/grade')"><icon-svg iconClass="duihao"></icon-svg>等级头衔</button-tab-item>
      </button-tab>
    </x-header>
    <div class="app-body">
      <group class="user-import" stylereset>
        <div class="user-import__head">
          <img :src="userImage" class="user-import__portrait">
          <p class="user-import__word-item">
            帐号：{{ userName }}
            <span class="vip-grade" :class="'vip-grade--' + levelCode"></span>
          </p>
          <p class="user-import__word-item">
            头衔：<span class="user-import__deposit">{{ levelName }}</span>
            <span class="user-import__deposit-handle">成长值{{ amount }}分</span>
          </p>
        </div>
        <div class="user-import__body">
          <div class="progress-bar">
            <p class="progress-bar__title"><span v-if="lastLevel > levelCode">距离下一级需{{ levelNextIntegral - amount }}分</span><span>每充值1元加1分</span></p>
            <div class="progress-bar__inner">
              <span v-if="lastLevel > levelCode" class="progress-bar__word">VIP{{ levelCode }}</span>
              <div class="progress-bar__speed">
                <p class="progress-bar__speed-curr" :style="{ 'width': levelNextPercentage + '%' }"><i>{{ levelNextPercentage }}%</i></p>
              </div>
              <span class="progress-bar__word progress-bar__word--right">VIP{{ lastLevel > levelCode ? levelCode + 1 : lastLevel }}</span>
            </div>
          </div>
        </div>
      </group>
      <group class="grade-list" stylereset>
        <h3 class="grade-list__title">等级机制</h3>
        <div class="grade-list__body">
          <x-table class="grade-list__table" :full-bordered="true" :content-bordered="true" :cell-bordered="true">
            <thead>
              <tr>
                <th width="14%">等级</th>
                <th width="14%">头衔</th>
                <th width="18%">成长积分</th>
                <th width="28%">晋级奖励（元）</th>
                <th width="28%">跳级奖励（元）</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="item in dataList">
                <td>{{ item.level }}</td>
                <td>{{ item.levelName }}</td>
                <td>{{ item.integral }}</td>
                <td>{{ isOpenFun ? item.promotionAward : 0 }}</td>
                <td>{{ isOpenFun ? item.skipAward : 0 }}</td>
              </tr>
            </tbody>
          </x-table>
          <dl class="grade-list__desc">
            <dt>活动说明</dt>
            <dd v-if="isOpenFun">1、会员每晋级一个等级，都能获得奖励，最高可达{{ dataList[dataList.length - 1].promotionAward }}元</dd>
            <dd>{{ isOpenFun ? '2、' : '1、' }}充值1元可获得1分成长积分</dd>
          </dl>
        </div>
      </group>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { ButtonTab, ButtonTabItem, XTable, LoadMore, cookie } from 'vux'
  import { mapMutations } from 'vuex'
  import * as API from 'api/wapi/user'
  export default {
    data () {
      return {
        title: '等级头衔',
        tabActive: 1,
        userImage: '',
        userName: '',
        levelCode: 0,
        lastLevel: 0,
        levelName: '-',
        amount: 0,
        dataList: [],
        isOpenFun: false, // 是否开启功能
        levelNextIntegral: 0, // 晋下一级积分
        levelNextPercentage: 0 // 晋下一级百分比
      }
    },
    components: {
      ButtonTab, ButtonTabItem, XTable, LoadMore
    },
    created () {
      this.getUserProfile()
    },
    methods: {
      // tab切换
      tabSwitchHandle (hash) {
        this.$router.push(hash)
      },
      // 获取用户基本信息
      getUserProfile () {
        var params = {
          withLevel: 1
        }
        API.getUserProfile(params).then(res => {
          if (!res.error && res.result) {
            // 头像处理
            var imgFilePath = cookie.get('imgFilePath')
            if (!imgFilePath || !/\S/.test(imgFilePath)) {
              // 获取图片文件展示路径
              API.getImgFilePath().then(data => {
                imgFilePath = !data.error ? data.result : ''
                this.userImage = imgFilePath + '/' + res.result.userImage
                this.setCookieImgFilePath({ 'imgFilePath': imgFilePath })
              })
            } else {
              this.userImage = imgFilePath + '/' + res.result.userImage
            }
            this.userName = res.result.loginId
            this.levelCode = res.result.levelCode
            this.levelName = res.result.levelName || '-'
            this.amount = res.result.amount || 0
            // 积分处理
            this.getActivityPromotion().then(() => {
              for (var i = 0; i < this.dataList.length; i++) {
                if (this.dataList[i].integral > this.amount || (i + 1) === this.dataList.length) {
                  this.levelNextIntegral = this.dataList[i].integral || 0
                  var _num = Number(this.amount / this.levelNextIntegral).toFixed(2) * 100
                  this.levelNextPercentage = _num > 100 ? 100 : _num
                  break
                }
              }
            })
          }
        })
      },
      // 获取晋级活动
      getActivityPromotion () {
        return API.getActivityPromotion().then(res => {
          if (!res.error && res.result) {
            this.isOpenFun = res.result.status === 1 || false
            this.lastLevel = res.result.lastLevel
            this.dataList = res.result.promotion || []
          } else {
            this.isOpenFun = false
            this.dataList = []
          }
        })
      },
      ...mapMutations(['setCookieImgFilePath'])
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user__information-grade {
    .user-import {
      .weui-cells {
        position: relative
        align-items: center
        margin-top: 0
      }
      &__head {
        overflow: hidden
        padding: rem(40) rem(50) 0
      }
      &__portrait {
        float: left
        width: rem(128)
        height: rem(128)
        margin-right: rem(35)
        border: 1px solid #8a8a8a
        border-radius: 50%
        vertical-align: middle
        border-radius: 50%
      }
      &__word-item {
        margin-top: rem(25)
        font-size: rem(28)
      }
      &__word-item + .user-import__word-item {
        margin-top: rem(10)
      }
      &__deposit {
        color: #878787
      }
      &__deposit-handle {
        margin-left: rem(15)
        color: #ff5151
      }
      &__body {
        margin: rem(25) 0
        padding: 0 rem(25) 0 rem(50)
      }
      .progress-bar {
        font-size: rem(20)
        &__title {
          text-align: center
          color: #434343
          > span {
            padding: 0 rem(12.5)
          }
        }
        &__inner {
          position: relative
          display: flex
          align-items: center
          margin-top: rem(10)
        }
        &__word {
          color: #ff5151
        }
        &__speed {
          width: 100%
          height: rem(24)
          margin: 0 rem(25)
          background-color: #a4a4a4
          border-radius: 10px
          &-curr {
            display: block
            box-sizing: border-box
            width: 0%
            height: 100%
            line-height: rem(24)
            text-align: right
            background-color: #ff5151
            color: #fff
            border-radius: 10px
            > i {
              padding: 0 rem(10)
            }
          }
        }
      }
    }
    .grade-list {
      &__title {
        height: rem(74)
        padding: 0 rem(25)
        line-height: rem(74)
        font-size: rem(24)
        color: #000
      }
      &__body {
        padding: 0 rem(15) rem(15)
      }
      &__table {
        thead tr {
          background-color: #f1f3f4
        }
        th {
          font-size: rem(24)
          color: #000
        }
        td {
          font-size: rem(20)
          color: #6c6b6b
        }
      }
      &__desc {
        margin-top: rem(42)
        font-size: rem(22)
        color: #434343
        dt {
          margin-bottom: rem(5)
        }
        dd {
          margin: rem(5) 0
        }
      }
    }
  }
</style>
