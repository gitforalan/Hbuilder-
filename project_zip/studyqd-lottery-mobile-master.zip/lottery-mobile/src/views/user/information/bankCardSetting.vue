<template>
  <div class="app-main page-user page-user__information-bankCard-setting">
    <x-header
      :title="title"
      :left-options="{ backText: '', preventGoBack: true }"
      @on-click-back="$router.push({ path: `${withdrawals ? '/user/withdrawals' : '/user/information/bankCard'}`})"
      class="is-fixed">
    </x-header>
    <div class="app-body">
      <group label-width="5.5em" label-margin-right="1.5em" label-align="right" class="handle-form" stylereset>
        <selector title="开户银行:" v-model="dataForm.bankId" :options="bankList" placeholder="请选择开户银行"></selector>
        <x-input title="分行名称:" v-model="dataForm.bankBranch" placeholder="请输入分行名称"></x-input>
        <x-input title="开户人姓名:" v-model="dataForm.name" placeholder="请输入开户人姓名"></x-input>
        <x-input title="银行卡号:" v-model="dataForm.bankAccount" placeholder="请输入银行卡号"></x-input>
        <x-input title="确认卡号:" v-model="dataForm.confirmBankAccount" placeholder="请输入确认卡号"></x-input>
      </group>
      <p class="handle-form__btn-bar">
        <x-button type="warn" class="handle-form__btn-submit" @click.native="submitForm">保存</x-button>
        <x-button class="handle-form__btn-cancel" @click.native="cancelHandle">取消</x-button>
      </p>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { Group, Selector } from 'vux'
  import * as API from 'api/wapi/user'
  export default {
    data () {
      return {
        title: '设置 - 我的银行卡',
        dataForm: {
          bankId: '',
          bankBranch: '',
          name: '',
          bankAccount: '',
          confirmBankAccount: ''
        },
        bankList: [],
        withdrawals: ''
      }
    },
    components: {
      Group, Selector
    },
    created () {
      this.withdrawals = localStorage.getItem('DRAWAL')
      this.getUserChargeBank()
    },
    destroyed () {
      localStorage.removeItem('DRAWAL')
    },
    methods: {
      // 获取用户银行列表
      getUserChargeBank () {
        API.getUserChargeBank().then(res => {
          if (!res.error && res.result) {
            this.bankList = res.result.map(item => {
              return {
                key: item.bankId,
                value: item.bankName
              }
            })
          } else {
            this.bankList = []
          }
        })
      },
      // 提交表单
      submitForm () {
        if (this.validateForm()) {
          var params = {
            bankId: this.dataForm.bankId,
            name: this.dataForm.name,
            bankBranch: this.dataForm.bankBranch,
            bankAccount: this.dataForm.bankAccount
          }
          API.updateUserBank(params).then(res => {
            if (!res.error && res.result) {
              var self = this
              this.$vux.toast.show({
                type: 'success',
                text: '操作成功',
                onHide () {
                  if (localStorage.getItem('DRAWAL') === 'withdrawals') {
                    // self.$router.push({ path: '/user/atmPassword' })
                    self.$router.push({ path: '/user/security/atmPassword' })
                  } else {
                    self.$router.push({ path: '/user/information/bankCard' })
                  }
                }
              })
            } else {
              this.$vux.toast.show({
                type: 'warn',
                text: res.error.message
              })
            }
          })
        }
      },
      // 验证表单
      validateForm () {
        if (!/\S/.test(this.dataForm.bankId)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '请选择开户银行'
          })
          return false
        }
        if (!/\S/.test(this.dataForm.bankBranch)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '请输入分行名称'
          })
          return false
        }
        if (!/\S/.test(this.dataForm.name)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '请输入开户人姓名'
          })
          return false
        }
        if (!/\S/.test(this.dataForm.bankAccount)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '请输入银行卡号'
          })
          return false
        }
        if (!/\S/.test(this.dataForm.confirmBankAccount)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '请输入确认卡号'
          })
          return false
        }
        if (this.dataForm.bankAccount !== this.dataForm.confirmBankAccount) {
          this.$vux.toast.show({
            type: 'warn',
            text: '卡号2次输入不一致'
          })
          return false
        }
        return true
      },
      // 取消
      cancelHandle () {
        this.$router.go(-1)
      }
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user__information-bankCard-setting {
    .handle-form {
      .weui-select {
        height: auto
        line-height: inherit
      }
      &__btn-bar {
        padding: 0 rem(20)
        margin-top: rem(100)
      }
      &__btn-submit {
        color: #fff
        background-color: #f55
      }
      &__btn-cancel {
        color: #fff
        background-color: #858585
      }
    }
  }
</style>
