<template>
  <div class="app-main page-user page-user__information-bankCard">
    <x-header
      :title="title"
      :left-options="{ backText: '', preventGoBack: true }"
      @on-click-back="$router.push({ path: '/user/information' })"
      class="is-fixed">
    </x-header>
    <div class="app-body" v-if="isInit">
      <!-- 添加银行卡 -->
      <div class="card-box" v-if="!isSetting">
        <div class="card-bar card-bar__add" @click="settingHandle">
          <div class="card-bar__inner">
            <span class="card-bar__add-icon"><icon-svg slot="icon" iconClass="jia"></icon-svg></span>
            <p class="card-bar__add-title">点击添加银行卡</p>
          </div>
        </div>
        <dl class="card-bar__tips">
          <dt>温馨提示：</dt>
          <dd>您尚未添加银行卡，一共可以绑定1张银行卡。</dd>
        </dl>
      </div>
      <!-- 展示银行卡 -->
      <div class="card-box" v-else>
        <div class="card-bar card-bar__show">
          <div class="card-bar__inner">
            <div class="card-bar__show-header">
              <p>{{ card.bankName }}<span class="card-bar__show-address">{{ card.bankBranch }}</span></p>
            </div>
            <div class="card-bar__show-body">
              <p>卡号：{{ card.bankAccount }}</p>
              <p class="card-bar__show-name">户名：{{ card.name }}</p>
            </div>
            <!-- <div class="card-bar__show-footer">
              <p>绑卡日期：{{ card.loginLastUpdateTime }}</p>
            </div> -->
          </div>
        </div>
        <dl class="card-bar__tips">
          <dt>温馨提示：</dt>
          <dd>您已绑定绑定银行卡，如需修改请联系在线客服。</dd>
        </dl>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { dateFormat } from 'vux'
  import * as API from 'api/wapi/user'
  export default {
    data () {
      return {
        title: '我的银行卡',
        isInit: false,
        isSetting: false,
        card: {
          bankName: '',
          bankBranch: '',
          bankAccount: '',
          name: '',
          loginLastUpdateTime: ''
        }
      }
    },
    watch: {
      // 已设置过银行卡
      isSetting (val) {
        if (val) {
          this.getUserProfile()
        }
      }
    },
    created () {
      this.getUserWithdrawAccount()
    },
    methods: {
      // 银行卡设置
      settingHandle () {
        this.$router.push('/user/information/bankCard/setting')
      },
      // 获取用户绑定的银行列表
      getUserWithdrawAccount () {
        API.getUserWithdrawAccount().then(res => {
          this.isInit = true
          if (!res.error && res.result && res.result.length > 0) {
            this.isSetting = true
          } else {
            this.isSetting = false
          }
        })
      },
      // 获取用户银行信息
      getUserProfile () {
        var params = {
          withVipData: 1,
          withBank: 1
        }
        API.getUserProfile(params).then(res => {
          if (!res.error && res.result) {
            this.card.bankName = res.result.bankName
            this.card.bankBranch = res.result.bankBranch
            this.card.bankAccount = res.result.bankAccount
            this.card.name = res.result.name
            this.card.loginLastUpdateTime = dateFormat(res.result.loginLastUpdateTime, 'YYYY-MM-DD')
          }
        })
      }
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user__information-bankCard {
    background-color: #fff
    .card-box {
      position: relative
      padding: rem(40) rem(50)
      font-size: rem(26)
      color: #4f4f4f
      .card-bar {
        height: rem(370)
        text-align: center
        border: rem(5) solid #c6c6c6
        border-radius: rem(5)
      }
      .card-bar__tips {
        margin-top: rem(58)
        dt {
          margin-bottom: rem(15)
          font-size: rem(28)
          font-weight: 900
          color: #ff9600
        }
        dd {
          margin: rem(5) 0
          font-size: rem(24)
        }
      }
      .card-bar__add {
        &-icon {
          display: inline-block
          vertical-align: middle
          width: rem(118)
          height: rem(118)
          margin-top: rem(126)
          text-align: center
          line-height: 1
          border-radius: 100%
          color: #fff
          background-color: #ffd69c
          cursor: pointer
        }
        .lott-icon[class] {
          width: rem(80)
          height: rem(80)
          margin-top: rem(19)
        }
        &-title {
          margin-top: rem(30)
          font-size: rem(24)
          font-weight: 900
          color: #ff9600
        }
      }
      .card-bar__show {
        padding: rem(10)
        text-align: left
        .card-bar__inner {
          position: relative
          height: rem(365)
          border: 1px solid #c6c6c6
          border-radius: rem(5)
        }
        &-header {
          padding: rem(35) 0 rem(25)
          margin: 0 rem(15)
          border-bottom: 1px dashed #c6c6c6
        }
        &-address {
          padding-left: rem(40)
        }
        &-body {
          padding: rem(48) rem(10)
          text-align: center
          color: #000
        }
        &-name {
          font-size: rem(40)
          margin-top: rem(40)
        }
        &-footer {
          position: absolute
          right: 0
          bottom: 0
          left: 0
          height: rem(60)
          padding: 0 rem(15)
          line-height: rem(60)
          text-align: right
          border-top: 1px solid #dadada
          background-color: #f7f7f7
        }
      }
    }
  }
</style>
