<template>
  <div class="app-main page-user page-user__information">
    <x-header
      :left-options="{ backText: '', preventGoBack: true }"
      @on-click-back="$router.push({ path: '/user/index' })"
      class="is-fixed">
      <button-tab v-model="tabActive" stylereset>
        <button-tab-item @on-item-click="tabSwitchHandle('/user/information')"><icon-svg iconClass="duihao"></icon-svg>个人信息</button-tab-item>
        <button-tab-item @on-item-click="tabSwitchHandle('/user/information/grade')"><icon-svg iconClass="duihao"></icon-svg>等级头衔</button-tab-item>
      </button-tab>
    </x-header>
    <div class="app-body">
      <group v-for="(val, i) in menuList" :key="i" class="handle-form" stylereset>
        <cell
          v-for="item in val"
          :key="item.type"
          :title="item.name"
          @click.native="settingMenuHandle(item)"
          :is-link="item.isLink">
          <!-- 头像 -->
          <img v-if="item.type === 'portrait'" slot="value" class="user-portrait" :src="item.value.full">
          <!-- 帐号 -->
          <span v-if="item.type === 'account'" slot="value">{{ item.value }}</span>
          <!-- 昵称 -->
          <span v-if="item.type === 'nickname'" slot="value" :class="settingStateStyle(item.value)">{{ settingStateValue(item.value) }}</span>
          <!-- 手机号 -->
          <span v-if="item.type === 'telephone'" slot="value" :class="settingStateStyle(item.value)">{{ settingStateValue(item.value) }}</span>
          <!-- 邮箱 -->
          <span v-if="item.type === 'email'" slot="value" :class="settingStateStyle(item.value)">{{ settingStateValue(item.value) }}</span>
          <!-- 性别 -->
          <span v-if="item.type === 'sex'" slot="value">{{ item.value | sexFilter }}</span>
          <!-- 生日 -->
          <span v-if="item.type === 'birthday'" slot="value" :class="settingStateStyle(item.value)">{{ settingStateValue(item.value) }}</span>
        </cell>
      </group>
      <group class="handle-form" stylereset>
        <cell title="我的银行卡" link="/user/information/bankCard" is-link></cell>
      </group>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { ButtonTab, ButtonTabItem, cookie, dateFormat } from 'vux'
  import { mapMutations } from 'vuex'
  import * as API from 'api/wapi/user'
  export default {
    data () {
      return {
        title: '会员中心',
        tabActive: 0,
        menuList: [
          {
            'portrait': { name: '头像', type: 'portrait', value: {}, isLink: true },
            'account': { name: '帐号', type: 'account', value: '', isLink: false },
            'nickname': { name: '昵称', type: 'nickname', value: '', isLink: true }
          },
          {
            'telephone': { name: '手机号', type: 'telephone', value: '', isLink: true },
            'email': { name: '邮箱', type: 'email', value: '', isLink: true },
            'sex': { name: '性别', type: 'sex', value: '', isLink: true },
            'birthday': { name: '生日', type: 'birthday', value: '', isLink: true }
          }
        ]
      }
    },
    components: {
      ButtonTab, ButtonTabItem
    },
    filters: {
      sexFilter (val) {
        if (val === 1) {
          return '男'
        } else if (val === 2) {
          return '女'
        } else {
          return '保密'
        }
      }
    },
    created () {
      this.getUserProfile()
    },
    methods: {
      backHanle () {
        alert(1)
      },
      // tab切换
      tabSwitchHandle (hash) {
        this.$router.push(hash)
      },
      // 设置状态, 样式
      settingStateStyle (val) {
        return !val || !/\S/.test(val) ? 'is-secondary' : ''
      },
      // 设置状态, 值
      settingStateValue (val, type) {
        return !val || !/\S/.test(val) ? '未设置' : val
      },
      // 设置菜单内容
      settingMenuHandle (menu) {
        if (menu.isLink) {
          this.setActiveMenu({ 'activeMenu': menu })
          this.$router.push('/user/information/setting')
        }
      },
      // 获取用户基本信息
      getUserProfile () {
        var params = {
          withVipData: 1
        }
        API.getUserProfile(params).then(res => {
          if (!res.error && res.result) {
            // 头像处理
            var imgFilePath = cookie.get('imgFilePath')
            if (!imgFilePath || !/\S/.test(imgFilePath)) {
              // 获取图片文件展示路径
              API.getImgFilePath().then(data => {
                imgFilePath = !data.error ? data.result : ''
                this.menuList[0].portrait.value = {
                  'face': res.result.userImage,
                  'full': imgFilePath + '/' + res.result.userImage
                }
                this.setCookieImgFilePath({ 'imgFilePath': imgFilePath })
              })
            } else {
              this.menuList[0].portrait.value = {
                'face': res.result.userImage,
                'full': imgFilePath + '/' + res.result.userImage
              }
            }
            this.menuList[0].account.value = res.result.loginId
            this.menuList[0].nickname.value = res.result.nickname
            this.menuList[1].telephone.value = res.result.mobile
            this.menuList[1].email.value = res.result.email
            this.menuList[1].sex.value = res.result.gender === 1 || res.result.gender === 2 ? res.result.gender : 0
            this.menuList[1].birthday.value = dateFormat(res.result.birthday, 'YYYY-MM-DD')
          }
        })
      },
      ...mapMutations(['setActiveMenu', 'setCookieImgFilePath'])
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user__information {
    .user-portrait {
      width: rem(80)
      height: rem(80)
      border: 1px solid #8a8a8a
      border-radius: 50%
      vertical-align: middle
    }
  }
</style>
