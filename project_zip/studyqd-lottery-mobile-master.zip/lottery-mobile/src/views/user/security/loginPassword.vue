<template>
  <div class="app-main page-user page-user__security-login-password">
    <x-header
      :title="title"
      :left-options="{ backText: '', preventGoBack: true }"
      @on-click-back="$router.push({ path: '/user/security' })"
      class="is-fixed">
    </x-header>
    <div class="app-body">
      <div class="tips-info">
        <p class="tips-info__item">定期更换登录密码，让您的账户更安全</p>
      </div>
      <group label-width="5.5em" label-margin-right="1.5em" label-align="right" class="handle-form" stylereset>
        <x-input title="当前密码" type="password" v-model="dataForm.password" placeholder="请输入当前密码"></x-input>
        <x-input title="新密码" type="password" v-model="dataForm.newPassword" placeholder="请输入新密码"></x-input>
        <x-input title="确认新密码" type="password" v-model="dataForm.confirmPassword" placeholder="请输入确认新密码"></x-input>
      </group>
      <p class="handle-form__btn-bar">
        <x-button type="warn" class="handle-form__btn-submit" @click.native="submitForm()">保存</x-button>
      </p>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { Group } from 'vux'
  import * as API from 'api/wapi/user'
  import Encode from '@/utils/sha1'
  export default {
    data () {
      return {
        title: '登录密码',
        dataForm: {
          password: '',
          newPassword: '',
          confirmPassword: ''
        }
      }
    },
    components: {
      Group
    },
    methods: {
      submitForm () {
        if (this.validateForm()) {
          var encodePsw = new Encode().encodePsw(this.dataForm.password)
          var params = {
            'saltedPassword': encodePsw.token,
            'salt': encodePsw.salt,
            'newPassword': new Encode().encodeSha1(this.dataForm.newPassword)
          }
          API.updateUserPassword(params).then(res => {
            if (!res.error && res.result) {
              var self = this
              this.$vux.toast.show({
                type: 'success',
                text: '操作成功',
                onHide () {
                  self.$router.push({ path: '/login', query: { flag: 0 } })
                }
              })
            } else {
              this.$vux.toast.show({
                type: 'warn',
                text: res.error.message
              })
            }
          })
        }
      },
      validateForm () {
        if (!/\S/.test(this.dataForm.password)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '请输入当前密码'
          })
          return false
        }
        if (!/\S/.test(this.dataForm.newPassword)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '请输入新密码'
          })
          return false
        }
        if (!/^[0-9a-zA-Z]{6,12}$/.test(this.dataForm.newPassword)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '新密码只能输入6-12位数字/字母或组合'
          })
          return false
        }
        if (!/\S/.test(this.dataForm.confirmPassword)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '请输入确认新密码'
          })
          return false
        }
        if (this.dataForm.newPassword !== this.dataForm.confirmPassword) {
          this.$vux.toast.show({
            type: 'warn',
            text: '新密码2次输入不一致'
          })
          return false
        }
        return true
      }
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user__security-login-password {
    .tips-info {
      padding: rem(40) rem(10)
      text-align: center
      font-size: rem(24)
      color: #7c7c7c
    }
    .handle-form {
      &__btn-bar {
        padding: 0 rem(20)
        margin-top: rem(100)
      }
      &__btn-submit {
        color: #fff
        background-color: #f55
      }
      &__btn-cancel {
        color: #fff
        background-color: #858585
      }
    }
  }
</style>
