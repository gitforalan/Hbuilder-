<template>
  <div class="app-main page-user page-user__security-atm-password">
    <x-header
      :title="title"
      :left-options="{ backText: '', preventGoBack: true }"
      @on-click-back="$router.push({ path: '/user/security' })"
      class="is-fixed">
    </x-header>
    <div class="app-body">
      <div class="tips-info">
        <p class="tips-info__item">定期更换取款密码，让您的账户更安全</p>
        <p v-if="!isSetting" class="tips-info__item" style="margin-top: 10px; color: #f55;">初次修改密码时，默认取款密码为 “0000” ！</p>
      </div>
      <group label-width="5.5em" label-margin-right="1.5em" label-align="right" class="handle-form" stylereset>
        <cell title="当前密码">
          <select v-model="updateForm.password[i - 1]" v-for="i in 4" :key="i" class="password-selector">
            <option>-</option>
            <option v-for="k in 10" :key="k">{{ k - 1 }}</option>
          </select>
        </cell>
        <cell title="新密码">
          <select v-model="updateForm.newPassword[i - 1]" v-for="i in 4" :key="i" class="password-selector">
            <option>-</option>
            <option v-for="k in 10" :key="k">{{ k - 1 }}</option>
          </select>
        </cell>
        <cell title="确认新密码">
          <select v-model="updateForm.confirmPassword[i - 1]" v-for="i in 4" :key="i" class="password-selector">
            <option>-</option>
            <option v-for="k in 10" :key="k">{{ k - 1 }}</option>
          </select>
        </cell>
      </group>
      <p class="handle-form__btn-bar">
        <x-button type="warn" class="handle-form__btn-submit" @click.native="submitForm()">保存</x-button>
      </p>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { Group, Cell, cookie } from 'vux'
  import * as API from 'api/wapi/user'
  import Encode from '@/utils/sha1'
  import { mapMutations } from 'vuex'
  export default {
    data () {
      return {
        title: '取款密码',
        isSetting: false,
        updateForm: {
          password: ['-', '-', '-', '-'],
          newPassword: ['-', '-', '-', '-'],
          confirmPassword: ['-', '-', '-', '-']
        }
      }
    },
    components: {
      Group, Cell
    },
    created () {
      this.getUserPaypassFlag()
    },
    methods: {
      submitForm () {
        if (this.validateForm()) {
          this.update()
        }
      },
      // 修改密码
      update () {
        var encode = new Encode()
        var userId = cookie.get('userId')
        var params = {
          'oldPayPwd': encode.encodeSha1(userId + encode.encodeSha1(this.updateForm.password.join(''))),
          'newPayPwd': encode.encodeSha1(userId + encode.encodeSha1(this.updateForm.newPassword.join('')))
        }
        API.updateUserPaypwd(params).then(res => {
          if (!res.error && Number(res.result) === 1) {
            var self = this
            this.$vux.toast.show({
              type: 'success',
              text: '操作成功',
              onHide () {
                self.updateForm.password = ['-', '-', '-', '-']
                self.updateForm.newPassword = ['-', '-', '-', '-']
                self.updateForm.confirmPassword = ['-', '-', '-', '-']
                if (localStorage.getItem('DRAWAL') === 'withdrawals') {
                  localStorage.removeItem('DRAWAL')
                  self.$router.push({ path: '/user/withdrawals' })
                }
                self.setEditPayPassShow({flag: false})
                self.setCookieEditPayPass({showEditPayPass: 1})
              }
            })
          } else {
            this.$vux.toast.show({
              type: 'warn',
              text: res.error.message
            })
          }
        })
      },
      // 验证表单
      validateForm () {
        if (/-/.test(this.updateForm.password.join(''))) {
          this.$vux.toast.show({
            type: 'warn',
            text: '当前密码填写不完整'
          })
          return false
        }
        if (/-/.test(this.updateForm.newPassword.join(''))) {
          this.$vux.toast.show({
            type: 'warn',
            text: '新密码填写不完整'
          })
          return false
        }
        if (/-/.test(this.updateForm.confirmPassword.join(''))) {
          this.$vux.toast.show({
            type: 'warn',
            text: '确认新密码填写不完整'
          })
          return false
        }
        if (this.updateForm.newPassword.join('') !== this.updateForm.confirmPassword.join('')) {
          this.$vux.toast.show({
            type: 'warn',
            text: '新密码2次输入不一致'
          })
          return false
        }
        return true
      },
      // 获取用户有无支付密码
      getUserPaypassFlag () {
        API.getUserPaypassFlag().then(res => {
          if (!res.error && Number(res.result) === 1) {
            this.isSetting = true
          } else {
            this.isSetting = false
          }
        })
      },
      ...mapMutations(['setEditPayPassShow', 'setCookieEditPayPass'])
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user__security-atm-password {
    .tips-info {
      padding: rem(40) rem(10)
      text-align: center
      font-size: rem(24)
      color: #7c7c7c
    }
    .handle-form {
      .vux-cell-primary {
        flex: 0
      }
      .weui-cell__ft {
        width: 100%
        text-align: left
      }
      .password-selector {
        position: relative
        z-index: 1
        -webkit-appearance: none
        border: 0
        outline: 0
        background-color: transparent
        width: 25%
        height: rem(50)
        line-height: rem(50)
        padding-left: rem(36)
      }
      &__btn-bar {
        padding: 0 rem(20)
        margin-top: rem(100)
      }
      &__btn-submit {
        color: #fff
        background-color: #f55
      }
      &__btn-cancel {
        color: #fff
        background-color: #858585
      }
    }
  }
</style>
