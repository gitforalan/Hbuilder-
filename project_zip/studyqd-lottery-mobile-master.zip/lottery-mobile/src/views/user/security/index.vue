<template>
  <div class="app-main page-user page-user__security">
    <x-header
      :title="title"
      :left-options="{ backText: '', preventGoBack: true }"
      @on-click-back="$router.push({ path: '/user/index' })"
      class="is-fixed">
    </x-header>
    <div class="app-body">
      <div class="login-info">
        <p class="login-info__item">上次登录：{{ loginInfo.dateTime }}</p>
        <p class="login-info__item">{{ loginInfo.address || '&nbsp;' }}</p>
      </div>
      <group class="security-menu" stylereset>
        <cell
          v-for="item in securityMenuList"
          :key="item.name"
          :title="item.name"
          :link="item.link"
          :is-link="item.isLink">
          <span slot="default">修改</span>
        </cell>
      </group>
    </div>
    <x-button type="warn" class="btn-logout" @click.native="logout()">退出当前账户</x-button>
  </div>
</template>

<script type="text/ecmascript-6">
  import Vue from 'vue'
  import { Group, Cell, ConfirmPlugin } from 'vux'
  import { mapMutations } from 'vuex'
  import * as API from 'api/wapi/user'
  Vue.use(ConfirmPlugin)
  export default {
    data () {
      return {
        title: '安全设置',
        loginInfo: {
          dateTime: '',
          address: ''
        },
        securityMenuList: [
          { name: '登录密码', link: '/user/security/loginPassword', isLink: true },
          { name: '取款密码', link: '/user/security/atmPassword', isLink: true }
        ]
      }
    },
    components: {
      Group, Cell
    },
    created () {
      this.getUserLoginInfo()
    },
    methods: {
      // 获取用户基本信息
      getUserLoginInfo () {
        API.getUserLoginInfo().then(res => {
          if (!res.error && res.result) {
            this.loginInfo.dateTime = res.result.loginLastUpdateTime
            this.loginInfo.address = res.result.loginAddr
          }
        })
      },
      // 退出
      logout () {
        var self = this
        this.$vux.confirm.show({
          title: '您确定退出当前账户?',
          onConfirm () {
            API.logout().then(res => {
              if (!res.error && Number(res.result) === 1) {
                self.delCookieToken()
                self.$router.push({ path: '/home' })
              } else {
                self.$vux.toast.show({
                  type: 'warn',
                  text: res.error.message
                })
              }
            })
          }
        })
      },
      ...mapMutations(['setAtmPasswordHandleType', 'delCookieToken'])
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user__security {
    .login-info {
      padding: rem(40) rem(10)
      text-align: center
      font-size: rem(24)
      color: #7c7c7c
      &__item + .login-info__item {
        margin-top: rem(20)
      }
    }
    .btn-logout {
      position: fixed
      bottom: 0
      height: rem(90)
      padding: 0
      line-height: rem(90)
      font-size: rem(28)
      border-radius: 0
      background-color: #f55
      &:after {
        display: none
      }
    }
  }
</style>
