<!-- Created By fx on 2017/9/16. -->
<template>
  <div class="app-main page-user page-user_personal">
    <x-header :left-options="{backText: ''}" class="is-fixed">
      <button-tab v-model="tabActive" stylereset>
        <button-tab-item @on-item-click="btnClick()"><icon-svg iconClass="duihao"></icon-svg>个人总览</button-tab-item>
        <button-tab-item @on-item-click="btnClick()"><icon-svg iconClass="duihao"></icon-svg>个人报表</button-tab-item>
      </button-tab>
    </x-header>
    <div class="app-body">
      <div v-show="showTotal">
        <div class="condition">
          <flexbox :gutter="0">
          <dateRange ref="totalDateRange"></dateRange>
          <flexbox-item class="search"><x-button stylereset @click.native="searchAll()" type="warn" :show-loading="queryLoading"><template v-if="!queryLoading">查询</template></x-button></flexbox-item>
          </flexbox>
        </div>
        <div class="showUserAccount" v-show="showUserAccount">
          会员帐号：{{this.userAccount}}
        </div>
        <grid :cols="3">
          <grid-item v-for="(item, index) in personalTotalData" :key="index">
            <span class="grid-center">
              <h1>{{item.title}}</h1>
              <p>{{item.value}}</p>
            </span>
          </grid-item>
        </grid>
        <div v-show="isUser" class="memo"><strong>净盈利</strong>=中奖金额+投注返点+所有代理返点+优惠金额+日工资-有效投注-我的打赏</div>
        <div v-show="isAgent" class="memo"><strong>净盈利</strong>=中奖金额+投注返点+优惠金额-有效投注-我的打赏</div>
      </div>
      <div v-show="showReport">
        <div class="condition">
          <flexbox :gutter="0">
          <dateRange ref="reportDateRange"></dateRange>
          <flexbox-item class="search"><x-button stylereset @click.native="searchReport()" type="warn" :show-loading="queryLoading"><template v-if="!queryLoading">查询</template></x-button></flexbox-item>
          </flexbox>
        </div>
        <div class="showUserAccount" v-show="showUserAccount">
          会员帐号：{{this.userAccount}}
        </div>
        <div class="wrap title ul-div">
          <ul class="ul-title">
            <li style="width: 22%;">日期</li>
            <li>有效投注</li>
            <li>中奖金额</li>
            <li>投注返点</li>
            <li style="width: 18%;">详情</li>
          </ul>
          <div v-show="isUser">
            <ul class="ul-content" @click="openInfo(index)" v-for="(item, index) in personalReportData" :key="index">
              <li style="width: 22%;">{{(item.dateTime).substring(0,10)}}</li>
              <li>{{item.validBet}}</li>
              <li>{{item.winAmount}}</li>
              <li>{{item.betRebates}}</li>
              <li style="width: 18%;">
                <icon-svg class="right-icon" :icon-class="item.expand ? 'up' : 'down'"></icon-svg>
              </li>
              <template v-if="item.expand">
                <p><span>优惠金额</span><span>{{item.myDiscounts}}</span><span>我的打赏</span><span>{{item.myReward}}</span></p>
                <p><span>充值金额</span><span>{{item.recharge}}</span><span>提款金额</span><span>{{item.withdrawals}}</span></p>
                <p><span>净盈利</span><span>{{item.netProfit}}</span><span></span><span></span></p>
              </template>
            </ul>
            <ul v-if="personalReportData.length > 0" @click="openSum()">
              <li style="width: 22%;">总计</li>
              <li>{{personalReportTotalData.validBet}}</li>
              <li>{{personalReportTotalData.winAmount}}</li>
              <li>{{personalReportTotalData.betRebates}}</li>
              <li style="width: 18%;">
                <icon-svg class="right-icon" :icon-class="showInfo ? 'up' : 'down'"></icon-svg>
              </li>
              <template v-if="showInfo">
                <p><span>优惠金额</span><span>{{personalReportTotalData.myDiscounts}}</span><span>我的打赏</span><span>{{personalReportTotalData.myReward}}</span></p>
                <p><span>充值金额</span><span>{{personalReportTotalData.recharge}}</span><span>提款金额</span><span>{{personalReportTotalData.withdrawals}}</span></p>
                <p><span>净盈利</span><span>{{personalReportTotalData.netProfit}}</span><span></span><span></span></p>
              </template>
            </ul>
          </div>
          <div v-show="isAgent">
            <ul class="ul-content" @click="openInfo(index)" v-for="(item, index) in personalReportData" :key="index">
              <li style="width: 22%;">{{(item.dateTime).substring(0,10)}}</li>
              <li>{{item.validBet}}</li>
              <li>{{item.winAmount}}</li>
              <li>{{item.betRebates}}</li>
              <li style="width: 18%;">
                <icon-svg class="right-icon" :icon-class="item.expand ? 'up' : 'down'"></icon-svg>
              </li>
              <template v-if="item.expand">
                <p><span>优惠金额</span><span>{{item.myDiscounts}}</span><span>代理返点</span><span>{{item.agentRebates}}</span></p>
                <p><span>日工资</span><span>{{item.daySalary}}</span><span>我的打赏</span><span>{{item.myReward}}</span></p>
                <p><span>分红</span><span>{{item.profit}}</span><span>提款金额</span><span>{{item.withdrawals}}</span></p>
                <p><span>充值金额</span><span>{{item.recharge}}</span><span>净盈利</span><span>{{item.netProfit}}</span></p>
              </template>
            </ul>
            <ul v-if="personalReportData.length > 0" @click="openSum()">
              <li style="width: 22%;">总计</li>
              <li>{{personalReportTotalData.validBet}}</li>
              <li>{{personalReportTotalData.winAmount}}</li>
              <li>{{personalReportTotalData.betRebates}}</li>
              <li style="width: 18%;">
                <icon-svg class="right-icon" :icon-class="showInfo ? 'up' : 'down'"></icon-svg>
              </li>
              <template v-if="showInfo">
                <p><span>优惠金额</span><span>{{personalReportTotalData.myDiscounts}}</span><span>代理返点</span><span>{{personalReportTotalData.agentRebates}}</span></p>
                <p><span>日工资</span><span>{{personalReportTotalData.daySalary}}</span><span>我的打赏</span><span>{{personalReportTotalData.myReward}}</span></p>
                <p><span>分红</span><span>{{personalReportTotalData.profit}}</span><span>提款金额</span><span>{{personalReportTotalData.withdrawals}}</span></p>
                <p><span>充值金额</span><span>{{personalReportTotalData.recharge}}</span><span>净盈利</span><span>{{personalReportTotalData.netProfit}}</span></p>
              </template>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
import { ButtonTab, ButtonTabItem, Grid, GridItem, Flexbox, FlexboxItem, cookie } from 'vux'
import dateRange from '../components/range-select'
import * as API from 'api/wapi/user'
export default {
  data () {
    return {
      tabActive: 0,
      showTotal: true,
      showReport: false,
      showInfo: false,
      userOrAgent: '',
      userId: 0,
      isUser: false,
      isAgent: false,
      pageSize: 15,
      pageIndex: 1,
      startTime: '',
      endTime: '',
      queryLoading: false,
      personalTotalData: [],
      personalReportTotalData: {},
      personalReportData: [],
      showUserAccount: false,
      userAccount: ''
    }
  },
  components: {
    ButtonTab,
    ButtonTabItem,
    Grid,
    GridItem,
    dateRange,
    Flexbox,
    FlexboxItem
  },
  created () {
  },
  watch: {
  },
  mounted () {
    var type = this.$route.query.type
    var id = this.$route.query.id
    if (type !== undefined && id !== undefined) {
      this.userOrAgent = this.$route.query.type
      this.userId = this.$route.query.id
      this.showUserAccount = true
      this.userAccount = JSON.parse(sessionStorage.getItem('loginType')).loginId
    } else {
      this.userOrAgent = cookie.get('loginType')
      this.userId = cookie.get('userId')
    }
    if (this.userOrAgent === 'agent') {
      this.isAgent = true
      this.isUser = false
      this.getAgentPersonalTotalData()
      this.getAgentPersonalListData()
    } else {
      this.isAgent = false
      this.isUser = true
      this.getUserPersonalTotalData()
      this.getUserPersonalListData()
    }
  },
  methods: {
    // 获取会员个人总览
    getUserPersonalTotalData () {
      this.startTime = this.$refs['totalDateRange'].dateRange[0]
      this.endTime = this.$refs['totalDateRange'].dateRange[1]
      var params = {
        agentId: this.userId,
        beginTime: this.startTime,
        endTime: this.endTime
      }
      this.queryLoading = true
      API.getUserPersonalTotal(params).then(res => {
        this.queryLoading = false
        var result = res.result
        this.personalTotalData = [
          {title: '充值金额', value: result.recharge},
          {title: '提款金额', value: result.withdrawals},
          {title: '有效投注', value: result.validBet},
          {title: '中奖金额', value: result.winAmount},
          {title: '投注返点', value: result.betRebates},
          {title: '优惠金额', value: result.myDiscounts},
          {title: '打赏金额', value: result.myReward},
          {title: '净盈利', value: result.netProfit},
          {title: '', value: ''}
        ]
      })
    },
    // 获取会员个人报表
    getUserPersonalListData () {
      this.startTime = this.$refs['reportDateRange'].dateRange[0]
      this.endTime = this.$refs['reportDateRange'].dateRange[1]
      var params = {
        agentId: this.userId,
        beginTime: this.startTime,
        endTime: this.endTime,
        pageSize: this.pageSize,
        pageIndex: this.pageIndex
      }
      this.queryLoading = true
      API.getUserPersonalList(params).then(res => {
        this.queryLoading = false
        var result = res.result
        if (result !== null && result !== '' && result !== '0') {
          this.personalReportData = result.items
          for (var i = 0; i < this.personalReportData.length; i++) {
            this.$set(this.personalReportData[i], 'expand', false)
          }
          this.personalReportTotalData = result.subtotalMap
        }
      })
    },
    // 获取代理个人总览
    getAgentPersonalTotalData () {
      this.startTime = this.$refs['totalDateRange'].dateRange[0]
      this.endTime = this.$refs['totalDateRange'].dateRange[1]
      var params = {
        agentId: this.userId,
        beginTime: this.startTime,
        endTime: this.endTime
      }
      this.queryLoading = true
      API.getAgentPersonalTotal(params).then(res => {
        this.queryLoading = false
        var result = res.result
        this.personalTotalData = [
          {title: '充值金额', value: result.recharge},
          {title: '提款金额', value: result.withdrawals},
          {title: '有效投注', value: result.validBet},
          {title: '中奖金额', value: result.winAmount},
          {title: '投注返点', value: result.betRebates},
          {title: '代理返点', value: result.agentRebates},
          {title: '日工资', value: result.daySalary},
          {title: '分红', value: result.profit},
          {title: '优惠金额', value: result.myDiscounts},
          {title: '打赏金额', value: result.myReward},
          {title: '净盈利', value: result.netProfit},
          {title: '', value: ''}
        ]
      })
    },
    // 获取代理个人报表
    getAgentPersonalListData () {
      this.startTime = this.$refs['reportDateRange'].dateRange[0]
      this.endTime = this.$refs['reportDateRange'].dateRange[1]
      var params = {
        agentId: this.userId,
        beginTime: this.startTime,
        endTime: this.endTime,
        pageSize: this.pageSize,
        pageIndex: this.pageIndex
      }
      this.queryLoading = true
      API.getAgentPersonalList(params).then(res => {
        this.queryLoading = false
        var result = res.result
        if (result !== null && result !== '' && result !== '0') {
          this.personalReportData = result.items
          for (var i = 0; i < this.personalReportData.length; i++) {
            this.$set(this.personalReportData[i], 'expand', false)
          }
          this.personalReportTotalData = result.subtotalMap
        }
      })
    },
    btnClick () {
      if (this.tabActive === 0) {
        this.showTotal = true
        this.showReport = false
        if (this.userOrAgent === 'agent') {
          this.isAgent = true
          this.isUser = false
        } else {
          this.isAgent = false
          this.isUser = true
        }
      } else if (this.tabActive === 1) {
        this.showTotal = false
        this.showReport = true
        if (this.userOrAgent === 'agent') {
          this.isAgent = true
          this.isUser = false
        } else {
          this.isAgent = false
          this.isUser = true
        }
      }
    },
    openInfo (index) {
      this.personalReportData[index].expand = !this.personalReportData[index].expand
    },
    openSum () {
      this.showInfo = !this.showInfo
    },
    // 查询总览
    searchAll () {
      this.startTime = this.$refs['totalDateRange'].dateRange[0]
      this.endTime = this.$refs['totalDateRange'].dateRange[1]
      if (this.userOrAgent === 'agent') {
        this.isAgent = true
        this.isUser = false
        this.getAgentPersonalTotalData()
      } else {
        this.isAgent = false
        this.isUser = true
        this.getUserPersonalTotalData()
      }
    },
    // 查询报表
    searchReport () {
      this.startTime = this.$refs['reportDateRange'].dateRange[0]
      this.endTime = this.$refs['reportDateRange'].dateRange[1]
      if (this.userOrAgent === 'agent') {
        this.isAgent = true
        this.isUser = false
        this.getAgentPersonalListData()
      } else {
        this.isAgent = false
        this.isUser = true
        this.getUserPersonalListData()
      }
    }
  }
}
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user_personal
    .search
      text-align left
      margin-left rem(20)
      .weui-btn_warn
        display inline-block
    .app-body
      color #000
      font-weight bold
      font-size rem(30)
    dt
      background $color-eee
      padding rem(12) rem(24) rem(12) rem(34)
      i.lott-icon
        width rem(25)
    dd
      padding rem(20) rem(34) rem(20) rem(34)
      background $color-white
    .flex
      display: flex
      align-items center
    .flex_item
      flex 1
    .vux-button-group
      height: 100%;
      align-items: center;
      & > a
        background: $color-red
        color: $color-white
        position relative
        &.vux-button-tab-item-first:after, &.vux-button-tab-item-last:after
          border-color: $color-white
          color: $color-white
        &.vux-button-tab-item-first, &.vux-button-tab-item-first:after
          border-top-left-radius: rem(4);
          border-bottom-left-radius: rem(4);
        &.vux-button-tab-item-last, &.vux-button-tab-item-last:after
          border-top-right-radius: rem(4);
          border-bottom-right-radius: rem(4);
        &.vux-button-group-current
          background: $color-white
          color: $color-red
    .weui-cells
     margin 0
    .condition
      padding rem(30) rem(28) rem(30) rem(28)
      .vux-flexbox
        align-items center
    .weui-grids a
      height rem(154)
    .grid-center
      font-size rem(28)
      display: block
      text-align: center
      color: #010000
      p
        margin-top rem(20)
        color #ff6c00
    .memo
      font-size rem(28)
      line-height rem(44)
      padding rem(36) rem(28)
      strong
        font-weight: bold;
    .showUserAccount
      font-size rem(28)
      line-height rem(44)
      padding rem(14) rem(28) rem(28) rem(28)
</style>
