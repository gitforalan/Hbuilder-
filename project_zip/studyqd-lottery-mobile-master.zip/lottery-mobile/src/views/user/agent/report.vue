<template>
  <div class="app-main page-user page-user_AgentReport">
    <x-header class="is-fixed"
    :left-options="{ backText: '', preventGoBack: true }"
    @on-click-back="$router.push({ path: '/user/agent' })">
      <button-tab v-model="tabActive" stylereset>
        <button-tab-item @on-item-click="btnClick()"><icon-svg iconClass="duihao" v-if="showSum"></icon-svg>团队总览</button-tab-item>
        <button-tab-item @on-item-click="btnClick()"><icon-svg iconClass="duihao" v-if="showReport"></icon-svg>团队报表</button-tab-item>
      </button-tab>
    </x-header>
    <div class="app-body" style="padding-bottom:0">
      <!--总览-->
      <div v-show="showSum">
        <div class="condition">
          <flexbox :gutter="0">
          <dateRange ref="previewtDate" :options="{defaultDate: '最近七天'}"></dateRange>
          <flexbox-item class="search"><x-button stylereset type="warn" :show-loading="previewSearchLoading" @click.native="previewSearch"><template v-if="!previewSearchLoading">查询</template></x-button></flexbox-item>
          </flexbox>
        </div>
        <grid :cols="3">
          <grid-item v-for="(row, index) in sumData" :key="row.title">
            <span class="grid-center">
              <h1>{{row.title}}</h1>
              <p v-if="index + 1 !== sumData.length">{{row.value}}</p>
            </span>
          </grid-item>
        </grid>
        <div class="memo"><strong>团队净盈利</strong>=中奖金额+投注返点+所有代理返点+优惠金额+团队日工资-团队有效投注</div>
      </div>
      <div v-show="showReport">
        <div class="condition">
          <flexbox :gutter="0">
          <dateRange ref="reportDate" :options="{defaultDate: '最近七天'}"></dateRange>
          <flexbox-item class="search"><x-button stylereset type="warn" :show-loading="reportSearchLoading" @click.native="reportSearch"><template v-if="!reportSearchLoading">查询</template></x-button></flexbox-item>
          </flexbox>
        </div>
        <div class="ul-div">
          <ul class="ul-title clearfix">
            <li style="width: 22%;">用户名</li>
            <li>所属组</li>
            <li>有效投注</li>
            <li>中奖金额</li>
            <li style="width: 18%;">详情</li>
          </ul>
          <ul class="ul-content clearfix" @click="openInfo(index)" v-for="(row, index) in reportData" :key="row.dateTime">
            <li class="ellipsis" style="width: 22%;">{{row.loginId}}</li>
            <li>{{row.regType == 'a' ?  '代理' : '会员'}}</li>
            <li>{{notNull(row, 'validBet')}}</li>
            <li>{{notNull(row, 'winAmount')}}</li>
            <li style="width: 18%;">
              <icon-svg class="right-icon" :icon-class="row.expand ? 'up' : 'right'"></icon-svg>
            </li>
            <template v-if="row.expand">
              <p><span>投注人数</span><span>{{row.betNum == undefined ? 0 : row.betNum}}</span><span>代理返点</span><span>{{row.agentRebates}}</span></p>
              <p><span>优惠金额</span><span>{{row.discountsAmount == undefined ? 0 : row.discountsAmount}}</span><span>投注返点</span><span>{{row.betRebates == undefined ? 0 : row.betRebates}}</span></p>
              <p><span>日工资</span><span>{{row.daySalary == undefined ? 0 : row.daySalary}}</span><span>打赏金额</span><span>{{row.teamBetRebates == undefined ? 0 : row.teamBetRebates}}</span></p>
              <p><span>分红</span><span>{{row.withdrawals == undefined ? 0 : row.withdrawals}}</span><span>提款金额</span><span>{{row.withdrawalsAmount == undefined ? 0 : row.withdrawalsAmount}}</span></p>
              <p><span>充值金额</span><span>{{row.recharge == undefined ? 0 : row.recharge}}</span><span>净盈利</span><span class="red">{{row.netProfit == undefined ? 0 : row.netProfit}}</span></p>
              <p><span>代理扶持</span><span>{{row.agentHelp == undefined ? 0 : row.agentHelp}}</span><span>转账转入</span><span>{{row.transfer == undefined ? 0 : row.transfer}}</span></p>
              <p><span>账户余额</span><span>{{row.balance == undefined ? 0 : row.balance}}</span></p>
            </template>
          </ul>
          <ul class="clearfix" @click="openSum()" v-if="reportData.length > 0">
            <li style="width: 22%;">总计</li>
            <li><span style="visibility: hidden;">none</span></li>
            <li>{{notNull(subtotal, 'validBet')}}</li>
            <li>{{notNull(subtotal, 'winAmount')}}</li>
            <li style="width: 18%;">
              <icon-svg class="right-icon" :icon-class="showInfo ? 'up' : 'right'"></icon-svg>
            </li>
            <template v-if="showInfo">
              <p><span>投注人数</span><span>{{notNull(subtotal, 'betNum')}}</span><span>代理返点</span><span>{{notNull(subtotal, 'agentRebates')}}</span></p>
              <p><span>优惠金额</span><span>{{notNull(subtotal, 'discountsAmount')}}</span><span>投注返点</span><span>{{notNull(subtotal, 'betRebates')}}</span></p>
              <p><span>日工资</span><span>{{notNull(subtotal, 'daySalary')}}</span><span>打赏金额</span><span>{{notNull(subtotal, 'rewardAmount')}}</span></p>
              <p><span>分红</span><span>{{notNull(subtotal, 'withdrawals')}}</span><span>提款金额</span><span>{{notNull(subtotal, 'withdrawalsAmount')}}</span></p>
              <p><span>充值金额</span><span>{{notNull(subtotal, 'recharge')}}</span><span>净盈利</span><span class="red">{{notNull(subtotal, 'netProfit')}}</span></p>
              <p><span>代理扶持</span><span>{{notNull(subtotal, 'agentHelp')}}</span><span>转账转入</span><span>{{notNull(subtotal, 'transfer')}}</span></p>
              <p><span>账户余额</span><span>{{notNull(subtotal, 'balance')}}</span></p>
            </template>
          </ul>
          <!--<div class="getMore" v-if="reportData.total != 0 && !reportSearchPage.noMore" @click="reportSearch('plus')"><span v-html="reportSearchPage.text"></span></div>-->
        </div>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { ButtonTab, ButtonTabItem, Grid, GridItem, XButton, Flexbox, FlexboxItem, cookie } from 'vux'
  import dateRange from '../components/range-select'
  import * as API from 'api/wapi/user'
  import comFun from './comFunction'
  export default {
    data () {
      return {
        tabActive: 0,
        showSum: true,
        showReport: false,
        showInfo: false,
        userId: '',
        previewSearchLoading: false,
        reportSearchLoading: false,
        reportSearchData: {
          pageIndex: 1,
          pageSize: 10,
          total: 0
        }, // 团队查询参数
        reportSearchPage: {
          text: '更多&gt;&gt;',
          noMore: false
        },
        sumData: [
          {key: 'betNum', title: '投注人数', value: 0},
          {key: 'registerNum', title: '注册人数', value: 0},
          {key: 'firstRechargeNum', title: '首充人数', value: 0},
          {key: 'secondRechargeNum', title: '二充人数', value: 0},
          {key: 'subordinateNum', title: '下级人数', value: 0},
          {key: 'teamBalance', title: '团队余额', value: 0},
          {key: 'rechargeAmount', title: '充值金额', value: 0},
          {key: 'withdrawalsAmount', title: '提款金额', value: 0},
          {key: 'teamValidBet', title: '团队有效投注', value: 0},
          {key: 'winAmount', title: '中奖金额', value: 0},
          {key: 'teamBetRebates', title: '团队投注返点', value: 0},
          {key: 'allAgentRebates', title: '所有代理返点', value: 0},
          {key: 'teamDaySalary', title: '团队日工资', value: 0},
          {key: 'teamProfit', title: '团队分红', value: 0},
          {key: 'discountsAmount', title: '优惠金额', value: 0},
          {key: 'rewardAmount', title: '打赏金额', value: 0},
          {key: 'teamNetProfit', title: '团队净盈利', value: 0},
          {key: 'betNum', title: '', value: ''}
        ],
        reportData: [],
        subtotal: {}
      }
    },
    components: {
      ButtonTab,
      ButtonTabItem,
      Grid,
      GridItem,
      dateRange,
      XButton,
      Flexbox,
      FlexboxItem
    },
    mounted () {
      if (this.$route.query.id) {
        this.userId = this.$route.query.id
      } else {
        if (cookie.get('userId') || /\S/.test(cookie.get('userId'))) {
          this.userId = cookie.get('userId')
        }
      }
      this.previewSearch()
    },
    methods: {
      notNull (row, name) {
        return comFun.notNull(row, name)
      },
      previewSearch () {
        this.previewSearchLoading = true
        // 预览查询
        var params = {
          agentId: this.userId,
          beginTime: this.$refs['previewtDate'].dateRange[0],
          endTime: this.$refs['previewtDate'].dateRange[1]
        }
        API.GetTeamReportPreview(params).then(res => {
          this.previewSearchLoading = false
          // 总览团队盈利计算
          // res.result['teamNetProfit'] = (res.result['winAmount'] + res.result['teamBetRebates'] + res.result['allAgentRebates'] + res.result['discountsAmount'] + res.result['teamDaySalary'] - res.result['teamValidBet']).toFixed(2)
          Object.keys(res.result).forEach((keyName, index) => {
            let existName = this.sumData.findIndex(items => {
              return items.key === keyName
            })
            if (existName > -1) {
              this.sumData[existName]['value'] = res.result[keyName]
            }
          })
        }).catch(response => {
          this.previewSearchLoading = false
        })
      },
      reportSearch (p) {
        // 报表查询
        if (p === 'plus') {
          this.reportSearchData.pageIndex += 1
          // 没有更多的处理
          if (this.reportSearchPage.noMore) {
            return false
          }
        }
        var params = {
          agentId: this.userId,
          beginTime: this.$refs['reportDate'].dateRange[0],
          endTime: this.$refs['reportDate'].dateRange[1]
        }
        Object.assign(this.reportSearchData, params)
        this.reportSearchLoading = true
        API.GetTeamReportQuery(this.reportSearchData).then(res => {
          this.reportSearchLoading = false
          if (!res.error && res.result) {
            let data = res.result.items.map(items => {
              items.expand = false
              return items
            })
            this.subtotal = res.result.stats
            // this.reportSearchData.total = Math.ceil(res.result.total / this.reportSearchData.pageSize)
            if (p === 'plus') {
              this.reportData = this.reportData.concat(data)
            } else {
              this.reportData = data
            }
            // 没有更多的处理
            if (this.reportSearchData.pageIndex >= this.reportSearchData.total && this.reportSearchData.total !== 0) {
              this.reportSearchPage.text = '没有更多了'
              this.reportSearchPage.noMore = true
            }
          } else {
            // error
            this.$vux.toast.show({
              type: 'warn',
              text: res.error.message
            })
          }
        }).catch(response => {
          this.reportSearchLoading = false
        })
      },
      openInfo (index) {
        this.reportData[index].expand = !this.reportData[index].expand
      },
      openSum () {
        this.showInfo = !this.showInfo
      },
      itemClick (index) {
      },
      btnClick () {
        if (this.tabActive === 0) {
          this.showSum = true
          this.showReport = false
        } else if (this.tabActive === 1) {
          this.showSum = false
          this.showReport = true
        }
      }
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user_AgentReport
    .search
     text-align left
     margin-left rem(20)
     .weui-btn_warn
      display inline-block
    .red
      color $color-red
    .condition
      background $color-white
      padding rem(30) rem(28) rem(30) rem(28)
      .vux-flexbox
        align-items center
    .weui-grids
      background $color-white
      a
        height rem(154)
    .grid-center
      font-size $size-medium
      display: block
      text-align: center
      color: #010000
      p
        margin-top rem(20)
        color #ff6c00
    .memo
      background $color-white
      font-size rem(24)
      line-height rem(44)
      padding rem(36) rem(28)
      strong
        font-weight: bold;
</style>
