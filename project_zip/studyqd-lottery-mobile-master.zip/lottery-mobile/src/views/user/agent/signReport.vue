<template>
  <div class="app-main page-user page-user_dayMana page-user_signReport">
    <x-header class="is-fixed"
    :left-options="{ backText: '', preventGoBack: true }"
    @on-click-back="$router.push({ path: '/user/agent' })">
      {{title}}
    </x-header>
    <div class="app-body">
      <div class="ul-div">
        <ul class="ul-title clearfix">
          <li v-for="row in title == '签约日工资' ? titleData : titleData1" :key="row">{{row}}</li>
        </ul>
        <ul class="ul-content clearfix">
          <li>{{title == '签约日工资' ? list[0].validBet : list[0].validBet}}</li>
          <li>{{title == '签约日工资' ? list[0].validUser : list[0].validUser}}</li>
          <li>{{title == '签约日工资' ? list[0].bonusRate : list[0].bonusRate}}</li>
          <li>{{title == '签约日工资' ? celv(list[0].profitFlag): celv(list[0].profitFlag)}}</li>
        </ul>
      </div>
      <div style="text-align:center">
        <x-button type="warn" @click.native='btnSign(1)' :show-loading="loading1" :disabled="loading1" mini>立即签约</x-button>
        <x-button type="default" @click.native='btnSign(3)' :show-loading="loading2" :disabled="loading2" mini>拒绝签约</x-button>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import * as API from 'api/wapi/user'
  import { cookie } from 'vux'
  export default {
    data () {
      return {
        loading1: false,
        loading2: false,
        title: '',
        titleData: ['有效投注', '团队有效会员', '日工资比例', '日工资策略'],
        titleData1: ['有效投注', '团队有效会员', '分红比例', '分红策略'],
        list: [{
          validBet: '',
          validUser: '',
          bonusRate: '',
          profitFlag: ''
        }]
      }
    },
    mounted () {
      (async () => {
        if (this.$route.query.type === 'daily') {
          try {
            this.title = '签约日工资'
            this.$vux.loading.show()
            let r = await this.DailySendSign()
            this.list = []
            this.list.push(r)
            this.$vux.loading.hide()
          } catch (error) {
            this.$vux.loading.hide()
            this.$vux.toast.show({
              type: 'warn',
              text: error.message
            })
          }
        }
        if (this.$route.query.type === 'profit') {
          try {
            this.title = '签约分红'
            this.$vux.loading.show()
            let r = await this.ProfitSendSign()
            this.list = []
            this.list.push(r)
            this.$vux.loading.hide()
          } catch (error) {
            this.$vux.loading.hide()
            this.$vux.toast.show({
              type: 'warn',
              text: error.message
            })
          }
        }
      })()
    },
    methods: {
      celv (r) {
        let num = parseInt(r)
        if (num === 0) {
          return '盈亏不累计结算'
        } else if (num === 1) {
          return '盈亏累计结算'
        }
        return ''
      },
      btnSign (type) {
        (async () => {
          if (this.title === '签约日工资') {
            try {
              this.loading1 = true
              let r = await this.DailySignCacel(type)
              this.loading1 = false
              if (+r > 0) {
                this.$vux.toast.show({
                  type: 'success',
                  text: '操作成功'
                })
                if (+type === 1) {
                  this.$router.replace({path: '/user/agent/dayMana'})
                } else {
                  this.$router.replace({name: 'agent'})
                }
              } else if (+r === 0) {
                this.$vux.toast.show({
                  type: 'warn',
                  text: '操作失败'
                })
              }
            } catch (error) {
              this.$vux.toast.show({
                type: 'warn',
                text: error.message
              })
            }
          } else {
            try {
              this.loading2 = true
              let r = await this.ProfitSignCacel(type)
              this.loading2 = false
              if (+r > 0) {
                this.$vux.toast.show({
                  type: 'success',
                  text: '操作成功'
                })
                if (+type === 1) {
                  this.$router.replace({path: '/user/agent/profitMana'})
                } else {
                  this.$router.replace({name: 'agent'})
                }
              } else if (+r === 0) {
                this.$vux.toast.show({
                  type: 'warn',
                  text: '操作失败'
                })
              }
            } catch (error) {
              this.$vux.toast.show({
                type: 'warn',
                text: error.message
              })
            }
          }
        })()
      },
      DailySignCacel (type) {
        // 日工资签约操作
        let params = {
          agentId: cookie.get('userId'),
          state: type
        }
        return new Promise((resolve, reject) => {
          API.DailySignCacel(params).then(res => {
            if (!res.error && res.result) {
              resolve(res.result)
            } else {
              this.$vux.toast.show({
                type: 'warn',
                text: res.error.message
              })
            }
          })
        })
      },
      ProfitSignCacel (type) {
        // 分红签约操作
        let params = {
          agentId: cookie.get('userId'),
          state: type
        }
        return new Promise((resolve, reject) => {
          API.ProfitSignCacel(params).then(res => {
            if (!res.error && res.result) {
              resolve(res.result)
            } else {
              this.$vux.toast.show({
                type: 'warn',
                text: res.error.message
              })
            }
          })
        })
      },
      DailySendSign () {
        // 日工资签约, 列表
        return new Promise((resolve, reject) => {
          API.DailySendSign().then(res => {
            if (!res.error && res.result) {
              resolve(res.result)
            } else {
              reject(res.error)
            }
          })
        })
      },
      ProfitSendSign () {
        // 分红签约, 列表
        return new Promise((resolve, reject) => {
          API.ProfitSendSign().then(res => {
            if (!res.error && res.result) {
              resolve(res.result)
            } else {
              reject(res.error)
            }
          })
        })
      }
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user_signReport
    li
      width 25% !important
    .weui-btn_default
      background-color white
      background: #868686;
      color $color-white
</style>
