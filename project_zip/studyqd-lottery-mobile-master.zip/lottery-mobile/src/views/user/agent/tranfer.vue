<template>
  <div class="app-main page-user page-user_transfer">
    <x-header :left-options="{backText: ''}" :title="title" class="is-fixed"></x-header>
    <div class="app-body" style="padding-bottom: 0">
        <group>
          <x-input title='对方帐号：' disabled v-model="userName"></x-input>
          <x-input title='您的余额：' disabled v-model="balance"></x-input>
          <flexbox class="vux-x-input weui-cell type">
            <span class="left">转帐类型：</span>
            <span><selector @on-change='onChange' placeholder='请选择' v-model='selected' :options='ltypeList'></selector></span>
          </flexbox>
          <flexbox class="vux-x-input weui-cell type">
            <span class="left">取款密码：</span>
            <div class="password-no">
              <popup-picker :data="listNo" v-model="value1" value-text-align="left"></popup-picker>
              <popup-picker :data="listNo" v-model="value2" value-text-align="left"></popup-picker>
              <popup-picker :data="listNo" v-model="value3" value-text-align="left"></popup-picker>
              <popup-picker :data="listNo" v-model="value4" value-text-align="left"></popup-picker>
            </div>
          </flexbox>
          <x-input class="money" title='转帐金额：' v-model="money" @on-blur="moneyBlur"></x-input>
          <flexbox class="vux-x-input weui-cell damawrap">
            <span class="left">综合打码量稽核：</span>
            <span><icon-svg @click.native="radioClick" :iconClass="checkedDisabled ? 'radio-checked' : 'radio-check'"></icon-svg><x-input :style="{'visibility': checkedDisabled ? 'visible' : 'hidden'}" class="money dama" v-model="dama"></x-input></span>
          </flexbox>
          <x-textarea :show-counter="false" :max="200" title="备注：" placeholder="" v-model="memo"></x-textarea></span>
        </group>
        <div class="op">
          <x-button type="warn" @click.native="confirm" class="btn">确认</x-button>
        </div>
        <toast v-model="showSuccess" type="text" position="middle">{{showSuccessText}}</toast>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { XInput, XButton, Flexbox, FlexboxItem, PopupPicker, Toast, cookie } from 'vux'
  import * as API from 'api/wapi/user'
  import Encode from '@/utils/sha1'
  import fun from './comFunction'
  import { mapMutations } from 'vuex'
  export default {
    data () {
      return {
        showSuccess: false,
        checkedDisabled: false,
        showSuccessText: '',
        title: '转账',
        selected: '',
        ltypeList: [
          {value: '充值', key: 10702},
          {value: '分红', key: 10412},
          {value: '日工资', key: 10413},
          {value: '代理扶持', key: 10414}
        ],
        userId: '',
        userName: '',
        dama: '',
        damaAPI: '',
        balance: 0,
        money: '',
        memo: '',
        listNo: [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]],
        value1: [0],
        value2: [0],
        value3: [0],
        value4: [0]
      }
    },
    components: {
      XInput,
      XButton,
      Flexbox,
      FlexboxItem,
      PopupPicker,
      Toast
    },
    mounted () {
      this.getUserBalance()
      let tranferData = JSON.parse(window.sessionStorage.getItem('transferData'))
      this.userName = tranferData.name
      this.userId = tranferData.id
      if (tranferData.type === '会员') {
        this.ltypeList.splice(1, 3)
      }
      if (+cookie.get('showEditPayPass') === 0) {
        this.setEditPayPassShow({flag: true})
      }
    },
    methods: {
      moneyBlur () {
        if (parseInt(this.selected) === 10702 || parseInt(this.selected) === 10414) {
          (async () => {
            try {
              if (!this.validate()) {
                return false
              }
              this.$vux.loading.show()
              let num = await this.getLimit()
              if (!/\S/.test(this.dama)) {
                this.dama = num
              }
              this.$vux.loading.hide()
            } catch (error) {
              this.$vux.loading.hide()
            }
          })()
        }
      },
      // 获取用户账户余额
      getUserBalance () {
        API.getUserBalance().then(res => {
          if (!res.error && res.result) {
            this.balance = res.result.balance
          }
        })
      },
      onChange () {
        this.dama = ''
        if (parseInt(this.selected) === 10702 || parseInt(this.selected) === 10414) {
          this.checkedDisabled = true
        } else if (parseInt(this.selected) === 10412 || parseInt(this.selected) === 10413) {
          this.checkedDisabled = false
        }
      },
      radioClick () {
        if (parseInt(this.selected) === 10702 || parseInt(this.selected) === 10414) {
          this.checkedDisabled = true
        } else {
          this.checkedDisabled = !this.checkedDisabled
        }
      },
      validate () {
        if (!/\S/.test(this.selected)) {
          this.showSuccess = true
          this.showSuccessText = '请选择转账类型'
          return false
        } else if (!/\S/.test(this.money)) {
          this.showSuccess = true
          this.showSuccessText = '转账金额不能为空'
          return false
        } else if (!fun.reg.numnot0.test(this.money)) {
          this.showSuccess = true
          this.showSuccessText = '转账金额必须是大于0的数字,最多保留两位小数'
          return false
        }
        return true
      },
      getLimit () {
        if (!this.validate()) {
          return false
        }
        let params = {
          accountItem: this.selected,
          amount: this.money,
          userId: this.userId,
          userLoginId: this.userName
        }
        return new Promise((resolve, reject) => {
          API.addTransferKeyUp(params).then(res => {
            if (!res.error) {
              this.damaAPI = res.result.couponAuditBetAmount
              resolve(res.result.couponAuditBetAmount)
            } else {
              this.$vux.toast.show({
                type: 'warn',
                text: res.error.message
              })
            }
          })
        })
      },
      confirm () {
        (async () => {
          await this.getLimit()
          if (!this.validate()) {
            return false
          } else if (Number(this.dama) < Number(this.damaAPI) && (parseInt(this.selected) === 10702 || parseInt(this.selected) === 10414)) {
            this.showSuccess = true
            this.showSuccessText = `稽核需>=${this.damaAPI}`
            return false
          } else if (!fun.reg.num.test(this.dama) && this.checkedDisabled) {
            this.showSuccess = true
            this.showSuccessText = `稽核需为数字`
            return false
          }
          var params = {
            operatorId: cookie.get('userId'),
            userId: this.userId,
            accountItem: this.selected,
            amount: this.money
          }
          if (this.checkedDisabled) {
            params.couponAuditBetAmount = this.dama
          }
          let newPass = []
          for (let i = 1; i < 5; i++) {
            newPass = newPass.concat(this[`value${i}`])
          }
          let encode = new Encode()
          params.payPasword = encode.encodeSha1(cookie.get('userId') + encode.encodeSha1(newPass.join('')))
          if (/\S/.test(this.memo)) {
            params.memo = this.memo
          }
          API.addTransfer(params).then(res => {
            if (!res.error && +res.result > 0) {
              this.showSuccess = true
              this.showSuccessText = `操作成功`
              this.getUserBalance()
            } else {
              this.$vux.toast.show({
                type: 'warn',
                text: res.error.message
              })
            }
          })
        })()
      },
      ...mapMutations(['setEditPayPassShow', 'setCookieEditPayPass'])
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user_transfer
    .damawrap
      .lott-icon
        margin-left rem(20)
      & > span
        &.left
          width rem(230) !important
        display flex
        align-items center
        .dama
          .weui-input
            width rem(260)
          &:before
            border none
          .weui-cell__ft
            right rem(45)
    .btn
      width rem(670)
      height rem(78)
      font-size rem(28)
      background $color-red
    .op
      padding rem(24)
      .weui-btn_warn
        background $color-red
    .password-no
      display: flex
      justify-content: left
      width: 70%
      margin-left: rem(10)
      .vux-cell-box:before
        border: none
      & > div
        display: flex
        align-items: center
        justify-content: center
        background: $color-eee
        border: 1px solid $color-font-light
        width: rem(60)
        height: rem(60)
        padding: 0
        margin: 0
        text-align: center
        line-height: rem(60)
        margin-right: rem(10)
        font-size rem(24)
      .weui-cell__ft
        display none
    .weui-label, .weui-input, .left
      font-size rem(28)
      line-height 1.5
    .weui-label, .left
      width rem(150) !important
      text-align right
    text-align right
    .vux-selector
      display inline-block
    .left
      display inline-block
    .vux-selector {
      font-size rem(24)
      width rem(240)
      border solid 1px $color-ccc
      border-radius rem(4)
    }
    .weui-select {
      height rem(60)
      line-height rem(60)
      padding 0 rem(24)
    }
    .money
      .weui-cell__bd
       text-align left
      .weui-input
        font-size rem(24)
        border solid 1px $color-ccc
        border-radius rem(4)
        height rem(60)
        width rem(450)
        padding 0 rem(12)
      .weui-cell__ft
        position absolute
        right rem(100)
        top: rem(23)
    textarea
      width rem(450)
      border solid 1px $color-ccc
      padding 0 rem(12)
      font-size rem(24)
</style>
