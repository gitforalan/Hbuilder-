<template>
  <div class="app-main page-user page-user_rebate">
    <x-header :left-options="{backText: ''}" :title="title" class="is-fixed">
      <span @click="showTypeList()" slot="right">
        {{typeListSelect}}
        <icon-svg class="right-icon" :icon-class="showType ? 'up': 'down'"></icon-svg>  
      </span>
    </x-header>
    <div class="app-body" style="padding-bottom: 0">
      <div v-show="showType" class="rebate-type">
        <span :class="{active: row.id == typeListSelectId}" @click="selectedClick(row)" v-for="(row, index) in typeList" :key="row.id">{{row.name}}</span>
      </div>
      <div class="flex">
      <div class="rebate-ul-div">
        <ul>
          <li style="background-color: #F7F7F7;">
              <span>玩法</span>
              <span>\</span>
              <span>返点</span>
          </li>
          <li class="ellipsis" :style="{'background-color': (index + 1) % 2 == 0 ? '#F7F7F7': 'white'}" v-for="(row, index) in leftOption">{{row}}</li>
        </ul>
      </div>
      <div class="rebate-table-div">
        <div class="table header">
          <div class="cell" v-for="(row, index) in numRow" :key="index"><span>{{row}}</span></div>
        </div>
        <div class="table" v-for="(items, index) in rightOption" :key="index">
          <div class="cell" :style="{'background-color': (index + 1) % 2 == 0 ? '#F7F7F7': 'white'}" v-for="row1 in items" :key="row1.key"><span class="td">{{row1.value}}</span></div>
        </div>
        <!-- <x-table :cell-bordered="false" :content-bordered="false">
          <thead>
            <tr style="background-color: #F7F7F7;">
              <th v-for="(row, index) in numRow" :key="index"><span>{{row}}</span></th>
            </tr>
          </thead>
          <tbody>
            <tr :style="{'background-color': (index + 1) % 2 == 0 ? '#F7F7F7': 'white'}" v-for="(items, index) in rightOption" :key="index">
              <td v-for="row1 in items" :key="row1.key">{{row1.value}}</td>
            </tr>
          </tbody>
        </x-table> -->
      </div>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { XTable, cookie } from 'vux'
  import * as API from 'api/wapi/user'
  export default {
    data () {
      return {
        title: '返点赔率表',
        showType: false,
        typeListSelect: '',
        typeListSelectId: '',
        typeList: [],
        leftOption: [],
        rightOption: [],
        numRow: [],
        max: 0
      }
    },
    components: {
      XTable
    },
    created () {
      (async () => {
        try {
          console.log('get idname')
          this.$vux.loading.show()
          await this.rebateSeeIdName()
          await this.getData()
        } catch (e) {
          console.log(e)
        }
      })()
    },
    methods: {
      getData () {
        // 顶部点击
        (async () => {
          try {
            this.$vux.loading.show()
            console.log('get limit')
            await this.getLotteryLimit()
            console.log('get list')
            await this.getLotteryPlayList()
            this.$vux.loading.hide()
          } catch (e) {
            console.log(e)
            this.$vux.loading.hide()
            this.$vux.toast.show({
              type: 'warn',
              text: e.error.message
            })
          }
        })()
      },
      showTypeList () {
        this.showType = !this.showType
      },
      selectedClick (row) {
        this.typeListSelect = row.name
        this.typeListSelectId = row.id
        this.showType = !this.showType
        this.getData()
      },
      rebateSeeIdName () {
        return new Promise((resolve, reject) => {
          API.rebateSeeIdName().then(res => {
            if (!res.error && res.result) {
              this.typeList = res.result.items
              this.typeListSelect = this.typeList[0].name
              this.typeListSelectId = this.typeList[0].id
              resolve(this.typeList)
            } else {
              reject({error: res.error})
            }
          })
        })
      },
      getLotteryLimit () {
        // 最高限制
        let params = {
          lotteryTypeId: this.typeListSelectId,
          uid: cookie.get('userId')
        }
        return new Promise((resolve, reject) => {
          API.getLotteryLimit(params).then(res => {
            if (!res.error && res.result) {
              this.max = +res.result
              let newArray = []
              for (var i = +res.result; i >= 0; i--) {
                if (+res.result !== i) {
                  for (var y = 9; y >= 0; y--) {
                    if (i === 0 && y === 0) {
                    } else {
                      newArray.push(Number(i) + Number('0.' + y))
                    }
                  }
                } else {
                  newArray.push(Number(i))
                }
              }
              this.numRow = newArray
              resolve(this.numRow)
            } else {
              reject({error: res.error})
            }
          })
        })
      },
      getLotteryPlayList () {
        let params = {
          lotteryTypeId: this.typeListSelectId,
          rebate: this.max, // 取决一个接口
          noCache: 1
        }
        return new Promise((resolve, reject) => {
          API.getLotteryPlayList(params).then(res => {
            if (!res.error && res.result) {
              this.leftOption = res.result.map(item => {
                return item.playName + '-' + item.playTabName + '-' + item.playTypeName
              })
              let newArray = []
              this.rightOption = res.result.forEach(item => {
                let innerArray = []
                Object.keys(item.items).forEach(item1 => {
                  innerArray.push({key: item1, value: item.items[item1]})
                })
                newArray.push(innerArray)
              })
              this.rightOption = newArray
              this.rightOption = this.rightOption.map((items, index) => {
                // 从大到小
                items.sort(function (obj1, obj2) {
                  var val1 = Number(obj1.key)
                  var val2 = Number(obj2.key)
                  if (val1 > val2) {
                    return -1
                  } else if (val1 < val2) {
                    return 1
                  } else {
                    return 0
                  }
                })
                return items
              })
              resolve(this.rightOption)
            } else {
              reject({error: res.error})
            }
          })
        })
      }
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user_rebate
    .table
      display table
      &.header
       .cell
          line-height rem(79)
          border-bottom rem(1) solid #E1E1E1
      .cell
        display table-cell
        background-color: #F7F7F7;
        span
          color #010000
          line-height rem(80)
          width rem(174)
          display inline-block
          text-align center
        .td
          color #6f6f6f
    .flex
      display flex
    .vux-header-right
      span
        color white
    .right-icon
      width rem(36) !important
      position relative
      top rem(20)
    .app-body
      font-size rem(30)
      .rebate-type
        background-color white
        position fixed
        top rem(88)
        left 0
        z-index 3
        padding rem(24) rem(27)
        display flex
        flex-wrap wrap
        span
          width rem(150)
          height rem(60)
          text-align center
          line-height rem(60)
          margin-right rem(20)
          margin-bottom rem(30)
          padding 0
          border 1px solid $color-gray-a
          border-radius rem(4)
          &.active
            border-color $color-red
            color $color-red
          &:nth-child(4n)
            margin-right 0
      .rebate-ul-div
        width 30%
        border-right 1px solid #E1E1E1
        box-shadow 1px 0px 3px #ddd
        position relative
        ul 
          li
            line-height rem(80)
            color #6f6f6f
            text-align center
          li:first-child
            line-height rem(79)
            color #010000
            border-bottom rem(1) solid #E1E1E1
          li:last-child
            line-height rem(79)
            border-bottom rem(1) solid #E1E1E1
      .rebate-table-div
        width 70%
        overflow-x scroll
        -webkit-overflow-scrolling:touch;
        .vux-table
          tr
            th
              line-height rem(80)
              span
                color #010000
                width rem(174)
                display inline-block
            td 
              color #6f6f6f
              line-height rem(80)
</style>
