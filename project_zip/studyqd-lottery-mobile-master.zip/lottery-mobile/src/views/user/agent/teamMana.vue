<template>
  <div class="app-main page-user page-user_teamMana">
    <x-header :title="title" class="is-fixed"
    :left-options="{ backText: '', preventGoBack: true }"
    @on-click-back="$router.push({ path: '/user/agent' })"></x-header>
    <div class="app-body" style="padding-bottom:0">
        <div class="condition">
          <div class="top">
            <span><x-input title='用户名：' placeholder="请输入用户名" v-model="userLoginId"></x-input></span><span>
            <x-input title='余额：' v-model="balanceFrom"></x-input></span><span>
            <x-input title='至' v-model="balanceTo"></x-input></span>
          </div>
          <flexbox :gutter="0">
            登录时间：
          <dateRange ref="dateRange" :options="{defaultDate: '最近七天'}"></dateRange>
          <flexbox-item class="search"><x-button stylereset type="warn" :show-loading="queryLoading" @click.native="querySearch"><template v-if="!queryLoading">查询</template></x-button></flexbox-item>
          </flexbox>
        </div>
        <div class="ul-div">
          <ul class="ul-title clearfix">
            <li>用户名</li>
            <li>所属群组</li>
            <li style="width: 18%;">余额</li>
            <li>返点级别</li>
            <li>状态</li>
            <li style="width: 18%;">操作</li>
          </ul>
          <div v-for="(row, index) in reportData" :key="row.loginId">
            <ul class="ul-content clearfix">
              <li>{{row.loginId}}</li>
              <li>{{row.regType == 'a' ? row.levels + '级代理' : '会员'}}</li>
              <li style="width: 18%">{{row.balance}}</li>
              <li class="level"><a href="javascript:;" @click="goRebaseSee(row)"><icon-svg icon-class="chazhao"></icon-svg></a></li>
              <li>
                <template v-if="row.regType == 'a' && row.agentStatus == 1">启用</template>
                <template v-else-if="row.regType == 'a' && row.agentStatus == 4">停用</template>
                <template v-else-if="row.regType == 'n' && row.status == 1">启用</template>
                <template v-else-if="row.regType == 'n' && row.status == 4">停用</template>
                <template v-else><span style="visibility: hidden;">none</span></template>
              </li>
              <li style="width: 18%" @click="openInfo(index)">
                <icon-svg class="right-icon" :icon-class="row.expand ? 'up' : 'right'"></icon-svg>
              </li>
            </ul>
            <template v-if="row.expand">
              <div class="op">
                <div class="inner">
                  <a href="javascript:;" @click="goTransfer(row)" v-if="transferPermission">转账</a><a href="javascript:;" @click="goPersonReport(row)">个人报表</a><a href="javascript:;" @click="goTeamReport(row)" v-if="row.regType == 'a'">团队报表</a><a href="javascript:;" @click="goAccountDetail(row)">帐户明细</a>
                  <a href="javascript:;" @click="goRebaseSee(row)" v-if="row.regType == 'n'">返点设定</a>
                </div>
              </div>
            </template>
          </div>
        </div>
        <div class="getMore" v-if="queryData.total != 0" @click="querySearch('plus')"><span v-html="queryDataPage.text"></span></div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { Flexbox, FlexboxItem, XInput, cookie } from 'vux'
  import dateRange from '../components/range-select'
  import comFunction from './comFunction'
  import * as API from 'api/wapi/user'
  export default {
    data () {
      return {
        transferPermission: false,
        title: '团队管理',
        userLoginId: '',
        balanceFrom: '',
        balanceTo: '',
        queryData: {
          pageIndex: 1,
          pageSize: 10,
          total: 0
        },
        queryDataPage: {
          text: '更多&gt;&gt;',
          noMore: false
        },
        reportData: [],
        queryLoading: false
      }
    },
    components: {
      dateRange,
      Flexbox,
      FlexboxItem,
      XInput
    },
    mounted () {
      this.permissionTransfer()
    },
    methods: {
      goAccountDetail (row) {
        this.$router.push({name: 'accountDetails', query: { id: row.userId }})
        window.sessionStorage.setItem('loginType', JSON.stringify(row))
      },
      goPersonReport (row) {
        this.$router.push({path: '/user/personal', query: { id: row.userId, type: row.regType === 'a' ? 'agent' : 'user' }})
        window.sessionStorage.setItem('loginType', JSON.stringify(row))
      },
      goTeamReport (row) {
        this.$router.push({path: 'report', query: { id: row.userId }})
        window.sessionStorage.setItem('loginType', JSON.stringify(row))
      },
      goTransfer (row) {
        let transferData = {
          id: row.userId,
          name: row.loginId,
          balance: row.balance,
          type: row.regType === 'a' ? '代理' : '会员'
        }
        window.sessionStorage.setItem('transferData', JSON.stringify(transferData))
        this.$router.push({path: 'tranfer', query: { id: row.userId }})
      },
      goRebaseSee (row) {
        let rebateSeeData = {
          id: row.userId,
          name: row.loginId,
          type: row.regType === 'a' ? '代理' : '会员'
        }
        window.sessionStorage.setItem('rebateSeeData', JSON.stringify(rebateSeeData))
        this.$router.push({path: 'rebateSee', query: { id: row.userId }})
      },
      querySearch (p) {
        if (p === 'plus') {
          this.queryData.pageIndex += 1
          // 没有更多的处理
          if (this.queryDataPage.noMore) {
            return false
          }
        }
        var params = {
          parentAgentId: cookie.get('userId'),
          startDate: this.$refs['dateRange'].dateRange[0] + ' 00:00:00',
          endDate: this.$refs['dateRange'].dateRange[1] + ' 23:59:59'
        }
        if (/\S/.test(this.userLoginId)) {
          params.userLoginId = this.userLoginId
        }
        if (/\S/.test(this.balanceFrom)) {
          params.minBalance = this.balanceFrom
          if (!comFunction.reg.num.test(params.minBalance)) {
            this.$vux.toast.show({
              type: 'warn',
              text: '余额最小值只能输入不小于0的数字，最多带两位小数'
            })
            return false
          }
        }
        if (/\S/.test(this.balanceTo)) {
          params.maxBalance = this.balanceTo
          if (!comFunction.reg.num.test(params.maxBalance)) {
            this.$vux.toast.show({
              type: 'warn',
              text: '余额最大值只能输入不小于0的数字，最多带两位小数'
            })
            return false
          }
        }
        if (/\S/.test(this.balanceTo)) {
          if (/\S/.test(this.balanceFrom)) {
            if (Number(this.balanceFrom) > Number(this.balanceTo)) {
              this.$vux.toast.show({
                type: 'warn',
                text: '余额最小值不能大于最大值'
              })
              return false
            }
          } else {
            this.$vux.toast.show({
              type: 'warn',
              text: '请输入余额最小值'
            })
            return false
          }
        }
        if (/\S/.test(this.balanceFrom)) {
          if (/\S/.test(this.balanceTo)) {
            if (Number(this.balanceFrom) > Number(this.balanceTo)) {
              this.$vux.toast.show({
                type: 'warn',
                text: '余额最小值不能大于最大值'
              })
              return false
            }
          } else {
            this.$vux.toast.show({
              type: 'warn',
              text: '请输入余额最大值'
            })
            return false
          }
        }
        this.queryLoading = true
        let newP = Object.assign({}, this.queryData, params)
        API.GetTeamManagement(newP).then(res => {
          this.queryLoading = false
          comFunction.listBack(res, 'result', 'result.items', () => {
            var data = res.result.items.map(items => {
              items.expand = false
              return items
            })
            this.queryData.total = Math.ceil(res.result.total / this.queryData.pageSize)
            if (p === 'plus') {
              this.reportData = this.reportData.concat(data)
            } else {
              this.reportData = data
            }
            // 没有更多的处理
            if (this.queryData.pageIndex >= this.queryData.total && this.queryData.total !== 0) {
              this.queryDataPage.text = '没有更多了'
              this.queryDataPage.noMore = true
            }
          }, () => {
            this.$vux.toast.show({
              type: 'warn',
              text: res.error.message
            })
          }, () => {
            if (p !== 'plus') {
              this.reportData = []
              this.queryData.total = 0
              this.queryData.pageIndex = 0
            }
          })
        })
      },
      openInfo (index) {
        this.reportData[index].expand = !this.reportData[index].expand
      },
      permissionTransfer () {
        // 是否有权限转账
        API.hasPermission2Transfer().then(res => {
          if (!res.error) {
            this.transferPermission = +res.result === 1
          }
        })
      }
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user_teamMana
    .search
     text-align left
     margin-left rem(20)
     .weui-btn_warn
        display inline-block
    .level
      line-height 1
      i
        display inline-block
        background-size cover
        width rem(40)
        height rem(40)
        transform translateY(rem(8))
    &.page-user .ul-div
      background $color-white
      ul li
        width 16%
    .op
      padding 0 rem(14)
      text-align  center
      .inner
        border-bottom solid 1px #eaeaea
        padding rem(14) 0
      a
        display inline-block
        font-size rem(24)
        min-width rem(110)
        height rem(46)
        border solid 1px #434343
        color #010000
        text-align center
        line-height rem(46)
        margin-right rem(46)
        border-radius rem(4)
        &:last-child
          margin-right 0
    .condition
      background $color-white
      padding rem(30) rem(28) rem(30) rem(28)
      .top
          span
            margin-bottom rem(30)
            .weui-label
                width auto !important
            &:first-child
              margin-right rem(26)
              .weui-input
                width rem(176)
            &:last-child
              .weui-label
                padding 0 rem(18)
          display inline-flex
          .vux-x-input
            padding 0
            font-size rem(24)
            vux-x-input
            .weui-cell__ft
              position absolute
              right rem(5)
              top rem(18)
          .weui-input
            border solid 1px $color-ccc
            border-radius rem(4)
            width rem(80)
            height rem(60)
            padding 0 rem(12)
      .vux-flexbox
        align-items center
</style>
