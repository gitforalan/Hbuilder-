import { cookie } from 'vux'
import * as API from 'api/wapi/user'
import store from 'store'
const fun = {
  // 返点设置，下级看护检查文本是否为空，不超过两位数字
  checkedInputNum (list) {
    let len = list.length
    // let str = ''
    let errorArray = []
    for (let i = 0; i < len; i++) {
      if (!/\S/.test(list[i].input)) {
        errorArray.push(i)
        continue
      }
      if (!/^([1-9]\d*|0)(\.([0-9]|\d[0-9]))?$/.test(list[i].input)) {
        errorArray.push(i)
        continue
      }
      if (Number(list[i].input) > list[i].value) {
        errorArray.push(i)
        continue
      }
    }
    // for (let i = 0; i < len; i++) {
    //   if (!/\S/.test(list[i].input)) {
    //     str = `${list[i].name}不能为空`
    //     break
    //   }
    //   if (!/^([1-9]\d*|0)(\.([0-9]|\d[0-9]))?$/.test(list[i].input)) {
    //     str = `${list[i].name}只能输入返点值范围内的数字，最多保留两位小数`
    //     break
    //   }
    //   if (Number(list[i].input) > list[i].value) {
    //     str = `${list[i].name}不能大于${list[i].value}`
    //     break
    //   }
    // }
    return errorArray
  },
  reg: {
    num: /^([1-9]\d*|0)(\.([0-9]|\d[0-9]))?$/, // 整数且最多保留两位小数
    zeroOrInt: /^[1-9]\d*|0$/, // 正整数或0
    int: /^[1-9]\d*$/, // 正整数
    numnot0: /^(?!0+(?:\.0+)?$)(?:[1-9]\d*|0)(?:\.\d{1,2})?$/ // 非负数，最多保留两位小数
  },
  getUTCTime2US (val) {
    // 转美东时间函数
    // val=>时间戳
    // 获取utc时间+8小时转北京时间
    let timenow = ''
    let timeStamp = ''
    if (val === undefined) {
      timenow = new Date()
      timeStamp = Number(new Date(
        timenow.getUTCFullYear(),
        timenow.getUTCMonth(),
        timenow.getUTCDate(),
        timenow.getUTCHours(),
        timenow.getUTCMinutes(),
        timenow.getUTCSeconds()
      ).getTime()) + 8 * 3600 * 1000
    } else {
      timeStamp = new Date(new Date(val).toISOString().slice(0, -5)).getTime() + 8 * 3600 * 1000
    }
    // 返回一个时间戳, 美东时间
    return timeStamp - 3600 * 12 * 1000
  },
  dateFormat (date, fmt) {
    // 简单的时间格式化函数
    // dateFormat(new Date(你的时间), 'yyyy-MM-dd hh:mm:ss')
    var o = {
      'M+': date.getMonth() + 1,
      'd+': date.getDate(),
      'h+': date.getHours(),
      'm+': date.getMinutes(),
      's+': date.getSeconds(),
      'q+': Math.floor((date.getMonth() + 3) / 3),
      'S': date.getMilliseconds()
    }
    if (/(y+)/.test(fmt)) {
      fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length))
    }
    for (var k in o) {
      if (new RegExp('(' + k + ')').test(fmt)) {
        fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (('00' + o[k]).substr(('' + o[k]).length)))
      }
    }
    return fmt
  },
  getImgFilePath () {
    // 获取图片路径前缀
    return new Promise((resolve, reject) => {
      var imgFilePath = cookie.get('imgFilePath')
      if (!imgFilePath || !/\S/.test(imgFilePath)) {
        // 获取图片文件展示路径
        API.getImgFilePath().then(res => {
          imgFilePath = !res.error ? res.result : ''
          store.commit('setCookieImgFilePath', { 'imgFilePath': imgFilePath })
          resolve(imgFilePath)
        })
      } else {
        resolve(imgFilePath)
      }
    })
  },
  notNull (row, name) {
    if (typeof row === 'undefined' || row === null) {
      return 0
    } else {
      if (typeof row[name] === 'undefined' || row[name] === null) {
        return 0
      }
    }
    return row[name]
  },
  objectFindVaule (obj, path) {
    // 根据path来找到对应object的value值
    return path.split('.').reduce((target, key) => target && target[ key ], obj)
  },
  listBack (data, rootPath, path, success, error, empty) {
    // type ['result'], ['result']['items']
    let tPath = this.objectFindVaule(data, path)
    if (!data.error) {
      if (!this.objectFindVaule(data, rootPath) || !tPath || tPath.length === 0) {
        if (typeof empty === 'function') {
          empty()
        }
      } else {
        if (Array.isArray(tPath)) {
          success()
        }
      }
    } else {
      if (data.error.message) {
        error()
      }
    }
  }
}
export default fun
