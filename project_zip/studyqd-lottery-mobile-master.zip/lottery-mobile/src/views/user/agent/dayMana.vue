<template>
  <div class="app-main page-user page-user_dayMana" :style="{background: showSum ? '#f7f7f7' : '#fff' }">
    <x-header class="is-fixed"
    :left-options="{ backText: '', preventGoBack: true }"
    @on-click-back="$router.push({ path: '/user/agent' })">
      <button-tab v-model="tabActive" stylereset>
        <button-tab-item @on-item-click="btnClick()"><icon-svg iconClass="duihao"></icon-svg>日工资报表</button-tab-item>
        <button-tab-item @on-item-click="btnClick()"><icon-svg iconClass="duihao"></icon-svg>日工资签约</button-tab-item>
      </button-tab>
    </x-header>
    <div class="app-body">
      <div v-show="showSum" class="ul-div">
          <div class="condition">
            <div class="top">
              <flexbox class="selectWrap">
                <flexbox-item>
                  <span class="selectItem"><selector class="loTypeSel" placeholder="期数名称" v-model="ltype" :options="ltypeList"></selector><icon-svg iconClass="bg-down" class="up"></icon-svg></span>
                </flexbox-item>
                <dateRange ref="dateRange" :options="{defaultDate: '最近七天'}"></dateRange>
              </flexbox>
            </div>
            <flexbox :gutter="0">
              <x-input class="userSearch" title='用户名：' placeholder="请输入用户名" v-model="userLoginId"></x-input>
              <flexbox-item><x-button stylereset type="warn" :show-loading="queryLoading" @click.native="querySearch"><template v-if="!queryLoading">查询</template></x-button></flexbox-item>
            </flexbox>
          </div>
          <ul class="ul-title clearfix">
            <li>用户名</li>
            <li>所属组</li>
            <li>有效投注</li>
            <li>日工资比例</li>
            <li>日工资金额</li>
          </ul>
          <ul v-if="reportData.length > 0" class="ul-content clearfix" @click="openInfo(index)" v-for="(row, index) in reportData" :key="row.loginId">
            <li>{{row.loginId}}</li>
            <li>
              <template v-if="row.regType == 'a' && row.agentStatus == 1">启用</template>
              <template v-else-if="row.regType == 'a' && row.agentStatus == 4">停用</template>
              <template v-else-if="row.regType == 'n' && row.userStatus == 1">启用</template>
              <template v-else-if="row.regType == 'n' && row.userStatus == 4">停用</template>
              <template v-else><span style="visibility: hidden;">none</span></template>
            </li>
            <li>{{row.validBet}}</li>
            <li>{{row.salaryRate}}%</li>
            <li>
              {{row.hasSalary}}<icon-svg class="right-icon" :icon-class="row.expand ? 'up' : 'right'"></icon-svg>
            </li>
            <template v-if="row.expand">
              <p><span>期数名称</span><span>{{row.issue}}</span><span>团队投注返点</span><span>{{row.teamRebate}}</span></p>
              <p><span>返点等级</span><span class="level"><a href="javascript:;" @click.prevent="goRebaseSee(row)"><icon-svg icon-class="chazhao"></icon-svg></a></span><span>代理返点</span><span>{{row.agentRebate}}</span></p>
              <p><span>有效人数</span><span>{{row.validUser}}</span><span>团队盈亏</span><span class="red">{{row.curPayout}}</span></p>
            </template>
          </ul>
          <ul v-if="reportData.length > 0" @click="openSum()" class="clearfix sum">
            <li>总计</li>
            <li><span style="visibility: hidden;">none</span></li>
            <li>{{reportDataTotal.valid_bet}}</li>
            <li><span style="visibility: hidden;">none</span></li>
            <li>
              {{reportDataTotal.has_bonus}}<icon-svg class="right-icon" :icon-class="showInfo ? 'up' : 'right'"></icon-svg>
            </li>
            <template v-if="showInfo">
              <p><span>有效人数 </span><span>{{reportDataTotal.valid_user}}</span><span>团队投注返点</span><span>{{reportDataTotal.team_rebate}}</span></p>
              <p><span></span><span></span><span>代理返点</span><span>{{reportDataTotal.agent_rebate}}</span></p>
              <p><span></span><span></span><span>团队盈亏</span><span class="red">{{reportDataTotal.payout}}</span></p>
            </template>
          </ul>
           <div class="getMore" v-if="queryData.total != 0" @click="querySearch('plus')"><span v-html="queryDataPage.text"></span></div>
      </div>
      <div v-show="showReport" class="ul-div">
        <ul class="ul-title clearfix">
            <li>用户名</li>
            <li>有效投注</li>
            <li>当前比例</li>
            <li>状态</li>
            <li>操作</li>
          </ul>
          <ul class="ul-content clearfix" v-for="(row, index) in signData" :key="row.loginId">
            <li>{{row.loginId}}</li>
            <li>{{row.validBet}}</li>
            <li>{{row.bonusRate}}%</li>
            <li>
              <span v-if="row.state == -1">未签</span>
              <span class="org" v-if="row.state == 0">下级待确认</span>
              <span class="red" v-if="row.state == 1">已签</span>
              <span v-if="row.state == 2">取消</span>
              <span v-if="row.state == 3">下级拒绝</span>
            </li>
            <li>
              <span v-if="row.state == -1 || row.state == 2 || row.state == 3" ><span class="blue" @click="sign(index, row, 1)">签约</span><i class="clickIcon"><icon-svg @click.native="expandClick(index)" class="right-icon" :icon-class="row.expand ? 'up' : 'right'"></icon-svg></i></span>
              <span v-if="row.state == 0 || row.state == 1" ><span class="blue" @click="DailySignCacel(index, row, 3)">取消</span><i class="clickIcon"><icon-svg @click.native="expandClick(index)" class="right-icon" :icon-class="row.expand ? 'up' : 'right'"></icon-svg></i></span>
            </li>
            <template v-if="row.expand">
              <p><span>返点等级</span><span class="level"><a href="javascript:;" @click="goRebaseSee(row)"><icon-svg icon-class="chazhao"></icon-svg></a></span><span>有效人数</span><span>{{notNull(row, 'validUser')}}</span></p>
              <p><span>团队盈亏</span><span class="red">{{notNull(row, 'payout')}}</span><span></span><span></span></p>
            </template>
          </ul>
      </div>
      <div class="dialogCommon" v-transfer-dom>
        <x-dialog v-model="showScrollBox" hide-on-blur>
          <p class="dialog-title">自身日工资比例：<span v-if="signConf.radio != signConf.maxRadio">{{signConf.radio}}%~</span>{{signConf.maxRadio}}%，当前可设置直接下级日工资：0.1~{{signConf.maxRadio}}％</p>
          <div class="img-box">
              <div class="formItem">
                <span class="inputWrp"><x-input title='团队派彩金额≥' v-model="teamProfit"></x-input></span><span>元</span>
                <span class="inputWrp"><x-input title='团队有效投注≥' v-model="validBet"></x-input></span><span>元</span>
                <span class="inputWrp"><x-input title='有效会员≥' v-model="validUser"></x-input></span><span>人</span>
                <span class="inputWrp"><x-input title='日工资比例=' v-model="bonusRate"></x-input></span><span>%</span>
              </div>
              <div class="radioWrap"><span class="radio" v-for="(row, index) in radioList" :key="index" @click="radioChange(index)"><icon-svg :iconClass="index == radioChecked ? 'radio-checked' : 'radio-check'"></icon-svg>{{row}}</span></div>
              <x-button class="btnSubmit" type="warn" @click.native="DailySign">签约</x-button>
              <x-button class="btnSubmit reset" plain type="primary" @click.native="reset">重置</x-button>
          </div>
          <div @click="showScrollBox=false">
            <span class="vux-close"></span>
          </div>
        </x-dialog>
      </div>
      <div :class="{'signMemo slide': isShowArrowDown, 'signMemo animate': !isShowArrowDown}" v-if="showReport">
        <icon-svg :iconClass="isShowArrowDown ? 'arrow-down' : 'arrow-up'" @click.native="showArrowDown"></icon-svg>
        <div><h1>自身日工资比例： <span v-if="signConf.radio != signConf.maxRadio">{{signConf.radio}}%~</span>{{signConf.maxRadio}}%，当前可设置直接下级日工资： 0.1%-{{signConf.maxRadio}}%</h1></div>
        <div>
          <div class="inner">
            <p>日工资条件：</p>
            <p><!--日均投注 ? 元，-->团队总投注 {{signConf.teamValidBet}} 元，团队亏损 {{signConf.teamPayout}} 元，团队有效会员 {{signConf.teamValidUser}} 人</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import Vue from 'vue'
  import { ConfirmPlugin, Checklist, ButtonTab, ButtonTabItem, Flexbox, XButton, FlexboxItem, Selector, XDialog, TransferDomDirective as TransferDom } from 'vux'
  import dateRange from '../components/range-select'
  import * as API from 'api/wapi/user'
  Vue.use(ConfirmPlugin)
  import comFun from './comFunction'
  export default {
    data () {
      return {
        isShowArrowDown: true,
        radioList: ['盈亏累计', '盈亏不累计'],
        validBet: '',
        validUser: '',
        bonusRate: '',
        teamProfit: '',
        userLoginId: '',
        currentRow: '',
        radioChecked: 0,
        tabActive: 0,
        showSum: true,
        showReport: false,
        showInfo: false,
        showScrollBox: false, // 签约
        reportData: [],
        reportDataTotal: {},
        signData: [], // 签约列表
        signConf: {},
        ltype: '',
        ltypeList: [],
        queryDataPage: {
          text: '更多&gt;&gt;',
          noMore: false
        },
        queryData: {
          pageIndex: 1,
          pageSize: 10,
          total: 0
        },
        queryLoading: false
      }
    },
    directives: {
      TransferDom
    },
    components: {
      ButtonTab,
      ButtonTabItem,
      Flexbox,
      FlexboxItem,
      dateRange,
      Selector,
      XDialog,
      XButton,
      Checklist
    },
    mounted () {
      // this.querySearch()
      this.getLotteryTypeData()
    },
    watch: {
    },
    methods: {
      notNull (row, name) {
        return comFun.notNull(row, name)
      },
      goRebaseSee (row) {
        let rebateSeeData = {
          id: row.userId,
          type: row.regType === 'a' ? '代理' : '会员'
        }
        window.sessionStorage.setItem('rebateSeeData', JSON.stringify(rebateSeeData))
        this.$router.push({path: 'rebateSee', query: { id: row.userId }})
      },
      reset () {
        this.validBet = ''
        this.validUser = ''
        this.bonusRate = ''
        this.teamProfit = ''
      },
      expandClick (index) {
        this.signData[index].expand = !this.signData[index].expand
      },
      showArrowDown () {
        this.isShowArrowDown = !this.isShowArrowDown
      },
      // 获取日工资期数
      getLotteryTypeData () {
        API.GetDailyIssue().then(res => {
          var result = res.result
          if (result !== null && result !== '' && result !== '0') {
            this.ltypeList = result
            this.ltypeList = this.ltypeList.map(item => {
              return {
                key: item.issueName,
                value: item.issueName
              }
            })
          }
        })
      },
      querySearch (p) {
        // 日工资报表查询
        if (this.ltype === '') {
          this.$vux.toast.text('请选择期数名称', 'middle')
          return false
        }
        if (p === 'plus') {
          this.queryData.pageIndex += 1
          // 没有更多的处理
          if (this.queryDataPage.noMore) {
            return false
          }
        }
        this.queryLoading = true
        var params = {
          issue: this.ltype,
          withTotalMap: 1,
          beginTime: this.$refs['dateRange'].dateRange[0],
          endTime: this.$refs['dateRange'].dateRange[1]
        }
        if (/\S/.test(this.userLoginId)) {
          params.agentLoginId = this.userLoginId
        }
        Object.assign(this.queryData, params)
        API.GetDailyWage(this.queryData).then(res => {
          this.queryLoading = false
          if (!res.error && res.result && res.result.items) {
            var data = res.result.items.map(items => {
              items.expand = false
              return items
            })
            this.queryData.total = Math.ceil(res.result.total / this.queryData.pageSize)
            if (p === 'plus') {
              this.reportData = this.reportData.concat(data)
            } else {
              this.reportData = data
            }
            this.reportDataTotal = res.result.totalStats
            // 没有更多的处理
            if (this.queryData.pageIndex >= this.queryData.total && this.queryData.total !== 0) {
              this.queryDataPage.text = '没有更多了'
              this.queryDataPage.noMore = true
            }
          } else {
            this.$vux.toast.show({
              type: 'warn',
              text: res.error.message
            })
          }
        })
      },
      getSignData () {
        // 日工资签约
        API.GetDailySignList().then(res => {
          this.queryLoading = false
          if (!res.error && res.result) {
            this.signData = res.result.map(items => {
              items.expand = false
              return items
            })
          } else {
            this.$vux.toast.show({
              type: 'warn',
              text: res.error.message
            })
          }
        })
      },
      radioChange (index) {
        // 开户单选
        this.radioChecked = index
      },
      itemClick (index) {
      },
      sign (index, row, type) {
        this.showScrollBox = true
        row.index = index
        this.currentRow = row
        this.reset()
      },
      btnClick () {
        if (this.tabActive === 0) {
          this.showSum = true
          this.showReport = false
        } else if (this.tabActive === 1) {
          this.showSum = false
          this.showReport = true
          this.getSignData()
          this.getDailyRate()
        }
      },
      openInfo (index) {
        this.reportData[index].expand = !this.reportData[index].expand
      },
      openSum () {
        this.showInfo = !this.showInfo
      },
      getDailyRate () {
        // 获取日工资说明
        API.GetDailyRate().then(res => {
          if (!res.error) {
            this.signConf = res.result
          } else {
            // error
          }
        })
      },
      DailySign () {
        // 签约， 重签
        var prams = {
          agentId: this.currentRow.agentId,
          validBet: this.validBet,
          validUser: this.validUser,
          bonusRate: this.bonusRate,
          payout: this.teamProfit,
          profitFlag: +this.radioChecked + 1
        }
        if (!comFun.reg.num.test(this.validBet)) {
          this.$vux.toast.text('团队有效投注请输入数字', 'middle')
          return false
        }
        if (!comFun.reg.num.test(this.bonusRate)) {
          this.$vux.toast.text('日工资比例请输入数字', 'middle')
          return false
        }
        if (this.bonusRate < 0.1 || this.bonusRate > this.signConf.maxRadio) {
          this.$vux.toast.text(`日工资比例请输入0.1-${this.signConf.maxRadio}`, 'middle')
          return false
        }
        if (!comFun.reg.zeroOrInt.test(this.validUser)) {
          this.$vux.toast.text('有效会员请输入数字', 'middle')
          return false
        }
        if (!comFun.reg.num.test(this.teamProfit)) {
          this.$vux.toast.text('团队派彩金额请输入数字', 'middle')
          return false
        }
        API.DailySign(prams).then(res => {
          if (!res.error && +res.result > 0) {
            this.showScrollBox = false
            this.$vux.toast.show({
              type: 'success',
              text: '操作成功'
            })
            this.signData[this.currentRow.index].validBet = this.validBet
            this.signData[this.currentRow.index].validUser = this.validUser
            this.signData[this.currentRow.index].bonusRate = this.bonusRate
            this.signData[this.currentRow.index].payout = this.teamProfit
            this.signData[this.currentRow.index].state = 0
          } else {
            this.$vux.toast.show({
              type: 'warn',
              text: '操作失败'
            })
          }
        })
      },
      DailySignCacel (index, row) {
        // 签约取消
        const _this = this
        var prams = {
          agentId: row.agentId,
          state: 2
        }
        this.$vux.confirm.show({
          content: '您确定进行此操作?',
          onConfirm () {
            API.DailySignCacel(prams).then(res => {
              if (!res.error) {
                _this.showScrollBox = false
                if (+res.result > 0) {
                  _this.$vux.toast.show({
                    type: 'success',
                    text: '操作成功'
                  })
                  _this.signData[index].state = 2
                } else {
                  _this.$vux.toast.show({
                    type: 'warn',
                    text: '操作失败'
                  })
                }
              } else {
                _this.$vux.toast.show({
                  type: 'warn',
                  text: res.error.message
                })
              }
            })
          }
        })
      }
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
</style>
