const hotLoad = require('@/utils/import_' + process.env.NODE_ENV)
/* 代理中心下的模块 */
const Report = hotLoad('user/agent/report')
const TeamMana = hotLoad('user/agent/teamMana')
const DayMana = hotLoad('user/agent/dayMana')
const ProfitMana = hotLoad('user/agent/profitMana')
const OpenAccount = hotLoad('user/agent/openAccount')
const AgentIntro = hotLoad('user/agent/agentIntro')
const Rebate = hotLoad('user/agent/rebate')
const RebateSee = hotLoad('user/agent/rebateSee')
const Tranfer = hotLoad('user/agent/tranfer')
const CodeDetail = hotLoad('user/agent/codeDetail')
const SignReport = hotLoad('user/agent/signReport')

export default {
  Report,
  TeamMana,
  DayMana,
  ProfitMana,
  OpenAccount,
  AgentIntro,
  Rebate,
  RebateSee,
  Tranfer,
  CodeDetail,
  SignReport
}
