<template>
  <keep-alive>
    <component :is="currentView" v-if="currentView">
      <!-- 根据router/index的name拉取对应的组件显示 -->
    </component>
  </keep-alive>
</template>

<script type="text/ecmascript-6">
  import Comps from './agentComps'
  export default {
    data () {
      return {
        currentView: null
      }
    },
    components: Comps,
    methods: {
      updateCurrrentView () {
        let sId = this.$route.params.sid
        switch (sId) {
          case 'report':
            this.currentView = Comps.Report
            break
          case 'teamMana':
            this.currentView = Comps.TeamMana
            break
          case 'dayMana':
            this.currentView = Comps.DayMana
            break
          case 'profitMana':
            this.currentView = Comps.ProfitMana
            break
          case 'openAccount':
            this.currentView = Comps.OpenAccount
            break
          case 'agentIntro':
            this.currentView = Comps.AgentIntro
            break
          case 'rebate':
            this.currentView = Comps.Rebate
            break
          case 'rebateSee':
            this.currentView = Comps.RebateSee
            break
          case 'tranfer':
            this.currentView = Comps.Tranfer
            break
          case 'codeDetail':
            this.currentView = Comps.CodeDetail
            break
          case 'signReport':
            this.currentView = Comps.SignReport
            break
          default:
            this.currentView = null
            this.$router.replace({ name: 'Err404' })
        }
      }
    },
    created () {
      this.updateCurrrentView()
    },
    watch: {
      $route (to, from) {
        this.updateCurrrentView()
      }
    }
  }
</script>

<style scoped></style>
