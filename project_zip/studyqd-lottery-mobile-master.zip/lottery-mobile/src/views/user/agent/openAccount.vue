<template>
  <div class="app-main page-user page-user_openAccount">
    <x-header class="is-fixed"
    :left-options="{ backText: '', preventGoBack: true }"
    @on-click-back="$router.push({ path: '/user/agent' })">
      <button-tab v-model="tabActive" stylereset>
        <button-tab-item @on-item-click="btnClick()"><icon-svg iconClass="duihao" v-if="showSum"></icon-svg>下级开户</button-tab-item>
        <button-tab-item @on-item-click="btnClick()"><icon-svg iconClass="duihao" v-if="showReport"></icon-svg>邀请码</button-tab-item>
      </button-tab>
    </x-header>
    <div class="app-body" style="padding-bottom: 0">
      <div v-show="showSum">
        <ul class="ul top">
          <li><div class="items"><label class="type">开户类型</label><span class="radio" v-for="(row, index) in radioList" :key="index" @click="radioChange(index)"><icon-svg :iconClass="index == radioChecked ? 'radio-checked' : 'radio-check'"></icon-svg>{{row}}</span></div></li>
          <li><div class="items"><label>请先为下级设置返点，</label><router-link to="rebate" class="red">点击查看返点赔率表</router-link></div></li>
        </ul>
        <ul class="ul list">
          <li v-for="(row, index) in combineData" :key="row.id"><div class="items"><span class="title">{{row.name}}</span><span class="text"><x-input :class="row.error ? 'error' : ''" placeholder="" v-model="row.input"></x-input></span><span class="intro">自身返点{{row.value}}，可设置0-{{row.value}}</span></div></li>
        </ul>
        <x-button class="btnSubmit" type="warn" @click.native="codeAdd" :show-loading="addCodeLoading" :disabled="addCodeLoading">{{addCodeLoadingText}}</x-button>
      </div>
       <div v-show="showReport" class="invite">
         <ul class="ul top">
          <li><div class="items"><label class="type">邀请码类型</label><span class="radio" v-for="(row, index) in radioList" :key="index" @click="radioIChange(index)"><icon-svg :iconClass="index == radioIChecked ? 'radio-checked' : 'radio-check'"></icon-svg>{{row}}</span></div></li>
        </ul>
        <template v-for="(row, index) in codelist">
          <ul class="ul list">
            <li><div class="items"><span class="title">邀请码:</span><span class="text code"><x-input readonly placeholder="" v-model="row.agentCode"></x-input></span><span class="copy" v-clipboard="row.agentCode" :key="row.agentCode"  @success="handleSuccess" @error="handleError">复制</span></div></li>
            <li><div class="items"><span class="title">注册链接:</span><span class="text href"><x-input readonly placeholder="" v-model="row.vipUrl"></x-input></span><span class="copy" v-clipboard="row.vipUrl" :key="row.vipUrl" @success="handleSuccess" @error="handleError">复制</span></div></li>
            <li><div class="items"><span class="title">生成时间:</span><span class="text font">{{row.createTime}}</span></div></li>
            <li><div class="items"><span class="title">状态:</span><span class="text font">注册（{{row.invitedUsers}}）</span></div></li>
            <li><div class="items"><span class="title">备注:</span><span class="text memo font">
                <template v-if="!row.isEdit">{{!row.memo ? '未设置': row.memo}}</template>
                <template v-if="row.isEdit"><x-input :max="100" placeholder="" v-model="row.memo" @on-blur="memoBlur(index)"></x-input></template>
                <icon-svg v-if="!row.isEdit" iconClass="bi" class="pen" @click.native="editCont(index)"></icon-svg>
              </span>
              </div>
            </li>
          </ul>
          <div class="op">
            <x-button class="detail" mini @click.native="goDetail(row)">详情</x-button>
            <x-button class="delete" mini @click.native="codeDelete(row.agentCode)">删除</x-button>
          </div>
        </template>
        <div class="getMore" v-if="codeListData.total != 0" @click="getCodeList('plus')"><span v-html="codeListDataPage.text"></span></div>
       </div>
    </div>
    <toast v-model="showSuccess" type="text" position="middle">{{ callBackText }}</toast>
  </div>
</template>

<script type="text/ecmascript-6">
  import Vue from 'vue'
  import { ButtonTab, ButtonTabItem, Toast, cookie, ConfirmPlugin } from 'vux'
  import fun from './comFunction'
  Vue.use(ConfirmPlugin)
  import VueClipboards from 'vue-clipboards'
  import * as API from 'api/wapi/user'
  Vue.use(VueClipboards)
  export default {
    data () {
      return {
        addCodeLoading: false,
        addCodeLoadingText: '生成邀请码',
        combineData: [],
        radioList: ['代理', '会员'],
        radioChecked: 0,
        radioIChecked: 0,
        memoData: '',
        showSuccess: false,
        callBackText: '',
        tabActive: 0,
        showSum: true,
        showReport: false,
        codelist: [],
        codeListData: {
          pageIndex: 1,
          pageSize: 10,
          total: 0
        },
        codeListDataPage: {
          text: '更多&gt;&gt;',
          noMore: false
        }
      }
    },
    components: {
      ButtonTab,
      ButtonTabItem,
      Toast
    },
    created () {
      this.combine().then(res => {
        this.combineData = res.map(items => {
          items.error = false
          return items
        })
      })
    },
    watch: {
    },
    methods: {
      getWebpath () {
        return new Promise((resolve, reject) => {
          var params = {
            'domain': window.location.hostname
          }
          API.snInfo(params).then(res => {
            if (!res.error && res.result) {
              resolve(res.result)
            } else {
              this.$vux.toast.show({
                type: 'warn',
                text: res.error.message
              })
              reject('')
            }
          })
        })
      },
      goDetail (row) {
        let codeDetailData = {
          id: row.agentId,
          regCode: row.regCode
        }
        window.sessionStorage.setItem('codeDetailData', JSON.stringify(codeDetailData))
        this.$router.push({path: 'codeDetail', query: {id: row.agentId}})
      },
      isPass () {
        let isPass = fun.checkedInputNum(this.combineData)
        if (isPass.length > 0) {
          this.combineData = this.combineData.map(items => {
            items.error = false
            return items
          })
          for (let i = 0; i < isPass.length; i++) {
            this.combineData[isPass[i]].error = true
          }
          this.$vux.toast.text('只能输入返点值范围内的数字，最多保留两位小数', 'middle')
          return false
        }
        return true
      },
      codeAdd () {
        if (!this.isPass()) {
          return false
        }
        (async() => {
          this.addCodeLoadingText = '处理中'
          this.addCodeLoading = true
          let snInfo = ''
          try {
            snInfo = await this.getWebpath()
            var params = {
              agentId: cookie.get('userId'),
              confType: +this.radioChecked + 1,
              domain: window.location.hostname,
              webPath: snInfo.webDomain.webPath
            }
            let rebateRateRule = this.combineData.map(items => {
              return items.id + '-' + items.input * 100 + '-' + items.value * 100
            })
            params.rebateRateRule = rebateRateRule.join('|')
            API.addCode(params).then(res => {
              this.addCodeLoadingText = '生成邀请码'
              this.addCodeLoading = false
              if (!res.error) {
                this.$vux.toast.show({
                  type: 'success',
                  text: '操作成功'
                })
                this.combineData = this.combineData.map(items => {
                  items.input = ''
                  items.error = false
                  return items
                })
              } else {
                this.$vux.toast.show({
                  type: 'warn',
                  text: res.error.message
                })
              }
            })
          } catch (e) {
            this.addCodeLoadingText = '生成邀请码'
            this.addCodeLoading = false
            console.log(e)
          }
        })()
      },
      combine () {
        // 合并数据
        let _this = this
        var combineData = []
        async function asyncAction () {
          try {
            _this.$vux.loading.show()
            var idName = await _this.rebateSeeIdName()
            var keyValue = await _this.rebateSeeKeyValue()
            var keyValueArray = Object.keys(keyValue)
            // 循环可能有bug
            for (let i = 0; i < idName.length; i++) {
              for (let j = 0; j < keyValueArray.length; j++) {
                if (typeof idName[i].id !== 'undefined' && typeof keyValueArray[j] !== 'undefined') {
                  if (parseInt(idName[i].id) === parseInt(keyValueArray[j])) {
                    combineData.push({input: '', id: idName[i].id, value: keyValue[idName[i].id], name: idName[i].name})
                  }
                }
              }
            }
          } catch (e) {
            combineData = []
            _this.$vux.toast.show({
              type: 'warn',
              text: e.error.message
            })
          }
          _this.$vux.loading.hide()
          return combineData
        }
        return asyncAction()
      },
      rebateSeeIdName () {
        return new Promise((resolve, reject) => {
          API.rebateSeeIdName().then(res => {
            if (!res.error && res.result) {
              resolve(res.result.items)
            } else {
              reject(res)
            }
          })
        })
      },
      rebateSeeKeyValue () {
        var params = {
          userId: cookie.get('userId')
        }
        return new Promise((resolve, reject) => {
          API.rebateSeeKeyValue(params).then(res => {
            if (!res.error) {
              resolve(res.result)
            } else {
              reject(res)
            }
          })
        })
      },
      radioChange (index) {
        // 开户单选
        this.radioChecked = index
      },
      radioIChange (index) {
        // 邀请单选
        this.radioIChecked = index
        this.getCodeList()
      },
      memoBlur (index) {
        // 备注修改
        this.codelist[index]['isEdit'] = !this.codelist[index]['isEdit']
        let params = {
          agentCode: this.codelist[index]['agentCode'],
          memo: this.codelist[index]['memo']
        }
        if (this.codelist[index]['memo'].length > 100) {
          this.showSuccess = true
          this.callBackText = '备注不能超过100个字符'
          return false
        }
        API.editCodeMemo(params).then(res => {
          if (!res.error && +res.result > 0) {
            this.showSuccess = true
            this.callBackText = '操作成功'
          }
        })
      },
      codeDelete (id) {
        // 删除邀请码
        const _this = this
        this.$vux.confirm.show({
          content: '确定删除',
          onCancel () {
          },
          onConfirm () {
            let params = {
              agentCode: id
            }
            API.deleteCode(params).then(res => {
              if (!res.error) {
                if (+res.result > 0) {
                  _this.showSuccess = true
                  _this.callBackText = '操作成功'
                  console.log(id)
                  console.log(_this.codelist.findIndex(items => {
                    console.log(parseInt(items.agentCode) === id)
                  }))
                  _this.codelist.splice(_this.codelist.findIndex(items => parseInt(items.agentCode) === parseInt(id)), 1)
                } else {
                  this.$vux.toast.show({
                    type: 'warn',
                    text: '删除失败'
                  })
                }
              } else {
                this.$vux.toast.show({
                  type: 'warn',
                  text: res.error.message
                })
              }
            })
          }
        })
      },
      editCont (index) {
        this.codelist[index]['isEdit'] = !this.codelist[index]['isEdit']
      },
      itemClick (index) {
      },
      handleSuccess (e) {
        this.showSuccess = true
        this.callBackText = '复制成功'
      },
      handleError (e) {
        this.showSuccess = true
        this.callBackText = '复制失败, 请手动长按复制'
      },
      btnClick () {
        if (this.tabActive === 0) {
          this.showSum = true
          this.showReport = false
        } else if (this.tabActive === 1) {
          this.showSum = false
          this.showReport = true
          if (this.codelist.length === 0) {
            this.getCodeList()
          }
        }
      },
      getCodeList (p) {
        if (p === 'plus') {
          this.codeListData.pageIndex += 1
          // 没有更多的处理
          if (this.codeListDataPage.noMore) {
            return false
          }
        }
        this.codeListData.agentId = cookie.get('userId')
        this.codeListData.regType = parseInt(this.radioIChecked) + 1
        API.GetCodeList(this.codeListData).then(res => {
          if (!res.error) {
            let data = res.result.items.map(items => {
              items.isEdit = false
              return items
            })
            this.codeListData.total = Math.ceil(res.result.total / this.codeListData.pageSize)
            if (p === 'plus') {
              this.codelist = this.codelist.concat(data)
            } else {
              this.codelist = data
            }
            // 没有更多的处理
            if (this.codeListData.pageIndex >= this.codeListData.total && this.codeListData.total !== 0) {
              this.codeListDataPage.text = '没有更多了'
              this.codeListDataPage.noMore = true
            }
          }
        })
      }
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user_openAccount
    overflow hidden
    .error
      .weui-input
        border-color $color-red !important
    /* 单选 */
    .radio
      margin-right rem(90)
      i
        vertical-align middle
        position relative
        width rem(32)
        height rem(32)
        margin-right rem(28)
        .svg-icon
          position absolute
          left 0
          top 0
    .invite
      .type
        margin-right rem(36) !important
      .pen
        width rem(40)
        vertical-align top
        margin-left rem(36)
      .op
        border-bottom solid 1px #eaeaea
        margin-bottom rem(20)
        background #fff
        padding rem(24) 0
        text-align center
        .weui-btn
          margin 0 0 0 0
          color $color-white
          font-size rem(24)
          width rem(144)
          line-height rem(60)
          &.detail
            background $color-red
          &.delete
            background #868686
          &:last-child
            margin-left rem(40)
      .ul.list
        margin-bottom 0
      .font
        line-height rem(68) !important
        color #858585
        font-size rem(24)
        margin-left rem(42)
      .code
        color $color-red
        .weui-input
          border-color $color-white
          font-size rem(24)
      .weui-input
        padding-left rem(10) !important
      .href, .memo
        .weui-input
          width rem(380)
          color #858585
          font-size rem(24)
      .memo
        margin-left rem(28)
        .weui-input
          margin-left 0
        .weui-cell__ft
          top rem(0)
      .items
        border-bottom 0 !important
    .btnSubmit
      width rem(670)
      height rem(78)
      font-size rem(28)
      background $color-red
    .ul
      &.top
        line-height rem(94)
        .type
          margin-right rem(70)
        .items
          height rem(94)
      &.list
        .items
          padding rem(10) 0
          display flex
        li
          padding-right 0
      .weui-cell {
        padding 0
        display inline-block
      }
      .weui-label {
        width rem(180) !important
      }
      .weui-input {
        background $color-white
        border solid 1px $color-ccc
        width rem(170)
        height rem(66)
        padding 0 rem(24)
        margin 0 rem(28)
      }
      .inputWrp {
        position relative
      }
      .weui-cell__ft {
        position absolute
        right rem(40)
        top rem(18)
      }
      margin-bottom rem(20)
      .red
        color $color-red
      background $color-white
      color #000000
      font-size rem(28)
      border-bottom solid 1px #eaeaea
      border-top solid 1px #eaeaea
      li
        padding 0 rem(20) 0 rem(20)
        &:last-child
          .items
            border-bottom 0
        .items
          width 100%
          padding 0 0 0 rem(36)
          border-bottom solid 1px #eaeaea
          .title
            width rem(130)
            text-align right
            line-height rem(68)
          .intro
            line-height rem(68)
            color #b2b2b2
            font-size rem(24)
            max-width rem(350)
          .text
            line-height 1
            max-width rem(550)
          .copy
            line-height rem(68)
            color #0096ff
            font-size rem(24)
          span
            display inline-block
            vertical-align top
            word-wrap: break-word;
            word-break: break-all;
</style>
