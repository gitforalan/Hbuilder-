<template>
  <div class="app-layout" style="background: #f7f7f7">
    <div class="app-main page-user__agentIndex" v-if="this.isCurrentRoute">
      <x-header :title="title" class="is-fixed"
      :left-options="{ backText: '', preventGoBack: true }"
      @on-click-back="$router.push({ path: '/user/index' })"></x-header>
      <div class="app-body">
        <group class="firstGrounp">
          <template v-for="(row, index) in link">
            <cell v-if="index < 5 && row.show" :title="row.title" @click.native="linkTo(row)" is-link></cell>
          </template>
        </group>
        <group>
          <cell :title="link[5].title" @click.native="linkTo(link[5])" is-link></cell>
        </group>
      </div>
    </div>
    <router-view></router-view>
  </div>
</template>

<script type="text/ecmascript-6">
  import { Cell, CellBox, CellFormPreview, Group, cookie } from 'vux'
  import Vue from 'vue'
  import * as API from 'api/wapi/user'
  export default {
    data () {
      return {
        title: '代理中心',
        isCurrentRoute: true,
        list: [],
        showBonusFlag: 0,
        showSalaryFlag: 0,
        dailyStatus: 1,
        profitStatus: 1,
        link: [
          {title: '团队报表', url: 'report', show: true},
          {title: '团队管理', url: 'teamMana', show: true},
          {title: '日工资管理', url: 'dayMana', show: false}, // false
          {title: '分红管理', url: 'profitMana', show: false}, // false
          {title: '下级开户', url: 'openAccount', show: true},
          {title: '代理说明', url: 'agentIntro', show: true}
        ]
      }
    },
    beforeRouteEnter: (to, from, next) => {
      let loginType = cookie.get('loginType')
      if (loginType === 'agent') {
        next()
      } else {
        Vue.$vux.toast.show({
          type: 'warn',
          text: '非代理无法查看',
          onHide () {
            next(false)
          }
        })
      }
    },
    components: {
      Group,
      Cell,
      CellFormPreview,
      CellBox
    },
    created () {
      // 决定显示index还是detail
      (async () => {
        if (this.$route.name !== 'agent') {
          this.isCurrentRoute = false
        }
        if (this.isCurrentRoute) {
          try {
            this.$vux.loading.show()
            let s1 = await this.hasPermission2SalaryBonus()
            let s2 = await this.DailySendSign()
            this.dailyStatus = parseInt(s2.state)
            let s3 = await this.ProfitSendSign()
            this.profitStatus = parseInt(s3.state)
            if (s1 && s1 !== 0) {
              this.showSalaryFlag = parseInt(s1.salaryFlag)
              this.showBonusFlag = parseInt(s1.bonusFlag)
              if (this.showSalaryFlag === 1 && this.dailyStatus !== 3) {
                this.link[2].show = true
              }
              if (this.showBonusFlag === 1 && this.profitStatus !== 3) {
                this.link[3].show = true
              }
            }
            this.$vux.loading.hide()
          } catch (e) {
            this.$vux.loading.hide()
          }
        }
      })()
    },
    methods: {
      linkTo (row) {
        if (row.url === 'dayMana') {
          if (this.dailyStatus === 0) {
            // 发起签约
            this.$router.push({ name: 'agentComp', params: { sid: 'signReport' }, query: { type: 'daily' } })
          } else if (this.dailyStatus === 1) {
            // 确定签约
            this.$router.push({ name: 'agentComp', params: { sid: row.url } })
          }
        } else if (row.url === 'profitMana') {
          if (this.profitStatus === 0) {
            // 发起签约
            this.$router.push({ name: 'agentComp', params: { sid: 'signReport' }, query: { type: 'profit' } })
          } else {
            // 确定签约
            this.$router.push({ name: 'agentComp', params: { sid: row.url } })
          }
        } else {
          this.$router.push({ name: 'agentComp', params: { sid: row.url } })
        }
      },
      itemClick (row) {
      },
      hasPermission2SalaryBonus () {
        // 是否有权限看日工资和分红
        return new Promise((resolve, reject) => {
          API.hasPermission2SalaryBonus().then(res => {
            if (!res.error && res.result) {
              resolve(res.result)
            } else {
              reject('')
            }
          })
        })
      },
      DailySendSign () {
        // 日工资签约
        return new Promise((resolve, reject) => {
          API.DailySendSign().then(res => {
            if (!res.error && res.result) {
              resolve(res.result)
            } else {
              res.result = {}
              res.result.state = 1
              resolve(res.result)
            }
          })
        })
      },
      ProfitSendSign () {
        // 分红签约
        return new Promise((resolve, reject) => {
          API.ProfitSendSign().then(res => {
            if (!res.error && res.result) {
              resolve(res.result)
            } else {
              res.result = {}
              res.result.state = 1
              resolve(res.result)
            }
          })
        })
      }
    },
    beforeRouteLeave (to, from, next) {
      this.$vux.loading.hide()
      next()
    },
    watch: {
      $route (to, from) {
        // 决定显示index还是detail
        if (from.name === 'agent') {
          this.isCurrentRoute = false
        } else if (to.name === 'agent') {
          this.isCurrentRoute = true
        }
      }
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .page-user__agentIndex
    label
      font-size $size-medium
    .weui-cell
      padding: rem(29) rem(42)
      font-size: rem(28)
      color: #000
      &:before {
        left: rem(20)
        right: rem(20)
      }
    .firstGrounp
      .vux-no-group-title
        margin-top 0
</style>
