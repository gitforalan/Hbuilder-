<template>
  <div class="app-main page-user page-user_openAccount">
    <x-header class="is-fixed" :title="title"></x-header>
    <div class="app-body">
      <ul class="ul list">
        <li v-for="(row, index) in combineData" :key="row.id"><div class="items"><span class="title">{{row.name}}</span><span class="text"><x-input disabled placeholder="" v-model="row.input"></x-input></span><span class="intro">自身返点{{row.value}}</span></div></li>
      </ul>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { ButtonTab, ButtonTabItem, Toast } from 'vux'
  import * as API from 'api/wapi/user'
  export default {
    data () {
      return {
        title: '详情',
        passData: '',
        combineData: []
      }
    },
    components: {
      ButtonTab,
      ButtonTabItem,
      Toast
    },
    mounted () {
      let data = JSON.parse(window.sessionStorage.getItem('codeDetailData'))
      this.passData = data
      this.combine()
    },
    watch: {
    },
    methods: {
      getCodeDetail () {
        return new Promise((resolve, reject) => {
          let params = {
            'confId': this.passData.regCode
          }
          API.codeDetail(params).then(res => {
            if (!res.error && res.result) {
              resolve(res.result)
            } else {
              this.$vux.toast.show({
                type: 'warn',
                text: res.error.message
              })
            }
          })
        })
      },
      combine () {
        // 合并数据
        let _this = this
        var combineData = []
        async function asyncAction () {
          try {
            var idName = await _this.rebateSeeIdName()
            var keyValue = await _this.getCodeDetail()
            // var pData = await _this.getCodeDetail()
            var keyValueArray = Object.keys(keyValue)
            // 循环可能有bug
            for (let i = 0; i < idName.length; i++) {
              for (let j = 0; j < keyValueArray.length; j++) {
                if (typeof idName[i].id !== 'undefined' && typeof keyValueArray[j] !== 'undefined') {
                  if (parseInt(idName[i].id) === parseInt(keyValueArray[j])) {
                    combineData.push({input: keyValue[idName[i].id], id: idName[i].id, value: keyValue[idName[i].id], name: idName[i].name})
                  }
                }
              }
            }
          } catch (e) {
            combineData = []
          }
          return combineData
        }
        asyncAction().then(res => {
          this.combineData = res
        })
      },
      rebateSeeIdName () {
        return new Promise((resolve, reject) => {
          API.rebateSeeIdName().then(res => {
            if (!res.error && res.result) {
              resolve(res.result.items)
            }
          })
        })
      },
      rebateSeeKeyValue () {
        // 根据登录id
        var params = {
          userId: this.passData.id
        }
        return new Promise((resolve, reject) => {
          API.rebateSeeKeyValue(params).then(res => {
            if (!res.error) {
              resolve(res.result)
            }
          })
        })
      }
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user_openAccount
    overflow hidden
    /* 单选 */
    .radio
      margin-right rem(90)
      i
        vertical-align middle
        position relative
        width rem(32)
        height rem(32)
        margin-right rem(28)
        .svg-icon
          position absolute
          left 0
          top 0
    .invite
      .type
        margin-right rem(36) !important
      .pen
        width rem(40)
        vertical-align top
        margin-left rem(36)
      .op
        border-bottom solid 1px #eaeaea
        margin-bottom rem(20)
        background #fff
        padding rem(24) 0
        text-align center
        .weui-btn
          margin 0 0 0 0
          color $color-white
          font-size rem(24)
          width rem(144)
          line-height rem(60)
          &.detail
            background $color-red
          &.delete
            background #868686
          &:last-child
            margin-left rem(40)
      .ul.list
        margin-bottom 0
      .font
        line-height rem(68) !important
        color #858585
        font-size rem(24)
        margin-left rem(42)
      .code
        color $color-red
        .weui-input
          border-color $color-white
          font-size rem(24)
      .weui-input
        padding-left rem(10) !important
      .href, .memo
        .weui-input
          width rem(380)
          color #858585
          font-size rem(24)
      .memo
        margin-left rem(28)
        .weui-input
          margin-left 0
        .weui-cell__ft
          top rem(0)
      .items
        border-bottom 0 !important
    .btnSubmit
      width rem(670)
      height rem(78)
      font-size rem(28)
      background $color-red
    .ul
      &.top
        line-height rem(94)
        .type
          margin-right rem(70)
        .items
          height rem(94)
      &.list
        .items
          padding rem(10) 0
          display flex
        li
          padding-right 0
      .weui-cell {
        padding 0
        display inline-block
      }
      .weui-label {
        width rem(180) !important
      }
      .weui-input {
        background $color-white
        border solid 1px $color-ccc
        width rem(170)
        height rem(66)
        padding 0 rem(24)
        margin 0 rem(28)
      }
      .inputWrp {
        position relative
      }
      .weui-cell__ft {
        position absolute
        right rem(40)
        top rem(18)
      }
      margin-bottom rem(20)
      .red
        color $color-red
      background $color-white
      color #000000
      font-size rem(28)
      border-bottom solid 1px #eaeaea
      border-top solid 1px #eaeaea
      li
        padding 0 rem(20) 0 rem(20)
        &:last-child
          .items
            border-bottom 0
        .items
          width 100%
          padding 0 0 0 rem(36)
          border-bottom solid 1px #eaeaea
          .title
            width rem(130)
            text-align right
            line-height rem(68)
          .intro
            line-height rem(68)
            color #b2b2b2
            font-size rem(24)
            max-width rem(350)
          .text
            line-height 1
          .copy
            line-height rem(68)
            color #0096ff
            font-size rem(24)
          span
            display inline-block
            vertical-align top
</style>