<template>
  <div class="app-main page-user page-user_AgentReport">
    <x-header :left-options="{backText: ''}" :title="title" class="is-fixed"></x-header>
    <div class="app-body">
      <div class="tab-content" v-cloak>
        <div class="agentMain agentIntro">
          <img src="../../../assets/image/banner.jpg">
          <div class="content">
            <p>当您能看到这个页面，说明您的账号既是玩家账号也是代理账号，既可以自己投注，也可以发展下级玩家，赚取返点佣金。</p>
            <ul>
              <li><img src="../../../assets/image/intro1.png"><span>如何赚取返点？</span></li>
              <li class="li-text">
                <span><img src="../../../assets/image/intro0.png">可获得的返点，等于自身返点与下级返点的差值，如自身返点5，下级返点3，你将能获得下级投注金额2%的返点，如下级投注100元，你将会获得2元。</span>
                <span><img src="../../../assets/image/intro0.png">点击下级开户，可查看自身返点，也可为下级设置返点。</span>
              </li>
              <li><img src="../../../assets/image/intro2.png"><span>如何为下级开户？</span></li>
              <li class="li-text">
                <span><img src="../../../assets/image/intro0.png">点击下级开户，先为您的下级设置返点，设置成功后会生成一条邀请码，将邀请码发送给您的下级注册，注册后他就是您的下级，点击会员管理，就能查看他注册的账号；</span>

                <span><img src="../../../assets/image/intro0.png">如果您为下级设置的是代理类型的账号，那么您的下级就能继续发展下级，如果设置的是玩家类型，那么您的下级只能投注，不能再发展下级，也看不到代理中心；</span>
              </li>
              <li><img src="../../../assets/image/intro3.png"><span>温馨提示</span></li>
              <li class="li-text">
                <span><img src="../../../assets/image/intro0.png">返点不同赔率也不同，点击返点赔率表，可查看返点赔率；</span>
                <i class="i-short"></i>
                <span><img src="../../../assets/image/intro0.png">返点越低，赔率就越低，建议为下级设置的返点不要过低；</span>
                <i class="i-short i-short2"></i>
                <span><img src="../../../assets/image/intro0.png">可在代理报表、投注明细、交易明细查看代理的发展情况；</span>
                <i class="i-short i-short3"></i>
                <span><img src="../../../assets/image/intro0.png">建议开设的下级也是代理类型，无论发展了几级，您都能获得返点。</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
    data () {
      return {
        title: '代理说明'
      }
    },
    created () {
    },
    watch: {
    },
    methods: {
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user_AgentReport
    .app-body
      background-color white
      color #434343
      font-size rem(26)
      font-weight bold
      .agentIntro 
        >img 
          width 100%
          height rem(250)
        p 
          display inline-block
          line-height rem(40)
          font-size rem(26)
        .content
          padding rem(10) rem(20)
          ul
            li 
              color $color-red
              font-weight bold
              margin rem(20) 0
              img 
                position: absolute
                left rem(14)
                width rem(28)
              >span
                font-weight bold
                font-size rem(30)
                padding-left rem(30)
                margin-left rem(8)
            .li-text
              color #000
              position relative
              line-height rem(40)
              span
                font-weight normal
                font-size rem(26)
                display block
              span
                border-left 1px solid #EAEAEA
              span:last-child
                border none
              span
                img 
                  position: absolute
                  left rem(-5)
                  width rem(28)
              i
                position absolute
                border 1px solid #EAEAEA
                left rem(-22)
                top rem(25)
              .i-long
                height rem(95)
              .i-short
                height rem(12)
              .i-short2
                top rem(66)
              .i-short3
                top rem(106)
</style>
