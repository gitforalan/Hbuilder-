<!-- Created By fx on 2017/9/4. -->
<template>
  <div class="app-main page-bindPhone">
    <x-header :title="title" class="is-fixed" :left-options="{backText: ''}"></x-header>
    <div class="app-body">
      <group class="input-group" label-margin-right=".5em" label-align="right" gutter="-1px">
        <x-input v-model="form.phone" placeholder="请输入手机号码" name="userName" type="text">
          <icon-svg slot="label" icon-class="shouji"></icon-svg>
        </x-input>
        <x-input v-model="form.number" placeholder="请输入验证码" type="text">
          <icon-svg slot="label" icon-class="yanzhengma"></icon-svg>
          <x-button slot="right" type="warn" :disabled="form.btn" @click.native="getCode" mini>{{form.text}}</x-button>
        </x-input>
      </group>
    </div>
    <div class="btn">
      <x-button type="warn" class="btn-submit" @click.native="save" :disabled="form.submit">保存</x-button>
    </div>

  </div>
</template>

<script type="text/ecmascript-6">
  import Vue from 'vue'
  import * as API from 'api/wapi/user'
  import { ConfirmPlugin } from 'vux'
  Vue.use(ConfirmPlugin)
  let inter = ''
  export default {
    data () {
      return {
        title: '绑定手机',
        form: {
          phone: '',
          number: '',
          btn: false,
          time: 60,
          text: '获取验证码',
          submit: false
        }
      }
    },
    created () {
    },
    mounted () {
    },
    methods: {
      save () {
        if (!/\S/.test(this.form.phone)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '请输入手机号码'
          })
          return false
        }
        if (!/\S/.test(this.form.number)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '请输入验证码'
          })
          return false
        }
        this.form.submit = true
        API.smsCheck({mobile: this.form.phone, authcode: this.form.number}).then(res => {
          if (!res.error) {
            var result = res.result
            if (+result === 1) {
              this.$vux.toast.show({
                text: '绑定成功'
              })
              setTimeout(() => {
                this.$router.replace({path: '/user/deposit'})
              }, 2000)
            } else {
              this.$vux.toast.show({
                text: '绑定失败'
              })
              this.resetCode()
            }
          } else {
            this.$vux.toast.show({
              type: 'warn',
              text: res.error.message
            })
          }
        })
      },
      resetCode () {
        this.form.time = 60
        this.form.text = '获取验证码'
        this.form.btn = false
        clearInterval(inter)
      },
      getCode () {
        if (!/\S/.test(this.form.phone)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '请输入手机号码'
          })
          return false
        }
        this.form.btn = true
        inter = setInterval(() => {
          this.form.time--
          if (this.form.time >= 0) {
            this.form.text = this.form.time + 'S'
          } else {
            this.resetCode()
          }
        }, 1000)
        API.smsSend({mobile: this.form.phone}).then(res => {
          if (!res.error) {
            var result = res.result
            if (+result === 1) {
              this.$vux.toast.show({
                text: '发送成功'
              })
            } else {
              this.$vux.toast.show({
                text: '发送失败'
              })
              this.resetCode()
            }
          } else {
            this.$vux.toast.show({
              type: 'warn',
              text: res.error.message
            })
            this.resetCode()
          }
        })
      }
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .page-bindPhone
    .input-group .weui-cells
      font-size $size-medium
      .weui-cell:before
        left 0
    div
      .input-group
        border 1px solid $color-border
        border-bottom none
        margin-top 3rem
        width 90%
        margin-left 5%
        .weui-cell__hd i
          width 1.8rem
          height 1.8rem
          padding-right .5rem
          color $color-gray
    .btn
      width rem(546)
      height rem(72)
      line-height rem(72)
      background $color-red
      color $color-white
      margin 0 auto
      border-radius 5px
      font-size $size-medium
      button
        font-size $size-small
        overflow visible
        height 100%
</style>