<template>
  <div class="app-main page-user page-user_DepositIndex">
    <loading :show="loading"></loading>
    <x-header :title="title" :left-options="{ backText: '', showBack: !paySuccess }" class="is-fixed"></x-header>
    <div class="success-help" v-if="paySuccess" @click="helpShow">帮助</div>
    <div class="app-body">
      <section v-if="!paySuccess">

        <div class="deposit-compte">
          <div class="compte-ctn">
            账号：
            <span class="fontred">{{userId}}</span>
          </div>
          <div class="compte-ctn">
            余额：
            <span class="fontred">{{balance}}</span>
            <span>元</span>
            <!-- <img slot="icon" src="../../../assets/image/refresh.png" > -->
            <span class="float-r"><icon-svg iconClass="shuaxin" class="shuaxin" @click.native="getBalance"></icon-svg></span>
          </div>
        </div>

        <div class="amount-ctn">
          <span>请输入充值金额：</span>
          <group class="money">
            <x-input v-model="money" placeholder="输入金额" :max="10"></x-input>
          </group>
          <span>元</span>
          <div class="button">
            <x-button @click.native="emptyMoney">清空</x-button>
          </div>  
        </div>

        <div class="amount-shortcut">
          <div class="button">
            <span @click="click50">50</span>
            <span @click="click100">100</span>
            <span @click="click500">500</span>
            <span @click="click1000">1000</span>
            <span @click="click5000">5000</span>
          </div>  
        </div>

        <div class="deposit-way">
          <span>请任选一种充值通道，若充值不成功，请切换其他充值通道：</span>
        </div>

        <div class="deposit-mode">
          <button-tab v-model="depositMode">
            <!-- <button-tab-item @on-item-click="btnClick()" v-for="(item, index) in passArr" :key="index" :selected="item.isSelected">{{item.value}}</button-tab-item> -->
            <button-tab-item @on-item-click="btnClick(item.chargeMode)" v-for="(item, index) in passArr" :key="index" :selected="item.isSelected">{{item.value}}</button-tab-item>
          </button-tab>
        </div>

        <!-- 微信扫码 -->
        <template v-if="depositMode === 0">
          <div v-if="wx.length > 0">
            <div class="deposit-wrap" v-for="(item, index) in wx" :key="index">
              <a href="javascript:;" @click="changeWeChat(item)">
                <icon-svg iconClass="weixin"></icon-svg>
                <div>
                  <h3 v-if="item && item.bankName">{{item ? item.bankName : ''}} 通道{{index + 1}} 【立即到帐】</h3>
                  <p>『二维码/扫一扫，单笔1元-5000元』</p>
                </div>
                <span class="arrow-right">
                  <icon-svg iconClass="right"></icon-svg>
                </span>
              </a>
            </div>
          </div>
          <div class="nonsupport" v-else>暂无充值通道</div>
        </template>

        <!-- 支付宝扫码 -->
        <template v-if="depositMode === 1">
          <div v-if="ali.length > 0">
            <div class="deposit-wrap" v-for="(item, index) in ali" :key="index">
              <a href="javascript:;" @click="changeAlipay(item)">
                <icon-svg iconClass="zhifubao"></icon-svg>
                <div>
                  <h3 v-if="item && item.bankName">{{item ? item.bankName : ''}} 通道{{index + 1}} 【立即到帐】</h3>
                  <p>『二维码/扫一扫，单笔1元-5000元』</p>
                </div>
                <span class="arrow-right">
                  <icon-svg iconClass="right"></icon-svg>
                </span>
              </a>
            </div>
          </div>
          <div class="nonsupport" v-else>暂无充值通道</div>
        </template>

        <!-- QQ钱包扫码 -->
        <template v-if="depositMode === 2">
          <div v-if="qq.length > 0">
            <div class="deposit-wrap" v-for="(item, index) in qq" :key="index">
              <a href="javascript:;" @click="changeQQ(item)">
                <icon-svg iconClass="QQ"></icon-svg>
                <div>
                  <h3 v-if="item && item.bankName">{{item ? item.bankName : ''}} 通道{{index + 1}} 【立即到帐】</h3>
                  <p>『二维码/扫一扫，单笔1元-5000元』</p>
                </div>
                <span class="arrow-right">
                  <icon-svg iconClass="right"></icon-svg>
                </span>
              </a>
            </div>
          </div>
          <div class="nonsupport" v-else>暂无充值通道</div>
        </template>
        <!-- QQ钱包扫码 -->

        <!-- 网银支付 -->
        <template v-if="depositMode === 3">
          <div class="nonsupport">暂不支持，该通道充值</div>
        </template>
        <!-- 网银支付 -->

        <!-- 银行汇款 -->
        <template v-if="depositMode === 4">
          <div class="deposit-wrap">
            <a href="javascript:;" @click="bankRemit">
              <icon-svg iconClass="yinhanghuikuan"></icon-svg>
              <div>
                <h3>公司入款</h3>
                <p>『更快捷/0~3分钟到账，大额无忧』</p>
              </div>
              <span class="arrow-right">
                <icon-svg iconClass="right"></icon-svg>
              </span>
            </a>
          </div>
        </template>
        <!-- 银行汇款 -->

        <!-- 快速充值 -->
        <template v-if="depositMode === 5">
          <div class="nonsupport">暂不支持，该通道充值</div>
        </template>
        <!-- 快速充值 -->

      </section>

      <!-- 支付成功 -->
      <section v-if="paySuccess" class="paySuccess">
        <iframe name="payIframe" id="payIframe" class="payIframe"></iframe>
      </section>
      <!-- 支付成功 -->
    </div>

    <x-dialog v-model="helpflag" hide-on-blur :dialog-style="{'max-width': '100%', width: '100%', height: '50%', 'background-color': 'transparent'}">
      <div class="help-warp">
        <h2>扫码步骤：</h2> 
        <p>1.长按二维码图片或截图保存到相册;</p> 
        <p>2.请在支付宝或微信中打开"扫一扫";</p> 
        <p>3.在"扫一扫"中点击右上角的"相册"，从相册中选取已保存的二维码图片;</p> 
        <p>4.确认支付金额无误后，按"立即付款"即可完成充值。</p> 
        <x-button @click.native="helpflag = false">返回扫码</x-button>
      </div>
    </x-dialog>

  </div>
</template>

<script type="text/ecmascript-6">
import { ButtonTab, ButtonTabItem, Loading, XDialog, cookie, dateFormat } from 'vux'
import * as API from 'api/wapi/user'

export default {
  data () {
    return {
      title: '存款',
      paySuccess: false, // 支付状态 【成功，失败】
      userId: '',
      balance: 0,
      money: '',
      loading: true,
      chargeNo: null,
      depositTime: null,
      helpflag: false,
      passArr: [{
        value: '微信',
        isSelected: true,
        chargeMode: 1
      }, {
        value: '支付宝',
        isSelected: false,
        chargeMode: 2
      }, {
        value: 'QQ钱包',
        isSelected: false,
        chargeMode: 3
      }, {
        value: '网银支付',
        isSelected: false,
        chargeMode: 0
      }, {
        value: '银行汇款',
        isSelected: false,
        chargeMode: -1
      }, {
        value: '快速充值',
        isSelected: false,
        chargeMode: -1
      }],
      tabCurrent: {
        list: [
          {id: 0, name: '微信', type: 'wx', flag: false, show: 0, list: [], chargeMode: 1},
          {id: 1, name: '支付宝', type: 'ail', flag: false, show: 0, list: [], chargeMode: 2},
          {id: 2, name: 'QQ钱包', type: 'qq', flag: false, show: 0, list: [], chargeMode: 3},
          {id: 3, name: '网银支付', type: 'wy', flag: false, show: 0, list: ['wy'], chargeMode: 0},
          {id: 4, name: '银行汇款', type: 'gsrk', flag: false, show: 0, list: ['gsrk'], chargeMode: -1},
          {id: 5, name: '快速充值', type: 'fast', flag: false, show: 0, url: '', chargeMode: -1}
        ]
      },
      tabList: {
        23: {id: 23, flag: false, name: '支付宝个人转帐', payType: 'alipay-person'},
        24: {id: 24, flag: false, name: '微信个人转帐', payType: 'weixin-person'},
        45: {id: 45, flag: false, name: 'QQ个人转帐', payType: 'qq-person'},
        // 46: {flag: false, name: '微信一键支付'},
        47: {id: 47, flag: false, name: '微信扫码', payType: 'pay', list: []},
        // 48: { flag: false, name: '支付宝一键支付'},
        49: {id: 49, flag: false, name: '支付宝扫码', payType: 'pay', list: []},
        // 50: { id: 50, flag: false, name: '网银在线支付', payType: 'onlinepay'},
        52: {id: 52, flag: false, name: '京东钱包扫码', payType: 'pay', list: []},
        // 55: {flag: false, name: '京东钱包一键支付'},
        53: {id: 53, flag: false, name: '百度钱包扫码', payType: 'pay', list: []},
        // 54: {flag: false, name: '百度钱包一键支付'},
        // 56: {flag: false, name: 'QQ钱包一键支付'},
        57: {id: 57, flag: false, name: 'QQ钱包扫码', payType: 'pay', list: []},
        wy: {id: 'wy', flag: false, name: '网银支付', payType: 'onlinepay', bank: {}},
        gsrk: {id: 'gsrk', flag: false, name: '银行汇款', payType: 'bankpay'}
      },
      wx: [],
      ali: [],
      qq: [],
      wy: [],
      depositMode: 0,
      chargeMode: 1 // [1: 微信, 2: 支付宝, 3: QQ, -1: 其它]
    }
  },
  components: {
    ButtonTab, ButtonTabItem, Loading, XDialog
  },
  mounted () {
    // document.querySelector('.app-layout .app-body').style.paddingTop = window.getComputedStyle(document.querySelector('.app-layout .vux-header'))['height']
    document.querySelector('.app-layout').style.background = '#fff'

    if (!cookie.get('userName')) {
      // 跳转登陆
      this.$router.push({ path: '/login' })
    }
    // 登录名
    this.userId = cookie.get('userName')
    // 余额
    this.getBalance()
    // 获取订单号
    this.chargeNoGet()
  },
  methods: {

    // 微信支付
    changeWeChat (item) {
      // 判断金额
      if (!this.isMoney(this.money)) return
      this.paymentApply(item, 'wx')
    },

    // 支付宝支付
    changeAlipay (item) {
      // 判断金额
      if (!this.isMoney(this.money)) return
      this.paymentApply(item, 'ali')
    },

    // QQ支付
    changeQQ (item) {
      // 判断金额
      if (!this.isMoney(this.money)) return
      this.paymentApply(item, 'qq')
    },

    // 银行汇款
    bankRemit () {
      // 判断金额
      if (!this.isMoney(this.money)) return
      // 判断银行限额
      this.changeMoney()
    },

    // 判断限额
    changeMoney () {
      var params = {
        amount: this.money,
        chargeType: 2
      }
      API.optionGet(params).then(res => {
        if (!res.error) {
          // 跳转银行汇款引导页
          this.$router.push({path: '/user/paragraph'})
          // 金额存入缓存
          sessionStorage.setItem('show', 1) // 是否直接进入当前页面
          sessionStorage.setItem('money', this.money)
          sessionStorage.setItem('chargeNo', this.chargeNo)
        } else {
          this.$vux.toast.show({
            type: 'warn',
            text: res.error.message
          })
        }
      })
    },

    // 支付
    paymentApply (payItem, mark) {
      var params = {}
      params.chargeNo = this.chargeNo
      params.amount = this.money
      params.fromBankId = payItem.bankId
      params.toPayId = payItem.payId
      params.digest = payItem.digest

      API.paymentApply(params).then(res => {
        if (!res.error) {
          if (res.result) {
            // 跳转第三方支付
            var chargeId = res.result
            var model = {}
            model.isQrCode = payItem.wxFlag === 2 // 自提取
            model.isIframe = model.isQrCode ? false : (payItem.iframeFlag === 1)
            model.isOpenWin = model.isQrCode || !model.isIframe
            model.payId = payItem.payId
            model.sn = cookie.get('token')
            model.money = this.money
            model.TransID = this.chargeNo
            model.orderNo = this.orderNo
            model.TradeDate = this.depositTime
            model.orderTime = this.depositTime
            model.failureTime = this.curentTimeAdd(90)
            model.Merchant_url = `${this.loadBaseUrl()}/pay/jsp/gopay/true.jsp`
            model.merRemark1 = chargeId
            model.merRemark2 = encodeURIComponent(payItem.digest)
            model.bankCode = payItem.providerBankCode
            model.MerchantID = payItem.paycode
            model.Amount = this.money
            model.orderAmount = this.money
            model.ProductName = payItem.payName
            model.Username = payItem.providerCode
            model.NoticeType = '0'
            model.terminalid = payItem.payTerminal
            model.referer = window.location.host
            model.merNo = payItem.paycode
            model.providerCode = payItem.providerCode
            model.paytype = mark // wx ali qq
            model.payUrl = payItem.payUrl
            model.ext1 = payItem.ext1
            model.ext2 = payItem.ext2
            model.secretKey = payItem.secretKey

            switch (payItem.providerCode) {
              case 'baofoo.com':
                model.action = `http://${model.payUrl}/pay/jsp/baopay/sign.jsp`
                model.returnUrl = `http://${model.payUrl}/pay/jsp/gopay/true.jsp`
                model.notifyUrl = `http://${model.payUrl}/pay/jsp/baopay/res.jsp`
                break
              case 'sfpay.com':
                model.action = `http://${model.payUrl}/pay/jsp/sfpay/sign.jsp`
                model.returnUrl = `http://${model.payUrl}/pay/jsp/gopay/true.jsp`
                model.notifyUrl = `http://${model.payUrl}/pay/jsp/gopay/true.jsp`
                break
              case 'funbay.com':
                model.action = `http://${model.payUrl}/pay/jsp/funpay/sign.jsp`
                model.returnUrl = `http://${model.payUrl}/pay/jsp/gopay/true.jsp`
                model.notifyUrl = `http://${model.payUrl}/pay/jsp/funpay/res.jsp`
                break
              case 'yompay.com':
                model.action = `http://${model.payUrl}/pay/jsp/yompay/sign.jsp`
                model.returnUrl = `http://${model.payUrl}/pay/jsp/gopay/true.jsp`
                model.notifyUrl = `http://${model.payUrl}/pay/jsp/yompay/res.jsp`
                break
              case 'juypay.com':
                model.action = `http://${model.payUrl}/pay/jsp/juypay/sign.jsp`
                model.returnUrl = `http://${model.payUrl}/pay/jsp/gopay/true.jsp`
                model.notifyUrl = `http://${model.payUrl}/pay/jsp/juypay/res.jsp`
                break
              case 'okfpay.com':
                model.action = `http://${model.payUrl}/pay/jsp/okpay/sign.jsp`
                model.returnUrl = `http://${model.payUrl}/pay/jsp/gopay/true.jsp`
                model.notifyUrl = `http://${model.payUrl}/pay/jsp/okpay/res.jsp`
                break
              case 'allscore.com':
                model.action = `http://${model.payUrl}/pay/jsp/scorepay/sign.jsp`
                model.returnUrl = `http://${model.payUrl}/pay/jsp/gopay/true.jsp`
                model.notifyUrl = `http://${model.payUrl}/pay/jsp/scorepay/res.jsp`
                break
              case 'fdpay.com':
                model.action = `http://${model.payUrl}/pay/jsp/fdpay/sign.jsp`
                model.returnUrl = `http://${model.payUrl}/pay/jsp/gopay/true.jsp`
                model.notifyUrl = `http://${model.payUrl}/pay/jsp/fdpay/res.jsp`
                break
              default:
                model.action = `http://${model.payUrl}/pay/jsp/commpay.jsp`
                break
            }

            // 创建form表单
            var form = document.createElement('form')
            this.toform(form, model)
            document.body.appendChild(form)

            // 显示支付视图 和 帮助按钮
            this.paySuccess = true

            // iframe
            this.$nextTick(() => {
              // 提交逻辑在 `centerPay.html`中
              // var payIframe = document.querySelector('#payIframe')
              // payIframe.setAttribute('src', `./centerPay.html?_t=${(new Date()).getTime()}`)

              // 提交逻辑
              var submitForm = document.querySelector('.J_centerPayForm')
              submitForm.submit()
              setTimeout(() => {
                // 重定向到存款页面
                // this.$router({path: '/user/deposit'})
                // this.$router.go(0)
                this.$router.go({
                  path: '/user/deposit',
                  force: true
                })
              }, 0)

              // 移除表单
              setTimeout(() => {
                document.querySelector('form.J_centerPayForm') && document.querySelector('form.J_centerPayForm').parentElement.removeChild(document.querySelector('form.J_centerPayForm'))
              }, 30)
            })
          }
        } else {
          this.$vux.toast.show({
            type: 'warn',
            text: res.error.message
          })
        }
        // 清空金额  重新获取订单号
        this.money = null
        this.chargeNoGet()
      })
    },

    // 厅主支持支付入口
    payBiglist () {
      var params = {}
      this.ali = []
      this.wx = []
      this.qq = []
      params.isFromMobile = 1 // 先写死
      params.chargeMode = this.chargeMode
      params.changeNo = this.chargeNo
      API.paymentBiglist(params).then(res => {
        // data.result = {"qq":[],"wx":[],"wy":[],"bd":[],"ail":[],"jd":[]}
        if (!res.error) {
          if (res.result && Object.keys(res.result).length > 0) {
            res.result.wx.forEach((item) => {
              this.wx.push(item[46] || item[47] || item[24])
            })
            res.result.ail.forEach((item) => {
              this.ali.push(item[48] || item[49] || item[23])
            })
            res.result.qq.forEach((item) => {
              this.qq.push(item[45] || item[56] || item[57])
            })
            // this.tabList[47] = res.result.wx
            // this.tabList[49] = res.result.ail
            // this.tabList[57] = res.result.qq
            // this.tabList['gsrk'] = res.result.wy
          }
        }
      })
    },

    // 获取订单号
    chargeNoGet () {
      API.chargeNoGet({}).then(res => {
        if (!res.error) {
          if (res.result) {
            this.chargeNo = res.result
            this.depositTime = dateFormat(new Date(), 'YYYY-MM-DD HH:mm:ss')
            this.payBiglist()
          }
        } else {
          this.$vux.toast.show({
            type: 'warn',
            text: res.error.message
          })
        }
      })
    },

    // 获取余额
    getBalance () {
      var params = {
      }
      this.loading = true
      API.balanceGet(params).then(res => {
        this.loading = false
        if (!res.error) {
          if (res.result) {
            this.balance = res.result.balance
          }
        }
      })
    },

    // 加载基本URL
    loadBaseUrl () {
      var payPath = `http://scjgoil.com`
      return payPath
    },

    // 创建时间添加 // 失效时间
    curentTimeAdd (day) {
      var now = new Date()
      now.setDate(now.getDate() + day)
      var year = now.getFullYear().toString() // 年
      return `${year}${new Date().getMonth() + 1 < 10 ? '0' + String(new Date().getMonth() + 1) : new Date().getMonth() + 1}${new Date().getDate() < 10 ? '0' + String(new Date().getDate()) : new Date().getDate()}${new Date().getHours() < 10 ? '0' + String(new Date().getHours()) : new Date().getHours()}${new Date().getMinutes() < 10 ? '0' + String(new Date().getMinutes()) : new Date().getMinutes()}${new Date().getSeconds() < 10 ? '0' + String(new Date().getSeconds()) : new Date().getSeconds()}`
    },

    // 判断金额
    isMoney (money) {
      // var reg = /^(\d*\.)?\d+$/
      var reg = /^(\d*)?(\.)?\d{2}?$/
      if (money === '' || money === null) {
        this.$vux.toast.show({
          type: 'warn',
          text: '请输入支付金额'
        })
        return false
      } else if (!reg.test(money)) {
        this.$vux.toast.show({
          type: 'warn',
          text: '请输入正确的金额格式'
        })
        return false
      }
      return true
    },

    // 支付窗口
    toform (form, obj) {
      form.setAttribute('id', 'J_centerPayForm')
      form.setAttribute('class', 'J_centerPayForm')
      form.appendChild(this.inputCt('action', obj.action))
      form.appendChild(this.inputCt('PAY_URL', obj.payUrl))
      form.appendChild(this.inputCt('MER_NO', obj.merNo))
      form.appendChild(this.inputCt('ORDER_AMOUNT', obj.orderAmount))
      form.appendChild(this.inputCt('ORDER_NO', obj.orderNo))
      form.appendChild(this.inputCt('BANK_CODE', obj.bankCode))
      form.appendChild(this.inputCt('RETURN_URL', obj.returnUrl))
      form.appendChild(this.inputCt('NOTIFY_URL', obj.notifyUrl))
      form.appendChild(this.inputCt('Remark1', obj.merRemark1))
      form.appendChild(this.inputCt('Remark2', obj.merRemark2))
      form.appendChild(this.inputCt('SN', obj.sn))
      form.appendChild(this.inputCt('PAYID', obj.toPayId))
      form.appendChild(this.inputCt('ORDER_TIME', obj.orderTime))
      form.appendChild(this.inputCt('Terminalid', obj.terminalid))
      form.appendChild(this.inputCt('REFERER', document.domain))
      form.appendChild(this.inputCt('PROVIDER_CODE', obj.providerCode))
      form.appendChild(this.inputCt('PAYTYPE', obj.paytype))

      form.setAttribute('method', 'post')
      form.setAttribute('action', obj.action)
      form.setAttribute('id', obj.orderNo)
      form.setAttribute('target', 'formresult')
      // if (obj.isOpenWin) { // 另开视窗
      //   form.setAttribute('method', 'post')
      //   form.setAttribute('action', obj.action)
      //   form.setAttribute('id', obj.orderNo)
      //   form.setAttribute('target', 'formresult')
      // }
    },

    // 创建表单控件
    inputCt (k, v) {
      var hiddenField = document.createElement('input')
      hiddenField.setAttribute('name', k)
      hiddenField.setAttribute('value', v)
      hiddenField.setAttribute('type', 'hidden')
      return hiddenField
    },

    // 显示帮助
    helpShow () {
      this.helpflag = true
    },

    // 点击tab触发
    btnClick (chargeMode) {
      this.chargeMode = chargeMode
      // 重新请求订单号
      this.chargeNoGet()
    },

    // 清空金额
    emptyMoney () {
      this.money = ''
    },

    click50 () {
      this.money = 50
    },

    click100 () {
      this.money = 100
    },

    click500 () {
      this.money = 500
    },

    click1000 () {
      this.money = 1000
    },

    click5000 () {
      this.money = 5000
    }
  }
}
</script>

<style scoped lang="stylus">
@import "~@/assets/baseStylus/variable"
@keyframes pulse
  0%
    transform: translateX(0)
    opacity 1.0
  100%
    transform: translateX(20px)
    opacity 0

.page-user_DepositIndex
  background: $color-white
  .help-warp
    width 95%
    margin 0 auto
    padding rem(40) rem(20)
    box-sizing border-box
    background $color-white
    color $color-blue
    text-align left
    h2
      line-height rem(60)
    p
      line-height rem(40)
    .weui-btn_default
      background $color-red
      color $color-white
  .success-help
    position absolute
    top 0
    right 10px
    z-index 999
    height $topBarHeight
    line-height $topBarHeight
    color $color-white
  .deposit-compte
    display: flex
    justify-content: space-between
    box-sizing: border-box
    width: 100%
    height: rem(80)
    padding: 0 rem(30)
    line-height: rem(80)
    background: $color-eee
    .compte-ctn
      width: 50%
      .float-r
        float: right
      .fontred
        color: $color-red
      .shuaxin
        position relative
        top rem(16)
      img
        width: rem(30)
        height: rem(26)
  .amount-ctn
    display: flex
    justify-content: space-between
    align-items: center
    box-sizing: border-box
    width: 100%
    height: rem(80)
    padding: rem(18) rem(28)
    line-height: rem(50)
    font-size: $size-medium
    .money
      padding: rem(2)
    .button
      .weui-btn
        line-height: rem(40)
        padding: rem(4)
        width: rem(100)
        border-right: 1px solid rgba(0, 0, 0, 0.2)
        font-size: $size-small
        border-radius 0
        border none
        background $color-ccc
      .weui-btn:after
        border-radius 0
      .weui-cells:before
        border-top 0
        content ''
      .weui-cells:after
        border-bottom 0
        content ''  
  .amount-shortcut
    .button
      button
        margin: 0 rem(10)
        line-height: rem(60)
        background: $color-white
  .deposit-way
    background: $color-eee
    padding: rem(30) rem(30)
    font-size: $size-small
  .vux-button-group > a.vux-button-tab-item-first:after, .vux-button-group > a.vux-button-tab-item-middle:after, .vux-button-group > a.vux-button-tab-item-last:after
    border-color #f5f5f5
  .vux-button-group > a
    color #111
  .vux-button-group > a:nth-child(4), .vux-button-group > a:nth-child(6)
    color $color-ccc
  .vux-button-group > a.vux-button-group-current
    background: $color-red
    color #fff
  .vux-button-group > a.vux-button-tab-item-first:after, .vux-button-group > a.vux-button-tab-item-middle:after, .vux-button-group > a.vux-button-tab-item-last:after, .vux-button-group > a.vux-button-group-current
    border-top-left-radius: 0
    border-bottom-left-radius: 0
    border-top-right-radius: 0
    border-bottom-right-radius: 0
  .deposit-mode
    setBottomLine($color-red)
    overflow: hidden
    margin: 0 rem(30)
    margin-bottom: rem(20)
    .vux-button-group
      a:nth-child(4), a:nth-child(6)
        background $color-gray-e
        border-radius 0
  .vux-button-group
    display: initial
  .vux-button-group > a
    float: left
    width: 33.33333%
    height: rem(80)
    line-height: rem(80)
  .nonsupport
    text-align: center
    line-height: rem(200)
  .deposit-wrap
    margin: 0 rem(30)
    setBottomLine($color-gray-b)
    a
      overflow: hidden
      display: block
      margin-top: rem(40)
      margin-bottom: rem(20)
      > i, > div
        float: left
      > div
        margin-left: rem(20)  
        h3
          font-size: $size-medium
          color: $color-gray
        p
          line-height: rem(60)
          font-size: $size-small-s
      .arrow-right
        position: absolute
        right: 0
        animation: pulse 1s linear 0s infinite
</style>

<style lang="stylus">
@import "~@/assets/baseStylus/variable"
.page-user_DepositIndex
  .help-warp
    .weui-btn_default
      margin-top rem(40)
      width 100%
      height rem(80)
      font-size rem(28)
      line-height rem(80)
      border-radius rem(4)
  .money, .button
    .weui-cells
      margin-top: 0
    .weui-cell
      padding: 0
    .weui-btn
      padding: initial
      line-height: initial
  .money
    setLine()
    .weui-cell
      width: rem(310)
    .weui-cells:before, .weui-cells:after
      border 0 
  .amount-shortcut
    padding: 0 rem(30)
    margin-bottom: rem(20)
    .button
      display: flex
      justify-content center
      span
        setLine()
        width 20%
        line-height rem(60)
        text-align center
        color #111
        margin-right rem(15)
      span:last-child
        margin-right 0  
</style>
