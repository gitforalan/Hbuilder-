<template>
  <div class="app-main page-user_paragraph">
    <x-header :title="title" :left-options="{ backText: '' }" class="is-fixed"></x-header>
    <div class="app-body">
      <section>
        <div class="step">
          <span :class="{ active: step === 1 }">1.选择存款账户</span>
          <icon-svg iconClass="right"></icon-svg>
          <span :class="{ active: step === 2 }">2.填写信息</span>
          <icon-svg iconClass="right"></icon-svg>
          <span :class="{ active: step === 3 }">3.核对信息</span>
        </div>

        <template v-if="step === 1">
          <div class="step1">
            <div class="receipt-card-list" v-for="(item, index) in accountListArr" :key="index">
              <div class="dagou" style="margin-right: 19px" @click="otherAecharge(index)">
                <icon-svg iconClass="dagou-copy" v-if="!iconNH[index]"></icon-svg>
                <icon-svg iconClass="dagou-copy-copy" v-else></icon-svg>
              </div>
              <div>
                <p><span>银行 : {{item.bankName}}</span></p>
                <p><span>收款人 : {{item.receiver}}</span></p>
                <p><span>卡号 : {{item.receiveAccount}}</span></p>
              </div>
            </div>
            <div class="btn-wrap">
              <x-button type="warn" @click.native="nextStep1">下一步</x-button>
            </div>
          </div>
        </template>

        <template v-if="step === 2">
          <div class="step2">
            <div class="form">
              <x-input title="姓名" placeholder="请输入存款人姓名" class="name-deposits" v-model="nameDeposits"></x-input>
              <popup-picker title="存款方式" :data="listDeposits" v-model="deposits" @on-change="onChangeDeposits"></popup-picker>
              <popup-picker title="银行" :data="listBanks" v-model="banks" @on-change="onChangeBanks"></popup-picker>
              <cell class="money" title="金额" :value="`${money}元`"></cell>
              <!-- <datetime title="存款时间" :max-year="maxYear" :min-year="minYear" v-model="dateTime"></datetime> -->
              <datetime title="存款时间" v-model="dateTime"></datetime>
            </div>
            <div class="btn-wrap">
              <x-button type="warn" @click.native="nextStep2">下一步</x-button>
            </div>
          </div>
        </template>

        <template v-if="step === 3">
          <div class="step3">
            <timeline>
              <timeline-item>
                <h4 class="recent">充值完成,您的充值申请已经提交成功</h4>
                <p class="recent">充值金额 <span class="color-red">{{money}}</span>元</p>
              </timeline-item>
              <timeline-item>
                <h4>充值到帐</h4>
                <p>充值成功后,您的余额将在5分钟内更新,请稍后查看,若届时仍未更新,请联系在线客服</p>
              </timeline-item>
            </timeline>

            <div class="btn-wrap">
              <x-button type="warn" @click.native="sucess">完成</x-button>
            </div>
          </div>
        </template>

      </section>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
import { PopupPicker, Datetime, Timeline, TimelineItem } from 'vux'
import * as API from 'api/wapi/user'

export default {
  data () {
    return {
      title: '存款',
      step: 1,
      amount: '',
      listDeposits: [['请选择存款方式', '网银转账', 'ATM自动柜员机', 'ATM现金入款', '银行柜台', '手机银行转账', '其他']],
      // 1.ATM自动柜员机;2.ATM现金入款;3.银行柜台;4.手机银行转账;5.支付宝转账;6.微信支付;7.财付通,8.网银转账;9.个人微信扫码;10.个人支付宝扫码;11.个人QQ扫码;12.个人京东钱包扫码;13.个人百度钱包扫码
      resDepositsList: [{
        name: '网银转账',
        value: 8
      }, {
        name: 'ATM自动柜员机',
        value: 1
      }, {
        name: 'ATM现金入款',
        value: 2
      }, {
        name: '银行柜台',
        value: 3
      }, {
        name: '手机银行转账',
        value: 4
      }, {
        name: '其他',
        value: -1
      }],
      listBanks: [['请选择银行']],
      resBankList: [],
      banks: ['请选择银行'],
      deposits: ['请选择存款方式'],
      accountListArr: [],
      aechargeIndex: null,
      iconNH: [false],
      money: null,
      nameDeposits: null,
      fromChannel: null,
      fromBankId: null,
      transferId: null,
      show: null,
      dateTime: null,
      minYear: 2017,
      maxYear: 2017
    }
  },
  components: {
    PopupPicker, Datetime, Timeline, TimelineItem
  },
  beforeCreate () {
    // 如果输入页面地址直接进来，直接返回，重定向到首页
    this.show = sessionStorage.getItem('show')
    if (+this.show !== 1 && !sessionStorage.getItem('chargeNo')) {
      this.$router.push({path: '/'})
      return
    }
    // 不存在订单号
    // if (!sessionStorage.getItem('chargeNo')) {
      // 重定向到我的账户
      // this.$router.push({path: '/user/index'})
    // }
  },
  destroyed () {
    // 离开页面，清除订单号，金额等信息
    this.money = null
    sessionStorage.removeItem('money')
    sessionStorage.removeItem('chargeNo')
    sessionStorage.removeItem('show')
  },
  mounted () {
    document.querySelector('.app-layout').style.background = '#fff'
    this.getAccountList()
  },
  methods: {

    // 获取订单号
    getChargeNo () {
      API.chargeNoGet({}).then(res => {
        if (!res.error) {
          if (res.result) {
            sessionStorage.setItem('chargeNo', res.result)
            // 重新请求user.charge.transfer.apply 接口
            this.nextStep2()
          }
        } else {
          this.$vux.toast.show({
            type: 'warn',
            text: res.error.message
          })
        }
      })
    },

    // 选择收款人
    otherAecharge (index) {
      for (var i = 0; i < this.iconNH.length; i++) {
        this.iconNH[i] = false
      }
      this.aechargeIndex = index
      this.$set(this.iconNH, index, true)
    },

    // 获取收款人列表
    getAccountList () {
      var params = {}
      API.accountList(params).then(res => {
        if (!res.error) {
          if (res.result && Object.keys(res.result).length > 0) {
            this.accountListArr = res.result
          }
        }
      })
    },

    // 下一步操作
    nextStep1 () {
      var AechargeFlag = false
      this.iconNH.map((item) => { AechargeFlag = item === true })
      // 使用后清空
      this.iconNH = []
      if (AechargeFlag) {
        // 显示第二个步骤
        this.step = 2
        this.money = sessionStorage.getItem('money')
        this.getBankList()
      } else {
        this.$vux.toast.show({
          type: 'warn',
          text: '请选择存款账户'
        })
      }
    },

    // 下一步操作
    nextStep2 () {
      if (!this.nameDeposits) {
        this.$vux.toast.show({
          type: 'warn',
          text: '请输入存款人姓名'
        })
      } else if (!this.fromChannel) {
        this.$vux.toast.show({
          type: 'warn',
          text: '请选择存款方式'
        })
      } else if (!this.fromBankId) {
        this.$vux.toast.show({
          type: 'warn',
          text: '请选择银行'
        })
      } else if (!this.dateTime) {
        this.$vux.toast.show({
          type: 'warn',
          text: '请选择存款时间'
        })
      }
      var params = {}
      params.chargeNo = sessionStorage.getItem('chargeNo')
      params.fromBankId = this.fromBankId
      params.toAccountId = this.accountListArr[this.aechargeIndex].toAccountId
      params.amount = this.money
      params.transferTime = this.dateTime
      params.fromAccountOwner = this.nameDeposits
      params.chargeFrom = 8 // 来源. 1, pc-web(默认);2,pc-client;3,android-app;4,ios-app;5,android-pad;6,ios-pad; 7,系统保留; 8, h5;
      params.fromChannel = this.fromChannel

      API.transferApply(params).then(res => {
        if (!res.error) {
          if (res.result) {
            this.transferId = res.result
            this.step = 3
          }
        } else {
          // 存款申请单流水号已使用, 重新获取
          if (res.error.message === '存款申请单流水号已使用') {
            this.getChargeNo()
          }
        }
      })
    },

    // 获取银行列表
    getBankList () {
      API.bankList({}).then(res => {
        if (!res.error) {
          if (res.result) {
            this.resBankList = res.result
            res.result.forEach(item => {
              this.listBanks[0].push(item.bankName)
            })
          }
        }
      })
    },

    // 选择存款方式
    onChangeDeposits (value) {
      var item = {}
      if (value && value.length > 0 && value[0] !== '请选择存款方式') {
        item = this.resDepositsList[this.resDepositsList.findIndex(item => item.name === value[0])]
      }
      this.fromChannel = item.value
    },

    // 选择银行
    onChangeBanks (value) {
      var item = {}
      if (value && value.length > 0 && value[0] !== '请选择银行') {
        item = this.resBankList[this.resBankList.findIndex(item => item.bankName === value[0])]
      }
      this.fromBankId = item.bankId
    },

    // 完成
    sucess () {
      // 跳转到我的页面
      this.$router.push({path: '/user/index'})
    }
  }
}
</script>

<style scoped lang="stylus">
@import "~@/assets/baseStylus/variable"
.page-user_paragraph
  font-size: $size-medium
  .step
    background: $color-eee
    display: flex
    align-items: center
    margin-left: rem(20)
    margin-top: rem(20)
    padding: rem(10) 0
    .active
      color: $color-red
  .step1    
    .receipt-card-list
      display: flex
      align-items: center
      padding: rem(50) 0
      margin-left: rem(20)
      div
        margin-left: rem(10)
      p
        line-height: rem(40)
    .btn-wrap
      margin: 0 rem(20)
      .weui-btn_warn
        border-radius rem(4)
        background-color $color-red
  .step2
    margin-top: rem(20)
    .form
      padding-left: rem(20)
      setTopLine()
      setBottomLine()
    .name-deposits
      padding: rem(20) 0
      padding-left: rem(30)
    .btn-wrap
      margin: rem(40) rem(20) 0 rem(20)
      .weui-btn_warn
        border-radius rem(4)
        background-color $color-red
  .step3
    line-height rem(30)
    h4
      line-height rem(60)
      font-size rem(34)
    p
      line-height rem(40)  
    .color-red
      color: $color-red
    .vux-timeline
      padding: rem(80) rem(60)
    .btn-wrap
      margin: 0 rem(20)
      .weui-btn_warn
        border-radius rem(4)
        background-color $color-red
  .weui-btn_warn
    background-color: $color-red
  
</style>

<style lang="stylus">
@import "~@/assets/baseStylus/variable"

.page-user_paragraph
  .vux-cell-value
    color #111
  .step2
    .vux-no-group-title, .weui-cells
      margin-top: 0
    .weui-cell
      padding-top rem(30)
  .step3    
    .vux-timeline-item-content
      padding-left rem(40)
  .form
    .name-deposits
      margin-right rem(40)
      .weui-input
        text-align right
    .money
      .weui-cell__ft
        color #111       
</style>