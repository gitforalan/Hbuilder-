<template>
  <div class="app-layout">
    <div class="app-main page-user page-user_sign">
      <x-header :left-options="{backText: ''}" :title="title" class="is-fixed"></x-header>
      <div class="app-body" ref="appBody">
        <div v-if="isNull">
          <ul class="sign-content">
            <li v-for="(item, index) in signList" :key="index" v-if="item.isShow == 1">
              <p>
                <span>{{item.time}}</span>
                <span v-if="item.seize == 2">每日签到</span>
                <span v-else-if="item.seize == 1">签到赠送<span class="font-red">1元夺宝</span></span>
              </p>
              <p>
                <span>赠送金额<span v-if="item.issueflag == 1" class="font-red">{{item.money}}</span>
                  <span v-else-if="item.issueflag == 2 || item.issueflag == 0" class="font-red"> - </span>元
                </span>
                <span>
                  <x-button v-if="item.isSign == 1" plain mini class="sign-btn-end">已签到</x-button>
                  <x-button v-else-if="item.isSign == 2" plain mini class="sign-btn-end">已逾期</x-button>
                  <x-button v-else plain mini class="sign-btn" @click.native="sign(item.money, item.seize, index, item.issueflag)">签到</x-button>
                </span>
              </p>
            </li>
          </ul> 
          <div v-if="showMore" class="getMore" @click="getMore()">更多>></div>
        </div>
        <div class="isNull" v-else>
          目前无每日签到~~
        </div>
      </div>
      <div v-transfer-dom class="sign-dialog">
        <x-dialog v-model="showSign" class="dialog-demo" hide-on-blur>
          <span class="vux-close" @click="showSign=false"></span>
          <div class="img-box">
            <div class="sign-img">
              <span v-if="getSignMoney !== 0">获得{{getSignMoney}}元彩金</span>
            </div>
            <div class="sign-receive">
              <img src="../../../assets/image/sign.png" style="max-width:100%">
            </div>
          </div>
        </x-dialog>
      </div>
    </div>
  </div>
</template> 
<script type="text/ecmascript-6">
import * as API from 'api/wapi/user'
import { XDialog, TransferDomDirective as TransferDom, cookie } from 'vux'
import comFun from '../agent/comFunction'
export default {
  data () {
    return {
      title: '签到',
      showSign: false,
      showMore: false,
      isNull: true,
      signList: [],
      month: 0,
      signContent: {},
      getSignMoney: '',
      userRegTime: ''
    }
  },
  directives: {
    TransferDom
  },
  components: {
    XDialog
  },
  mounted () {
    this.getSignContent()
  },
  methods: {
    // 获取签到内容
    getSignContent () {
      var params = {
        userId: cookie.get('userId')
      }
      API.getSignContent(params).then(res => {
        if (!res.error && res.result) {
          this.signContent = res.result
          if (this.signContent === null || this.signContent === '' || this.signContent === undefined) {
            this.isNull = false
            return false
          } else {
            this.isNull = true
            this.getData(new Date(new Date(comFun.getUTCTime2US()).getTime()).getDate(), new Date(new Date(comFun.getUTCTime2US()).getTime()).getMonth() + 1)
          }
        } else {
          this.isNull = false
        }
      })
    },
    // 用户信息
    getUserProfile () {
      return new Promise((resolve, reject) => {
        var params = {}
        API.getUserProfile(params).then(res => {
          if (!res.error && res.result) {
            resolve(res.result.regTime)
          }
        })
      })
    },
    // 获取签到列表
    getSignData (day, month) {
      var year = new Date(new Date(comFun.getUTCTime2US()).getTime()).getFullYear()
      this.month = month
      var createM = ''
      var createD = ''
      this.userRegTime = this.userRegTime.replace(/-/g, '/')
      this.signContent.createTime = this.signContent.createTime.replace(/-/g, '/')
      if (new Date(this.userRegTime).getTime() < new Date(this.signContent.createTime).getTime()) {
        createM = this.signContent.createTime.substring(5, 7)
        createD = this.signContent.createTime.substring(8, 10)
      } else {
        createM = this.userRegTime.substring(5, 7)
        createD = this.userRegTime.substring(8, 10)
      }
      if (this.signContent !== '' && this.signContent !== null) {
        for (var i = day; i > 0; i--) {
          var newData = {}
          if (+createM !== +this.month) {
            newData = {
              time: year + '-' + (this.month < 10 ? '0' + this.month : this.month) + '-' + (i < 10 ? '0' + i : i),
              money: 0,
              seize: this.signContent.seize,
              isSign: 2,
              issueflag: 0,
              isShow: 0
            }
          } else {
            if (i >= +createD) {
              newData = {
                time: year + '-' + (this.month < 10 ? '0' + this.month : this.month) + '-' + (i < 10 ? '0' + i : i),
                money: 0,
                seize: this.signContent.seize,
                isSign: 2,
                issueflag: 0,
                isShow: 1
              }
            } else {
              newData = {
                time: year + '-' + (this.month < 10 ? '0' + this.month : this.month) + '-' + (i < 10 ? '0' + i : i),
                money: 0,
                seize: this.signContent.seize,
                isSign: 2,
                issueflag: 0,
                isShow: 0
              }
            }
          }
          this.signList.push(newData)
          this.showMore = true
          // if (+this.month === +createM && +createD === i) {
          //   this.showMore = false
          //   break
          // }
        }
      }
      var params = {}
      API.getSign(params).then(res => {
        var result = res.result === null ? [] : res.result.items
        if (!res.error && res.result) {
          for (var m = 0; m < this.signList.length; m++) {
            if (this.signList[m].time === comFun.dateFormat(new Date(new Date(comFun.getUTCTime2US()).getTime()), 'yyyy-MM-dd')) {
              this.signList[m].isSign = 0
              this.signList[m].money = this.signContent.amount
              this.signList[m].issueflag = 1
              this.signList[m].isShow = 1
            }
          }
          for (var y = 0; y < result.length; y++) {
            for (var z = 0; z < this.signList.length; z++) {
              if (result[y].signdate === this.signList[z].time) {
                this.signList[z].isSign = 1
                this.signList[z].seize = result[y].extraflag
                this.signList[z].money = result[y].couponamount
                this.signList[z].issueflag = result[y].issueflag
                this.signList[z].isShow = 1
              }
            }
          }
        } else {
          for (var x = 0; x < this.signList.length; x++) {
            if (this.signList[x].time === comFun.dateFormat(new Date(new Date(comFun.getUTCTime2US()).getTime()), 'yyyy-MM-dd')) {
              this.signList[x].isSign = 0
              this.signList[x].money = this.signContent.amount
              this.signList[x].issueflag = 1
              this.signList[x].isShow = 1
            }
          }
        }
      })
      // 只保留一个月
      if (new Date(new Date(comFun.getUTCTime2US()).getTime()).getMonth() + 1 - month === 1) {
        this.showMore = false
      }
    },
    // 异步判断
    getData (day, month) {
      (async () => {
        this.userRegTime = await this.getUserProfile()
        this.getSignData(day, month)
      })()
    },
    // 点击签到
    sign (money, seize, index, type) {
      var params = {
        amount: money,
        seize: seize,
        issueflag: type
      }
      API.doCheckIn(params).then(res => {
        if (!res.error && res.result) {
          var result = res.result
          if (+result === 1) {
            this.showSign = true
            if (type === 1) {
              this.getSignMoney = money
            } else {
              this.getSignMoney = 0
            }
            this.signList[index].isSign = 1
          } else {
            this.$vux.toast.show({
              type: 'warn',
              width: '10em',
              text: '签到失败，请重试',
              position: 'middle'
            })
          }
        }
      })
    },
    mGetDate (year, month) {
      var d = new Date(year, month, 0)
      return d.getDate()
    },
    getMore () {
      var month = this.month - 1
      var day = this.mGetDate(new Date(new Date(comFun.getUTCTime2US()).getTime()).getFullYear(), month)
      if (new Date(new Date(comFun.getUTCTime2US()).getTime()).getMonth() + 1 - month === 1) {
        this.getSignData(day, month)
      } else {
        this.showMore = false
      }
    }
  }
}
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  @import '~vux/src/styles/close.less'
  .page-user_sign
    .app-body
      color #000
      font-weight bold
      font-size rem(30)
    .sign-content li
      margin 0rem 0.5rem
      border-bottom 1px solid #EAEAEA
    .sign-content li p
      line-height 2rem
    .sign-content li p:first-child
      padding rem(30) 0rem 0rem 1rem
    .sign-content li p:last-child
      padding 0rem 0rem rem(20) 1rem
    .sign-content li p>span
      display inline-block
    .sign-content li p span:last-child
      width 44%
    .sign-content li p:first-child>span:first-child
      color #636363
    .sign-content li p>span:last-child
      float right
      text-align center
    .sign-content li p span div
      width rem(118)
      text-align center
      border-radius rem(5)
      font-size rem(28)
      line-height 1.6rem
      display inline-block
    .sign-content .sign-btn
      border 1px solid $color-red
      color $color-red
      line-height rem(50)
      padding 0
      width rem(126)
    .sign-content .sign-btn-end
      border 1px solid #a2a2a2
      color #a2a2a2
      line-height rem(50)
      padding 0
      width rem(126)
    .isNull
      font-size rem(42)
      text-align center
      margin 100px 10px
  .sign-dialog
    .weui-dialog
      background-color transparent
    .vux-close
      position absolute
      right 0
      width rem(27)
    .vux-close:before, .vux-close:after
      width rem(27)
      height rem(4)
      color white
    .sign-img
      position absolute
      top 65%
      width 95%
      span
        font-size rem(30)
        color white
</style>

