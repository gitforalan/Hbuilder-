<template>
  <!-- 会员 -->
  <div class="app-main page-user page-user_account" v-if="accountPage === 'user'">
    <x-header :title="title" :left-options="{ backText: '' }" class="is-fixed"></x-header>

    <flexbox class="selectWrap">
      <flexbox-item>
        <span class="selectItem"><selector v-model="ltypens" :options="ltypeUserList" @on-change="onChange"></selector><icon-svg iconClass="bg-down" class="up"></icon-svg></span>
      </flexbox-item>

      <flexbox-item>
        <dateRange ref="dateRange1" :options="{defaultDate: '最近七天'}"></dateRange>
      </flexbox-item>

      <flexbox-item>
        <x-button type="warn" stylereset @click.native="searchUserAccountEvent" :show-loading="queryLoading"><template v-if="!queryLoading">查询</template></x-button>
      </flexbox-item>
    </flexbox>

    <div class="account-content" v-if="accountContent.items && accountContent.items.length >= 1">
      <ul>
        <li v-for="(item, index) in accountContent.items" :key="index">
          <p>
            <span>{{item.type}}</span>
            <span>{{item.lotteryName}}</span>
          </p>
          <p>
            <span>单号：{{item.bizId}}</span>
            <span>
              <b class="color-red" v-if="item.expend">-{{item.expend}}元</b>
              <span v-if="item.expend && item.income">，</span>
              <b class="color-red" v-if="item.income">+{{item.income}}元</b>
            </span>
          </p>
          <p>
            <span class="color-gray-a">{{item.dateTime}}</span>
            <span>余额：{{item.balance}}</span>
          </p>
        </li>
      </ul>
    </div>
    <div v-else class="txt-bottom">
      <p>暂无数据</p>
    </div>
    <div class="getMore" v-if="accountContent.items.length >= 5" @click="querySearch('user')"><span v-html="queryDataPage.text"></span></div>


  </div>
  <!-- 会员 -->

  <!-- 代理 -->
  <div class="app-main page-user page-user_account page-user_account_agent" v-else>
    <x-header :title="title" :left-options="{ backText: '' }" class="is-fixed"></x-header>

    <flexbox class="selectWrap">
      <flexbox-item>
        <span class="selectItem"><selector v-model="ltypens" :options="ltypeAgentList" @on-change="onChange"></selector><icon-svg iconClass="bg-down" class="up"></icon-svg></span>
      </flexbox-item>

      <flexbox-item>
        <dateRange ref="dateRange2" :options="{defaultDate: '最近七天'}"></dateRange>
      </flexbox-item>

    </flexbox>

    <flexbox class="selectWrap selectWrap_agent">
      <flexbox-item>
        <span>用户名：</span>
        <x-input placeholder="请输入用户名" v-model="userLoginId"></x-input>
      </flexbox-item>

      <flexbox-item>
        <x-button type="warn" @click.native="agentSearchAccountEvent" :show-loading="queryLoading"><template v-if="!queryLoading">查询</template></x-button>
      </flexbox-item>

    </flexbox>

    <div class="account-content" v-if="accountAgent.items && accountAgent.items.length >= 1">
      <ul>
        <li v-for="(item, index) in accountAgent.items" :key="index">
          <p>
            <span>用户：<b class="color-red">{{item.loginId}}</b></span>
            <span>所属组：{{item.regType === 'a' ? '代理' : '会员'}}</span>
          </p>
          <p>
            <span>{{item.type}}</span>
            <span>{{item.lotteryName}}</span>
          </p>
          <p>
            <span>单号：{{item.bizId}}</span>
            <span>
              <b class="color-red" v-if="item.expend">-{{item.expend}}元</b> 
              <span v-if="item.expend && item.income">，</span>
              <b class="color-red" v-if="item.income">+{{item.income}}元</b>
            </span>
          </p>
          <p>
            <span class="color-gray-a">{{item.dateTime}}</span>
            <span>余额：{{item.balance}}</span>
          </p>
        </li>

      </ul>
    </div>
    <div v-else class="txt-bottom">
      <p>暂无数据</p>
    </div>
    <div class="getMore"  v-if="accountAgent.items.length >= 5" @click="querySearch('agnet')"><span v-html="queryDataPage.text"></span></div>

  </div>
  <!-- 代理 -->
</template>

<script type="text/ecmascript-6">

import { Selector, Flexbox, FlexboxItem, cookie, stringTrim } from 'vux'
import dateRange from '../components/range-select'
import * as API from 'api/wapi/user'

export default {
  data () {
    return {
      title: '帐户明细',
      accountPage: 'user',
      ltypens: null,
      queryLoading: false,
      ltypeUserList: [{
        key: null,
        value: '全部'
      }, {
        key: 10101,
        value: '公司入款'
      }, {
        key: 10201,
        value: '第三方支付'
      }, {
        key: 10301,
        value: '人工存款'
      }, {
        key: 10400,
        value: '优惠金额'
      }, {
        key: 20,
        value: '彩票结算'
      }, {
        key: 60,
        value: '投注返点'
      }, {
        key: 10702,
        value: '转账转入'
      }, {
        key: 21,
        value: '1元夺奖结算'
      }, {
        key: 30,
        value: '彩票撤单'
      }, {
        key: 20401,
        value: '出款扣除'
      }, {
        key: 20101,
        value: '用户提款'
      }, {
        key: 20301,
        value: '人工提出'
      }, {
        key: 10,
        value: '彩票下注'
      }, {
        key: 11,
        value: '1元夺奖下注'
      }, {
        key: 20702,
        value: '转账转出'
      }],
      ltypeAgentList: [{
        key: null,
        value: '全部'
      }, {
        key: 10101,
        value: '公司入款'
      }, {
        key: 10201,
        value: '第三方支付'
      }, {
        key: 10301,
        value: '人工存款'
      }, {
        key: 10400,
        value: '优惠金额'
      }, {
        key: 20,
        value: '彩票结算'
      }, {
        key: 60,
        value: '投注返点'
      }, {
        key: 10702,
        value: '转账转入'
      }, {
        key: 21,
        value: '1元夺奖结算'
      }, {
        key: 30,
        value: '彩票撤单'
      }, {
        key: 20401,
        value: '出款扣除'
      }, {
        key: 20101,
        value: '用户提款'
      }, {
        key: 20301,
        value: '人工提出'
      }, {
        key: 10,
        value: '彩票下注'
      }, {
        key: 11,
        value: '1元夺奖下注'
      }, {
        key: 20702,
        value: '转账转出'
      }, {
        key: 10412,
        value: '代理分红'
      }, {
        key: 10413,
        value: '代理日工资'
      }, {
        key: 10414,
        value: '代理扶持'
      }, {
        key: 70,
        value: '代理返点'
      }],
      accountContent: {
        items: {}
      },
      accountAgent: {
        items: {}
      },
      accountItem: '',
      pageAgentIndex: 1,
      pageUserIndex: 1,
      queryDataPage: {
        text: '更多&gt;&gt;',
        noMore: false
      },
      more: false,
      userLoginId: '', // 用户输入
      agentId: ''
    }
  },
  components: { dateRange, Selector, Flexbox, FlexboxItem },
  created () {
    // 先拿 sessionStorage，后拿cookie
    var obj = JSON.parse(sessionStorage.getItem('loginType')) // 前面页面传递的数据，字段名为`loginType`
    var loginType = obj && (obj['regType'] === 'n' ? 'user' : 'agent')
    this.accountPage = loginType || cookie.get('loginType')
    if (`${this.accountPage}` === 'user') { // 会员
      this.agentId = cookie.get('userId')
      this.userLoginId = this.$route.query.id
    } else { // 代理
      this.agentId = cookie.get('userId')
      this.userLoginId = obj && obj['loginId']
    }
  },
  destroyed () {
    // 离开页面之后销毁 loginType
    sessionStorage.removeItem('loginType')
  },
  mounted () {
    if (`${this.accountPage}` === 'user') { // 会员
      this.searchUserAccount()
    } else {
      this.agentSearchAccount()
    }
  },
  methods: {

    // 下一页
    querySearch (ua) {
      if (this.queryDataPage.noMore) {
        return
      }
      if (ua === 'agnet') {
        this.pageAgentIndex++
        if (this.accountAgent.pageIndex >= this.accountAgent.total && this.accountAgent.total !== 0) {
          this.queryDataPage.text = '没有更多了'
          this.queryDataPage.noMore = true
          this.more = false
        }
        this.more = true
        this.agentSearchAccount()
      } else {
        this.pageUserIndex++
        if (this.accountContent.pageIndex >= this.accountContent.total && this.accountContent.total !== 0) {
          this.queryDataPage.text = '没有更多了'
          this.queryDataPage.noMore = true
          this.more = false
        }
        this.more = true
        this.searchUserAccount()
      }
    },

    onChange (val) {
      this.accountItem = val
    },

    searchUserAccountEvent () {
      this.accountContent = {
        items: []
      }
      this.pageAgentIndex = 1
      this.searchUserAccount()
    },

    // 会员查询列表
    searchUserAccount () {
      var params = {
        pageIndex: this.pageUserIndex
      }
      params.startTime = `${this.$refs.dateRange1.dateRange[0]} 00:00:00`
      params.endTime = `${this.$refs.dateRange1.dateRange[1]} 23:59:59`
      params.agentId = this.agentId
      params.userLoginId = this.userLoginId
      if (this.accountItem) {
        params.accountItem = this.accountItem
      }
      this.queryLoading = true
      API.userDetailList(params).then(res => {
        this.queryLoading = false
        if (!res.error) {
          if (res.result && Object.keys(res.result).length > 0) {
            if (this.more) {
              this.accountContent.items = this.accountContent.items.concat(res.result.items)
              this.accountContent.pageIndex = res.result.pageIndex
              this.accountContent.total = res.result.total
            } else {
              this.accountContent = res.result // 代理
            }
          } else {
            this.accountContent = {
              items: []
            }
          }
        }
      })
    },

    agentSearchAccountEvent () {
      this.accountAgent = {
        items: []
      }
      this.pageAgentIndex = 1
      this.agentSearchAccount()
    },

    // 代理查询列表
    agentSearchAccount () {
      var params = {
        pageIndex: this.pageAgentIndex
      }
      params.startTime = `${this.$refs.dateRange2.dateRange[0]} 00:00:00`
      params.endTime = `${this.$refs.dateRange2.dateRange[1]} 23:59:59`
      if (this.accountItem) {
        params.accountItem = this.accountItem
      }
      params.agentId = this.agentId
      params.userLoginId = this.userLoginId && `${stringTrim(this.userLoginId)}`
      this.queryLoading = true
      API.agentDetailList(params).then(res => {
        this.queryLoading = false
        if (!res.error) {
          if (res.result && Object.keys(res.result).length > 0) {
            if (this.more) {
              this.accountAgent.items = this.accountAgent.items.concat(res.result.items)
              this.accountAgent.pageIndex = res.result.pageIndex
              this.accountAgent.total = res.result.total
            } else {
              this.accountAgent = res.result // 代理
            }
          } else {
            this.accountAgent = {
              items: []
            }
          }
        }
      })
    }
  }
}
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"

.page-user_account
  .getMore {
    text-align: center;
    padding: rem(50);
    color: $color-red;
  }
  .selectWrap 
    width auto
    margin-top rem(88)
    background $color-white
    padding rem(30) rem(28) rem(30) rem(28)
    .vux-flexbox-item
      display table
    .weui-cell:before
      display none
    .vux-selector
      display inline-flex
      width rem(240)
      border solid 1px #ccc
      border-radius rem(4)
    .vux-x-input
      padding 0
      vertical-align middle
    .vux-x-input .weui-label
      width rem(100) !important
      margin-left rem(40)
    .vux-x-input:last-child .weui-label
      width rem(40) !important
      margin-left rem(10)
    .weui-input
      width rem(100)
    .weui-select
      height rem(60)
      line-height rem(60)
      padding 0 rem(24)
    .weui-cell_select .weui-cell__bd:after
      display none
  .selectItem
    position relative    
    .lott-icon
      position absolute
      right 0
  .weui-btn_loading.weui-btn_warn, .weui-btn_warn
    background #f55
  .weui-btn:after
    border-color #f55
    border-radius rem(4)
  .weui-btn
    width 5.285714285714286rem
    height 2.142857142857143rem
    border-radius rem(4)
    font-size 0.857142857142857rem
    margin-left rem(11)

  .account-content
    margin-top rem(34)
    setBottomLine()
    .color-gray-a
      color: $color-gray-3
    li
      setTopLine()
      padding-top rem(20)   
      padding-left rem(20)
      padding-bottom rem(12)
      line-height rem(48)
      p
        overflow hidden
      p span:first-child
        float left
      p span:last-child
        float right
        margin-right rem(90)
    .color-red
      color $color-red
  .txt-bottom
    text-align center
    padding-top rem(40)
    setTopLine()

.page-user_account_agent
  .selectWrap 
    .vux-selector
      width rem(332)
  .vux-flexbox-item .vux-x-input:last-child .weui-label
    width rem(120) !important
  .vux-flexbox-item .vux-x-input:last-child .weui-cell__primary
    width rem(170)
    .weui-input
      width rem(170)
  .selectWrap_agent
    margin-top 0
    padding 0 rem(28) rem(30) rem(28)
    .vux-flexbox-item
      display flex
      line-height rem(48)
      .weui-cells
        margin-top 0
  .selectWrap .vux-flexbox-item:first-child .vux-x-input
    border 1px solid #C7C7C7
    padding 0 rem(6)
    // setLine()
    .weui-cell__ft
      position absolute
      right 0
</style>
