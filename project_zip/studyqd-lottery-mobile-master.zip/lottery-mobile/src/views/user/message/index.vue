<template>
  <div class="app-main page-user page-user_MessageIndex">
    <x-header class="is-fixed"
    :left-options="{ backText: '', preventGoBack: true }"
    @on-click-back="$router.push({ path: '/user/index' })">
      <button-tab v-model="tabActive" stylereset>
        <button-tab-item @on-item-click="btnClick()"><icon-svg iconClass="duihao" v-if="showNotice"></icon-svg>公告</button-tab-item>
        <button-tab-item @on-item-click="btnClick()"><icon-svg iconClass="duihao" v-if="showPrivate"></icon-svg>私信</button-tab-item>
      </button-tab>
    </x-header>
    <div class="app-body" style="padding-bottom:0">
      <div id="notice" v-show="showNotice">
         <group v-for="(row, index) in systemNoticeList" :key="row.noticeFrom">
          <cell
          :title="getTitle(row)"
          is-link
          class="vux-1px-b"
          :border-intent="false"
          :arrow-direction="row.expand ? 'up' : 'down'"
          @click.native="expand(index)">
            <div slot="value">
              <time>{{format(row.createTime)}}</time>
            </div>
          </cell>
          <div class="slide" :class="row.expand ?'animate':''">
            <div>{{JSON.parse(row.content).contentZh}}</div>
          </div>
          </group>
          <div class="getMore" v-if="systemNoticeData.total != 0" @click="getSystemNotice('plus')"><span v-html="systemNoticePage.text"></span></div>
          <div class="noData" v-if="systemNoticeList.length <= 0"></div>
      </div>
      <div id="private" v-show="showPrivate">
        <group v-for="(row, index) in personalNoticeList" :key="row.noticeFrom">
          <cell
          :title="getTitle(row)"
          is-link
          class="vux-1px-b"
          :border-intent="false"
          :arrow-direction="row.expand ? 'up' : 'down'"
          @click.native="expandPrive(index)">
            <div slot="value">
              <time>{{format(row.createTime)}}</time>
            </div>
          </cell>
          <div class="slide" :class="row.expand ?'animate':''">
            <div>{{JSON.parse(row.content).contentZh}}</div>
          </div>
          </group>
          <div class="getMore" v-if="personalNoticeData.total != 0" @click="getPersonalNotice('plus')"><span v-html="personalNoticePage.text"></span></div>
          <div class="noData person" v-if="personalNoticeList.length <= 0"></div>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { ButtonTab, ButtonTabItem } from 'vux'
  import * as API from 'api/wapi/user'
  import comFun from '../agent/comFunction'
  export default {
    data () {
      return {
        tabActive: 0,
        showNotice: true,
        showPrivate: false,
        systemNoticeData: {
          pageIndex: 1,
          pageSize: 10,
          total: 0
        },
        systemNoticePage: {
          text: '更多&gt;&gt;',
          noMore: false
        },
        personalNoticePage: {
          text: '更多&gt;&gt;',
          noMore: false
        },
        personalNoticeData: {
          pageIndex: 1,
          pageSize: 10,
          total: 0
        },
        systemNoticeLoading: false,
        personalNoticeLoading: false,
        systemNoticeList: [],
        personalNoticeList: []
      }
    },
    components: {
      ButtonTab,
      ButtonTabItem
    },
    mounted () {
      this.getSystemNotice()
    },
    watch: {
    },
    methods: {
      format (date) {
        return comFun.dateFormat(new Date(date), 'yyyy-MM-dd')
      },
      getTitle (row) {
        let r = JSON.parse(row.content).contentZh
        return r.substr(0, 9) + '...'
      },
      expand (index) {
        this.systemNoticeList[index].expand = !this.systemNoticeList[index].expand
      },
      expandPrive (index) {
        this.personalNoticeList[index].expand = !this.personalNoticeList[index].expand
      },
      getSystemNotice (p) {
        // 网站公告
        if (p === 'plus') {
          this.systemNoticeData.pageIndex += 1
          // 没有更多的处理
          if (this.systemNoticePage.noMore) {
            return false
          }
        }
        this.systemNoticeLoading = true
        var params = {
        }
        Object.assign(this.systemNoticeData, params)
        API.GetSystemNotice(this.systemNoticeData).then(res => {
          this.systemNoticeLoading = false
          comFun.listBack(res, 'result', 'result.items', () => {
            var data = res.result.items.map(items => {
              items.expand = false
              return items
            })
            this.systemNoticeData.total = Math.ceil(res.result.total / this.systemNoticeData.pageSize)
            if (p === 'plus') {
              this.systemNoticeList = this.systemNoticeList.concat(data)
            } else {
              this.systemNoticeList = data
            }
            // 没有更多的处理
            if (this.systemNoticeData.pageIndex >= this.systemNoticeData.total && this.systemNoticeData.total !== 0) {
              this.systemNoticePage.text = '没有更多了'
              this.systemNoticePage.noMore = true
            }
          }, () => {
            this.$vux.toast.show({
              type: 'warn',
              text: res.error.message
            })
          }, () => {
            if (p !== 'plus') {
              this.systemNoticeList = []
              this.systemNoticeData.total = 0
              this.systemNoticeData.pageIndex = 0
            }
          })
        })
      },
      getPersonalNotice (p) {
        // 私信
        if (p === 'plus') {
          this.personalNoticeData.pageIndex += 1
          // 没有更多的处理
          if (this.personalNoticeData.noMore) {
            return false
          }
        }
        if (this.personalNoticeData.pageIndex > this.personalNoticeData.total && this.personalNoticeData.total !== 0) {
          this.personalNoticePage.text = '没有更多了'
          return false
        }
        this.personalNoticeLoading = true
        var params = {
        }
        Object.assign(this.personalNoticeData, params)
        API.GetPersonalNotice(this.personalNoticeData).then(res => {
          this.systemNoticeLoading = false
          comFun.listBack(res, 'result', 'result.items', () => {
            var data = res.result.items.map(items => {
              items.expand = false
              return items
            })
            this.personalNoticeData.total = Math.ceil(res.result.total / this.personalNoticeData.pageSize)
            if (p === 'plus') {
              this.personalNoticeList = this.personalNoticeList.concat(data)
            } else {
              this.personalNoticeList = data
            }
            // 没有更多的处理
            if (this.personalNoticeData.pageIndex >= this.personalNoticeData.total && this.personalNoticeData.total !== 0) {
              this.personalNoticePage.text = '没有更多了'
              this.personalNoticePage.noMore = true
            }
          }, () => {
            this.$vux.toast.show({
              type: 'warn',
              text: res.error.message
            })
          }, () => {
            if (p !== 'plus') {
              this.personalNoticeList = []
              this.personalNoticeData.total = 0
              this.personalNoticeData.pageIndex = 0
            }
          })
        })
      },
      itemClick (index) {
      },
      btnClick () {
        if (this.tabActive === 0) {
          this.showNotice = true
          this.showPrivate = false
        } else if (this.tabActive === 1) {
          this.showNotice = false
          this.showPrivate = true
          if (this.personalNoticeList.length <= 0) {
            this.getPersonalNotice()
          }
        }
      }
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user_MessageIndex
    .noData {
      width rem(194)
      height rem(161)
      background url(../../../assets/image/no-information.png) no-repeat scroll center center
      background-size contain
      margin rem(100) auto 0 auto
      &.person {
        background url(../../../assets/image/no-announcement.png) no-repeat scroll center center
        background-size contain
      }
    }
    .weui-cells
     margin 0
    .slide {
      overflow: hidden;
      max-height: 0;
      transition: max-height .5s cubic-bezier(0, 1, 0, 1) -.1s;
    }
    .animate {
      max-height: 9999px;
      transition-timing-function: cubic-bezier(0.5, 0, 1, 0);
      transition-delay: 0s;
    }
    line-height 1.5
    .getMore
        text-align:center;
        color:$color-red;
        padding rem(24) 0 rem(24) 0;
    .weui-cell 
      background $color-eee
      padding rem(16) rem(24) rem(16) rem(34)
      .vux-label, time
        font-size rem(24)
      time
       display inline-block
       margin-right rem(20)
       color #696969
      .weui-cell__ft:after
        border-color #696969
    .slide > div
      padding rem(20) rem(34) rem(20) rem(34)
      background $color-white
      font-size rem(22)
</style>
