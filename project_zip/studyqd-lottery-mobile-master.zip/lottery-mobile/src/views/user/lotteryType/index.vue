<template>
  <div class="app-main page-user page-user_lotteryType">
    <x-header class="is-fixed"
      :left-options="{ backText: '', preventGoBack: true }"
      @on-click-back="$router.push({ path: '/user/index' })">
      <button-tab v-model="tabActive" stylereset>
        <button-tab-item @on-item-click="btnClick()"><icon-svg iconClass="duihao"></icon-svg>赔率返点</button-tab-item>
        <button-tab-item @on-item-click="btnClick()"><icon-svg iconClass="duihao"></icon-svg>投注限额</button-tab-item>
      </button-tab>
    </x-header>
    <div class="app-body" style="padding-bottom: 0">
      <flexbox class="selectWrap">
        <flexbox-item>
          <span class="selectItem"><selector @on-change="change0" placeholder="彩种选择" v-model="ltype" :options="ltypeList"></selector><icon-svg iconClass="bg-down" class="up"></icon-svg></span><span class="selectItem">
          <selector @on-change="change1"  placeholder="玩法选择" v-model="limitType" :options="platyTypeList"></selector><icon-svg iconClass="bg-down" class="up"></icon-svg></span>
        </flexbox-item>
        <x-button stylereset type="warn" @click.native="search" :show-loading="queryLoading"><template v-if="!queryLoading">查询</template></x-button>
      </flexbox>
      <div id="back" v-show="showBack">
        <div class="wrap title">
        <x-table :cell-bordered="false" style="background-color:#fff;">
          <thead>
            <tr style="background-color: #eee">
              <th>玩法类型</th>
              <th>基本奖金</th>
              <th>投注返点</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="row in list0" :key="row.playTypeName">
              <td>{{row.playTypeName}}</td>
              <td>{{row.maxPrize}}</td>
              <td>{{row.rebate}}</td>
            </tr>
          </tbody>
        </x-table>
        </div>
      </div>
      <div id="limit" v-show="showLimit">
         <x-table :cell-bordered="false" style="background-color:#fff;">
            <thead>
              <tr style="background-color: #eee">
                <th>玩法类型</th>
                <th>单注最低限额</th>
                <th>单注最高限额</th>
                <th>单项最高限额</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="row in list1" :key="row.playTypeName">
                <td>{{row.playTypeName}}</td>
                <td>{{row.eachMinBet}}</td>
                <td>{{row.eachMaxBet}}</td>
                <td>{{row.itemMaxBet}}</td>
              </tr>
            </tbody>
          </x-table>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { ButtonTab, ButtonTabItem, Group, XButton, Flexbox, FlexboxItem, XTable, cookie } from 'vux'
  import * as API from 'api/wapi/user'
  export default {
    data () {
      return {
        tabActive: 0,
        showBack: true,
        showLimit: false,
        ltype: '',
        limitType: '',
        selected0: ['', ''],
        selected1: ['', ''],
        ltypeList: [],
        platyTypeList: [{key: 1, value: '官方玩法'}, {key: 2, value: '信用玩法'}],
        list0: [],
        list1: [],
        queryLoading: false
      }
    },
    components: {
      ButtonTab,
      ButtonTabItem,
      XButton,
      Group,
      Flexbox,
      FlexboxItem,
      XTable
    },
    created () {
      this.getLotteryTypeData()
    },
    watch: {
    },
    methods: {
      // 获取彩种类型
      getLotteryTypeData () {
        API.getLotteryType().then(res => {
          var result = res.result
          if (!res.error && result !== null && result) {
            this.ltypeList = result.items
            this.ltypeList = this.ltypeList.map(item => {
              return {
                key: item.id,
                value: item.name
              }
            })
          }
        })
      },
      search () {
        if (this.tabActive === 0) {
          if (this.selected0[0] === '') {
            this.$vux.toast.text('请选择彩种', 'middle')
            return false
          }
          if (this.selected0[1] === '') {
            this.$vux.toast.text('请选择玩法', 'middle')
            return false
          }
          this.getLotteryTypeList()
        } else if (this.tabActive === 1) {
          if (this.selected1[0] === '') {
            this.$vux.toast.text('请选择彩种', 'middle')
            return false
          }
          if (this.selected1[1] === '') {
            this.$vux.toast.text('请选择玩法', 'middle')
            return false
          }
          this.getLotteryTypeList1()
        }
      },
      // 获取赔点返律
      getLotteryTypeList () {
        this.queryLoading = true
        var params = {
          uid: cookie.get('userId'),
          lotteryTypeId: this.ltype
        }
        params.lotteryTypeId = this.selected0[0]
        params.playTabMode = this.selected0[1]
        API.getLotteryTypeList(params).then(res => {
          this.queryLoading = false
          var result = res.result
          if (!res.error && result) {
            this.list0 = result
          } else {
            this.$vux.toast.show({
              type: 'warn',
              text: res.error.message
            })
          }
        })
      },
      // 获取投注
      getLotteryTypeList1 () {
        this.queryLoading = true
        var params = {
          uid: cookie.get('userId'),
          lotteryTypeId: this.ltype
        }
        params.lotteryTypeId = this.selected1[0]
        params.playTabMode = this.selected1[1]
        API.getLotteryTypeList(params).then(res => {
          this.queryLoading = false
          var result = res.result
          if (!res.error && result) {
            this.list1 = result
          } else {
            this.$vux.toast.show({
              type: 'warn',
              text: res.error.message
            })
          }
        })
      },
      change0 (val) {
        if (this.tabActive === 0) {
          this.selected0[0] = val
        } else if (this.tabActive === 1) {
          this.selected1[0] = val
        }
      },
      change1 (val) {
        if (this.tabActive === 0) {
          this.selected0[1] = val
        } else if (this.tabActive === 1) {
          this.selected1[1] = val
        }
      },
      itemClick (index) {
      },
      btnClick () {
        this.queryLoading = false
        if (this.tabActive === 0) {
          this.showBack = true
          this.showLimit = false
          this.ltype = this.selected0[0]
          this.limitType = this.selected0[1]
        } else if (this.tabActive === 1) {
          this.showBack = false
          this.showLimit = true
          this.ltype = this.selected1[0]
          this.limitType = this.selected1[1]
        }
      }
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user_lotteryType
    .selectWrap
      .selectItem
        position relative
        margin-right rem(22)
        setLine()
        height rem(60)
        line-height rem(60)
        display inline-block
      .lott-icon.up
        width rem(40)
        height rem(60)
        position absolute
        top 50%
        margin-top rem(-30)
        right rem(10)
      background $color-white
      width auto
      padding rem(28)
      .weui-cell:before
        display none
      .vux-selector
        display inline-flex
        width rem(240)
        border-radius rem(4)
      .weui-select
        height 100%
        line-height 100%
        padding 0 rem(24)
      .weui-cell_select
        .weui-cell__bd:after
          display none
    line-height 1.5
    tbody td:before
      transform: translateX(0)
      border-bottom-color #eaeaea
    tbody td:first-child:before
      transform: translateX(rem(20))
    tbody td:last-child:before
      transform: translateX(rem(-20))
</style>