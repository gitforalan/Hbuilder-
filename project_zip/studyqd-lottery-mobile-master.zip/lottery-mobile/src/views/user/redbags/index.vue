<template>
  <div class="app-layout">
    <div class="app-main page-user page-user_redbags">
      <x-header :left-options="{backText: ''}" :title="title" class="is-fixed"></x-header>
      <div class="app-body" ref="appBody">
        <div v-if="redbagsList.length > 1">
          <ul class="redbags-content">
            <li v-for="(item, index) in redbagsList" :key="index">
              <p>
                <span>红包名称：{{item.activityName}}</span>
                <span>赠送金额<span class="font-red">{{item.amount}}</span>元</span>
                <span style="color: #636363;">{{item.createTime}}</span>
              </p>
              <p>
                <span>
                  <x-button v-if="item.status == 4" plain mini class="redbags-btn-end">已领取</x-button>
                  <x-button v-else-if="item.status == 1" plain mini class="redbags-btn" @click.native="receive(item, index)">马上领取</x-button>
                  <x-button v-else plain mini class="redbags-btn-end">已过期</x-button>
                </span>
              </p>
            </li>
          </ul>
          <div class="getMore" v-if="showMore" @click="getMore()">更多>></div>
        </div>
        <div class="isNull" v-else>
          <img src="../../../assets/image/no-redbags.png">
        </div>
      </div>
      <div v-transfer-dom class="redbags-dialog">
        <x-dialog v-model="showRedbags" class="dialog-demo" hide-on-blur>
          <span class="vux-close" @click="showRedbags=false"></span>
          <div class="img-box">
            <div class="redbags-img">
              <span>恭喜获得{{getRedbagsItem.amount}}元红包!</span>
            </div>
            <div class="redbags-receive">
              <img @click="receiveTrue()" class="receive-img" src="../../../assets/image/receive.png" style="max-width:100%">
              <img src="../../../assets/image/redbags.png" style="max-width:100%">
            </div>
          </div>
        </x-dialog>
      </div>
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
import { XDialog, TransferDomDirective as TransferDom, cookie } from 'vux'
import * as API from 'api/wapi/user'
import comFun from '../agent/comFunction'
export default {
  data () {
    return {
      title: '我的红包',
      showRedbags: false,
      getRedbagsItem: {},
      pageSize: 15,
      pageIndex: 1,
      total: '',
      startTime: '',
      endTime: '',
      showMore: false,
      redbagsList: [],
      rdIndex: 0
    }
  },
  directives: {
    TransferDom
  },
  components: {
    XDialog
  },
  mounted () {
    this.getRebBagsData()
  },
  methods: {
    // 获取红包列表
    getRebBagsData () {
      var params = {
        userId: cookie.get('userId'),
        status: [1, 4],
        startTime: comFun.dateFormat(new Date(new Date(comFun.getUTCTime2US()).getTime() - 3600 * 24 * 1000 * 6), 'yyyy-MM-dd hh:mm:ss'),
        endTime: comFun.dateFormat(new Date(new Date(comFun.getUTCTime2US()).getTime()), 'yyyy-MM-dd hh:mm:ss'),
        pageIndex: this.pageIndex,
        pageSize: this.pageSize
      }
      this.$vux.loading.show()
      API.getRedBags(params).then(res => {
        this.$vux.loading.hide()
        if (!res.error && res.result) {
          var result = res.result
          if (result !== null && result !== '' && result !== '0') {
            this.total = Math.ceil(result.total / this.pageSize)
            if (this.pageIndex > this.total) {
              this.showMore = false
            } else {
              this.showMore = true
              this.redbagsList = this.redbagsList.concat(result.items === null ? [] : result.items)
            }
          }
        }
      })
    },
    // 点击领取红包
    receive (val, index) {
      this.showRedbags = true
      this.getRedbagsItem = val
      this.rdIndex = index
    },
    // 确认领取红包
    receiveTrue () {
      this.showRedbags = false
      var params = {
        reportId: this.getRedbagsItem.reportId,
        status: 4
      }
      API.doReceiveRedBags(params).then(res => {
        if (!res.error && res.result) {
          var result = res.result
          if (+result.code === 1) {
            this.$vux.toast.show({
              text: '领取成功',
              position: 'middle'
            })
            this.redbagsList[this.rdIndex].status = 4
          } else {
            this.$vux.toast.show({
              type: 'warn',
              width: '10em',
              text: res.result.msg,
              position: 'middle'
            })
            this.redbagsList[this.rdIndex].status = 0
          }
        }
      })
    },
    getMore () {
      this.pageIndex = this.pageIndex + 1
      this.getRebBagsData()
      if (this.pageIndex > this.total && this.total !== 0) {
        this.showMore = false
        return false
      }
    }
  }
}
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  @import '~vux/src/styles/close.less'

  .page-user_redbags
    .app-body
      color #000
      font-weight bold
      font-size rem(30)
    .redbags-content li
      margin 0rem 0.5rem
      border-bottom 1px solid #EAEAEA
    .redbags-content li p:first-child
      display inline-block
      line-height 1.6rem
      padding rem(30)
    .redbags-content li p:last-child
      width: 25%
      display inline-block
      text-align center
      float right
    .redbags-content li p:last-child>span
      line-height 6.8rem
    .redbags-content li p>span
      display block
    .redbags-content li p span div
      width rem(118)
      text-align center
      border-radius rem(5)
      font-size rem(28)
      line-height 1.6rem
      display inline-block
    .redbags-content .redbags-btn
      border 1px solid $color-red
      color $color-red
      line-height rem(50)
      padding 0
      width rem(126)
    .redbags-content .redbags-btn-end
      border none
      color #a2a2a2
      line-height rem(50)
      padding 0
      width rem(126)
    .weui-cells:before
    .weui-cells:after
      border none
    .isNull
      font-size rem(42)
      text-align center
      margin 100px 10px
      img
        width: 100%;
  .redbags-dialog
    .weui-dialog
      background-color transparent
    .vux-close
      position absolute
      right 0
      width rem(27)
    .vux-close:before, .vux-close:after
      width rem(27)
      height rem(4)
      color white
    .redbags-img
      position absolute
      top 50%
      width 100%
      span
        font-size rem(30)
        color white
    .redbags-receive
      .receive-img
        position: absolute
        top 76%
        width 74%
        left 13%
</style>

