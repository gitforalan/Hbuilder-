<template>
  <div class="datetime-range">
    <group>
      <span class="onepx"><datetime v-model="dateStart"></datetime><icon-svg iconClass="riqi" style="color:#949494"></icon-svg></span><span class="hr">-</span><span class="onepx">
      <datetime v-model="dateEnd"></datetime><icon-svg iconClass="riqi" style="color:#949494"></icon-svg></span></span>
    </group>
  </div>
</template>

<script type="text/ecmascript-6">
  import { Datetime } from 'vux'
  export default {
    data () {
      return {
        dateStart: '2015-11-12',
        dateEnd: '2015-11-12'
      }
    },
    components: {
      Datetime
    },
    created () {
    },
    methods: {
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .datetime-range {
    line-height 1.5
    display inline-block
    .weui-cells {
      overflow visible
    }
    .weui-cells:after {
      border 0
    }
    .weui-cells:before {
      border 0
    }
    .vux-no-group-title {
      margin 0
    }
    i {
      width rem(30) !important
      height rem(30) !important
      position absolute
      top 40%
      right rem(10)
      margin-top rem(-10)
      & .svg-icon {
        position absolute
        left 0
        top 0
      }
    }
    .hr {
      margin 0 rem(8)
      color #858585
    }
    span.onepx {
      border-radius rem(4)
      display inline-block
      padding 0 rem(22)
      position relative
      min-width rem(200)
      height rem(60)
      border solid 1px $color-ccc
      border-radius rem(4)
      &:before {
        border 0
      }
    }
    .vux-datetime {
      display inline-block
      padding 0
      line-height rem(60)
      .vux-cell-value {
        color #858585
        font-size rem(24)
      }
      .weui-cell__ft:after {
        display none
      }
      .weui-cell__ft {
        padding 0
      }
    }
  }
</style>
