<template>
  <span class='range-select'>
    <!-- 本周，今天，昨天日期区间选择 -->
    <selector @on-change='onChange' :placeholder='placeholder' v-model='selected' :options='ltypeList'></selector><icon-svg iconClass='riqi' style='color:#949494'></icon-svg>
  </span>
</template>

<script type='text/ecmascript-6'>
  import { Selector } from 'vux'
  import comFun from '../agent/comFunction'
  export default {
    data () {
      return {
        placeholder: '今天',
        selected: '今天',
        ltypeList: ['今天', '昨天', '前天', '最近七天'],
        dateRange: ['', ''],
        params: {},
        defaultParams: {}
      }
    },
    props: {
      options: {
        type: Object
      }
    },
    components: {
      Selector
    },
    created () {
      // 默认tody
      if (this.checkOptionName('defaultDate')) {
        this.onChange(this.options['defaultDate'])
        this.selected = this.options['defaultDate']
        this.placeholder = this.options['defaultDate']
      } else {
        this.setToday()
      }
    },
    methods: {
      checkOption () {
        if (typeof this.options !== 'undefined') {
          return true
        }
        return false
      },
      checkOptionName (name) {
        Object.assign(this.params, this.defaultParams, this.options)
        if (typeof this.options !== 'undefined') {
          if (this.options[name] !== 'undefined') {
            return true
          }
          return false
        }
        return false
      },
      setToday () {
        this.$set(this.$data.dateRange, 0, comFun.dateFormat(new Date(comFun.getUTCTime2US()), 'yyyy-MM-dd'))
        this.$set(this.$data.dateRange, 1, comFun.dateFormat(new Date(comFun.getUTCTime2US()), 'yyyy-MM-dd'))
      },
      setYesterday () {
        this.dateRange[0] = comFun.dateFormat(new Date(new Date(comFun.getUTCTime2US()).getTime() - 3600 * 24 * 1000 * 1), 'yyyy-MM-dd')
        this.dateRange[1] = comFun.dateFormat(new Date(new Date(comFun.getUTCTime2US()).getTime() - 3600 * 24 * 1000 * 1), 'yyyy-MM-dd')
      },
      setTheDayBeforeYesterday () {
        this.dateRange[0] = comFun.dateFormat(new Date(new Date(comFun.getUTCTime2US()).getTime() - 3600 * 24 * 1000 * 2), 'yyyy-MM-dd')
        this.dateRange[1] = comFun.dateFormat(new Date(new Date(comFun.getUTCTime2US()).getTime() - 3600 * 24 * 1000 * 2), 'yyyy-MM-dd')
      },
      setWeekend () {
        this.$set(this.$data.dateRange, 0, comFun.dateFormat(new Date(new Date(comFun.getUTCTime2US()).getTime() - 3600 * 24 * 1000 * 6), 'yyyy-MM-dd'))
        this.$set(this.$data.dateRange, 1, comFun.dateFormat(new Date(new Date(comFun.getUTCTime2US()).getTime()), 'yyyy-MM-dd'))
      },
      onChange (val) {
        switch (val) {
          case '今天':
            this.setToday()
            break
          case '昨天':
            this.setYesterday()
            break
          case '前天':
            this.setTheDayBeforeYesterday()
            break
          case '最近七天':
            this.setWeekend()
            break
        }
      }
    }
  }
</script>

<style lang='stylus'>
  @import '~@/assets/baseStylus/variable'
  .range-select {
    display inline-block
    position relative
    background $color-white
    i {
      width rem(30) !important
      height rem(30) !important
      position absolute
      top 40%
      right rem(10)
      margin-top rem(-10)
      & .svg-icon {
        position absolute
        left 0
        top 0
      }
    }
    .weui-cell:before {
      display none
    }
    .vux-selector {
      font-size rem(24)
      width rem(240)
      border solid 1px $color-ccc
      border-radius rem(4)
    }
    .weui-select {
      height rem(60)
      line-height rem(60)
      padding 0 rem(24)
    }
    .weui-cell_select {
      .weui-cell__bd:after {
        display none
      }
    }
  }
</style>
