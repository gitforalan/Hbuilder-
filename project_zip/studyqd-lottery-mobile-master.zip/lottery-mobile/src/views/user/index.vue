<template>
  <div class="app-main page-user page-user__index">
    <x-header :title="title" :left-options="{ showBack: false }" class="is-fixed">
      <a href="javascript:;" slot="right"  @click.stop="customerServiceUrl">客服</a>
    </x-header>
    <div class="app-body">
      <group class="user-import" stylereset>
        <div class="user-import__head">
          <img :src="userImage" class="user-import__portrait">
        </div>
        <div class="user-import__body">
          <p class="user-import__word-item">
            帐号：{{ userName }}
            <span class="vip-grade" :class="'vip-grade--' + levelCode"></span>
          </p>
          <p class="user-import__word-item">
            余额：<span class="user-import__deposit">{{ depositIsShow ? balance : '***' }}</span>
            <span class="user-import__deposit-handle" @click="depositIsShow = !depositIsShow">{{ depositIsShow ? '隐藏' : '显示' }}</span>
          </p>
          <x-button type="default" link="/user/sign" class="user-import__btn-sign">签到</x-button>
        </div>
      </group>
      <div class="user-shortcut">
        <grid>
          <grid-item @click.native="goDeposit">
            <span slot="default">
              <img src="../../assets/image/icon_recharge.png" class="user-shortcut__icon icon-recharge"></img>我要充值
            </span>
          </grid-item>
          <grid-item link="/user/withdrawals">
          <!-- <grid-item @click.native="changeNewUser"> -->
            <span slot="default">
              <img src="../../assets/image/icon_withdraw.png" class="user-shortcut__icon icon-withdraw"></img>我要提现
            </span>
          </grid-item>
        </grid>
      </div>
      <group class="user-menu" stylereset>
        <cell
          v-for="item in userMenuList"
          v-if="!item.isShow"
          :key="item.name"
          :title="item.name"
          :link="item.link"
          :is-link="item.isLink">
          <icon-svg slot="icon" :iconClass="item.iconCls" :style="{ 'color': item.iconColor }"></icon-svg>
        </cell>
      </group>

      <confirm 
        v-model="newUserState"
        @on-confirm="onConfirm"
        title="操作提示">
          <p style="text-align:center;">为了您资金安全，请绑定手机号</p>
      </confirm>

    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { Grid, GridItem, Group, Cell, Confirm, cookie } from 'vux'
  import { mapMutations } from 'vuex'
  import * as API from 'api/wapi/user'
  export default {
    data () {
      return {
        title: '我的帐户',
        userName: '',
        userImage: '',
        levelCode: 0,
        balance: 0,
        depositIsShow: true,
        userMenuList: [
          { name: '个人信息', link: '/user/information', isLink: true, iconCls: 'yonghu', iconColor: '#10aeff' },
          { name: '我的红包', link: '/user/redbags', isLink: true, iconCls: 'iconzhenghe03', iconColor: '#ff592c' },
          { name: '个人报表', link: '/user/personal', isLink: true, iconCls: 'baobiao1', iconColor: '#8f6cff' },
          { name: '投注记录', link: '/user/betting', isLink: true, iconCls: 'jilu', iconColor: '#24c18f' },
          { name: '帐户明细', link: '/user/accountDetails', isLink: true, iconCls: 'ezhanghu', iconColor: '#ffb108' },
          { name: '彩种信息', link: '/user/lotteryType', isLink: true, iconCls: 'tubiao', iconColor: '#ff592c' },
          { name: '我的消息', link: '/user/message', isLink: true, iconCls: 'xiaoxi', iconColor: '#8f6cff' },
          { name: '代理中心', link: '/user/agent', isLink: true, iconCls: 'yonghu1', iconColor: '#cc782e', isShow: cookie.get('loginType') !== 'agent' && sessionStorage.getItem('newUser') !== 'new' },
          { name: '安全设置', link: '/user/security', isLink: true, iconCls: 'yanzhengma', iconColor: '#505bcb' },
          { name: '更多', link: '/user/more', isLink: true, iconCls: 'more1', iconColor: '#24c18f' }
        ],
        newUserState: false
      }
    },
    components: {
      Grid, GridItem, Group, Cell, Confirm
    },
    created () {
      this.getUserProfile()
      this.getUserBalance()
    },
    methods: {
      // 判断是否是新用户
      changeNewUser () {
        if (sessionStorage.getItem('newUser') && sessionStorage.getItem('newUser') !== 'new') {
          // 跳转到我要提现
          this.$router.push({ path: '/user/withdrawals' })
        } else {
          this.newUserState = true
        }
      },

      // 用户第一次充值时，需要先绑定手机号码
      goDeposit () {
        //  link="/user/deposit"
        var params = {
          userId: cookie.get('userId')
        }
        API.mobileFlag(params).then(res => {
          if (!res.error) {
            if (+res.result === 1) {
              this.$router.push({ path: '/user/deposit' })
            } else {
              this.loginMark()
            }
          } else {
            this.$vux.toast.show({
              type: 'warn',
              text: res.error.message
            })
          }
        })
      },

      // 判断用户是否是第三方登录
      loginMark () {
        var params = {
          userId: cookie.get('userId')
        }
        API.loginFlag(params).then(res => {
          if (!res.error) {
            if (+res.result === 1) {
              // 未绑定手机引导绑定手机界面
              this.newUserState = true
            } else {
              this.$router.push({ path: '/user/deposit' })
            }
          } else {
            this.$vux.toast.show({
              type: 'warn',
              text: res.error.message
            })
          }
        })
      },

      // 确定
      onConfirm () {
        // 跳转绑定手机界面
        this.$router.push({ path: '/user/bindPhone' })
      },

      // 获取用户基本信息
      getUserProfile () {
        var params = {
          withLevel: 1
        }
        API.getUserProfile(params).then(res => {
          if (!res.error && res.result) {
            this.userName = res.result.loginId
            this.levelCode = res.result.levelCode
            // 头像处理
            var imgFilePath = cookie.get('imgFilePath')
            if (!imgFilePath || !/\S/.test(imgFilePath)) {
              // 获取图片文件展示路径
              API.getImgFilePath().then(data => {
                imgFilePath = !data.error ? data.result : ''
                this.userImage = imgFilePath + '/' + res.result.userImage
                this.setCookieImgFilePath({ 'imgFilePath': imgFilePath })
              })
            } else {
              this.userImage = imgFilePath + '/' + res.result.userImage
            }
          }
        })
      },
      // 获取用户账户余额
      getUserBalance () {
        API.getUserBalance().then(res => {
          if (!res.error && res.result) {
            this.balance = res.result.balance
            window.setTimeout(() => {
              this.depositIsShow = false
            }, 3000)
          }
        })
      },
       // 在线客服
      customerServiceUrl () {
        var self = this
        var onlineCustomerServiceUrl = cookie.get('onlineCustomerServiceUrl')
        if (!onlineCustomerServiceUrl || !/\S/.test(onlineCustomerServiceUrl)) {
          var params = {
            'domain': window.location.hostname
          }
          API.snInfo(params).then(res => {
            if (!res.error && res.result) {
              self.setCustomerServiceUrl({ 'onlineCustomerServiceUrl': res.result.onlineCustomerServiceUrl })
              window.location.href = res.result.onlineCustomerServiceUrl
            } else {
              self.$vux.toast.show({
                type: 'warn',
                text: res.error.message
              })
            }
          })
        } else {
          window.location.href = onlineCustomerServiceUrl
        }
      },
      ...mapMutations(['setCookieImgFilePath', 'setCustomerServiceUrl'])
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user__index {
    .user-import {
      .weui-cells {
        position: relative
        display: flex
        align-items: center
        padding: rem(16) rem(24)
        margin-top: rem(10)
      }
      &__head {
        width: rem(140)
        height: rem(140)
        margin: 0 rem(25) 0 rem(12)
        border: 1px solid #8a8a8a
        border-radius: 50%
        vertical-align: middle
      }
      &__portrait {
        width: 100%
        height: 100%
        border-radius: 50%
      }
      &__body {
        position: relative
        flex: 1
        padding-right: rem(150)
      }
      &__word-item {
        margin: rem(10) 0
        font-size: rem(28)
        white-space: nowrap
      }
      &__deposit {
        color: #878787
      }
      &__deposit-handle {
        margin-left: rem(15)
        color: #ff5151
        cursor: pointer
      }
      &__btn-sign {
        position: absolute
        top: 50%
        right: 0
        width: auto
        transform: translate(0, -50%)
        padding: rem(16) rem(30)
        line-height: 1
        font-size: rem(30)
        border: 1px solid #ea5151
        border-radius: 3px
        background: transparent
        color: #ea5151
        overflow: initial
        &:after {
          display: none
        }
      }
    }
    .user-shortcut {
      margin-top: rem(15)
      font-size: rem(30)
      text-align: center
      background-color: #fff
      .weui-grid {
        color: #434343
      }
      .weui-grids:after,
      .weui-grid + .weui-grid:before {
        display: none
      }
      &__icon {
        display: inline-block
        vertical-align: middle
        margin-right: rem(25)
        background-repeat: no-repeat
        background-size: cover
      }
      .icon-recharge {
        width: rem(104)
        height: rem(79)
        margin-bottom: rem(10)
      }
      .icon-withdraw {
        width: rem(88)
        height: rem(89)
      }
    }
  }
</style>
