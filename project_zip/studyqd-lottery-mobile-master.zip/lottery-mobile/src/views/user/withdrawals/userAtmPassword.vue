<template>
  <div class="app-main page-user page-user__security-atm-password">
    <x-header :title="title" :left-options="{ backText: '' }" class="is-fixed">
    </x-header>
    <div class="app-body">
      <group v-if="handleType === 'setting'" label-width="5.5em" label-margin-right="1.5em" label-align="right" class="handle-form" stylereset>
        <cell title="取款密码">
          <select v-model="settingForm.password[i - 1]" v-for="i in 4" :key="i" class="password-selector">
            <option v-for="k in 10" :key="k">{{ k - 1 }}</option>
          </select>
        </cell>
        <cell title="新密码">
          <select v-model="settingForm.confirmPassword[i - 1]" v-for="i in 4" :key="i" class="password-selector">
            <option v-for="k in 10" :key="k">{{ k - 1 }}</option>
          </select>
        </cell>
      </group>
      <p class="handle-form__btn-bar">
        <x-button class="handle-form__btn-submit" @click.native="submitForm()">确定</x-button>
      </p>

      <div class="tips">
        <p>*提款时需要取款密码，请务必记住！</p>
        <p>*取款密码默认为0000，请尽快修改取款密码。</p>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { Group, Cell, cookie } from 'vux'
  import * as API from 'api/wapi/user'
  import Encode from '@/utils/sha1'
  export default {
    data () {
      return {
        title: '修改取款密码',
        handleType: '',
        settingForm: {
          password: [0, 0, 0, 0],
          confirmPassword: [0, 0, 0, 0]
        }
      }
    },
    components: {
      Group, Cell
    },
    created () {
      this.handleType = 'setting'
    },
    methods: {
      submitForm () {
        this.update()
      },
      // 修改密码
      update () {
        var encode = new Encode()
        var userId = cookie.get('userId')
        var params = {
          'oldPayPwd': encode.encodeSha1(userId + encode.encodeSha1(this.settingForm.password.join(''))),
          'newPayPwd': encode.encodeSha1(userId + encode.encodeSha1(this.settingForm.confirmPassword.join('')))
        }
        API.updateUserPaypwd(params).then(res => {
          if (!res.error && Number(res.result) === 1) {
            this.settingForm.password = [0, 0, 0, 0]
            this.settingForm.confirmPassword = [0, 0, 0, 0]
            // 重定向到提现界面
            this.$router.push({path: '/user/withdrawals'})
          } else {
            this.$vux.toast.show({
              type: 'warn',
              text: res.error.message
            })
          }
        })
      }
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  @import "~@/assets/baseStylus/user"
  .page-user__security-atm-password {
    .tips {
      text-align: center
      margin-top: rem(40)
      line-height: rem(40)
      color: $color-ccc
    }
    .tips-info {
      padding: rem(40) rem(10)
      text-align: center
      font-size: rem(24)
      color: #7c7c7c
    }
    .handle-form {
      .vux-cell-primary {
        flex: 0
      }
      .weui-cell__ft {
        width: 100%
        text-align: left
      }
      .password-selector {
        position: relative
        z-index: 1
        -webkit-appearance: none
        border: 0
        outline: 0
        background-color: transparent
        width: 25%
        height: rem(50)
        line-height: rem(50)
        padding-left: rem(36)
      }
      &__btn-bar {
        padding: 0 rem(20)
        margin-top: rem(100)
      }
      &__btn-submit {
        color: #fff
        background-color: #f55
      }
      &__btn-cancel {
        color: #fff
        background-color: #858585
      }
    }
  }
</style>
