<template>
  <div class="app-main page-user page-user_bankInfo">
    <x-header :title="title" :left-options="{ backText: '' }" class="is-fixed"></x-header>
    <div class="app-body">
      <section>
        <div class="tips">请确实填写您的出款银行,以免有心人士窃取</div>
        <div class="cardnum">
          <h2>卡号信息</h2>
          <group>
            <x-input title="开户人姓名：" v-model="accountHolder" placeholder="请输入开户名"></x-input>
          </group>
          <group>
            <x-input title="开户行网点：" v-model="openingBank" placeholder="请输入开户行网点"></x-input>
          </group>
          <group>
            <popup-picker title="开户银行：" :data="listBanks" v-model="banks" @on-change="onChangeBanks"></popup-picker>
          </group>
          <group>
            <x-input title="银行账号：" v-model="bankAccount" placeholder="请输入银行帐号"></x-input>
          </group>
        </div>
        <div class="btn-wrap">
          <group>
            <x-button @click.native="next">下一步</x-button>
          </group>
          <group>
            <x-button @click.native="removeData">重置</x-button>
          </group>
        </div>
      </section>

      <div class="bank-state">
        <confirm v-model="setBankState"
        cancel-text=""
        @on-confirm="onConfirm">
          <p style="text-align:center;">设定成功</p>
        </confirm>
      </div>

    </div>
  </div>
</template>

<script type="text/ecmascript-6">
import { Group, XInput, PopupPicker, XButton, Confirm } from 'vux'
import * as API from 'api/wapi/user'

export default {
  data () {
    return {
      title: '银行资料',
      accountHolder: '', // 开户人
      openingBank: '', // 开户行
      bankAccount: '', // 银行账号
      fromBankId: '', // 选择开户银行
      listBanks: [['请选择银行']],
      banks: ['请选择银行'],
      setBankState: false
    }
  },
  components: {
    Group, XInput, PopupPicker, XButton, Confirm
  },
  mounted () {
    document.querySelector('.app-layout').style.backgroundColor = '#fff'
    // 获取银行列表
    this.getBankList()
  },
  methods: {

    // 设定成功
    onConfirm () {
      // 跳转设定密码
      this.$router.push({path: '/user/atmPassword'})
    },

    // 下一步
    next () {
      var str = ''
      var reg = /[\u4e00-\u9fa5]/g
      if (!this.accountHolder) {
        str += '请输入开户名姓名<br/>'
      } else if (!reg.test(this.accountHolder)) {
        str += '开户人姓名只能为中文<br/>'
      } else {
        if (!this.openingBank) {
          str += '请输入开户行网点<br/>'
        }
        if (!this.bankAccount) {
          str += '请输入银行帐号<br/>'
        }
        if (!this.fromBankId) {
          str += '请选择出款银行<br/>'
        }
      }
      if (str) {
        this.$vux.toast.show({
          type: 'warn',
          text: str
        })
        return
      }
      // 更新用户信息
      this.updatebankInfo()
    },

    // 更新用户信息
    updatebankInfo () {
      var params = {}
      params.name = this.accountHolder
      params.bankId = this.fromBankId
      params.bankBranch = this.openingBank
      params.bankAccount = this.bankAccount
      API.bankUpdate(params).then(res => {
        if (!res.error) {
          if (res.result && res.result !== '0') {
            this.setBankState = true
          } else {
            this.setBankState = false
          }
        } else {
          this.$vux.toast.show({
            type: 'warn',
            text: res.error.message
          })
        }
      })
    },

    // 清空请求数据
    removeData () {
      this.accountHolder = ''
      this.openingBank = ''
      this.bankAccount = ''
      this.fromBankId = ''
      this.banks = ['请选择银行']
    },

    // 选择银行
    onChangeBanks (value) {
      var item = {}
      if (value && value.length > 0 && value[0] !== '请选择银行') {
        item = this.resBankList[this.resBankList.findIndex(item => item.bankName === value[0])]
      }
      this.fromBankId = item.bankId
    },

    // 获取银行列表
    getBankList () {
      API.bankList({}).then(res => {
        if (!res.error) {
          if (res.result) {
            this.resBankList = res.result
            res.result.forEach(item => {
              this.listBanks[0].push(item.bankName)
            })
          }
        }
      })
    }
  }
}
</script>

<style scoped lang="stylus">
@import "~@/assets/baseStylus/variable"
.page-user_bankInfo
  .tips
    background $color-gray-f
    padding-left rem(16)
    padding-bottom rem(22)
    padding-top rem(22)
  .cardnum
    h2
      setLeftLine($color-red)
      margin-left rem(10)
      margin-top rem(26)
      padding-left rem(4)
  .btn-wrap
    margin 0 rem(22)
  .btn-wrap >div:first-child
    .weui-btn_default
      background-color $color-red
      color $color-white
    .weui-cells:before, .weui-cells:after
      border-bottom-color $color-red
  .btn-wrap >div:last-child
    .weui-btn_default
      background-color $color-white
      color $color-font-light 
</style>

<style lang="stylus">
@import "~@/assets/baseStylus/variable"
.page-user_bankInfo
  .cardnum
    .weui-cells:before, .weui-cells:after, .vux-cell-box:before
      border 0
  .cardnum .weui-cells
    border-bottom 2px dotted $color-gray-a
    margin-top rem(10)
  .btn-wrap
    .weui-cells:before, .weui-cells:after
      border none
    .weui-btn_default
      border-radius rem(4) 
  .bank-state
    .weui-dialog__ft
      a:first-child
        display none     
</style>