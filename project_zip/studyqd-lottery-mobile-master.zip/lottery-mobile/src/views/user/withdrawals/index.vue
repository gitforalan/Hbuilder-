<template>
  <div class="app-main page-user page-user_withdrawals">
    <x-header :title="title" :left-options="{ backText: '' }" class="is-fixed"></x-header>
    <div class="app-body">
      <section>
        <div class="withdrawals">
          <group>
            <cell title="收款人姓名" :value="bankAccountOwner | wordsToEllipsis"></cell>
            <cell title="账户余额" :value="balance"></cell>
          </group>

          <group>
            <div class="proportion">
              <div class="withdrawalsHead">
                <span>消费比例</span>
                <span><router-link to="/user/withdrawalsdetails">查看详情</router-link></span>
              </div>
              <div>
                <p><span>需达投注量：</span><span>{{totalCutAmount}}</span></p>
                <p><span>已达投注量：</span><span>{{totalOrderAmount}}</span></p>
              </div>
              <div>
                <p><span>是否可以提款：</span><span>{{(totalCutAmount - totalOrderAmount) > 0 ? '是' : '否'}}</span></p>
                <p><span>免手续费：</span><span>{{poundage}}</span></p>
              </div>
            </div>
          </group>  

          <group>
            <div class="withd-content">
              <group>
                <cell title="收款银行：">
                  <span>{{bankName}}</span>
                </cell>
              </group>

              <group>
                <cell title="收款帐号：">
                  <span>{{bankAccount | wordsToEllipsisContent}}</span>
                </cell>
              </group>

              <div class="withd-content-list-1">
                <group class="withd-content-money">
                  <cell title="提款金额：">
                    <span></span>
                    <x-input v-model="money" @on-blur="updateWithdrawOption" :placeholder="`最小提款金额为${minAmount}元`"></x-input>
                  </cell>
                </group>
                <div class="withd-content-details">
                  <p>
                    <span>手续费</span>
                    <span class="color-red">{{feeAmount}}</span>
                  </p>
                  <p>
                    <span>出款上限</span>
                    <span class="color-red">{{maxAmount}}</span> 出款下限 <span class="color-red">{{minAmount}}</span>
                  </p>
                  <p>
                    <span>剩余免手续费次数</span>
                    <span class="color-red">{{nonFeeTimes}}</span>
                  </p>
                </div>
              </div>

              <div class="password">
                <cell title="取款密码：">
                  <select v-model="settingForm.password[i - 1]" v-for="i in 4" :key="i" class="password-selector">
                    <option v-for="k in 10" :key="k">{{ k - 1 }}</option>
                  </select>
                </cell>
                <!-- <div class="password-no">
                  <popup-picker :data="listNo" v-model="value1" value-text-align="left"></popup-picker>
                  <popup-picker :data="listNo" v-model="value2" value-text-align="left"></popup-picker>
                  <popup-picker :data="listNo" v-model="value3" value-text-align="left"></popup-picker>
                  <popup-picker :data="listNo" v-model="value4" value-text-align="left"></popup-picker>
                </div> -->
              </div>
            </div>
          </group>

          <div class="btn-wrap">
            <x-button type="warn" @click.native="confirm">确认</x-button>
          </div>
        </div>
      </section>

      <div>
        <confirm v-model="addBank"
        title="操作提示"
        @on-cancel="onCancel"
        @on-confirm="onConfirm">
          <p style="text-align:center;">是否添加银行卡</p>
        </confirm>
      </div>

    </div>
  </div>
</template>

<script type="text/ecmascript-6">
import { PopupPicker, Confirm, cookie } from 'vux'
import * as API from 'api/wapi/user'
import Encode from '@/utils/sha1'

export default {
  data () {
    return {
      title: '提现',
      UpBettingAmount: 0,
      HasBettingAmount: 0,
      isDrawing: false,
      poundage: 0,
      money: null,
      settingForm: {
        password: [0, 0, 0, 0]
      },
      // listNo: [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]],
      // value1: [0],
      // value2: [0],
      // value3: [0],
      // value4: [0],
      addBank: false,
      bankAccountOwner: '',
      balance: '',
      bankAccount: '',
      bankName: '',
      feeAmount: '',
      maxAmount: '',
      minAmount: '',
      nonFeeTimes: '',
      bankId: null,
      withdrawNo: null,
      statsCacheKey: null,
      totalCutAmount: null,
      totalOrderAmount: null
    }
  },
  components: {
    PopupPicker, Confirm
  },
  created () {
    localStorage.removeItem('DRAWAL')
  },
  mounted () {
    this.changeAccountList()
  },
  filters: {
    // 姓名显示省略号
    wordsToEllipsis (val) {
      if (!val) return
      var len = val.length
      var stars = ''
      var start = 1
      stars = new Array(len - start).join('*')
      return val.substring(0, start) + stars
    },

    // 收款账号显示省略号
    wordsToEllipsisContent (val) {
      if (!val) return
      var len = val.length
      var stars = ''
      var start = 1
      if (len < 10) {
        stars = new Array(len - start).join('*')
        return val.substring(0, start) + stars
      }
      var reg = /^(.{5})(.*)(.{6})$/
      return val.replace(reg, ($1, $2, $3, $4) => {
        return $2 + new Array($3.length).join('*') + $4
      })
    }
  },
  methods: {

    // 确认
    confirm () {
      var params = {}
      var encode = new Encode()
      var userId = cookie.get('userId')
      if (!this.money) {
        this.$vux.toast.show({
          type: 'warn',
          text: '请输入提款金额'
        })
        return
      }
      params.withdrawNo = this.withdrawNo
      params.payPasword = encode.encodeSha1(userId + encode.encodeSha1(this.settingForm.password.join('')))
      params.toBankId = this.bankId
      params.amount = this.money
      params.statsCacheKey = this.statsCacheKey
      API.withdrawApply(params).then(res => {
        if (!res.error) {
          if (res.result) {
            var self = this
            this.$vux.toast.show({
              type: 'success',
              text: '操作成功',
              onHide () {
                // 重置输入密码
                self.settingForm.password = [0, 0, 0, 0]
                // 重置金额
                self.money = null
                // 重新取款申请流水号
                self.getNoGet()
                // 重新获取余额
                self.getBalance()
                // 重新获取出款金额
                self.getWithdrawOption()
              }
            })
          }
        } else {
          this.$vux.toast.show({
            type: 'warn',
            text: res.error.message
          })
        }
      })
    },

    // 查询用户出款银行记录
    changeAccountList () {
      var params = {}
      params.defaultOnly = 1 // [1, 表示默认]
      API.withdrawAccountList(params).then(res => {
        if (!res.error) {
          // res.result = []
          if (res.result && res.result.length <= 0) {
            this.addBank = true
          } else {
            this.addBank = false
            this.bankAccountOwner = res.result[0].bankAccountOwner
            this.bankAccount = res.result[0].bankAccount
            this.bankName = res.result[0].bankName
            this.bankId = res.result[0].bankId
            this.getBalance()
            this.getWithdrawOption()
            this.getAuditAboutCurrent()
            this.getNoGet()
          }
        }
      })
    },

    // 获取取款申请流水号
    getNoGet () {
      API.withdrawNoGet().then(res => {
        if (!res.error) {
          if (res.result) {
            this.withdrawNo = res.result
          }
        }
      })
    },

    // 获取余额
    getBalance () {
      API.balanceGet().then(res => {
        if (!res.error) {
          if (res.result) {
            this.balance = res.result.balance
          }
        }
      })
    },

    // 更新用户出款金额
    updateWithdrawOption () {
      var reg = /^(\d*\.)?\d+$/
      if (!reg.test(this.money)) {
        this.$vux.toast.show({
          type: 'warn',
          text: '请输入正确的金额格式'
        })
        return
      }
      this.getWithdrawOption()
    },

    // 即时稽核查询
    getAuditAboutCurrent () {
      API.auditAboutCurrentGet().then(res => {
        if (!res.error) {
          if (res.result) {
            this.statsCacheKey = res.result.statsCacheKey

            // 消费比例
            this.poundage = res.result.feeAmount
            this.totalCutAmount = res.result.totalCutAmount
            this.totalOrderAmount = res.result.totalOrderAmount
          }
        }
      })
    },

    // 用户出款金额可选项(有效范围)查询
    getWithdrawOption () {
      var params = {}
      if (this.money) {
        params.amount = this.money
      }
      API.withdrawOptionGet().then(res => {
        if (!res.error) {
          if (res.result) {
            this.feeAmount = res.result.feeAmount
            this.maxAmount = res.result.maxAmount
            this.minAmount = res.result.minAmount
            this.nonFeeTimes = res.result.nonFeeTimes
          }
        }
      })
    },

    // 绑定银行卡 - 取消
    onCancel () {
      // 重定向到会员中心
      this.$router.push({path: '/user'})
    },

    // 绑定银行卡 - 确定
    onConfirm () {
      // 跳转银行卡资料
      // this.$router.push({path: '/user/bankInfo'})
      localStorage.setItem('DRAWAL', 'withdrawals')
      this.$router.push({ path: '/user/information/bankCard/setting' })
    },

    // 判断金额
    isMoney (money) {
      var reg = /^(\d*\.)?\d+$/
      if (money === '' || money === null) {
        this.$vux.toast.show({
          type: 'warn',
          text: '请输入金额'
        })
        return false
      } else if (!reg.test(money)) {
        this.$vux.toast.show({
          type: 'warn',
          text: '请输入正确的金额格式'
        })
        return false
      }
      return true
    }
  }
}
</script>

<style scoped lang="stylus">
@import "~@/assets/baseStylus/variable"
$color-gray-c7 = #c7c7c7 // gray

.page-user_withdrawals
  .password 
    .weui-cell__ft
      width rem(220)
    .password-selector
      padding-left rem(40)
      margin-right rem(20)
  .proportion
    padding: rem(20) rem(30)
    a
      color: $color-blue
      font-size: $size-small-s
    > div
      display: flex
      p
        width: 50%
        span:first-child
          color: $color-font-light
  .withdrawalsHead
    margin-bottom: rem(10)
    justify-content: space-between
  .withd-content
    > div:not(:last-child)
      setBottomLine()
    .color-red
      color: $color-red
    .withd-content-details
      padding-left rem(30)
      padding-bottom rem(20)
    .withd-content-money
      .weui-cell__ft .weui-cell
        padding 0
        border 1px solid $color-gray-c7
        padding-left rem(6)
        line-height rem(50)
        // setLine()
  .btn-wrap
    margin: rem(20)
    .weui-btn_warn
      background-color $color-red
      border-radius rem(4)
  .password
    display: flex
    span
      line-height: rem(60)
    .weui-cell_access .weui-cell__ft
      display: none
    .password-no
      display: flex
      justify-content: left
      width: 70%
      margin-left: rem(10)
      .vux-cell-box:before
        border: none
      & > div
        display: flex
        align-items: center
        justify-content: center
        background: $color-eee
        border: 1px solid $color-font-light
        width: rem(60)
        height: rem(60)
        padding: 0
        margin: 0
        text-align: center
        line-height: rem(60)
        margin-right: rem(10)
</style>

<style lang="stylus">
@import "~@/assets/baseStylus/variable"
.page-user_withdrawals
  .password-selector {
    position: relative
    z-index: 1
    -webkit-appearance: none
    border: 0
    outline: 0
    background-color: transparent
    width: rem(100)
    height: rem(50)
    line-height: rem(50)
    background #f3f3f3
  }
  &__btn-bar {
    padding: 0 rem(20)
    margin-top: rem(100)
  }
  &__btn-submit {
    color: #fff
    background-color: #f55
  }
  &__btn-cancel {
    color: #fff
    background-color: #858585
  }

  .weui-cells
    font-size $size-medium
  .withd-content
    .weui-cells
      display: flex
      margin-top: 0
    .weui-cells:before, .weui-cells:after, .weui-cell:before
      border: none
    .weui-input
      box-sizing: border-box
  .password
    .weui-cell_access .weui-cell__ft
      display: none     
</style>