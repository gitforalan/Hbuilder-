<template>
  <div class="app-main page-user page-user_withdrawals-details">
    <x-header :title="title" :left-options="{ backText: '' }" class="is-fixed"></x-header>
    <div class="app-body">
      <section>
        <div class="with-details">
          <group>
            <div class="consumer-detail__header">
              <b @click="effectiveBets">{{bets ? '显示' : '隐藏'}}</b>
              <span>实际有效投注额</span>
              <b @click="preferentialAuditEvent">{{audit ? '显示' : '隐藏'}}</b>
              <span>优惠稽核</span>
            </div>
            <div class="consumer-detail__con">
              <p>
                <span>优惠稽核：</span>
                <span v-if="!couponBetAudited" style="color: red;">未通过</span>
                <span v-else>
                  <span v-if="+couponBetAudited === 1" style="color: green;">通过</span>
                  <span v-if="+couponBetAudited === 2" style="color: red;">未通过</span>
                  <span v-if="+couponBetAudited === 3" style="color: blue;">不需要稽核</span>
                </span>
                优惠稽核，需扣除存款优惠：<span style="color: red;">{{couponCutAmount}}</span> 元
              </p>
              <p><span>常态性稽核：</span>
              <span v-if="!auditBetAudited" style="color: red;">未通过</span>
              <span v-else>
                <span v-if="+auditBetAudited === 1" style="color: green;">通过</span>
                <span v-if="+auditBetAudited === 2" style="color: red;">未通过</span>
                <span v-if="+auditBetAudited === 3" style="color: blue;">不需要稽核</span>
              </span>，需扣除{{auditCutPercent}}%行政费：<span style="color: red;">{{feeAmount}}</span>元</p>
              <p>优惠稽核 + 常态性稽核  共需扣除: <span class="color-red">{{totalCutAmount}}</span>元</p>
              <p>此次出款时间为: <span class="color-red">{{withdrawTime}}</span></p>
            </div>
          </group>

          <template v-for="(item, index) in consumptionArr">
            <div class="consumer-detail__topbar">No.{{index + 1}}</div>
            <div>
              <x-table :cell-bordered="false" style="background-color:#fff;">
                <thead>
                  <tr style="background-color: #ccc">
                    <th>存款日期区间</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>起始：{{item.chargeStartTime}}</td>
                  </tr>
                  <tr>
                    <td>结束：{{item.chargeEndTime}}</td>
                  </tr>
                </tbody>
              </x-table>


              <x-table :cell-bordered="false" style="background-color:#fff;">
                <thead>
                  <tr style="background-color: #ccc">
                    <th>存款金额</th>
                    <th>存款优惠</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td style="border-right: 1px solid #ccc;">{{item.chargeAmount}}</td>
                    <td>{{item.couponAmount}}</td>
                  </tr>
                </tbody>
              </x-table>


              <div class="consumer-detail_title" v-if="bets">实际有效投注额</div>
              <x-table :cell-bordered="false" style="background-color:#fff;" v-if="bets">
                <thead>
                  <tr style="background-color: #ccc">
                    <th></th>
                    <th></th>
                  </tr>
                </thead>
                <tbody class="effective">
                  <tr>
                    <td style="border-right: 1px solid #ccc;">彩票</td>
                    <td>{{item.lotteryOrderAmount}}</td>
                  </tr>
                </tbody>
              </x-table>


              <div class="consumer-detail_title" v-if="audit">优惠稽核</div>
              <x-table :cell-bordered="false" style="background-color:#fff;"  v-if="audit">
                <thead>
                  <tr style="background-color: #eee">
                    <th>彩票打码量</th>
                    <th>通过</th>
                  </tr>
                </thead>
                <tbody class="effective">
                  <tr>
                    <td style="border-right: 1px solid #ccc;">{{item.lotteryBetAmount}}</td>
                    <td>{{item.lotteryBetAudited ? '是' : '否'}}</td>
                  </tr>
                </tbody>
              </x-table>
              <x-table :cell-bordered="false" style="background-color:#fff;">
                <thead>
                  <tr style="background-color: #eee">
                    <th>综合打码量</th>
                    <th>通过</th>
                  </tr>
                </thead>
                <tbody>
                  <tr class="effective">
                    <td style="border-right: 1px solid #ccc;">{{item.couponBetAmount}}</td>
                    <td>
                      <span v-if="+item.couponBetAudited === 1">通过</span>
                      <span v-else-if="+item.couponBetAudited === 0">不通过</span>
                      <span v-else="+item.couponBetAudited === 3">不需要稽核</span>
                    </td>
                  </tr>
                </tbody>
              </x-table>


              <div class="consumer-detail_title">常态性稽核</div>
              <x-table :cell-bordered="false" style="background-color:#fff;">
                <thead>
                  <tr style="background-color: #eee">
                    <th>标准打码量</th>
                    <th>放宽额度</th>
                    <th>通过</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td style="border-right: 1px solid #ccc;">{{item.auditBetAmount}}</td>
                    <td style="border-right: 1px solid #ccc;">{{item.auditRelaxAmount}}</td>
                    <td>
                      <span v-if="+item.auditBetAudited === 1">通过</span>
                      <span v-else-if="+item.auditBetAudited === 0">不通过</span>
                      <span v-else="+item.auditBetAudited === 3">不需要稽核</span>
                    </td>
                  </tr>
                </tbody>
              </x-table>
              <x-table :cell-bordered="false" style="background-color:#fff;">
                <thead>
                  <tr style="background-color: #eee">
                    <th>需扣除行政费用</th>
                    <th>需扣除金额</th>
                  </tr>
                </thead>
                <tbody>
                  <tr class="effective">
                    <td style="border-right: 1px solid #ccc;">{{item.auditCutFeeFlag ? '需要' : '不需要'}}</td>
                    <td>{{item.auditCutAmount}}</td>
                  </tr>
                </tbody>
              </x-table>
            </div>
          </template>
        </div>
      </section>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
import { Group, XTable } from 'vux'
import * as API from 'api/wapi/user'

export default {
  data () {
    return {
      title: '提现',
      withdrawTime: 0,
      preferentialAudit: 0,
      auditNormality: 0,
      auditBetAudited: 0,
      auditCutPercent: 0,
      couponBetAudited: 0,
      consumptionArr: [],
      bets: true,
      audit: true,
      couponCutAmount: 0,
      feeAmount: 0,
      totalCutAmount: 0
    }
  },
  components: {
    Group, XTable
  },
  mounted () {
    // document.querySelector('.app-layout .app-body').style.paddingTop = window.getComputedStyle(document.querySelector('.app-layout .vux-header'))['height']
    this.getAuditAboutCurrent()
  },
  methods: {

    // 实际有效投注额
    effectiveBets () {
      this.bets = !this.bets
    },

    // 优惠稽核
    preferentialAuditEvent () {
      this.audit = !this.audit
    },

    // 即时稽核查询
    getAuditAboutCurrent () {
      API.auditAboutCurrentGet().then(res => {
        if (!res.error) {
          if (res.result) {
            this.withdrawTime = res.result.withdrawTime
            this.preferentialAudit = res.result.preferentialAudit
            this.auditNormality = res.result.auditNormality
            this.auditBetAudited = res.result.auditBetAudited
            this.auditCutPercent = res.result.auditCutPercent
            this.couponBetAudited = res.result.couponBetAudited
            this.couponCutAmount = res.result.couponCutAmount
            this.totalCutAmount = res.result.totalCutAmount
            this.feeAmount = res.result.feeAmount

            this.consumptionArr = res.result.items
          } else {
            this.withdrawTime = 0
            this.preferentialAudit = 0
            this.auditNormality = 0
            this.auditBetAudited = 0
            this.auditCutPercent = 0
            this.couponBetAudited = 0
            this.consumptionArr = []
          }
        }
      })
    }
  }
}
</script>

<style scoped lang="stylus">
@import "~@/assets/baseStylus/variable"
.page-user_withdrawals-details
  font-size $size-medium
  .consumer-detail__header
    setBottomLine()
    padding rem(20) rem(60)
    b
      background $color-blue-f
      color $color-white
      font-size $size-small
      padding rem(4)
      border-radius rem(5)
  .consumer-detail__con
    padding rem(20) rem(30)
    font-size $size-small-s
    line-height rem(40)
    .color-red
      color: $color-red
  .consumer-detail__topbar
    height rem(40)
    margin rem(20) 0
    line-height rem(40)
    text-align center
  .consumer-detail_title
    text-align center
    line-height rem(80)
    background-color $color-ccc
  .effective
    td
      width 50%
</style>

<style lang="stylus">
@import "~@/assets/baseStylus/variable"
.page-user_withdrawals-details
  .weui-cells:before
    border-top 0
    content ''
  .with-details
    .vux-no-group-title
      margin 0
</style>
