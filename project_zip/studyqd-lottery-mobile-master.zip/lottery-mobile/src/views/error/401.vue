<template>
  <p>401，您无权访问该页！</p>
</template>
<script type="text/ecmascript-6">
  export default {}
</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"
  p
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    font-size: $font-size-large-x;
</style>
