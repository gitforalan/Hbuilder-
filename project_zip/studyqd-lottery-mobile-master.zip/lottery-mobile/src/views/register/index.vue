<!-- Created By fx on 2017/9/4. -->
<template>
  <div class="app-main">
    <div class="app-body">
      <group class="input-group" label-width="4.5em" label-margin-right=".5em" label-align="right" gutter="-1px">
        <x-input title="用户名:" v-model.trim="registerForm.userName" placeholder="4-12位数字/字母或组合" type="text"></x-input>
        <x-input title="密码:" v-model="registerForm.password" placeholder="6-12位数字/字母或组合" type="password"></x-input>
        <x-input title="确认密码:" v-model="registerForm.confirmPassword" placeholder="再次确认密码" type="password"></x-input>
        <x-input title="验证码:" v-model="registerForm.code" placeholder="请输入验证码" type="tel">
          <img slot="right" :src="codeImg" alt="" @click="getCodeImg" width="80" height="30" style="vertical-align: middle">
        </x-input>
      </group>
      <div class="is-agree">
        <check-icon :value.sync="isAgree"><span>我已年满18周岁并接受本站的</span></check-icon>
        <a href="javascript:;" @click="$router.push({ path: '/clause' })">《服务条款》</a>
      </div>
      <div class="btn btn-reg">
        <x-button type="warn" class="btn-submit" :disabled="!isAgree" @click.native="submitForm()">立即注册</x-button>
      </div>
      <!-- <div class="btn btn-free-play">
        <x-button type="default">免费试玩</x-button>
      </div> -->
      <div class="btn-login" align="right" @click="$router.push({ path: '/login', query: { flag: 0 } })">已有账号,直接登录 &gt;</div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import * as API from 'api/wapi/user'
  import { mapMutations } from 'vuex'
  import Encode from '@/utils/sha1'
  export default {
    data () {
      return {
        codeImg: '',
        registerForm: {
          userName: '',
          password: '',
          confirmPassword: '',
          code: '',
          captchaKey: ''
        },
        isAgree: true
      }
    },
    created () {
      this.getCodeImg()
    },
    methods: {
      // 获取验证码
      getCodeImg () {
        this.registerForm.captchaKey = parseInt(Math.random() * 100000000)
        this.codeImg = window.API_PATH + '/cloud/api.do?pa=captcha.next&key=' + this.registerForm.captchaKey
      },
      // 注册
      submitForm () {
        if (this.validateForm()) {
          var params = {
            'host': window.location.hostname,
            'loginId': this.registerForm.userName,
            'password': new Encode().encodeSha1(this.registerForm.password),
            'captchaKey': this.registerForm.captchaKey,
            'captchaCode': this.registerForm.code,
            'regFrom': '8'
          }
          API.register(params).then(res => {
            if (!res.error && res.result) {
              this.setCookieToken({ 'token': res.result.sessionId })
              this.setCookieUserId({ 'userId': res.result.userId })
              this.setCookieUserName({ 'userName': this.registerForm.userName })
              this.setCookieLoginType({ 'loginType': res.result.regType === 'a' ? 'agent' : 'user' })
              this.$router.push({ path: '/home' })
            } else {
              this.$vux.toast.show({
                type: 'warn',
                text: res.error.message
              })
            }
          })
        }
      },
      validateForm () {
        if (!/\S/.test(this.registerForm.userName)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '请输入用户名'
          })
          return false
        } else if (!/^[0-9A-Za-z]{4,12}$/.test(this.registerForm.userName)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '用户名只能输入4-12位数字/字母或组合'
          })
          return false
        }
        if (!/\S/.test(this.registerForm.password)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '请输入密码'
          })
          return false
        } else if (!/^[0-9A-Za-z]{6,12}$/.test(this.registerForm.password)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '密码只能输入6-12位数字/字母或组合'
          })
          return false
        }
        if (!/\S/.test(this.registerForm.confirmPassword)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '请输入确认密码'
          })
          return false
        } else if (this.registerForm.password !== this.registerForm.confirmPassword) {
          this.$vux.toast.show({
            type: 'warn',
            text: '密码2次输入不一致'
          })
          return false
        }
        if (!/\S/.test(this.registerForm.code)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '请输入验证码'
          })
          return false
        }
        return true
      },
      ...mapMutations(['setCookieToken', 'setCookieUserId', 'setCookieUserName', 'setCookieLoginType'])
    }
  }
</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"

  div
    .input-group
      border 1px solid $color-border
      border-bottom none
      margin-top 3rem
      width 90%
      margin-left 5%
    .is-agree
      width 100%
      text-align center
      margin 1rem 0
      span
        color $color-gray-a
      a
        color blue

    .btn
      width rem(546)
      height rem(72)
      line-height rem(72)
      margin 0 auto
      margin-top rem(34)
      button
        font-size $size-small
        height 100%
        overflow visible
    .btn-free-play button
      background transparent
      color: $color-red

    .btn-submit {
      background-color: #f55
    }
    .btn-login
      width rem(546)
      margin 0 auto
      font-size $size-medium
      color #4933f8
      padding-top rem(34)
</style>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .input-group .weui-cells
    font-size $size-medium
    .weui-cell:before
      left 0

  .is-agree
    // .vux-check-icon > .weui-icon-success:before
    // .vux-check-icon > .weui-icon-success-circle:before
    //   color #ccc
    // .vux-check-icon i.weui-icon-success
    //   font-size $size-small-s
    .vux-check-icon .weui-icon-success, .vux-check-icon .weui-icon-circle
      font-size rem(32)
</style>
