<!-- Created By fx on 2017/9/4. -->
<template>
  <div class="app-layout app-main agentReg">
    <x-header class="is-fixed"
    title="代理注册" :left-options="{ backText: '' }">
    </x-header>
    <div class="app-body">
      <group class="input-group" label-width="4.5em" label-margin-right=".5em" label-align="right" gutter="-1px">
        <x-input title="代理账号:" v-model.trim="registerForm.userName" placeholder="4-12位数字/字母或组合" type="text"></x-input>
        <x-input title="登录密码:" v-model="registerForm.password" placeholder="6-12位数字/字母或组合" type="password"></x-input>
        <x-input title="确认密码:" v-model="registerForm.confirmPassword" placeholder="请再次输入密码" type="password"></x-input>
        <x-input title="真实姓名:" v-model="registerForm.realName" placeholder="请输入真实姓名" type="text"></x-input>
        <p class="red">必须与您设置的提款银行账户姓名一致，否则无法提款</p>
        <flexbox class="vux-x-input weui-cell type">
          <span class="left">取款密码：</span>
          <div class="password-no">
            <popup-picker :data="registerForm.listNo" v-model="registerForm.value1" value-text-align="left"></popup-picker>
            <popup-picker :data="registerForm.listNo" v-model="registerForm.value2" value-text-align="left"></popup-picker>
            <popup-picker :data="registerForm.listNo" v-model="registerForm.value3" value-text-align="left"></popup-picker>
            <popup-picker :data="registerForm.listNo" v-model="registerForm.value4" value-text-align="left"></popup-picker>
          </div>
        </flexbox>
        <x-input title="手机号码:" v-model="registerForm.mobile" placeholder="" type="text"></x-input>
        <x-input title="QQ号码:" v-model="registerForm.qq" placeholder="" type="text"></x-input>
        <x-input title="微信:" v-model="registerForm.wechat" placeholder="" type="text"></x-input>
        <x-input title="邮箱:" v-model="registerForm.email" placeholder="格式：tom@QQ.com" type="text"></x-input>
      </group>
      <div class="btn btn-reg">
        <x-button type="warn" class="btn-submit" :disabled="loading" @click.native="submitForm()">确认</x-button>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import * as API from 'api/wapi/user'
  // import { mapMutations } from 'vuex'
  import Encode from '@/utils/sha1'
  import { Flexbox, PopupPicker } from 'vux'
  export default {
    data () {
      return {
        loading: false,
        registerForm: {
          userName: '',
          password: '',
          confirmPassword: '',
          realName: '',
          mobile: '',
          qq: '',
          wechat: '',
          email: '',
          listNo: [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]],
          value1: [0],
          value2: [0],
          value3: [0],
          value4: [0]
        }
      }
    },
    created () {
    },
    components: {
      Flexbox,
      PopupPicker
    },
    methods: {
      reset () {
        this.registerForm.userName = ''
        this.registerForm.password = ''
        this.registerForm.confirmPassword = ''
        this.registerForm.realName = ''
        this.registerForm.mobile = ''
        this.registerForm.qq = ''
        this.registerForm.wechat = ''
        this.registerForm.email = ''
        this.registerForm.value1 = [0]
        this.registerForm.value2 = [0]
        this.registerForm.value3 = [0]
        this.registerForm.value4 = [0]
      },
      getSn () {
        return API.getSn({ host: window.location.hostname })
      },
      async submitForm () {
        if (this.validateForm()) {
          const res = await this.getSn().catch(err => {
            console.error('sn获取错误!')
          })
          if (res.error || !res.result) return
          let newPass = []
          for (let i = 1; i < 5; i++) {
            newPass = newPass.concat(this.registerForm[`value${i}`])
          }
          var params = {
            'sn': res.result,
            'loginId': this.registerForm.userName,
            'password': new Encode().encodeSha1(this.registerForm.password),
            'payPassword': new Encode().encodeSha1(newPass.join('')),
            'mobile': this.registerForm.mobile,
            'qq': this.registerForm.qq,
            'wechat': this.registerForm.wechat,
            'email': this.registerForm.email
          }
          this.loading = true
          API.agentReg(params).then(res => {
            this.loading = false
            if (!res.error) {
              if (+res.result > 0) {
                this.$vux.toast.show({
                  type: 'success',
                  text: '操作成功',
                  time: 2000
                })
                this.reset()
                setTimeout(() => {
                  // this.$router.push({path: '/home'})
                }, 2000)
              } else {
                this.$vux.toast.show({
                  type: 'warn',
                  text: '操作失败'
                })
              }
            } else {
              this.$vux.toast.show({
                type: 'warn',
                text: res.error.message
              })
            }
          })
        }
      },
      validateForm () {
        if (!/\S/.test(this.registerForm.userName)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '请输入用户名'
          })
          return false
        } else if (!/^[0-9A-Za-z]{4,12}$/.test(this.registerForm.userName)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '用户名只能输入4-12位数字/字母或组合'
          })
          return false
        }
        if (!/\S/.test(this.registerForm.password)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '请输入密码'
          })
          return false
        } else if (!/^[0-9A-Za-z]{6,12}$/.test(this.registerForm.password)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '密码只能输入6-12位数字/字母或组合'
          })
          return false
        }
        if (!/\S/.test(this.registerForm.confirmPassword)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '请输入确认密码'
          })
          return false
        } else if (this.registerForm.password !== this.registerForm.confirmPassword) {
          this.$vux.toast.show({
            type: 'warn',
            text: '密码2次输入不一致'
          })
          return false
        }
        if (!/\S/.test(this.registerForm.realName)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '请输入真实姓名'
          })
          return false
        }
        if (!/\S/.test(this.registerForm.email)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '请输入邮箱'
          })
          return false
        } else if (!/^[A-Za-z\d]+([-_.][A-Za-z\d]+)*@([A-Za-z\d]+[-.])+[A-Za-z\d]{2,4}$/.test(this.registerForm.email)) {
          this.$vux.toast.show({
            type: 'warn',
            text: '邮箱格式错误'
          })
          return false
        }
        return true
      }
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .agentReg
    .password-no
      .weui-cell__ft
        display none !important
      display: flex
      justify-content: left
      width: 70%
      margin-left: rem(10)
      .vux-cell-box:before
        border: none
      & > div
        display: flex
        align-items: center
        justify-content: center
        background: $color-eee
        border: 1px solid $color-font-light
        width: rem(60)
        height: rem(60)
        padding: 0
        margin: 0
        text-align: center
        line-height: rem(60)
        margin-right: rem(10)
        font-size rem(24)
    .red
      color $color-red
      setTopLine()
      padding rem(10) rem(10)
      font-size rem(24)
    .input-group
      border 1px solid $color-border
      border-bottom none
      margin-top rem(30)
      width 90%
      margin-left 5%
    .is-agree
      width 100%
      text-align center
      margin 1rem 0
      span
        color $color-gray-a
      a
        color blue

    .btn
      width rem(546)
      height rem(72)
      line-height rem(72)
      margin 0 auto
      margin-top rem(34)
      button
        font-size $size-small
        height 100%
        overflow visible
    .btn-free-play button
      background transparent
      color: $color-red

    .btn-submit {
      background-color: #f55
    }
    .btn-login
      width rem(546)
      margin 0 auto
      font-size $size-medium
      color #4933f8
      padding-top rem(34)
</style>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .input-group .weui-cells
    font-size $size-medium
    .weui-cell:before
      left 0
</style>
