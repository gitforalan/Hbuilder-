<!-- Created By fx on 2017/10/19. -->
<template>
  <section class="live-vedio">
    <canvas id="canvas" ref="canvas" style="background-color: #0D0E1B; width: 100%"></canvas>
  </section>
</template>

<script type="text/ecmascript-6">
  /* eslint-disable */
  export default {
    mounted () {
      const self = this
      let Module = {
        print: (function() {
          return function(text) {
            if (arguments.length > 1) text = Array.prototype.slice.call(arguments).join(' ')
            document.getElementById("logout").innerHTML += text + "<br>"
            console.log(text)
          }
        })(),
        printErr: function(text) {
          if (arguments.length > 1) text = Array.prototype.slice.call(arguments).join(' ')
          document.getElementById("logout").innerHTML += text + "<br>"
          if (0) { // XXX disabled for safety typeof dump == 'function') {
            dump(text + '\n') // fast, straight to the real console
          } else {
            //console.error(text)
          }
        }
      }

      let webGLCanvas = new WebGLCanvas(this.$refs.canvas, Module["noWebGL"], {})
      self.fc = new FlvClient()
      self.fc.videoBuffer = 1
      self.fc.audioBuffer = 12
      if (!FlvClient.prototype.audioContext) {
        window.AudioContext = window.AudioContext || window.webkitAudioContext
        var context = new window.AudioContext()
        initWebAudio()
      }
      var _unlocked = false

      function _playEmptySound () {
        if (context == null) {
          return
        }
        var source = context.createBufferSource()
        source.buffer = context.createBuffer(1, 1, 22050)
        source.connect(context.destination)
        //source.start(0, 0, 0)
        source.start(0)

        FlvClient.prototype.audioContext = context
      }

      //尝试解锁声音
      function _unlock (event) {
        // alert('context state:' + context.state)
        if (_unlocked) {
          return
        }
        context.resume()
        _playEmptySound()
        if (context.state == "running") {
          document.removeEventListener("mousedown", _unlock, true)
          document.removeEventListener("touchend", _unlock, true)
          _unlocked = true
        }
      }

      function initWebAudio () {
        // alert(context.state)
        if (context.state != "running") {
          _unlock() // When played inside of a touch event, this will enable audio on iOS immediately.
          document.addEventListener("mousedown", _unlock, true)
          document.addEventListener("touchend", _unlock, true)
          //var audio = document.createElement("audio")
          //audio.src = "sounds/fish.mp3"
          //audio.play()
        } else {
          FlvClient.prototype.audioContext = context
        }
      }


      onerror = handleErr
      var txt = ""

      function handleErr (msg, url, l) {
        txt = "There was an error on this page.\n\n"
        txt += "Error: " + msg + "\n"
        txt += "URL: " + url + "\n"
        txt += "Line: " + l + "\n\n"
        txt += "Click OK to continue.\n\n"
        document.getElementById("logout").innerHTML += txt + "<br>"
        return true
      }

      function test () {
        //mc.connect("182.16.68.70:81", "live", "")
//        self.fc.play("ws://192.168.2.205:8088/live/user1.flv", webGLCanvas)
//        self.fc.play("ws://flv.foshanmsk.com/live/A01_2.flv", webGLCanvas)
        self.fc.play("ws://flv.foshanmsk.com/live/B02_2.flv", webGLCanvas)
        //mc.connect("113.10.201.210:81", "live", "")
        //mc.connect("123.108.249.106", "live")
        //mc.connect('43.227.97.170:81', 'live')
        self.fc.onNetStatus = function(info) {
          console.log(info.code)
        }
      }

      test()
    },
    beforeDestroy () {
      this.fc && this.fc.close()
    }
  }
</script>

<style scoped lang="stylus">
  .live-vedio
    height rem(500)
</style>
