/**
 * Created by fx on 2017/8/19.
 */
import Index from './index.vue'

export default Index
