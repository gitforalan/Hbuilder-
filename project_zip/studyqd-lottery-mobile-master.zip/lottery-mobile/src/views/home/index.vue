<template>
  <div class="app-main">
    <x-header :left-options="{showBack: false}" @on-click-title="onClickTitle" class="app-header is-fixed" ref="xHeader"
              resetstyle>
      <router-link v-if="!isLogin" :to="{ path: '/login' }" slot="right">登录</router-link>
      <router-link v-if="!isLogin" :to="{ path: '/register' }" slot="overwrite-left">注册</router-link>
      <div class="title-img"><img :src="titleImg" alt="title"></div>
    </x-header>
    <div class="app-body" ref="appBody">
      <!-- 轮播 -->
      <div v-if="items.length" class="slide-wrapper">
        <div class="slide-content">
          <slider ref="slide">
            <div v-for="item in items">
              <a :href="item.linkUrl">
                <img class="needsclick" :src="item.picUrl">
              </a>
            </div>
          </slider>
        </div>
      </div>
      <!-- 公告 -->
      <div class="notice" flex="box:justify cross:center" ref="mainX" v-if="noticeList.length > 0">
        <div class="gong-gao-img" flex="cross:center">
          <icon-svg slot="icon" iconClass="gonggao1"></icon-svg>
        </div>
        <div style="margin-left: .5rem">
          <marquee>
            <marquee-item v-for="i in noticeList" :key="i" class="align-middle" @click.native="showNotice(i, 0)">{{i}}</marquee-item>
          </marquee>
        </div>
        <div flex="cross:center">
          <icon-svg iconClass="right"></icon-svg>
        </div>
      </div>
      <x-dialog v-model="showNoticeLayer" class="showNoticeLayer" @on-hide="noticeLayerHide">
        <div class="dialog-title">公告<span @click="showNoticeLayer = false" class="closeWrap"><x-icon type="ios-close-outline" class="vux-close" style="fill:#9b9b9b" ></x-icon></span></div>
        <div class="img-box">
          {{showNoticeContent}}
        </div>
        <div class="dialog-footer" @click="showNoticeLayer = false">确认</div>
      </x-dialog>
      <!-- nav -->
      <div class="main-nav">
        <ul flex="box:mean" align="center">
          <li>
            <a href="#/user/deposit">
              <p><img slot="icon" src="../../assets/image/icon_recharge_02.png"></p>
              <p>充值</p>
            </a>
          </li>
          <li>
            <a href="#/user/withdrawals">
              <p><img slot="icon" src="../../assets/image/icon_withdraw_02.png"></p>
              <p>提现</p>
            </a>
          </li>
          <li>
            <a href="#/user/betting">
              <p><img slot="icon" src="../../assets/image/icon_betting.png"></p>
              <p>投注纪录</p>
            </a>
          </li>
          <li>
            <a href="javascript:;" @click.stop="customerServiceUrl">
              <p><img slot="icon" src="../../assets/image/icon_help.png"></p>
              <p>在线客服</p>
            </a>
          </li>
        </ul>
      </div>

      <!-- 直播视频 -->
      <!--<live-vedio></live-vedio>-->

      <!--中奖公告-->
      <div class="marquee" flex="">
        <!-- <marquee>
          <marquee-item v-for="i in 5" :key="i">恭喜： ***中奖 <span>1000</span>元{{i}}</marquee-item>
        </marquee> -->
        <p>中奖公告</p>
      </div>
      <!-- 大厅 -->
      <transition-group name="fade" tag="section" class="hall-group" ref="hallGroup" flex="dir:top">
        <div v-for="(row, rowIndex) in lotteryList"
             class="hall-row"
             :class="{'hall-sub-row': row.subRow, 'current': currentRowKey === row.key, 'last': row.lastSubRow && rowIndex !== lotteryList.length - 1}"
             flex="box:mean"
             :key="row.key">
          <div v-for="(col,colIndex) in row.data"
               class="hall-col"
               ref='hallCol'
               :class="{'open-sub-row': isOpenSubRow(row, colIndex)}"
               flex="cross:center dir:left box:first"
               @click.stop="expandCol(row, rowIndex, col, colIndex)">
            <transition name="fade">
              <div>
                <img :src="col.icon" alt="" width="60px" height="60px">
              </div>
            </transition>
            <div>
              <h3 class="title-lg">{{ col.title }}</h3>
              <p class="title-sm ellipsis"><span>{{ col.desc }}</span></p>
            </div>
          </div>
          <div class="hall-col" v-if="(row.data.length % 2 !== 0 )"></div>
        </div>
      </transition-group>
      <!--</scroll>-->

      <sign-redbags ref="signRedbags"></sign-redbags>
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
  import Slider from '@/components/slide/slide'
  import SignRedbags from '@/components/signRedbags/signRedbags'
  import { lotteryListFac } from './hallData'
  import { mapState, mapMutations } from 'vuex'
  import { Marquee, MarqueeItem, cookie, XDialog } from 'vux'
  import * as API from 'api/wapi/front'
  import * as APIUser from 'api/wapi/user'
  // import LiveVedio from './liveVedio' // 直播视频

  let lastId = 0
  export default {
    data () {
      return {
        showNoticeLayer: false,
        fromNoticeLayer: false,
        showNoticeLayerIndex: 0,
        showNoticeContent: '',
        noticeList: [], // 公告, 跑马灯
        noticeListLayer: [], // 公告， 弹窗
        isLogin: false, // 是否登录
        asyncCount: 0,
        notice: '描述文字',
        titleImg: require('../../assets/image/logo.png'),
        showSlide: true,
        sliderAt: 0,
        items: [],
        lotteryList: [],
        time: '',
        openSubRow: {}, // 存子行展开状态
        currentRowKey: 0, // 存当前展开行的key 用做高亮线条样式
        cacheOpenRow: { row: 0, col: 1 }, // 默认,
        openRowDelayTime: 300, // 延迟展开行
        cacheLotteryList: 'CACHE_LOTTERYLIST' // 大厅列表缓存key
      }
    },
    components: { SignRedbags, Slider, Marquee, MarqueeItem, XDialog },
    computed: {
      ...mapState({
        token: state => state.user.token
      })
    },
    methods: {
      showNotice (content, type) {
        if (type === 0) {
          this.fromNoticeLayer = false
          if (this.noticeList[0] !== '暂无任何公告') {
            this.showNoticeLayer = true
          }
        } else {
          this.fromNoticeLayer = true
          this.showNoticeLayer = true
        }
        this.showNoticeContent = content
      },
      noticeLayerHide () {
        // 弹窗只有登录的情况下展示
        this.showNoticeLayerIndex ++
        if (this.showNoticeLayerIndex < this.noticeListLayer.length && this.fromNoticeLayer) {
          this.showNotice(this.noticeListLayer[this.showNoticeLayerIndex])
        }
        if (this.showNoticeLayerIndex === this.noticeListLayer.length) {
          // 关闭完全
        }
        if (this.isLogin) {
          if (!cookie.get('showLoginLayer')) {
            cookie.set('showLoginLayer', 'false', { expires: 30 })
          }
        }
      },
      getHomeNotice () {
        // 获取公告内容
        let resultBack = (res) => {
          let Layerlist = [] // 弹窗数据
          let list = [] // 跑马灯数据
          res.result.items.map(items => {
            let content = JSON.parse(items.content)
            if (items.popupFlag === 'Y') {
              Layerlist.push(content.contentZh)
            } else {
              list.push(content.contentZh)
            }
          })
          this.noticeList = list
          if (this.noticeList.length === 0) {
            this.noticeList = ['暂无任何公告']
          }
          this.noticeListLayer = Layerlist
          if (this.noticeListLayer.length > 0) {
            this.showNoticeLayerIndex = 0
            if (cookie.get('showLoginLayer')) {
              this.noticeListLayer = []
            } else {
              this.showNotice(this.noticeListLayer[0])
            }
          }
        }
        if (this.isLogin) {
          // 登录， 跑马灯和弹窗
          APIUser.GetHomeSystemNotice().then(res => {
            if (!res.error && res.result) {
              resultBack(res)
            } else {
              this.noticeList = []
              this.noticeListLayer = []
            }
          })
        } else {
          // 未登录, 只显示跑马灯
          APIUser.getHomeNotice({ sn: cookie.get('sn'), popupFlag: 'N' }).then(res => {
            if (!res.error && res.result) {
              resultBack(res)
            } else {
              this.noticeList = []
              this.noticeListLayer = []
            }
          })
        }
      },
      getHomeBanner () {
        // 获取图片banner
        let combineData = []

        function getImgFilePath () {
          // 获取图片路径
          return new Promise((resolve, reject) => {
            var imgFilePath = ''
            // 获取图片文件展示路径
            APIUser.getHomeBannerUrl().then(res => {
              imgFilePath = !res.error ? res.result : ''
              resolve(imgFilePath)
            })
          })
        }

        function homeBanner () {
          return new Promise((resolve, reject) => {
            APIUser.getHomeBanner({ host: window.location.hostname, ismobile: 2 }).then(res => {
              if (!res.error && res.result) {
                if (res.result) {
                  resolve(res.result)
                }
              } else {
                reject([])
              }
            })
          })
        }

        return (async () => {
          try {
            let filePath = await getImgFilePath()
            let bannerList = await homeBanner()
            combineData = bannerList.map(items => {
              let path = JSON.parse(items.filePath)
              return {
                linkUrl: items.itemUrl,
                picUrl: filePath + path.filePathZh,
                id: items.id
              }
            })
          } catch (e) {
            combineData = []
          }
          return combineData
        })()
      },
      // 获取sn
      getSn () {
        return APIUser.getSn({ host: window.location.hostname })
      },
      // 大厅列表
      async getLotteryList () {
        let cacheLotteryList = localStorage.getItem(this.cacheLotteryList)
        let versionCode
        if (cacheLotteryList) {
          cacheLotteryList = JSON.parse(cacheLotteryList)
          versionCode = cacheLotteryList.versionCode
          this.lotteryList = cacheLotteryList.lotteryList // 取缓存
          setTimeout(this.openRowFirst, this.openRowDelayTime) // 展开默认
        }
        // 拉取sn -->
        const res = await this.getSn().catch(err => {
          console.error('sn获取错误!')
        })
        if (res.error || !res.result) return // 错误时不继续
        cookie.set('sn', res.result) // {id: "1509447183040", result: "be00", error: null, jsonrpc: "2.0"}
        this.getHomeNotice()
        // <-- 拉取sn
        const query = { versionCode: versionCode }
        API.getLotteryList(query).then(res => {
          // 判断缓存是否有效
          if (versionCode && versionCode === res.data.versionCode) {
            console.log('取缓存list')
            return
          }
          // 处理数据
          this.lotteryList = lotteryListFac(res.data.lotteryTypeList)
          // 写入缓存
          const cacheData = {
            versionCode: res.data.versionCode,
            lotteryList: this.lotteryList
          }
          localStorage.setItem(this.cacheLotteryList, JSON.stringify(cacheData))
          console.log('lotteryList 写入缓存', this.lotteryList)
          setTimeout(this.openRowFirst, this.openRowFirst) // 展开默认
        }).catch(err => {
          this.$vux.toast.show({
            type: 'warn',
            text: err.desc,
            time: 5000
          })
        })
      },
      expandCol (row, rowIndex, col, colIndex) {
        if (col.expand instanceof Array) {
          // 关闭其它子行
          for (let i = this.lotteryList.length - 1; i >= 0; i--) {
            let _row = this.lotteryList[i]
            if (_row.key !== row.key) {
              if (_row.hasOwnProperty('subRow')) {
                this.lotteryList.splice(i, 1)
              } else {
                if (this.openSubRow.hasOwnProperty(_row.key)) {
                  delete this.openSubRow[_row.key]
                }
              }
            }
          }
          // 若已经展开
          if (this.openSubRow[row.key]) {
            if (col.typeId === lastId) {
              for (let r = this.lotteryList.length - 1; r >= 0; r--) {
                let _row = this.lotteryList[r]
                let key = row.key
                if (_row.hasOwnProperty('parentKey') && _row.parentKey === key) {
                  this.lotteryList.splice(r, 1)
                }
              }
              delete this.openSubRow[row.key]
              this.currentRowKey = 0 // 还原标记的key
              return
            }
          }
          let rightMenuArr = [] // 右菜单列表
          // 子项添加到渲染列表
          col.expand.map((v, k) => {
            lastId = col.typeId
            v.subRow = true
            if (k === col.expand.length - 1) v.lastSubRow = true
            v.parentKey = row.key
            this.lotteryList.splice(row.key + k, 0, v)
            v.data.map(i => {
              let obj = {}
              obj.id = i.id
              obj.lotteryName = i.title
              rightMenuArr.push(obj)
            })
          })
          this.set_rightMenu(rightMenuArr)
          this.openSubRow[row.key] = { ci: colIndex } // 标记打开状态 当前列序号ci
          this.currentRowKey = row.key // 当前行的key

          this.$nextTick(() => {
//            const APPBODY_TOP = this.$refs.appBody.offsetTop
            const XHEADER_TOP = this.$refs.xHeader.$el.offsetHeight
            const HALLGROUP_TOP = this.$refs.hallGroup.$el.offsetTop + XHEADER_TOP
            const ROW_HEIGHT = document.querySelector('.hall-row').offsetHeight
            // 当前行底边top
            const rowTop = HALLGROUP_TOP + ROW_HEIGHT * row.key
            // 滚动条位置
            const pageY = window.pageYOffset
            const subRowTotalHeight = col.expand.length * ROW_HEIGHT
            const sY = rowTop + subRowTotalHeight - window.innerHeight - pageY
            if (sY > 0) {
              window.scrollBy(0, sY)
            }
          })
          // 记忆展开的行
          const cacheOpenRow = { row: row.key - 1, col: colIndex }
          sessionStorage.setItem('cacheOpenRow', JSON.stringify(cacheOpenRow))
        } else {
          if (col.expand === 'undefined') return  // 防止接口无数据走跳转
          this.swich_lottery(true) // 暂时用不到了 todo
          // 直播彩票特殊处理
          const spCode = cookie.get('sn')
          const token = cookie.get('token')
          const homeUrl = window.location.host + window.location.pathname
          if (col.id === 'zhubo') {
            if (spCode && token) {
              // 有token带token  没有直接跳
              window.location.href = col.link + `?spCode=${spCode}&token=${token}&homeUrl=${homeUrl}`
            } else {
              window.location.href = col.link
            }
          } else {
            this.$router.push({ name: 'chunkComp', params: { sid: col.id } })
          }
        }
      },
      isOpenSubRow (row, colIndex) {
        const osr = this.openSubRow.hasOwnProperty(row.key) && this.openSubRow[row.key]
        return osr && osr.ci === colIndex && !row.subRow
      },
      // 打开第一行第二个列表
      openRowFirst () {
        let openRow = this.cacheOpenRow
        let _openRow = sessionStorage.getItem('cacheOpenRow')
        _openRow && (openRow = JSON.parse(_openRow))
        const row = this.lotteryList[openRow.row]
        this.expandCol(row, -1, row.data[openRow.col], openRow.col)
      },
      // 在线客服
      customerServiceUrl () {
        var self = this
        var onlineCustomerServiceUrl = cookie.get('onlineCustomerServiceUrl')
        if (!onlineCustomerServiceUrl || !/\S/.test(onlineCustomerServiceUrl)) {
          var params = {
            'domain': window.location.hostname
          }
          APIUser.snInfo(params).then(res => {
            if (!res.error && res.result) {
              self.setCustomerServiceUrl({ 'onlineCustomerServiceUrl': res.result.onlineCustomerServiceUrl })
              window.location.href = res.result.onlineCustomerServiceUrl
            } else {
              self.$vux.toast.show({
                type: 'warn',
                text: res.error.message
              })
            }
          })
        } else {
          window.location.href = onlineCustomerServiceUrl
        }
      },
      // 请缓存小工具 上线前移除 fixme
      onClickTitle () {
        localStorage.clear()
        sessionStorage.clear()
        let keys = document.cookie.match(/[^ =;]+(?=\=)/g) || [] // eslint-disable-line
        for (let key of keys) {
          cookie.remove(key)
        }
        alert('hi~ 此功能仅在测试环境可用\n\n恭喜您：\n缓存清除成功')
      },
      ...mapMutations('pks', ['setCustomerServiceUrl', 'pks_playTabName']),
      ...mapMutations('common', ['set_rightMenu', 'swich_lottery'])
    },
//    beforeRouteLeave (to, from, next) {
//      next()
//    },
    created () {
      this.getLotteryList() // 请求 大厅列表
      this.getHomeBanner().then(res => {
        this.items = res
      })
      // 已登录状态
      var token = cookie.get('token') || ''
      var userName = cookie.get('userName') || ''
      if (/\S/.test(token) && /\S/.test(userName)) {
        this.isLogin = true
      }
    }
  }
</script>

<style scoped lang="stylus">
  @import "~@/assets/baseStylus/variable"
  $t = .3s
  div
  .app-layout
    .showNoticeLayer
      .closeWrap
        width rem(96)
        height rem(96)
        position absolute
        right 0
        top rem(-6)
      .dialog-footer
        text-align center
        font-size rem(36)
        line-height rem(96)
        setTopLine()
        color #3CC51F
      .dialog-title
        position relative
        font-size rem(36)
        line-height rem(96)
        setBottomLine()
      .img-box
        text-align: justify
        max-height: rem(300)
        padding:rem(30) rem(40)
        overflow:scroll
        -webkit-overflow-scrolling:touch
        line-height 1.5
    .title-img
      height rem(88)
      line-height rem(88)
      img
        vertical-align middle
        width rem(140)
        height rem(40)
    .slide-wrapper
      position: relative
      width: 100%
      height: rem(257)
      overflow: hidden
    .slide-content
      position: absolute
      top: 0
      left: 0
      width: 100%
      height: 100%
    .slide-item a img
      height rem(257)
    .notice
      .vux-marquee-box
        li
          text-overflow: ellipsis;
          white-space: nowrap;
          overflow: hidden;
      position relative
      padding 0
      height rem(52)
      line-height rem(52)
      font-size rem(22)
      border-top 1px solid $color-border
      border-bottom 1px solid $color-border
      background $color-white
      box-sizing border-box
      color $color-black-c
      i
        width 1.1rem
        margin-right rem(10)
      .gong-gao-img
        i
          margin-left rem(10)
          margin-right 0
          font-size: rem(18)
          color: #ffb70d
        img
          display inline-block
          margin-left rem(15)
          width rem(30)
          height rem(32)
    .main-nav
      background $color-white
      font-size rem(22)
      color #000
      padding rem(15) 0
      ul li p
        color: #000
        &:first-child
          height: rem(68)
          line-height: rem(80)
        img
          width rem(60)
    .marquee
      height rem(51)
      line-height rem(51)
      padding: 0 rem(10)
      font-size rem(22)
      color $color-black-c
      background #f7f7f7
      border-top 1px solid $color-border
      border-bottom 1px solid $color-border
      box-sizing border-box
      p
        line-height rem(51)
        margin-left rem(17)
    .hall-group
      .hall-row
        transition all $t
        background #fff
        border-bottom 1px solid $color-border
        min-height rem(121)
        width 100%
        z-index 10
        box-sizing border-box
        .hall-col
          position relative
          margin-left rem(40)
          transition background .5s
          border-right 1px solid $color-border
          box-sizing border-box
          div
            .title-lg
              font-size rem(28)
              margin-bottom rem(7)
              color #000
              i
                width 2.3rem
                height .8rem
                padding 0 .2rem
                background #ffb70b
                color $color-white
                font-size $size-medium
                font-style normal
                text-align center
                border-top-left-radius 15px
                border-top-right-radius 25px
                border-bottom-right-radius 25px
            .title-sm
              line-height 1.2em
              font-size rem(22)
              color $color-black-b
            img
              margin-right rem(10)
              width rem(80)
              height rem(80)
              border-radius 1.88rem
          &:active
            background #eee
        .open-sub-row:before, .open-sub-row:after
          content: "";
          border-color: $color-red transparent;
          border-style: solid;
          display: block;
          height: 0;
          font-size: 0;
          line-height: 0;
          width: 0;
          border-width: 0 .5rem .5rem;
          position: absolute;
          z-index: 12;
          bottom: -.05rem;
          left: 50%
          zoom: 12
        .open-sub-row:after
          border-color: transparent transparent;
          bottom: -1px
          left: 50%;
          z-index: 13;
        &.current
          border-bottom 1px solid $color-red
      .hall-sub-row
        background: #f7f7f7
        border-bottom none
        z-index 9
        &.last
          border-bottom 1px solid $color-border
        .hall-col
          border-right none
      & > div:last-child
        border-bottom 0

      .fade-enter
        z-index 1
        opecity 0
        border-bottom 0
        transform translateY(-100%)
      .fade-enter-active
        border-bottom-color transparent !important
      .fade-leave
        z-index 2
        border-bottom-color transparent !important
      .fade-leave-to
        opacity 0
        transform translateY(10%)
      .fade-leave-active
        position absolute
      .fade-move
        transform translateY(0%)
        transition all  $t
</style>

<!--<style lang="stylus">-->
<!--.mint-cell-->
<!--background-color #f7f7f7-->

<!--.mint-cell-allow-right::after-->
<!--width .5rem-->
<!--height .5rem-->
<!--</style>-->

