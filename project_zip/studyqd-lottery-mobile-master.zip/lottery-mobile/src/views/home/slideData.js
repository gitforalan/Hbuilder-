/**
 * Created by fx on 2017/8/23.
 */
/*
 * slider 文档 [https://github.com/warpcgd/vue-concise-slider]
 */
import ad1 from '@/assets/image/ad1.jpg'
import ad2 from '@/assets/image/ad2.jpg'

const slideData = [
  {
    title: '',
    link: '/',
    style: {
      background: `url(${ad2})`
    }
  },
  {
    title: '',
    link: '/401',
    style: {
      background: `url(${ad1})`
    }
  }
]
export default slideData
