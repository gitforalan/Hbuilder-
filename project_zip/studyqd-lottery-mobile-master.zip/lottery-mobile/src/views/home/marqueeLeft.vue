<template>
  <div class="marqueeLeft">
    <div class="font">中奖公告</div>
    <div id="marqueeWrap" class="marqueeWrap">
      <div class="marqueeContent">
        <div id="marqueeHtml">
          <ul>
            <li v-for="items in list" :key="items.name"><a href="javascript:;">恭喜：{{items.name | repl}}中奖 <span>{{items.money}}</span>元</a></li>
          </ul>
        </div>
        <div id="marqueeCopyHtml"></div>
      </div>
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
  import * as API from 'api/wapi/user'
  export default {
    data () {
      return {
        list: [{name: 'weojge', money: '1212'}, {name: '曾送及格过', money: '3434'}]
      }
    },
    mounted () {
      this.getData()
    },
    filters: {
      repl (str) {
        return str.replace(/^(.).*(.)$/, '$1***$2')
      }
    },
    components: {},
    methods: {
      getData () {
        API.getHomePrize({ismobile: 2}).then(res => {
          if (!res.error && res.result) {
            console.log(res.result)
            this.run()
          } else {
            this.list = []
          }
        })
      },
      run () {
        var marqueeWrap = document.getElementById('marqueeWrap')
        let marqueeHtml = document.getElementById('marqueeHtml')
        let marqueeCopyHtml = document.getElementById('marqueeCopyHtml')
        if (this.list.length <= 1) {
          return false
        }
        marqueeCopyHtml.innerHTML = document.getElementById('marqueeHtml').innerHTML
        function Marquee () {
          if (marqueeWrap.scrollLeft - marqueeCopyHtml.offsetWidth >= 0) {
            marqueeWrap.scrollLeft -= marqueeHtml.offsetWidth
          } else {
            marqueeWrap.scrollLeft++
          }
        }
        let scrollLeft = setInterval(Marquee, 30)
        marqueeWrap.onmouseout = function () { scrollLeft = setInterval(Marquee, 40) }
        marqueeWrap.onmouseover = function () { clearInterval(scrollLeft) }
      }
    }
  }
</script>

<style lang="stylus">
  @import "~@/assets/baseStylus/variable"
  .marqueeLeft
    display flex
    line-height rem(52)
    font-size rem(22)
    color $color-black-c
    background #f7f7f7
    padding 0 rem(20)
    border-top 1px solid $color-border
    border-bottom 1px solid $color-border
    .font
      margin-right rem(20)
    .marqueeWrap
      flex 1
      overflow:hidden;
      width:100%;
      .marqueeContent
        width:8000%;
        height rem(51)
        div
          float:left;
      ul
        float:left;
        overflow:hidden;
        zoom:1;
        li
          float:left;
          list-style:none;
          a
            margin-right: rem(30);
</style>
