/**
 * Created by fx on 2017/10/25.
 */

const ROWLEN = 2 // 每行2个td
// 开发环境关闭缓存功能 ↓
// const debug = process.env.NODE_ENV !== 'production'
// if (debug) localStorage.removeItem('CACHE_LOTTERYLIST')
// ↑

/**
 * 引用icon图片资源
 * @param name
 * @return 图片base64(<8kb)、路径
 */
const icon = (sid = -1) => {
  let imgSrc
  try {
    imgSrc = sid === -1
      ? require('@/assets/image/icon.svg') // 无图片临时替代
      : require(`@/assets/image/lottery_${sid}.png`)
  } catch (e) {
    console.log(`图标lottery_${sid}不存在`, e)
    imgSrc = require('@/assets/image/icon.svg')
  }
  return imgSrc
}

/**
 * 彩种    typeId
 * 6hc     20
 * kl8     21
 * kl10    13
 * ksan    12
 * pcdd    15
 * pk10    14
 * ssc     10
 * syx5    11
 * ssl     16
 * pl3     19
 * fc3d    18
 */

/**
 * 行
 */
class Row {
  constructor (key, data = []) {
    this.key = key
    this.data = data
  }
}

/**
 * 单格
 */
// class Td {
//   constructor () {
//     this.icon = -1
//     this.title = ''
//     this.desc = '简介'
//     this.id = -1
//     this.typeId = -1
//     this.expand = null
//   }
// }

/* 数组切片 */
function chunkArray (arr, size) {
  let newArr = []
  for (let i = 0; i < arr.length; i += size) {
    newArr.push(arr.slice(i, i + size))
  }
  return newArr
}

// 处理大厅数据
// 首尾自定义数据
const baseData = {
  firstCol: {
    lotteryList: [{ hotDesc: '看直播有制度' }],
    lotteryTypeId: 'zhubo',
    lotteryTypeName: '直播彩票',
    link: window.LINK_ZHIBO,
    id: 'zhubo',
    show: true
  },
  lastCol: {
    lotteryList: [{ hotDesc: '好运连连' }],
    lotteryTypeId: 'yydb',
    lotteryTypeName: '一元夺宝',
    link: window.LINK_YYDB,
    id: 'yydb',
    show: true
  }
}

function lotteryListFac (data) {
  let listData = []
  let size // 一级列表长度
  // 排序
  // data.sort((a, b) => {
  //   return a.sort - b.sort
  // })
  // 插入头尾自定义数据
  data.unshift(baseData.firstCol)
  data.push(baseData.lastCol)
  // 行分组
  listData = chunkArray(data, ROWLEN)
  size = listData.length
  // 打标识
  listData = listData.map((r, i) => {
    let row = new Row()
    row.key = i + 1
    row.data = r
    // 遍历行
    r.map((c, ci) => {
      // let td = new Td()
      // 子行分组
      let subListData = chunkArray(c.lotteryList, ROWLEN)
      let desc = ''
      // 遍历子行分组
      subListData = subListData.map(sc => {
        let subRow = new Row()
        subRow.key = size + (i + 1) // 子行key
        subRow.data = sc
        sc.map(cc => {
          cc.icon = icon(cc.lotteryId)
          cc.title = cc.lotteryName
          cc.desc = cc.description
          cc.id = cc.lotteryId
          cc.typeId = cc.lotteryTypeId
          if (cc.hotDesc && !desc) desc = cc.hotDesc
        })
        return subRow
      })
      c.icon = icon(c.lotteryTypeId)
      if (c.lotteryTypeName === '分分彩') c.icon = icon(1006) // 分分彩一级图标 取 1006
      c.typeId = c.lotteryTypeId
      c.title = c.lotteryTypeName
      c.desc = desc
      if (!c.show) c.expand = subListData
      return c
    })
    return row
  })
  return listData
}

export { lotteryListFac }

