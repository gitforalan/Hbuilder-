import Vue from 'vue'
import Router from 'vue-router'
import { cookie } from 'vux'

const hotLoad = require('@/utils/import_' + process.env.NODE_ENV)

/* layout */
const Layout = hotLoad('layout/index')
/* home */
const Home = hotLoad('home/index')
/* 大厅 */
const Lottery = hotLoad('lottery/index')
/* ChunkComp 挂载子组件 */
const ChunkComp = hotLoad('lottery/chunkComp')
/* 玩法规则 */
const PlayRule = hotLoad('common/playRule/index')
/* 优惠活动 */
const Gift = hotLoad('gift/index')
const GiftDetail = hotLoad('gift/detail')
/* 走势 */
const Trend = hotLoad('trend/index')
/* 发现 */
const Find = hotLoad('find/index')
const FindList = hotLoad('find/list')
const FindDetail = hotLoad('find/detail')
/* 用户中心 深圳 */
const User = hotLoad('user/index')
const Sign = hotLoad('user/sign/index') // 签到
const Redbags = hotLoad('user/redbags/index') // 红包
const Personal = hotLoad('user/personal/index') // 个人报表
const Betting = hotLoad('user/betting/index') // 投注记录
const NoteSingleDetail = hotLoad('user/betting/noteSingleDetail') // 注单详情
const ChaseNumDetail = hotLoad('user/betting/chaseNumDetail') // 追号注单详情
const ChaseNumNoteSingle = hotLoad('user/betting/chaseNumNoteSingle') // 追号注单列表
const Deposit = hotLoad('user/deposit/index') // 充值
const Paragraph = hotLoad('user/deposit/paragraph') // 充值步骤
const accountDetails = hotLoad('user/account/index') // 账户明细 - 代理-会员
const Withdrawals = hotLoad('user/withdrawals/index') // 提现
const WithdrawalsDetails = hotLoad('user/withdrawals/details') // 提现详情
const Agent = hotLoad('user/agent/index') // 代理中心
const AgentComp = hotLoad('user/agent/agentComp') // 代理模块
const Message = hotLoad('user/message/index') // 我的消息
const LotteryType = hotLoad('user/lotteryType/index') // 彩种信息
const Information = hotLoad('user/information/index') // 个人信息
const InformationSetting = hotLoad('user/information/setting') // 个人信息／设置
const InformationGrade = hotLoad('user/information/grade') // 个人信息／等级头衔
const InformationBankCard = hotLoad('user/information/bankCard') // 个人信息／银行卡
const InformationBankCardSetting = hotLoad('user/information/bankCardSetting') // 个人信息／银行卡／设置
const Security = hotLoad('user/security/index') // 安全设置
const LoginPassword = hotLoad('user/security/loginPassword') // 安全设置／登录密码
const AtmPassword = hotLoad('user/security/atmPassword') // 安全设置／取款密码
const BankInfo = hotLoad('user/withdrawals/bankInfo') // 银行资料
const UserAtmPassword = hotLoad('user/withdrawals/userAtmPassword') // 修改取款密码
const More = hotLoad('user/more/index') // 会员中心更多
const aboutUs = hotLoad('user/more/aboutUs') // 关于我们
const help = hotLoad('user/more/help') // 帮助中心
const bindPhone = hotLoad('user/bind/phone') // 帮助中心
/* login */
const Login = hotLoad('login/index')
const LoginState = hotLoad('login/loginState') // 第三方登录状态
const OldUser = hotLoad('login/oldUser') // 老用户绑定
const MOldUser = hotLoad('login/moldUser') // 老用户绑定 - 短信登录
/* register */
const Register = hotLoad('register/index')
const agentReg = hotLoad('register/agent')
/* 服务条款 */
const Clause = hotLoad('clause/index')
/* error page */
const Navigation = hotLoad('navigation/index')
const Err404 = hotLoad('error/404')
const Err401 = hotLoad('error/401')
Vue.use(Router)

export const constantRouterMap = [
  { path: '/404', component: Err404, name: 'Err404' },
  { path: '/401', component: Err401, name: 'Err401' },
  {
    path: '/',
    component: Layout,
    redirect: '/home',
    name: '首页',
    children: [
      { path: 'home', component: Home, name: 'home', meta: { showBtmBar: true } }
    ]
  },
  {
    path: '/lottery',
    component: Lottery,
    name: 'lottery',
    children: [
      { path: 'playRule', component: PlayRule, name: 'playRule' },
      { path: ':sid', component: ChunkComp, name: 'chunkComp' }
    ]
  },
  {
    path: '/gift',
    component: Gift,
    name: 'gift',
    children: [
      { path: ':sid/:type', component: GiftDetail, name: 'giftDetail' }
    ]
  },
  {
    path: '/trend',
    component: Layout,
    redirect: '/trend/index',
    name: 'trend',
    children: [
      { path: 'index', component: Trend, name: 'trendIndex' }
    ]
  },
  {
    path: '/find',
    component: Layout,
    name: 'find',
    redirect: '/find/index',
    children: [
      { path: 'index', component: Find, name: 'findIndex' },
      { path: '/find/list/:type', component: FindList, name: 'Findlist' },
      { path: '/find/detail/:id', component: FindDetail, name: 'findDetail' }
    ]
  },
  {
    path: '/user',
    component: Layout,
    redirect: '/user/index',
    name: 'user',
    children: [
      { path: 'index', component: User, name: 'userIndex', meta: { showBtmBar: true } },
      { path: 'sign', component: Sign, name: '签到' },
      { path: 'redbags', component: Redbags, name: '我的红包' },
      { path: 'personal', component: Personal, name: '个人报表' },
      { path: 'betting', component: Betting, name: '投注记录' },
      { path: 'noteSingleDetail/:sid', component: NoteSingleDetail, name: '注单详情' },
      { path: 'chaseNumDetail/:sid', component: ChaseNumDetail, name: '追号方案详情' },
      { path: 'chaseNumNoteSingle/:sid', component: ChaseNumNoteSingle, name: '追号注单' },
      { path: 'deposit', component: Deposit, name: 'depositIndex' },
      { path: 'paragraph', component: Paragraph, name: 'paragraph' },
      { path: 'accountDetails', component: accountDetails, name: 'accountDetails' },
      { path: 'withdrawals', component: Withdrawals, name: 'withdrawals' },
      { path: 'withdrawalsDetails', component: WithdrawalsDetails, name: 'withdrawalsDetails' },
      { path: 'bankInfo', component: BankInfo, name: 'bankInfo' },
      { path: 'atmPassword', component: UserAtmPassword, name: 'userAtmPassword' },
      {
        path: 'agent',
        component: Agent,
        name: 'agent',
        children: [
          { path: ':sid', component: AgentComp, name: 'agentComp' }
        ]
      },
      { path: 'message', component: Message, name: 'message' },
      { path: 'lotteryType', component: LotteryType, name: 'lotteryType' },
      { path: 'information', component: Information, name: '个人信息' },
      { path: 'information/setting', component: InformationSetting, name: '个人信息／设置' },
      { path: 'information/grade', component: InformationGrade, name: '个人信息／等级头衔' },
      { path: 'information/bankCard', component: InformationBankCard, name: '个人信息／银行卡' },
      { path: 'information/bankCard/setting', component: InformationBankCardSetting, name: '个人信息／银行卡／设置' },
      { path: 'security', component: Security, name: '安全设置' },
      { path: 'security/loginPassword', component: LoginPassword, name: '安全设置／登录密码' },
      { path: 'security/atmPassword', component: AtmPassword, name: '安全设置／取款密码' },
      { path: 'more', component: More, name: '会员中心/更多' },
      { path: 'aboutUs', component: aboutUs, name: '会员中心/关于我们' },
      { path: 'help', component: help, name: '会员中心/帮助中心' },
      { path: 'bindPhone', component: bindPhone, name: '会员中心/绑定手机' }
    ],
    beforeEnter: (to, from, next) => {
      if (!cookie.get('token') || !/\S/.test(cookie.get('token'))) {
        return Vue.$vux.toast.show({
          type: 'warn',
          isShowMask: true,
          text: '请先登录',
          time: 2000,
          onHide () {
            next('/login')
          }
        })
      }
      next()
    }
  },
  {
    path: '/login',
    component: Login,
    name: 'login',
    beforeEnter: (to, from, next) => {
      // 登录页面访问，默认返回到原页面，直接URL访问返回到首页
      if (!/\S/.test(from.path) || from.path === '/') {
        to.query['flag'] = 0
      }
      next()
    }
  },
  { path: '/loginState', component: LoginState, name: '登录后 - 默认状态' },
  { path: '/oldUser', component: OldUser, name: '老用户绑定' },
  { path: '/moldUser', component: MOldUser, name: '老用户绑定 - 短信登录' },
  { path: '/register', component: Register, name: 'register' },
  { path: '/agentReg', component: agentReg, name: 'agentReg' },
  {
    path: '/clause',
    component: Layout,
    redirect: '/clause/index',
    name: 'clause',
    children: [
      { path: 'index', component: Clause, name: '服务条款' }
    ]
  },
  {
    path: '/navigation',
    component: Navigation,
    name: 'navigation'
  },
  { path: '*', redirect: '/404' }
]

export default new Router({
  mode: 'hash', // 后端支持可开
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRouterMap
})

// export const asyncRouterMap = []
