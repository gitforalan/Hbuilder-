/**
 * Created by fx on 2017/10/26.
 */
// 彩种类型
export default {
  SSC: 10,  // 时时彩
  SYX5: 11, // 11选5
  KSAN: 12, // 快三
  KLSF: 13, // 快乐十分
  PK10: 14, // 北京pk拾
  PCDD: 15, // pc蛋蛋
  SSL: 16,  // 时时乐
  QXC: 17,  // 七星彩
  FC3D: 18, // 福彩3D
  PL3: 19,  // 排列三
  LHC: 20,   // 六合彩
  KL8: 21,   // 快乐8
  YYDB: 'yydb' // 一元夺宝
}
