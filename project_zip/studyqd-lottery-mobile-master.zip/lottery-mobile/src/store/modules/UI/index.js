/**
 * Created by fx on 2017/9/18.
 * UI切换
 */
const UI_ICONROTATE = 'icon_down'
const DOPOPOVERPAGE = 'doPopoverPage' // 是否显示弹出页
const SET_SINGLEROW = 'set_singleRow' // 设置彩期是否单行

const UISTORE = {
  namespaced: true,
  state: {
    icon_isRotate: false,
    showPopoverPage: 0, // 按编号弹出对应页面 0不显示 x显示
    singleRow: false // 控制彩期是否显示一行
  },
  mutations: {
    [UI_ICONROTATE]: (state, data) => {
      state.icon_isRotate = data.rotate
    },
    [DOPOPOVERPAGE]: (state, payload) => {
      state.showPopoverPage = payload
    },
    [SET_SINGLEROW]: (state, payload) => {
      state.singleRow = payload
    }
  },
  actions: {
    // 旋转图标
    ui_icon_rotate: ({ commit }, data) => {
      commit(UI_ICONROTATE, data)
    }
  }
}

export default UISTORE
