const UserInformation = {
  state: {
    activeMenu: null // 设置菜单数据
  },
  mutations: {
    setActiveMenu: (state, data) => {
      state.activeMenu = data.activeMenu
    }
  },
  actions: {
  }
}

export default UserInformation
