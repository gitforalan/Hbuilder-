import { cookie } from 'vux'

const User = {
  state: {
    cookie: {
      showEditPayPassDialog: false, // 是否显示弹窗
      showEditPayPass: '', // 是否修改支付密码
      sn: '',
      token: '', // 用户token令牌（登录后创建）
      userId: '', // 用户ID（登录后创建）
      userName: '', // 用户名称（登录后创建）
      loginType: '', // 用户类型，user:会员／agent:代理（登录后创建）
      imgFilePath: '', // 图片文件展示路径（会员中心创建）
      onlineCustomerServiceUrl: '' // 客服地址
    }
  },
  mutations: {
    setEditPayPassShow: (state, data) => {
      state.cookie.showEditPayPassDialog = data.flag
      cookie.set('showEditPayPassDialog', data.flag, { expires: 30 })
    },
    setCookieEditPayPass: (state, data) => {
      state.cookie.showEditPayPass = data.showEditPayPass
      cookie.set('showEditPayPass', data.showEditPayPass, { expires: 30 })
    },
    setCookieSn: (state, data) => {
      state.cookie.sn = data.sn
      cookie.set('sn', data.sn)
    },
    setCookieToken: (state, data) => {
      state.cookie.token = data.token
      cookie.set('token', data.token)
    },
    delCookieToken: (state, data) => {
      state.cookie.token = ''
      cookie.remove('token')
      state.cookie.showEditPayPassDialog = false
      cookie.remove('showEditPayPassDialog')
      state.cookie.showEditPayPass = ''
      cookie.remove('showEditPayPass')
      cookie.remove('showLoginLayer')
    },
    setCookieUserId: (state, data) => {
      state.cookie.userId = data.userId
      cookie.set('userId', data.userId)
    },
    setCookieUserName: (state, data) => {
      state.cookie.userName = data.userName
      cookie.set('userName', data.userName)
    },
    setCookieLoginType: (state, data) => {
      state.cookie.loginType = data.loginType
      cookie.set('loginType', data.loginType)
    },
    setCookieImgFilePath: (state, data) => {
      state.cookie.imgFilePath = data.imgFilePath
      cookie.set('imgFilePath', data.imgFilePath)
    },
    setCustomerServiceUrl: (state, data) => {
      state.cookie.onlineCustomerServiceUrl = data.onlineCustomerServiceUrl
      cookie.set('onlineCustomerServiceUrl', data.onlineCustomerServiceUrl)
    }
  },
  actions: {
  }
}

export default User
