/**
 * Created by fx on 2017/9/18.
 * 命名空间 ksan
 */

const { log, error } = console // eslint-disable-line
const SET_PLAYTABNAME = 'set_playTabName'
const SET_PLAYNAME = 'set_playName'
const SET_PLAYID = 'set_playId'
const CURRENTPLAY = 'currentPlay'
const CURRENTTAB = 'currentTab' // tab分发到信用玩法
const IS_INPUT = 'is_input'
const IS_SELNUM = 'is_selNum'
const SET_SELECTEDTIMES = 'set_selectedTimes'
const SET_BETNUMBER = 'set_betNumber'
const SET_SINGLEBETMONEY = 'set_singleBetMoney'
const DOCLEARLAYOUT = 'doClearLayout'
const SET_REBATERATE = 'set_rebateRate'
const SET_PLAYTABID = 'set_playTabId'

const STORE = {
  namespaced: true,
  state: {
    currentPlay: null,   // 玩法数据
    currentTab: null,   // tab数据
    isSelNum: false,    // 是否有选号
    isInput: false,     // 是否输入框
    playTabId: -1,  // 玩法一级分类Id
    playTabName: '',  // 玩法一级分类
    playName: '',     // 玩法名
    playId: -1,       // 玩法id
    betNumber: 0,         // 实时注数
    rebateRate: 0,        // 用户选择的返水点
    doClearLayout: false, // 清空选号界面 sync 传行为
    // 信用玩法
    selectedNumber: '', // 已选择号码
    flattenBetList: [], // 注单数据
    clearNow: false, // 通知玩法组件清空号码, true-立即执行,false-不做操作
    betNow: false, // 通知玩法组件发起下注, true-立即执行,false-不做操作
    singleBetMoney: 0, // 筹码金额
    maxSliderVal: 0, // 活动条最大值
    // rebateRate: 0, // 返水点
    isInputStyleFooter: false, // 底部是纯输入的Footer
    isShowBetConfirm: false, // 是否显示投注确认对话
    minChosen: 0, // 最少选择的球数
    isResetRebateRateSlider: false // 通知Footer复位返水活动条
  },
  getters: {
    // 统计金额
    totalBetMoney (state) {
      return state.flattenBetList.map(i => i.singleMoney / 100).reduce((a, b) => +a + +b, 0)
    },
    // 统计注数
    totalBetNumbers (state) {
      return state.flattenBetList.length
    }
  },
  mutations: {
    [CURRENTPLAY]: (state, data) => {
      state.currentPlay = data.play
    },
    [CURRENTTAB]: (state, payload) => {
      state.currentTab = payload
    },
    [IS_INPUT]: (state, data) => {
      state.isInput = data.isInput
    },
    [SET_PLAYTABNAME]: (state, payload) => {
      state.playTabName = payload
    },
    [SET_PLAYNAME]: (state, payload) => {
      state.playName = payload
    },
    [SET_PLAYID]: (state, payload) => {
      state.playId = payload
    },
    [IS_SELNUM]: (state, selArr) => { // 是否选号
      let isSelNum
      for (let i = 0; i < selArr.length; i++) {
        const item = selArr[i]
        if (item.length) {
          isSelNum = true
          break
        }
        isSelNum = false
      }
      state.isSelNum = isSelNum
    },
    [SET_SELECTEDTIMES]: (state, times) => { // 当前倍数
      state.selectedTimes = times
    },
    [SET_BETNUMBER]: (state, num) => { // 实时注数
      state.betNumber = num
    },
    [SET_SINGLEBETMONEY]: (state, money) => { // 单注金额 todo
      state.singleBetMoney = money
    },
    [DOCLEARLAYOUT]: (state) => {
      state.doClearLayout = !state.doClearLayout // 改变值让 playArea 监听到有这个操作
    },
    [SET_REBATERATE]: (state, n) => { // 设置返水
      state.rebateRate = n
    },
    [SET_PLAYTABID]: (state, id) => { // 设置玩法一级分类ID
      state.playTabId = id
    },
    /* 信用玩法 ↓ */
    // 更新注单
    saveFlattenBetList: (state, data) => {
      state.flattenBetList = JSON.parse(JSON.stringify(data.flattenBetList))
    },
    // 开关：清空号码
    setClearNow: (state, data) => { // data:boolean
      state.clearNow = data
    },
    // 开关：下注
    setBetNow: (state, data) => { // data:boolean
      state.betNow = data
    },
    // 更新已选择号码
    updateSelectedNumber: (state, data) => {
      state.selectedNumber = data
    },
    // 更新筹码金额
    updateSingleBetMoney: (state, data) => {
      state.singleBetMoney = data
    },
    // 更新滑动条最大值
    updateMaxSliderVal: (state, data) => {
      state.maxSliderVal = data
    },
    // 更新返水控制 方法和官方玩法里的重复 待优化
    updateRebateRate: (state, data) => {
      state.rebateRate = data
    },
    // 开关：更新底部Footer的样式
    updateInputStyleFooter: (state, data) => { // data:boolean
      state.isInputStyleFooter = data
    },
    // 开关:投注确认对话
    updateShowBetConfirm: (state, data) => { // data:boolean
      state.isShowBetConfirm = data
    },
    // 更新最小选择球输
    updateMinChosen: (state, data) => { // data:number
      state.minChosen = data
    },
    // 开关:是否复位返水滑动条
    updateResetRebateRateSlider: (state, data) => { // data:boolean
      state.isResetRebateRateSlider = data
    }
  }
}

export default STORE
