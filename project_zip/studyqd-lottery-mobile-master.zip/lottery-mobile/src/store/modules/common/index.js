/**
 * Created by fx on 2017/9/18.
 * 命名空间 common
 */
import Vue from 'vue'
import router from '@/router'
import { ToastPlugin } from 'vux'
import * as API from 'api/wapi/front/'

Vue.use(ToastPlugin)

/* 用户 */
const UPDATE_USERINFO = 'update_userInfo'
/* 彩种 */
const COM_LOTTERYTYPEID = 'com_lotteryTypeId'
const COM_LOTTERYID = 'com_lotteryId'
const COM_LOTTERYNAME = 'com_lotteryName'
const SET_PLAYTABMODE = 'set_playTabMode'
const SET_MODEA = 'set_modeA'
const SET_MODEB = 'set_modeB'
const SET_HCSLTS = 'set_hcsLts'
const SET_HCSLTSFLAG = 'set_hcsLtsFlag'
/* cart */
const UPDATE_WTS = 'update_wts'
const UPDATE_TRACELIST = 'update_tracelist'
const ADD_BET = 'add_bet'
const DEL_BET = 'del_bet'
const CLEAR_BET = 'clear_bet'
const OPEN_CART = 'open_cart'
const UPDATE_ISSUE = 'update_issue'
const SET_BUYDOUBLE = 'set_buyDouble'
const RANDOMBETLIST = 'randomBetList' // 随机注数
const SET_REBATESHOW = 'set_rebateShow'
/* 界面通知 */
const NOTICE_ISSUE = 'notice_issue' // 彩期更新派发此通知
const NOTICE_ADDTOCART = 'notice_addToCart' // 添加到购票车派发此通知
const SET_RIGHTMENU = 'set_rightMenu' // 设置右菜单所需的名称和列表
const SWICH_LOTTERY = 'swich_lottery' // 切换彩种
const WITH_DRAWAL = 'with_drawal' // 撤单刷新事件

const COMMONSTORE = {
  namespaced: true,
  state: {
    userInfo: {
      loginId: '',
      uid: '',
      balance: -1,
      status: 0 // 0 未登录 1 已登录
    },
    lotteryTypeId: -1,
    lotteryId: -1,    // 彩种ID
    lotteryName: '',    // 彩种名
    issue: '',       // 彩期
    issueStatus: 1, // 1.正常 2.当期已封盘:当前彩期封盘 3.暂停投注：当前彩种暂停投注
    rebateShow: 0, // 0-可调 1-不可调 2-不显示
    winningToStop: 1,  // 中奖后停止追号
    betList: [],       // 下注信息 ['playId', 'buyCode', 'buyCodeFront', 'singleMoney', 'moneyUnit', 'rebateRate', 'imp', 'buyDouble']
    traceList: [],     // 追号信息 ['issue', 'times']
    playTabMode: 1,    // 1-官方玩法 2-传统玩法，默认官方玩法
    buyDouble: 1,      // 投注倍数
    moneyUnit: 3,      // 1-元/2-角/3-分
    modeA: 200,        // 官方 单注金额
    modeB: -1,         // 信用 单注金额
    hcs: [],          // 冷热
    lts: [],          // 遗漏
    hcsLtsFlag: 0,   // 默认 0冷热 1遗漏
    showCart: false,   // 显示购票车
    randomBetList: -1,      // 随机注数 sync
    noticeIssue: false, // 彩期是否有更新
    noticeAddToCart: false, // 是否触发购票车更新
    rightMenu: [], // 右菜单列表
    swich_lottery: false, // 是否切换彩种
    withdrawal: false // 是否撤单
  },
  getters: {
    lotteryTypeId: state => state.lotteryTypeId,
    issue: state => state.issue,
    lotteryId: state => state.lotteryId,
    lotteryName: state => state.lotteryName,
    playTabMode: state => state.playTabMode,
    rightMenu: state => state.rightMenu,
    swich_lotterys: state => state.swich_lottery,
    totalMoney: state => { // 统计总金额
      if (state.betList.length === 0) return 0
      let arr = state.betList.map(i => i.singleMoney * i.buyCount)
      let totalMoney = arr.reduce((a, b) => (+a) + (+b), 0)
      return totalMoney
    },
    totalTraceMoney: (state, getters) => { // 追号总金额
      let totalMoney = getters.totalMoney
      let traceList = state.traceList
      let times = []
      if (traceList.length) {
        times = traceList.map(i => i.times).reduce((a, b) => a + b, 0)
      }
      if (times) totalMoney = totalMoney * times // 如果有倍数
      return totalMoney
    },
    totalCounts: state => { // 统计总注数
      if (state.betList.length === 0) return 0
      let arr = state.betList.map(i => i.buyCount)
      let totalCounts = arr.reduce((a, b) => (+a) + (+b), 0)
      return totalCounts
    },
    willSubmitData: (state) => { // 过滤出要提交的数据
      let keys = ['playId', 'buyCode', 'buyCodeFront', 'singleMoney', 'moneyUnit', 'rebateRate', 'imp', 'buyDouble']
      let data = state.betList.map(i => {
        let tmp = {}
        keys.forEach(j => {
          if (j in i) {
            tmp[j] = i[j]
          }
        })
        return tmp
      })
      return data
    },
    allNumbers: (state) => { // 用于随机下注去重
      if (state.betList.length === 0) return []
      return state.betList.map(i => {
        return i.buyCode
      })
    }
  },
  mutations: {
    [UPDATE_USERINFO]: (state, data) => { // 存验证结果
      state.userInfo = data
    },
    [COM_LOTTERYTYPEID]: (state, data) => {
      state.lotteryTypeId = data.lotteryTypeId
    },
    [COM_LOTTERYID]: (state, data) => {
      state.lotteryId = data.lotteryId
      // 持久化 lotteryId
      if (data.lotteryId === -1) {
        sessionStorage.removeItem('lotteryId')
      } else {
        sessionStorage.setItem('lotteryId', data.lotteryId)
      }
    },
    [COM_LOTTERYNAME]: (state, payload) => {
      state.lotteryName = payload
    },
    [UPDATE_WTS]: (state, payload) => { // 更新中奖后停止追号
      state.winningToStop = payload
    },
    [UPDATE_TRACELIST]: (state, payload) => { // 更新追号
      let tmp = [].concat(payload)
      state.traceList = tmp
    },
    /* 各种下注操作 */
    [ADD_BET]: (state, payload) => { // 增加一次投注
      let curr = [].concat(state.betList)
      curr.unshift(payload)
      state.betList = curr
    },
    // 删除一次投注
    [DEL_BET]: (state, payload) => {
      // payload:index
      let curr = [].concat(state.betList)
      curr.splice(payload, 1)
      state.betList = curr
    },
    [CLEAR_BET]: (state) => {  // 清空
      state.betList = []
    },
    [SET_PLAYTABMODE]: (state, data) => {
      state.playTabMode = data.playTabMode
    },
    [SET_MODEA]: (state, data) => {
      state.modeA = data.mode
    },
    [SET_MODEB]: (state, data) => {
      state.modeB = data.mode
    },
    [SET_HCSLTS]: (state, data) => {
      state.hcs = data.hcs
      state.lts = data.lts
    },
    [SET_HCSLTSFLAG]: (state, data) => {
      state.hcsLtsFlag = data.flag
    },
    [OPEN_CART]: (state, payload) => { // 是否进入了购票车 true false
      state.showCart = payload
    },
    [UPDATE_ISSUE]: (state, payload) => { // 更新期号
      state.issue = payload
    },
    [SET_BUYDOUBLE]: (state, n) => { // 投注倍数
      state.buyDouble = n
    },
    [RANDOMBETLIST]: (state, n) => { // 随机注数
      state.randomBetList = n
      setTimeout(() => {
        state.randomBetList = -1
      }, 20)
    },
    [NOTICE_ISSUE]: (state, payload) => { // 彩期变化
      state.noticeIssue = payload
    },
    [NOTICE_ADDTOCART]: (state, payload) => { // 购票车变化
      state.noticeAddToCart = payload
    },
    [SET_REBATESHOW]: (state, payload) => { // 返水状态
      state.rebateShow = payload
    },
    [SET_RIGHTMENU]: (state, payload) => { // 右菜单
      state.rightMenu = payload
    },
    [SWICH_LOTTERY]: (state, payload) => { // 右菜单
      state.swich_lottery = payload
    },
    [WITH_DRAWAL]: (state, payload) => {
      state.withdrawal = payload
    }
  },
  actions: {
    // 冷热遗漏
    getLotteryHclt: ({ commit, state }, data) => {
      if (data.lotteryId === -1) {
        console.error('has a bug ->', data)
        return
      }
      const q = { lotteryId: data.lotteryId }
      API.getLotteryHclt(q).then(res => {
        commit(SET_HCSLTS, res.data)
      })
    },
    updateIssue: ({ commit, state }, data) => {
      if (state.issue !== '' && state.issue !== data && state.betList.length) {
        commit(NOTICE_ISSUE, true)
        setTimeout(() => {
          commit(NOTICE_ISSUE, false)
        }, 20)
      }
      commit(UPDATE_ISSUE, data)
    },
    // 随机N注 选好了 会派发此通知 playArea监听到此行为走后续逻辑
    [NOTICE_ADDTOCART]: ({ commit, state }, data) => {
      commit(NOTICE_ADDTOCART, true)
      setTimeout(() => {
        commit(NOTICE_ADDTOCART, false)
      }, 20)
    },
    validaSendBet: ({ commit, state }) => { // 注单统一验证入口
      if (!state.userInfo.status) { // 登录验证未通过
        Vue.$vux.toast.show({
          type: 'warn',
          text: '请先登录',
          time: 2000,
          onHide () {
            router.push({ name: 'login' })
          }
        })
        return Promise.reject('登录失效')
      }
      return Promise.resolve(state.userInfo)
    },
    /* 重置 */
    resetCommonState: ({ commit, state }) => {
      commit(UPDATE_ISSUE, '')
      commit(SET_BUYDOUBLE, 1)
      commit(COM_LOTTERYID, { lotteryId: -1 })
      commit(COM_LOTTERYTYPEID, { lotteryTypeId: -1 })
      commit(COM_LOTTERYNAME, '')
      commit(SET_MODEA, { mode: 200 })
      commit(SET_PLAYTABMODE, { playTabMode: 1 })
      commit(CLEAR_BET)
      commit(OPEN_CART, false)
      commit(SET_HCSLTS, { hcs: [], lts: [] })
      // commit(UPDATE_USERINFO, {
      //   loginId: '',
      //   uid: '',
      //   balance: -1,
      //   status: 0 // 0 未登录 1 已登录
      // })
    }
  }
}
export default COMMONSTORE
