const SET_DATAARR = 'set_dataArr'

const TRENDSTORE = {
  namespaced: true,
  state: {
    dataArr: [] // 走势号码数组
  },
  getters: {
    dataArr: state => state.dataArr
  },
  mutations: {
    [SET_DATAARR]: (state, data) => {
      state.dataArr = data
    }
  }
}

export default TRENDSTORE
