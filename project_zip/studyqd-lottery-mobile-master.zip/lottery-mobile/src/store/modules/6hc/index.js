/**
 * Created by fx on 2017/9/18.
 * 命名空间 lhc
 */

const LHCSTORE = {
  namespaced: true,
  state: {
    playTabName: '', // 玩法大类名称
    playTabId: -1, // 玩法大类ID
    shengxiaoAll: null, // 生肖Map
    selectedNumber: '', // 已选择号码
    flattenBetList: [], // 注单数据
    clearNow: false, // 通知玩法组件清空号码, true-立即执行,false-不做操作
    betNow: false, // 通知玩法组件发起下注, true-立即执行,false-不做操作
    singleBetMoney: 0, // 筹码金额
    maxSliderVal: 0, // 活动条最大值
    rebateRate: 0, // 返水点
    isInputStyleFooter: false, // 底部是纯输入的Footer
    isShowBetConfirm: false, // 是否显示投注确认对话
    minChosen: 0, // 最少选择的球数
    isResetRebateRateSlider: false // 通知Footer复位返水活动条
  },
  getters: {
    // 统计金额
    totalBetMoney (state) {
      return state.flattenBetList.map(i => i.singleMoney / 100).reduce((a, b) => +a + +b, 0)
    },
    // 统计注数
    totalBetNumbers (state) {
      return state.flattenBetList.length
    }
  },
  mutations: {
    // 更新playTabName
    lhc_playTabName: (state, data) => {
      state.playTabName = data.playTabName
    },
    // 更新playTabId
    lhc_playTabId: (state, data) => {
      state.playTabId = data.playTabId
    },
    // 更新生肖信息
    lhc_shengxiao: (state, data) => {
      state.shengxiaoAll = JSON.parse(JSON.stringify(data.shengxiaoAll))
    },
    // 更新注单
    lhc_flattenBetList: (state, data) => {
      state.flattenBetList = JSON.parse(JSON.stringify(data.flattenBetList))
    },
    // 开关：清空号码
    setClearNow: (state, data) => { // data:boolean
      // if (!state.flattenBetList.length) return
      state.clearNow = data
    },
    // 开关：下注
    setBetNow: (state, data) => { // data:boolean
      state.betNow = data
    },
    // 更新已选择号码
    updateSelectedNumber: (state, data) => {
      state.selectedNumber = data
    },
    // 更新筹码金额
    updateSingleBetMoney: (state, data) => {
      state.singleBetMoney = data
    },
    // 更新滑动条最大值
    updateMaxSliderVal: (state, data) => {
      state.maxSliderVal = data
    },
    // 更新返水控制
    updateRebateRate: (state, data) => {
      state.rebateRate = data
    },
    // 开关：更新底部Footer的样式
    updateInputStyleFooter: (state, data) => { // data:boolean
      state.isInputStyleFooter = data
    },
    // 开关:投注确认对话
    updateShowBetConfirm: (state, data) => { // data:boolean
      state.isShowBetConfirm = data
    },
    // 更新最小选择球输
    updateMinChosen: (state, data) => { // data:number
      state.minChosen = data
    },
    // 开关:是否复位返水滑动条
    updateResetRebateRateSlider: (state, data) => { // data:boolean
      state.isResetRebateRateSlider = data
    }
  },
  actions: {}
}

export default LHCSTORE
