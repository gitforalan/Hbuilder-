import Vue from 'vue'
import Vuex from 'vuex'
import common from './modules/common' // 公共变量管理
import ui from './modules/ui' // 控制UI切换
import ssc from './modules/ssc' // 时时彩变量模块
import ssl from './modules/ssl' // 时时乐
import pl3 from './modules/pl3' // 排列3
import fc3d from './modules/fc3d' // 时时乐
import ksan from './modules/ksan' // 快三
import syx5 from './modules/syx5' // 11选5
import lhc from './modules/6hc' // 六合彩变量模块
import pcdd from './modules/pcdd' // PC蛋蛋变量模块
import kl8 from './modules/kl8' // 快乐8变量模块
import kl10 from './modules/kl10' // 快乐十分变量模块
import pks from './modules/pks'
import trend from './modules/trend'
// import createPersistedState from 'vuex-persistedstate' // 持久化 关闭
// import createLogger from 'vuex/dist/logger'
import user from './modules/user' // 会员中心
import userInformation from './modules/user/information' // 会员中心／个人信息

Vue.use(Vuex)
// const debug = process.env.NODE_ENV !== 'production'
// const CACHE_KEY = 'LM_CACHE'
const store = new Vuex.Store({
  modules: {
    common,
    trend,
    ui,
    ssc,
    ksan,
    syx5,
    ssl,
    pl3,
    fc3d,
    pks,
    lhc,
    pcdd,
    kl8,
    kl10,
    user,
    userInformation
  }
  // strict: debug,
  // plugins: debug ? [createLogger(), createPersistedState({
  //   key: CACHE_KEY,
  //   storage: window.sessionStorage
  // })] : [createPersistedState({ storage: window.sessionStorage })]
})

export default store
