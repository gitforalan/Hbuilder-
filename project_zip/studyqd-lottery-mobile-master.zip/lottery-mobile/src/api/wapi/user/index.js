/**
 * Created by fx on 2017/9/6.
 * 命名规范 [有应该->postXXX, 应答默认->getXXX]
 */
import fetch from '../../fetch.js'
import cmdName from './cmdName'
import { commonParams } from './commonParams'

var API_PATH = window.API_PATH

/**
 * 获取图片文件展示路径
 * @param params
 */
export function getImgFilePath (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetImgFilePath,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetImgFilePath,
      'params': params
    })
  })
}

/**
 * 登录
 * @param params
 */
export function login (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.Login,
    method: 'post',
    data: commonParams({
      'method': cmdName.Login,
      'params': params
    }, 'post', false)
  })
}

/**
 * sn
 * @param params
 */
export function getSn (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.getSn,
    method: 'post',
    data: commonParams({
      'method': cmdName.getSn,
      'params': params
    }, 'post', false)
  })
}

/**
 * 注册
 * @param params
 */
export function register (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.Register,
    method: 'post',
    data: commonParams({
      'method': cmdName.Register,
      'params': params
    })
  })
}

/**
 * 代理注册
 * @param params
 */
export function agentReg (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.agentReg,
    method: 'post',
    data: commonParams({
      'method': cmdName.agentReg,
      'params': params
    })
  })
}

/**
 * 登录是否显示代理注册
 * @param params
 */
export function showAgentReg (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.showAgentReg,
    method: 'post',
    data: commonParams({
      'method': cmdName.showAgentReg,
      'params': params
    })
  })
}

/**
 * 退出
 * @param params
 */
export function logout (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.Logout,
    method: 'post',
    data: commonParams({
      'method': cmdName.Logout,
      'params': params
    })
  })
}

/**
 * 获取用户基本信息
 * @param params
 */
export function getUserLoginInfo (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetUserLoginInfo,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetUserLoginInfo,
      'params': params
    })
  })
}

/**
 * 获取用户基本信息
 * @param params
 */
export function getUserProfile (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetUserProfile,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetUserProfile,
      'params': params
    })
  })
}

/**
 * 获取用户账户余额
 * @param params
 */
export function getUserBalance (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetUserBalance,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetUserBalance,
      'params': params
    })
  })
}

/**
 * 获取用户有无支付密码
 * @param params
 */
export function getUserPaypassFlag (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetUserPaypassFlag,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetUserPaypassFlag,
      'params': params
    })
  })
}

/**
 * 修改登录密码
 * @param params
 */
export function updateUserPassword (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.UpdateUserPassword,
    method: 'post',
    data: commonParams({
      'method': cmdName.UpdateUserPassword,
      'params': params
    })
  })
}

/**
 * 设置支付密码
 * @param params
 */
export function resetUserPaypwd (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.ResetUserPaypwd,
    method: 'post',
    data: commonParams({
      'method': cmdName.ResetUserPaypwd,
      'params': params
    })
  })
}

/**
 * 修改支付密码
 * @param params
 */
export function updateUserPaypwd (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.UpdateUserPaypwd,
    method: 'post',
    data: commonParams({
      'method': cmdName.UpdateUserPaypwd,
      'params': params
    })
  })
}

/**
 * 获取晋级活动
 * @param params
 */
export function getActivityPromotion (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetActivityPromotion,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetActivityPromotion,
      'params': params
    })
  })
}

/**
 * 修改用户基本信息
 * @param params
 */
export function updateUserProfile (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.UpdateUserProfile,
    method: 'post',
    data: commonParams({
      'method': cmdName.UpdateUserProfile,
      'params': params
    })
  })
}

/**
 * 获取用户绑定的银行列表
 * @param params
 */
export function getUserWithdrawAccount (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetUserWithdrawAccount,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetUserWithdrawAccount,
      'params': params
    })
  })
}

/**
 * 获取用户银行列表
 * @param params
 */
export function getUserChargeBank (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetUserChargeBank,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetUserChargeBank,
      'params': params
    })
  })
}

/**
 * 更新用户银行信息
 * @param params
 */
export function updateUserBank (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.UpdateUserBank,
    method: 'post',
    data: commonParams({
      'method': cmdName.UpdateUserBank,
      'params': params
    })
  })
}

/** Luis **/
/**
 * // 获取签到和红包个数
 */
export function getSignAndRedbags (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetSignAndRedbags,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetSignAndRedbags,
      'params': params
    })
  })
}

/**
 * // 获取用户红包列表
 */
export function getRedBags (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetRedBagsList,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetRedBagsList,
      'params': params
    })
  })
}

/**
 * // 领取红包
 */
export function doReceiveRedBags (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.doReceiveRedBags,
    method: 'post',
    data: commonParams({
      'method': cmdName.doReceiveRedBags,
      'params': params
    })
  })
}

/** Luis **/
/**
 * // 获取用户签到列表
 */
export function getSign (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetSignList,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetSignList,
      'params': params
    })
  })
}

/**
 * // 获取用户签到内容
 */
export function getSignContent (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetSignContent,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetSignContent,
      'params': params
    })
  })
}

/**
 * // 点击签到
 */
export function doCheckIn (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.doCheckIn,
    method: 'post',
    data: commonParams({
      'method': cmdName.doCheckIn,
      'params': params
    })
  })
}

/**
 * // 获取会员个人总览
 * @param params
 */
export function getUserPersonalTotal (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetUserReportTotal,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetUserReportTotal,
      'params': params
    })
  })
}

/**
 * // 获取会员个人报表
 * @param params
 */
export function getUserPersonalList (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetUserReportList,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetUserReportList,
      'params': params
    })
  })
}

/**
 * // 获取代理个人总览
 * @param params
 */
export function getAgentPersonalTotal (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetAgentReportTotal,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetAgentReportTotal,
      'params': params
    })
  })
}

/**
 * // 获取代理个人报表
 * @param params
 */
export function getAgentPersonalList (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetAgentReportList,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetAgentReportList,
      'params': params
    })
  })
}

/**
 * // 获取彩种
 * @param params
 */
export function getLotteryType (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetLotteryType,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetLotteryType,
      'params': params
    })
  })
}

/**
 * // 获取投注记录列表
 * @param params
 */
export function getBettingRecordList (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetLotteryBettingList,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetLotteryBettingList,
      'params': params
    })
  })
}

/**
 * // 获取追号记录列表
 * @param params
 */
export function getChaseNumRecordList (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetLotteryChaseNumList,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetLotteryChaseNumList,
      'params': params
    })
  })
}

/**
 * // 获取投注记录详情
 */
export function GetLBettingRecordDetail (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetLotteryBettingDetail,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetLotteryBettingDetail,
      'params': params
    })
  })
}

/**
 * // 获取追号记录详情
 */
export function GetLChaseNumRecordDetail (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetLotteryChaseNumDetail,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetLotteryChaseNumDetail,
      'params': params
    })
  })
}

/**
 * // 撤单
 */
export function doOrderCancel (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.doOrderCancel,
    method: 'post',
    data: commonParams({
      'method': cmdName.doOrderCancel,
      'params': params
    })
  })
}

/**
 * // 验证token失效
 */
export function verifyTokenIsFail (params) {
  return fetch({
    url: API_PATH + '/auth/api/' + cmdName.verifyTokenIsFail,
    method: 'post',
    data: commonParams({
      'method': cmdName.verifyTokenIsFail,
      'params': params
    }, 'post', false)
  })
}

/** ivan **/
// 团队报表总览
export function GetTeamReportPreview (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetTeamReportPreview,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetTeamReportPreview,
      'params': params
    })
  })
}

// 团队报表查询
export function GetTeamReportQuery (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetTeamReportQuery,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetTeamReportQuery,
      'params': params
    })
  })
}

// 团队管理
export function GetTeamManagement (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetTeamManagement,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetTeamManagement,
      'params': params
    })
  })
}

// 日工资报表
export function GetDailyWage (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetDailyWage,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetDailyWage,
      'params': params
    })
  })
}

// 日工资期数
export function GetDailyIssue (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetDailyIssue,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetDailyIssue,
      'params': params
    })
  })
}

// 日工资签约
export function GetDailySignList (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetDailySignList,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetDailySignList,
      'params': params
    })
  })
}

// 日工资签约说明
export function GetDailyRate (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetDailyRate,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetDailyRate,
      'params': params
    })
  })
}

// 日工资签约,签约, 重签约
export function DailySign (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.DailySign,
    method: 'post',
    data: commonParams({
      'method': cmdName.DailySign,
      'params': params
    })
  })
}

// 日工资签约， 取消
export function DailySignCacel (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.DailySignCacel,
    method: 'post',
    data: commonParams({
      'method': cmdName.DailySignCacel,
      'params': params
    })
  })
}

// 日工资发起签约
export function DailySendSign (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.DailySendSign,
    method: 'post',
    data: commonParams({
      'method': cmdName.DailySendSign,
      'params': params
    })
  })
}

// 分红报表
export function GetBonusList (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetBonusList,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetBonusList,
      'params': params
    })
  })
}

// 分红期数
export function GetBonusIssue (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetBonusIssue,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetBonusIssue,
      'params': params
    })
  })
}

// 分红报表签约
export function GetBonusSignList (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetBonusSignList,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetBonusSignList,
      'params': params
    })
  })
}

// 分红签约说明
export function GetProfitManaRate (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.getProfitManaRate,
    method: 'post',
    data: commonParams({
      'method': cmdName.getProfitManaRate,
      'params': params
    })
  })
}

// 分红签约， 签约, 重签
export function ProfitSign (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.ProfitSign,
    method: 'post',
    data: commonParams({
      'method': cmdName.ProfitSign,
      'params': params
    })
  })
}

// 分红签约， 取消
export function ProfitSignCacel (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.ProfitSignCacel,
    method: 'post',
    data: commonParams({
      'method': cmdName.ProfitSignCacel,
      'params': params
    })
  })
}

// 分红发起签约
export function ProfitSendSign (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.ProfitSendSign,
    method: 'post',
    data: commonParams({
      'method': cmdName.ProfitSendSign,
      'params': params
    })
  })
}

// 首页未登录公告
export function GetHomeSystemNotice (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetHomeSystemNotice,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetHomeSystemNotice,
      'params': params
    })
  })
}

// 网站公告
export function GetSystemNotice (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetSystemNotice,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetSystemNotice,
      'params': params
    })
  })
}

// 私信
export function GetPersonalNotice (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetPersonalNotice,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetPersonalNotice,
      'params': params
    })
  })
}

// 转账接口
export function addTransfer (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.addTransfer,
    method: 'post',
    data: commonParams({
      'method': cmdName.addTransfer,
      'params': params
    })
  })
}

// 转账接口keyup
export function addTransferKeyUp (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.addTransferKeyUp,
    method: 'post',
    data: commonParams({
      'method': cmdName.addTransferKeyUp,
      'params': params
    })
  })
}

// 返点设置 id name
export function rebateSeeIdName (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.rebateSeeIdName,
    method: 'post',
    data: commonParams({
      'method': cmdName.rebateSeeIdName,
      'params': params
    })
  })
}

// 返点设置key value
export function rebateSeeKeyValue (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.rebateSeeKeyValue,
    method: 'post',
    data: commonParams({
      'method': cmdName.rebateSeeKeyValue,
      'params': params
    })
  })
}

// 修改会员返点设置
export function saveRebateSee (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.saveRebateSee,
    method: 'post',
    data: commonParams({
      'method': cmdName.saveRebateSee,
      'params': params
    })
  })
}

// 彩种列表
export function getLotteryTypeList (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.getLotteryTypeList,
    method: 'post',
    data: commonParams({
      'method': cmdName.getLotteryTypeList,
      'params': params
    })
  })
}

// 优惠列表
export function getCouponList (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.getCouponList,
    method: 'post',
    data: commonParams({
      'method': cmdName.getCouponList,
      'params': params
    }, 'post', false)
  })
}

// 优惠详情
export function getCouponDetail (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.getCouponDetail,
    method: 'post',
    data: commonParams({
      'method': cmdName.getCouponDetail,
      'params': params
    }, 'post', false)
  })
}

// 优惠详情领取按钮
export function getCouponActions (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.getCouponActions,
    method: 'post',
    data: commonParams({
      'method': cmdName.getCouponActions,
      'params': params
    })
  })
}

// 邀请码列表
export function GetCodeList (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.GetCodeList,
    method: 'post',
    data: commonParams({
      'method': cmdName.GetCodeList,
      'params': params
    })
  })
}

// 邀请码增加
export function addCode (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.addCode,
    method: 'post',
    data: commonParams({
      'method': cmdName.addCode,
      'params': params
    })
  })
}

// 邀请码删除
export function deleteCode (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.deleteCode,
    method: 'post',
    data: commonParams({
      'method': cmdName.deleteCode,
      'params': params
    })
  })
}

// 邀请码修改备注
export function editCodeMemo (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.editCodeMemo,
    method: 'post',
    data: commonParams({
      'method': cmdName.editCodeMemo,
      'params': params
    })
  })
}

// 邀请码详情
export function codeDetail (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.codeDetail,
    method: 'post',
    data: commonParams({
      'method': cmdName.codeDetail,
      'params': params
    })
  })
}

// 返点赔率，查询彩种赔率
export function getLotteryPlayList (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.getLotteryPlayList,
    method: 'post',
    data: commonParams({
      'method': cmdName.getLotteryPlayList,
      'params': params
    })
  })
}

// 返点赔率，最高限制
export function getLotteryLimit (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.getLotteryLimit,
    method: 'post',
    data: commonParams({
      'method': cmdName.getLotteryLimit,
      'params': params
    })
  })
}

// 首页banner
export function getHomeBanner (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.getHomeBanner,
    method: 'post',
    data: commonParams({
      'method': cmdName.getHomeBanner,
      'params': params
    }, 'post', false)
  })
}

// 主页公告
export function getHomeNotice (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.getHomeNotice,
    method: 'post',
    data: commonParams({
      'method': cmdName.getHomeNotice,
      'params': params
    }, 'post', false)
  })
}

// 主页中奖公告, 废弃
export function getHomePrize (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.getHomePrize,
    method: 'post',
    data: commonParams({
      'method': cmdName.getHomePrize,
      'params': params
    })
  })
}

// 主页banner url
export function getHomeBannerUrl (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.getHomeBannerUrl,
    method: 'post',
    data: commonParams({
      'method': cmdName.getHomeBannerUrl,
      'params': params
    })
  })
}

// 代理中心，是否有权限看到日工资和分红
export function hasPermission2SalaryBonus (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.hasPermission2SalaryBonus,
    method: 'post',
    data: commonParams({
      'method': cmdName.hasPermission2SalaryBonus,
      'params': params
    })
  })
}

// 团队报表，是否有权限看到转账
export function hasPermission2Transfer (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.hasPermission2Transfer,
    method: 'post',
    data: commonParams({
      'method': cmdName.hasPermission2Transfer,
      'params': params
    })
  })
}
// ----------------------------------
// AL start
// ----------------------------------
/**
 * 账户明细 - 全部
 * @export
 * @param {any} params
 * @returns
 */
export function detailType (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.DetailType,
    method: 'post',
    data: commonParams({
      'method': cmdName.DetailType,
      'params': params
    })
  })
}

/**
 * 账户明细 - 列表表格
 * @export
 * @param {any} params
 * @returns
 */
export function agentDetailList (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.AgentDetailList,
    method: 'post',
    data: commonParams({
      'method': cmdName.AgentDetailList,
      'params': params
    })
  })
}

/**
 * 账户明细 - 列表表格
 * @export
 * @param {any} params
 * @returns
 */
export function userDetailList (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.UserDetailList,
    method: 'post',
    data: commonParams({
      'method': cmdName.UserDetailList,
      'params': params
    })
  })
}

/**
 * 账户余额
 * @export
 * @param {any} params
 * @returns
 */
export function balanceGet (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.BalanceGet,
    method: 'post',
    data: commonParams({
      'method': cmdName.BalanceGet,
      'params': params
    })
  })
}

/**
 * 订单号
 * @export
 * @param {any} params
 * @returns
 */
export function chargeNoGet (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.ChargeNoGet,
    method: 'post',
    data: commonParams({
      'method': cmdName.ChargeNoGet,
      'params': params
    })
  })
}

/**
 * 厅主支持支付入口
 * @export
 * @param {any} params
 * @returns
 */
export function paymentBiglist (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.PaymentBiglist,
    method: 'post',
    data: commonParams({
      'method': cmdName.PaymentBiglist,
      'params': params
    })
  })
}

/**
 * 用户账户第三方支付充值申请
 * @export
 * @param {any} params
 * @returns
 */
export function paymentApply (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.PaymentApply,
    method: 'post',
    data: commonParams({
      'method': cmdName.PaymentApply,
      'params': params
    })
  })
}

/**
 * 分层用于接受入款的账号列表
 * @export
 * @param {any} params
 * @returns
 */
export function accountList (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.AccountList,
    method: 'post',
    data: commonParams({
      'method': cmdName.AccountList,
      'params': params
    })
  })
}

/**
 * 用户充值时支持的银行列表
 * @export
 * @param {any} params
 * @returns
 */
export function bankList (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.BankList,
    method: 'post',
    data: commonParams({
      'method': cmdName.BankList,
      'params': params
    })
  })
}

/**
 * 用户账户转账充值申请
 * @export
 * @param {any} params
 * @returns
 */
export function transferApply (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.TransferApply,
    method: 'post',
    data: commonParams({
      'method': cmdName.TransferApply,
      'params': params
    })
  })
}

/**
 * 获取厅主（简化）信息
 * @export
 * @param {any} params
 * @returns
 */
export function snInfo (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.SnInfo,
    method: 'post',
    data: commonParams({
      'method': cmdName.SnInfo,
      'params': params
    }, 'post', false)
  })
}

/**
 * 查询用户出款银行记录
 * @export
 * @param {any} params
 * @returns
 */
export function withdrawAccountList (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.WithdrawAccountList,
    method: 'post',
    data: commonParams({
      'method': cmdName.WithdrawAccountList,
      'params': params
    })
  })
}

/**
 * 更新用户信息
 * @export
 * @param {any} params
 * @returns
 */
export function bankUpdate (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.BankUpdate,
    method: 'post',
    data: commonParams({
      'method': cmdName.BankUpdate,
      'params': params
    })
  })
}

/**
 * 用户出款金额可选项(有效范围)查询
 * @export
 * @param {any} params
 * @returns
 */
export function withdrawOptionGet (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.WithdrawOptionGet,
    method: 'post',
    data: commonParams({
      'method': cmdName.WithdrawOptionGet,
      'params': params
    })
  })
}

/**
 * 即时稽核查询
 * @export
 * @param {any} params
 * @returns
 */
export function auditAboutCurrentGet (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.AuditAboutCurrentGet,
    method: 'post',
    data: commonParams({
      'method': cmdName.AuditAboutCurrentGet,
      'params': params
    })
  })
}

/**
 * 用户取款申请
 * @export
 * @param {any} params
 * @returns
 */
export function withdrawApply (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.WithdrawApply,
    method: 'post',
    data: commonParams({
      'method': cmdName.WithdrawApply,
      'params': params
    })
  })
}

/**
 * 获取取款申请流水号
 * @export
 * @param {any} params
 * @returns
 */
export function withdrawNoGet (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.WithdrawNoGet,
    method: 'post',
    data: commonParams({
      'method': cmdName.WithdrawNoGet,
      'params': params
    })
  })
}

/**
 * 查询第三方认证的配置
 * @export
 * @param {any} params
 * @returns
 */
export function oauthConfig (params) {
  return fetch({
    // url: 'http://192.168.1.112:8080/oauth/api/query.oauth.config?method=query.oauth.config&jsonrpc=2.0&sn=SP01'
    url: API_PATH + '/cloud/api/' + cmdName.OauthConfig,
    method: 'post',
    data: commonParams({
      'method': cmdName.OauthConfig,
      'params': params
    })
  })
}

/**
 * 判断用户是否登录
 * @export
 * @param {any} params
 * @returns
 */
export function oauthLogin (params) {
  return fetch({
    // url: 'http://192.168.1.112:8080/oauth/api/' + cmdName.OauthLogin,
    url: API_PATH + '/cloud/api/' + cmdName.OauthLogin,
    method: 'post',
    data: commonParams({
      'method': cmdName.OauthLogin,
      'params': params
    })
  })
}

/**
 * 绑定用户
 * @export
 * @param {any} params
 * @returns
 */
export function userBind (params) {
  return fetch({
    // url: 'http://192.168.1.112:8080/oauth/api/' + cmdName.UserBind,
    url: API_PATH + '/cloud/api/' + cmdName.UserBind,
    method: 'post',
    data: commonParams({
      'method': cmdName.UserBind,
      'params': params
    })
  })
}

/**
 * 绑定用户
 * @export
 * @param {any} params
 * @returns
 */
export function userRegiest (params) {
  return fetch({
    // url: 'http://192.168.1.112:8080/oauth/api/' + cmdName.UserRegiest,
    url: API_PATH + '/cloud/api/' + cmdName.UserRegiest,
    method: 'post',
    data: commonParams({
      'method': cmdName.UserRegiest,
      'params': params
    })
  })
}

/**
 * 绑定用户
 * @export
 * @param {any} params
 * @returns
 */
export function optionGet (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.OptionGet,
    method: 'post',
    data: commonParams({
      'method': cmdName.OptionGet,
      'params': params
    })
  })
}

/**
 * 发送验证码
 * @export
 * @param {any} params
 * @returns
 */
export function smsSend (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.SmsSend,
    method: 'post',
    data: commonParams({
      'method': cmdName.SmsSend,
      'params': params
    })
  })
}

/**
 * 验收手机验证码
 * @export
 * @param {any} params
 * @returns
 */
export function smsCheck (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.SmsCheck,
    method: 'post',
    data: commonParams({
      'method': cmdName.SmsCheck,
      'params': params
    })
  })
}

/**
 * 手机号登录
 * @export
 * @param {any} params
 * @returns
 */
export function mobileLogin (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.MobileLogin,
    method: 'post',
    data: commonParams({
      'method': cmdName.MobileLogin,
      'params': params
    })
  })
}

/**
 * 用户是否绑定登陆手机号
 * @export
 * @param {any} params
 * @returns
 */
export function mobileFlag (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.MobileFlag,
    method: 'post',
    data: commonParams({
      'method': cmdName.MobileFlag,
      'params': params
    })
  })
}

/**
 * 判断用户是否是第三方登录
 * @export
 * @param {any} params
 * @returns
 */
export function loginFlag (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.LoginFlag,
    method: 'post',
    data: commonParams({
      'method': cmdName.LoginFlag,
      'params': params
    })
  })
}

/**
 * 判断用户是否登录
 * @export
 * @param {any} params
 * @returns
 */
export function saveState (params) {
  return fetch({
    url: API_PATH + '/cloud/api/' + cmdName.SaveState,
    method: 'post',
    data: commonParams({
      'method': cmdName.SaveState,
      'params': params
    })
  })
}

// ----------------------------------
// AL end
// ----------------------------------
