/**
 * Created by fx on 2017/9/6.
 */
const cmdName = {
  GetImgFilePath: 'open.web.src.uri', // 获取图片文件展示路径
  getSn: 'sn.host.to.sn',
  Login: 'auth.login', // 登录
  showAgentReg: 'sn.settings.get', // 登录是否显示代理注册
  Register: 'auth.reg.login', // 注册
  agentReg: 'agent.reg', // 代理注册
  Logout: 'auth.online.logout', // 退出
  GetUserLoginInfo: 'sn.user.login.info', // 获取用户基本信息
  GetUserProfile: 'user.profile.get', // 获取用户基本信息
  GetUserBalance: 'user.balance.get', // 获取用户账户余额
  GetUserPaypassFlag: 'user.paypass.set.flag', // 获取用户有无支付密码
  UpdateUserPassword: 'user.password.update', // 修改登录密码
  ResetUserPaypwd: 'sn.user.paypwd.reset', // 设置支付密码
  UpdateUserPaypwd: 'user.paypwd.update', // 修改支付密码
  GetActivityPromotion: 'sn.activity.promotion.bysn', // 获取晋级活动
  UpdateUserProfile: 'user.profile.update', // 修改用户基本信息
  GetUserWithdrawAccount: 'user.withdraw.account.list', // 获取用户绑定的银行列表
  GetUserChargeBank: 'user.charge.bank.list', // 获取用户银行列表
  UpdateUserBank: 'user.bank.update', // 更新用户银行信息
  /**
   * Luis
   */
  GetSignAndRedbags: 'sn.activity.statistic.redpacket.user.has.count', // 获取签到和红包个数
  GetRedBagsList: 'sn.activity.set.statistic.redpacket.user.list', // 获取用户红包列表
  doReceiveRedBags: 'sn.activity.statistic.update', // 领取红包
  GetSignList: 'sn.activity.user.signin.query', // 获取用户签到列表
  GetSignContent: 'sn.activity.user.signin.coupon', // 获取用户签到内容
  doCheckIn: 'sn.activity.user.signin', // 点击签到
  GetUserReportTotal: 'sn.user.report.total', // 获取会员个人总览
  GetUserReportList: 'sn.user.report.query', // 获取会员个人报表
  GetAgentReportTotal: 'sn.agent.report.total', // 获取代理个人总览
  GetAgentReportList: 'sn.agent.report.query', // 获取代理个人报表
  GetLotteryType: 'sn.lottery.id.name.mapping', // 获取彩种信息
  GetLotteryBettingList: 'sn.lottery.order.query', // 获取投注记录列表
  GetLotteryChaseNumList: 'sn.lottery.trace.order.query', // 获取追号记录列表
  GetLotteryBettingDetail: 'sn.lottery.order.detail', // 获取投注记录详情
  GetLotteryChaseNumDetail: 'sn.lottery.trace.order.detail', // 获取追号记录详情
  doOrderCancel: 'sn.user.lottery.order.cancel', // 撤单
  verifyTokenIsFail: 'auth.session.validate.flag', // 验证token失效
  /**
   * ivan
   */
  GetTeamReportPreview: 'sn.team.report.total', // 团队报表总览
  GetTeamReportQuery: 'sn.team.report.query', // 团队报表
  GetTeamManagement: 'sn.item.manage.list', // 团队管理
  GetDailyWage: 'sn.report.sn.salary.query', // 日工资报表
  GetDailyIssue: 'sn.report.sn.salary.issue.list', // 日工资期数
  GetDailySignList: 'sn.subagent.salary.sign.query', // 日工资签约
  GetDailyRate: 'sn.agent.salary.sign.config', // 日工资签约说明
  DailySign: 'sn.agent.salary.contract.sign', // 日工资签约， 签约, 重签
  DailySignCacel: 'sn.agent.salary.contract.reply', // 日工资签约， 取消
  DailySendSign: 'sn.agent.salary.contract.get', // 日工资发起签约
  GetBonusList: 'sn.report.sn.bonus.query', // 分红报表
  GetBonusIssue: 'sn.report.bonus.issue.setting.list', // 分红期数
  GetBonusSignList: 'sn.subagent.bonus.sign.query', // 分红报表
  getProfitManaRate: 'sn.agent.bonus.sign.config', // 分红签约说明
  ProfitSign: 'sn.agent.bonus.contract.sign', // 分红签约， 签约, 重签
  ProfitSignCacel: 'sn.agent.bonus.contract.reply', // 分红签约， 取消
  ProfitSendSign: 'sn.agent.bonus.contract.get', // 分红发起签约
  hasPermission2SalaryBonus: 'sn.agent.bonus.salary.permission', // 是否有权限看到日工资和分红
  hasPermission2Transfer: 'sn.agent.transfer.permission', // 是否有权限转账
  GetCodeList: 'sn.agent.code.query', // 邀请码列表
  addCode: 'sn.agent.lottery.code.add', // 邀请码增加
  deleteCode: 'sn.agent.code.delete', // 邀请码删除
  codeDetail: 'sn.agent.lottery.odds.conf.info', // 邀请码详情
  editCodeMemo: 'sn.agent.code.update', // 邀请码备注修改
  GetHomeSystemNotice: 'sn.notice.new.query', // 首页未登录网站公告
  GetSystemNotice: 'sn.notice.full.query', // 网站公告，包含历史数据
  GetPersonalNotice: 'sn.user.notice.query', // 私信
  addTransfer: 'sn.agent.balance.transfer', // 转账操作
  addTransferKeyUp: 'sn.deposit.options.get', // 转账输入发起请求
  rebateSeeIdName: 'sn.lottery.typeid.name.mapping', // 返点设置id，name
  rebateSeeKeyValue: 'sn.agent.lottery.odds.conf', // 根据上面的id找到value
  saveRebateSee: 'sn.user.rebate.conf.update', // 修改用户返点设置
  getLotteryTypeList: 'sn.lottery.play.odds', // 彩种列表
  getCouponList: 'sn.activity.coupon.list', // 优惠活动列表
  getCouponDetail: 'sn.activity.coupon.get', // 优惠活动详情
  getCouponActions: 'sn.activity.set.statistic.request', // 优惠详情领取按钮
  getLotteryPlayList: 'sn.lottery.play.odds.list', // 返点赔率，查询彩种赔率
  getLotteryLimit: 'sn.lottery.user.rebate', // 返点赔率，最高限制
  getHomeBanner: 'sn.slice.list', // 主页banner
  getHomeNotice: 'sn.notice.new.layer.query', // 主页公告
  getHomePrize: 'sn.slice.list', // 主页中奖公告, 废弃
  getHomeBannerUrl: 'bg.web.cdn.uri', // 主页banner url前缀
  /**
   * AL
   */
  DetailType: 'sn.account.detail.type', // 账户明细 - 类型 (agent&member)
  AgentDetailList: 'sn.agent.account.detail.list', // 账户明细 - 表格查询 (agent&member)
  UserDetailList: 'sn.user.account.detail.list', // 账户明细 - 表格查询 （user）
  BalanceGet: 'user.balance.get', // 账户余额
  ChargeNoGet: 'user.charge.no.get', // 获取订单号
  PaymentBiglist: 'sn.payment.biglist', // 厅主支持支付入口
  PaymentApply: 'user.charge.payment.apply', // 用户账户第三方支付充值申请
  AccountList: 'layer.deposit.to.account.list', // 分层用于接受入款的账号列表
  BankList: 'user.charge.bank.list', // 用户充值时支持的银行列表
  TransferApply: 'user.charge.transfer.apply', // 用户账户转账充值申请
  SnInfo: 'sn.info', // 获取厅主（简化）信息
  WithdrawAccountList: 'user.withdraw.account.list', // 查询用户出款银行记录
  BankUpdate: 'user.bank.update', // 更新用户信息
  WithdrawOptionGet: 'user.withdraw.option.get', // 用户出款金额可选项(有效范围)查询
  AuditAboutCurrentGet: 'user.audit.about.current.get', // 即时稽核查询
  WithdrawApply: 'user.withdraw.apply', // 用户取款申请
  WithdrawNoGet: 'user.withdraw.no.get', // 获取取款申请流水号
  OauthConfig: 'query.oauth.config', // 查询第三方认证的配置
  OauthLogin: 'check.oauth.login', // 判断用户是否登录
  UserBind: 'oauth.user.bind', // 绑定用户
  UserRegiest: 'oauth.user.regiest', // 注册用户
  OptionGet: 'user.charge.option.get',
  SmsSend: 'sn.auth.sms.send', // 发送验证码
  SmsCheck: 'sn.auth.sms.check', // 验收手机验证码
  MobileLogin: 'sn.user.mobile.login', // 手机号登录
  MobileFlag: 'sn.user.login.mobile.flag', // 用户是否绑定登陆手机号
  LoginFlag: 'sn.user.oauth.login.flag', // 判断用户是否是第三方登录
  SaveState: 'oauth.user.save.state' // 判断用户是否登录
}

export default cmdName
