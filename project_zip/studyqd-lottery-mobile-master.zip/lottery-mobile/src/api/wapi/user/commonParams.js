import { cookie } from 'vux'
import qs from 'qs'
import merge from 'lodash/merge'

/**
 * 请求参数统一处理／组装
 * @param {*} opts 参数对象
 * @param {*} requestType 请求类型
 * @param {*} defultParams 默认参数
 */
export function commonParams (opts, requestType = 'post', defultParams = true) {
  var params = {
    'json': JSON.stringify(
      merge({
        'id': new Date().getTime(),
        'params': defultParams ? { 'sessionId': cookie.get('token') || 'token' } : {},
        'jsonrpc': '2.0'
      }, opts || {})
    )
  }
  return requestType === 'post' ? qs.stringify(params) : params
}
