/**
 * Created by fx on 2017/9/6.
 * 命名规范 [有应该->postXXX, 应答默认->getXXX]
 */
import fetch from '../../fetch.js'
import cmdName from './cmdName'
import { commonParams } from './commonParams'

export const CODE = 0 //  success CODE

//  mock 配置
//  const ISMOCK = process.env.NODE_ENV !== 'production' ? {baseURL: 'http:// 192.168.198.159/lottery-api/api/local'} : {}

// 重置
const FRONT_BASEURL = { url: process.env.BASE_API }

/**
 * 图形验证码
 * @param query
 */
export function getVcode (query) {
  const params = {}
  params.cmd = cmdName.GetVcode;
  ({
    key: params.key,
    width: params.width, // 单位像素
    height: params.height, // 单位像素
    length: params.length // 图形验证码的长度,即位数
  } = query || {})
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}

/**
 * 会员登陆接口
 * @param query
 */
export function postLogin (query) {
  const params = {}
  params.cmd = cmdName.Login;
  ({
    account: params.account,
    password: params.password,
    captchaKey: params.captchaKey, // 图形验证码key值
    captchaCode: params.captchaCode // 图形验证码code值
  } = query || {})
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}

/**
 * 会员登出接口
 * @param query
 */
export function postLogout (query) {
  const params = {}
  params.cmd = cmdName.Logout
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}

/**
 * 用户token登录
 * @param query
 */
export function getUserAuthValidate (query) {
  const params = {}
  params.cmd = cmdName.UserAuthValidate
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}

/**
 * 彩种列表查询接口
 * @param query
 */
export function getLotteryList (query) {
  const params = {}
  params.cmd = cmdName.LotteryList;
  ({
    versionCode: params.versionCode // versionCode
  } = query || {})
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}

/**
 * 彩种大厅查询接口
 * @param query
 */
export function getLotteryHall (query) {
  const params = {}
  params.cmd = cmdName.LotteryHall;
  ({
    lotteryTypeId: params.lotteryTypeId // 所属彩种类型ID
  } = query || {})
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}

/**
 * 当期彩种详情接口
 * @param query
 */
export function getLotteryCurrentInfo (query) {
  const params = {}
  params.cmd = cmdName.LotteryCurrentInfo;
  ({
    lotteryId: params.lotteryId // 彩种ID
  } = query || {})
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}

/**
 * 当期彩种详情接口
 * @param query
 */
export function getLotterySixPlayOdds (query) {
  const params = {}
  params.cmd = cmdName.LotterySixPlayOdds;
  ({
    playTabId: params.playTabId, // 玩法类别id
    freqType: params.freqType // 频率类型
  } = query || {})
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}

/**
 * 历史开奖信息查询接口
 * @param query
 */
export function getLotteryHistoryOpenInfo (query) {
  const params = {}
  params.cmd = cmdName.LotteryHistoryOpenInfo;
  ({
    lotteryId: params.lotteryId, // 彩种ID
    issueNum: params.issueNum // 查询期数 整数类型
  } = query || {})
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}

/**
 * 彩种类型的玩法及赔率查询接口
 * @param query
 */
export function getLotteryPlayOdds (query) {
  const params = {}
  params.cmd = cmdName.LotteryPlayOdds;
  ({
    lotteryTypeId: params.lotteryTypeId, // 彩种类型ID
    playTabMode: params.playTabMode, // 1-官方玩法 2-传统玩法，默认官方玩法
    versionCode: params.versionCode
  } = query || {})
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}

/**
 * 指定彩种冷热遗漏查询接口（预留）
 * @param query
 */
export function getLotteryHclt (query) {
  const params = {}
  params.cmd = cmdName.LotteryHclt;
  ({
    lotteryId: params.lotteryId // 彩种ID
  } = query || {})
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}

/**
 * 彩期列表查询接口
 * @param query
 */
export function getLotteryIssueList (query) {
  const params = {}
  params.cmd = cmdName.LotteryIssueList;
  ({
    lotteryId: params.lotteryId, // 彩种ID
    searchDate: params.searchDate, // 查询日期 不传或为空时,表示查询当天的所有彩期,否则查询指定日期的所有彩期
    issue: params.issue // 当前期号 不传空为空时,则查询周期内的所有彩期列表,否则查询周期内包含当前期在内的所有彩期列表
  } = query || {})
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}

/**
 * 指定彩种最近一期开奖信息查询接口
 * @param query
 */
export function getLotteryLastOpenInfo (query) {
  const params = {}
  params.cmd = cmdName.LotteryLastOpenInfo;
  ({
    lotteryId: params.lotteryId, // 彩种ID
    issue: params.issue // 当前期号 不传空为空时,则查询周期内的所有彩期列表,否则查询周期内包含当前期在内的所有彩期列表
  } = query || {})
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}

/**
 * 用户下注接口
 * @param query
 */
export function getLotteryUserBet (query) {
  const params = {}
  params.cmd = cmdName.LotteryUserBet;
  ({
    lotteryId: params.lotteryId, // 彩种ID
    issue: params.issue, // 当前期号 不传空为空时,则查询周期内的所有彩期列表,否则查询周期内包含当前期在内的所有彩期列表
    winningToStop: params.winningToStop, // 中奖后是否停止追号 0-否 1-是,默认为是
    betList: params.betList, // 下注信息
    traceList: params.traceList // 追号信息
  } = query || {})
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}

/**
 * 当前用户撤消注单接口
 * @param query
 */
export function getLotteryUserBetCancel (query) {
  const params = {}
  params.cmd = cmdName.LotteryUserBetCancel;
  ({
    items: params.items // 要撤单的数据列表
  } = query || {})
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}

/**
 * 查询投注剩余时间接口
 * @param query
 */
export function getLotteryBetRemainTime (query) {
  const params = {}
  params.cmd = cmdName.LotteryBetRemainTime;
  ({
    lotteryId: params.lotteryId, // 彩种ID
    issue: params.issue // 当前期号 不传空为空时,则查询周期内的所有彩期列表,否则查询周期内包含当前期在内的所有彩期列表
  } = query || {})
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}

/**
 * 彩种首页推荐列表查询接口
 * @param query
 */
export function getLotteryRecommendList (query) {
  const params = {}
  params.cmd = cmdName.LotteryRecommendList
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}

/**
 * 开奖公告查询接口
 * @param query
 */
export function getLotteryResultList (query) {
  const params = {}
  params.cmd = cmdName.LotteryResultList;
  ({
    lotteryId: params.lotteryId, // 彩种ID
    count: params.count // 查询最近开奖的数量，仅在彩种ID必填时有效，默认查询最近10条
  } = query || {})
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}

/**
 * 中奖排行查询接口
 * @param query
 */
export function getLotteryWinRanking (query) {
  const params = {}
  params.cmd = cmdName.LotteryWinRanking
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}

/**
 * 开户配置详情接口
 * @param query
 */
export function getMemberRegConfDetail (query) {
  const params = {}
  params.cmd = cmdName.MemberRegConfDetail;
  ({
    confId: params.confId // 开户配置唯一编号
  } = query || {})
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}

/**
 * 下级开户配置列表查询接口
 * @param query
 */
export function getMemberRegConfList (query) {
  const params = {}
  params.cmd = cmdName.MemberRegConfList;
  ({
    uid: params.uid, // 代理商id，即用户id
    status: params.status // 0-禁用 1-启用
  } = query || {})
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}

/**
 * 下级开户配置创建接口
 * @param query
 */
export function getMemberRegConfCreate (query) {
  const params = {}
  params.cmd = cmdName.MemberRegConfCreate;
  ({
    confType: params.confType, // 配置类型 1-代理 2-玩家
    rebateRateRule: params.rebateRateRule // 用户的所有彩种类型的返水率配置规则
  } = query || {})
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}

/**
 * 注单用户分组统计接口
 * @param query
 */
export function getOrderReportUserGroup (query) {
  const params = {}
  params.cmd = cmdName.OrderReportUserGroup;
  ({
    timeZone: params.timeZone, // 时区，默认为北京时间
    timeType: params.timeType, // 查询的时间类型，默认按下注时间查询
    beginTime: params.beginTime, // 查询的开始时间
    endTime: params.endTime, // 查询的结束时间
    spCode: params.spCode, // 平台商编码 根据平台商查询
    agentId: params.agentId, // 上级代理id 根据代理用户的id查询该代理下的所有直属用户注单
    userId: params.userId // 根据用户id查询该用户的所有注单
  } = query || {})
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}

/**
 * 注单详情接口
 * @param query
 */
export function getOrderDetail (query) {
  const params = {}
  params.cmd = cmdName.OrderDetail;
  ({
    orderCode: params.orderCode // 注单唯一编号
  } = query || {})
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}

/**
 * 走势接口
 * @param query
 */
export function getLotteryTrend (query) {
  const params = {}
  params.cmd = cmdName.LotteryTrend;
  ({
    lotteryId: params.lotteryId, // 彩种id
    periods: params.periods // 期数
  } = query || {})
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}

/**
 * 六合彩走势接口
 * @param query
 */
export function getLotterySixTrend (query) {
  const params = {}
  params.cmd = cmdName.LotterySixTrend;
  ({
    lotteryId: params.lotteryId, // 彩种id
    periods: params.periods // 期数
  } = query || {})
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}

/**
 * 平台商配置信息查询接口
 * @param query
 */
export function getSpLotteryConf (query) {
  const params = {}
  params.cmd = cmdName.SpLotteryConf;
  ({
    lotteryId: params.lotteryId // 彩种id
  } = query || {})
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}

/**
 * 注单明细列表接口
 * @param query
 */
export function getOrderInfoList (query) {
  const params = {}
  params.spCode = commonParams().sn
  params.cmd = cmdName.OrderInfoList;
  ({
    timeZone: params.timeZone, // 时区
    timeType: params.timeType, // 时间类型
    beginTime: params.beginTime, // 查询的开始时间
    endTime: params.endTime, // 查询的结束时间
    agentId: params.agentId, // 上级代理id 根据代理用户的id查询该代理下的所有直属用户注单
    userId: params.userId, // 根据用户id查询该用户的所有注单
    loginId: params.loginId, // 会员用户账号
    orderStatus: params.orderStatus, // 注单状态
    orderCode: params.orderCode, // 注单编号
    lotteryTypeId: params.lotteryTypeId, // 彩种类型ID
    lotteryId: params.lotteryId, // 彩种ID
    issue: params.issue, // 期号
    orderType: params.orderType, // 注单类型 是否为追号注单0-否 1-是
    pageSize: params.pageSize, // 数量
    pageNo: params.pageNo // 页码
  } = query || {})
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}

/**
 * 追号记录
 * @param query
 */
export function getOrderTraceList (query) {
  const params = {}
  params.spCode = commonParams().sn
  params.cmd = cmdName.OrderTraceList;
  ({
    userId: params.userId,
    beginTime: params.beginTime,
    endTime: params.endTime,
    pageSize: params.pageSize,
    pageNo: params.pageNo
  } = query || {})
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}

/**
 * 追号详情
 * @param query
 */
export function getOrderTraceDetail (query) {
  const params = {}
  params.spCode = commonParams().sn
  params.cmd = cmdName.OrderTraceDetail;
  ({
    // spCode: params.spCode,
    traceCode: params.traceCode,
    userId: params.userId
  } = query || {})
  return fetch({
    method: 'post',
    data: Object.assign({}, commonParams(), params),
    ...FRONT_BASEURL
  })
}
