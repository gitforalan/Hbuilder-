/**
 * Created by fx on 2017/9/6.
 */
const cmdName = {
  GetVcode: 'GetVcode', // 图形验证码
  Login: 'Login', // 会员登陆接口
  Logout: 'Logout', // 会员登出接口
  UserAuthValidate: 'UserAuthValidate', // 用户token 验证
  LotteryList: 'LotteryList', // 彩种列表查询接口
  LotteryHall: 'LotteryHall', // 彩种大厅查询接口
  LotteryCurrentInfo: 'LotteryCurrentInfo', // 当期彩种详情接口
  LotteryHistoryOpenInfo: 'LotteryHistoryOpenInfo', // 历史开奖信息查询接口
  LotteryPlayOdds: 'LotteryPlayOdds', // 指定彩种类型的玩法及赔率查询接口
  LotterySixPlayOdds: 'LotterySixPlayOdds', // 六合彩的玩法及赔率查询接口
  LotteryHclt: 'LotteryHclt', // 指定彩种冷热遗漏查询接口（预留）
  LotteryIssueList: 'LotteryIssueList', // 彩期列表查询接口
  LotteryLastOpenInfo: 'LotteryLastOpenInfo', // 指定彩种最近一期开奖信息查询接口
  LotteryUserBet: 'LotteryUserBet', // 用户下注接口
  LotteryUserBetCancel: 'LotteryUserBetCancel', // 当前用户撤消注单接口
  LotteryBetRemainTime: 'LotteryBetRemainTime', // 查询投注剩余时间接口
  LotteryRecommendList: 'LotteryRecommendList', // 彩种首页推荐列表查询接口
  LotteryResultList: 'LotteryResultList', // 开奖公告查询接口
  LotteryWinRanking: 'LotteryWinRanking', // 中奖排行查询接口
  MemberRegConfDetail: 'MemberRegConfDetail', // 开户配置详情接口
  MemberRegConfList: 'MemberRegConfList', // 下级开户配置列表查询接口
  MemberRegConfCreate: 'MemberRegConfCreate', // 下级开户配置创建接口
  OrderInfoList: 'OrderInfoList', // 注单明细列表接口
  OrderReportUserGroup: 'OrderReportUserGroup', // 注单用户分组统计接口
  OrderDetail: 'OrderDetail', // 注单详情接口,
  LotteryTrend: 'LotteryTrend', // 彩种走势接口
  LotterySixTrend: 'LotterySixTrend', // 六合彩走势接口
  SpLotteryConf: 'SpLotteryConf', // 彩种的配置信息
  OrderTraceList: 'OrderTraceList', // 追号记录
  OrderTraceDetail: 'OrderTraceDetail' // 追号详情
}

export default cmdName
