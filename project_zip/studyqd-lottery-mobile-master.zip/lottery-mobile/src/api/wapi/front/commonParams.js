import { cookie } from 'vux'

/**
 * 获取当前系统时间
 * @returns {number}
 */
const getCurrentSystemTime = () => new Date().getTime()

export function commonParams () {
  return {
    channel: 'lotteryMobile',
    clientType: 2,
    identity: getCurrentSystemTime(),
    version: '1.0',
    token: cookie.get('token') || '',
    sn: cookie.get('sn')
  }
}
