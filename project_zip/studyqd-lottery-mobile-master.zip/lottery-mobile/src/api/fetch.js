import axios from 'axios'
import Vue from 'vue'
import { ToastPlugin, cookie } from 'vux'
import router from '@/router'

Vue.use(ToastPlugin)

/**
 * 创建 axios 实例
 * @type {AxiosInstance}
 */
const service = axios.create({
  // baseURL: process.env.BASE_API,
  timeout: 30000
})

/* req拦截器 */
// service.interceptors.request.use((config) => {
//   // config.data = Object.assign({}, config.data, commonParams()) // 带全局参数
//   // console.log('req ', config)
//   return config
// }, (error) => {
//   return Promise.reject(error)
// })

/**
 * respone拦截器
 */
service.interceptors.response.use(
  response => {
    const res = response.data
    if (res.hasOwnProperty('code')) {
      if (res.code === 0) return Promise.resolve(res)
      if (res.code === 1006 || res.code === 1009) {
        setTimeout(() => {
          router.push({ path: '/login' })
          // router.go(0)
        }, 1500)
        Vue.$vux.toast.show({
          type: 'warn',
          text: res.desc,
          time: 1500
        })
      }
      process.env.NODE_ENV !== 'production' && console.error(res)
      // 接口返回错误码时 内部通过catch捕获
      return Promise.reject(res)
    } else {
      // 会员中心, 拦截用户登录有关状态
      if (router.history.current.fullPath !== '/login' && res.error) {
        if (res.error.code === '2202' || res.error.code === '2221') { // 登录超时、token失效
          // 保证message只提示一次
          window.ERROR_STATUS = window.ERROR_STATUS || []
          window.ERROR_STATUS.push(res.error.code)
          if (window.ERROR_STATUS.length === 1) {
            Vue.$vux.toast.show({
              type: 'warn',
              isShowMask: true,
              text: res.error.message,
              time: 1500,
              onHide () {
                cookie.remove('token')
                router.push({ path: '/login' }, () => {
                  window.ERROR_STATUS = []
                })
              }
            })
          }
        } else if (res.error.code === '20001') { // 参数非法字符
          Vue.$vux.toast.show({
            type: 'warn',
            isShowMask: true,
            text: res.error.message,
            time: 1500
          })
        }
        return Promise.resolve(res)
      } else {
        return Promise.resolve(res)
      }
    }
  },
  error => {
    // 网络异常提示
    const netError = { desc: '网络异常，<br>请稍后重试！' }
    Vue.$vux.toast.show({
      type: 'warn',
      text: `<span style="font-size: .8rem">${netError.desc}</span>`,
      time: 5000
    })
    return Promise.reject(netError)
  }
)

export default service
