<template>
  <div id="app">
    <router-view></router-view>
    <confirm class="showEditPayPass" v-model="$store.state.user.cookie.showEditPayPassDialog"
      title="为保障您的资金安全，请及时修改支付密码！"
      confirm-text="修改"
      @on-confirm="editPayPassConfirm"
      @on-cancel="editPayPassCancel">
      <p><check-icon :value.sync="showEditPayPassChecked">不再提示</check-icon></p>
    </confirm>
  </div>
</template>

<script>
import { Confirm, Checklist, cookie, CheckIcon } from 'vux'
import { mapMutations } from 'vuex'
import * as API from 'api/wapi/user'
export default {
  name: 'app',
  data () {
    return {
      showEditPayPassChecked: false
    }
  },
  components: {
    Confirm, Checklist, CheckIcon
  },
  mounted () {
    this.userCenterAction()
    this.existEditPayPass()
  },
  watch: {
    $route (to, from) {
      this.userCenterAction()
      this.existEditPayPass()
    }
  },
  methods: {
    editPayPassConfirm () {
      const path = this.$route
      this.$router.push({path: '/user/security/atmPassword', query: { redirect: path.fullPath }})
    },
    editPayPassCancel () {
      if (this.showEditPayPassChecked) {
        this.setEditPayPassShow({flag: false})
      }
    },
    userCenterAction (type) {
      const routerPath = this.$route.path
      if (routerPath.includes('user')) {
        if (type === 0) {
          this.setEditPayPassShow({flag: true})
        } else {
          if (cookie.get('showEditPayPassDialog') === 'true' && +cookie.get('showEditPayPass') === 0) {
            this.setEditPayPassShow({flag: true})
          }
        }
      }
    },
    existEditPayPass () {
      // 获取用户有无支付密码
      const routerPath = this.$route.path
      if (routerPath.includes('user')) {
        if (!cookie.get('showEditPayPass') || cookie.get('showEditPayPass') === 'undefined' || cookie.get('showEditPayPass') === 'null') {
          API.getUserPaypassFlag().then(res => {
            if (!res.error && +(res.result) === 1) {
              this.setCookieEditPayPass({showEditPayPass: 1})
            } else {
              this.showEditPayPassChecked = false
              this.setCookieEditPayPass({showEditPayPass: 0})
              this.userCenterAction(0)
            }
          })
        }
      }
    },
    ...mapMutations(['setEditPayPassShow', 'setCookieEditPayPass'])
  }
}
</script>

<style lang="stylus">
  .showEditPayPass {
    .weui-cells {
      &:before, &:after {
        display: none
      }
      .weui-check_label {
        text-align center
      }
    }
  }
</style>
