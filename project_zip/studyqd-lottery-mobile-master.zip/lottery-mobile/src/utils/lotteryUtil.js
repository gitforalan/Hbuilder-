/**
 * Created by fx on 2017/9/27.
 */
/* eslint-disable */
const random = require('lodash/random')

/* 随机数范围 fx */
export function getRandomInt (min, max) {
  return Math.floor(Math.random() * (max - min)) + min;
}

/* 随机数组不重复 fx */
export function getRandomArray (array, length) {
  let newArray = [];
  for (let i = 0; i < array.length; i++) {
    newArray.push(array[i]);
  }
  
  let arrayBack = [];
  for (let i = 0; i < length; i++) {
    let random = getRandomInt(0, newArray.length);
    let randomNum = newArray[random];
    arrayBack.push(randomNum);
    newArray.splice(random, 1);
  }
  return arrayBack;
}

/**
 * 生成identity随机长度数字
 * @return {Number}
 */
export function generateIdentity () {
  let arr = new Array(random(5, 9))
  for (let i = 0; i < arr.length; i++) {
    arr[i] = random(9)
  }
  return +arr.join('')
}

/**
 * 生成验证码随机key
 * @return {[Number]}
 */
export function generateCaptchaKey () {
  return parseInt(Math.random() * Date.now())
}

/**
 * 从原数组中递归过滤有效数据，返回新数组
 * @param  {[Arra}
 * @return {Array}
 */
export function recursiveData (label) {
  return label.filter(j => {
    if (!j.isopen) return false;
    if (j.label) {
      // 第三层
      j.label = recursiveData(j.label)
    }
    return true
  })
}

/**
 * 从LS中获取皮肤类名
 *
 * @param  {String}
 * @return {String}
 */
export function getLocalSkin (skinStr) {
  let localSkin = localStorage.getItem('skin')
  if (localSkin !== null) return localSkin;
  else return '';
}

/**
 * 根据key获取缓存
 * @param  {String} cacheKey
 * @return {[Object | null]}
 */
export function checkCache (cacheKey) {
  let cache, s = localStorage[cacheKey]
  if (!s) return null;
  try {
    cache = JSON.parse(s)
  } catch (err) {
    console.log('缓存数据解析错误')
    localStorage.removeItem(cacheKey)
    return null
  }
  return cache
}

/**
 * 精确乘法计算
 */
export function accMul (arg1, arg2) {
  var m = 0,
    s1 = arg1.toString(),
    s2 = arg2.toString();
  try {
    m += s1.split(".")[1].length;
  } catch (e) {
  }
  try {
    m += s2.split(".")[1].length;
  } catch (e) {
  }
  return Number(s1.replace(".", "")) * Number(s2.replace(".", "")) / Math.pow(10, m);
}

/**
 * 组合算法
 */
export function Combination (c, b) {
  let i
  b = parseInt(b);
  c = parseInt(c);
  if (b < 0 || c < 0) {
    return false;
  }
  if (b == 0 || c == 0) {
    return 1
  }
  if (b > c) {
    return 0
  }
  if (b > c / 2) {
    b = c - b
  }
  var a = 0;
  for (i = c; i >= (c - b + 1); i--) {
    a += Math.log(i)
  }
  for (i = b; i >= 1; i--) {
    a -= Math.log(i)
  }
  a = Math.exp(a);
  return Math.round(a)
}

export function getCombination (o, c) {
  var l = o.length;
  var r = new Array();
  var f = new Array();
  if (c > l) {
    return r
  }
  if (c == 1) {
    return o
  }
  if (l == c) {
    r[0] = o.join(",");
    return r
  }
  var a = "";
  var b = "";
  var s = "";
  for (var g = 0; g < c; g++) {
    a += "1";
    b += "1"
  }
  for (var e = 0; e < l - c; e++) {
    a += "0"
  }
  for (var d = 0; d < c; d++) {
    s += o[d] + ","
  }
  r[0] = s.substr(0, s.length - 1);
  var h = 1;
  s = "";
  while (a.substr(a.length - c, c) != b) {
    a = movestring(a);
    for (var d = 0; d < l; d++) {
      if (a.substr(d, 1) == "1") {
        s += o[d] + ","
      }
    }
    r[h] = s.substr(0, s.length - 1);
    s = "";
    h++
  }
  return r
}

function movestring (a) {
  var h = "";
  var k = "01";
  var b = "";
  var f = "";
  var j = "";
  var g = false;
  var c = false;
  for (var e = 0; e < a.length; e++) {
    if (g == false) {
      h += a.substr(e, 1)
    }
    if (g == false && a.substr(e, 1) == "1") {
      c = true
    } else {
      if (g == false && c == true && a.substr(e, 1) == "0") {
        g = true
      } else {
        if (g == true) {
          b += a.substr(e, 1)
        }
      }
    }
  }
  h = h.substr(0, h.length - 2);
  for (var d = 0; d < h.length; d++) {
    if (h.substr(d, 1) == "1") {
      f += h.substr(d, 1)
    } else {
      if (h.substr(d, 1) == "0") {
        j += h.substr(d, 1)
      }
    }
  }
  h = f + j;
  return h + k + b
}

/**
 * 检测
 */
Array.intersect = function(d, c) {
  return d.uniquelize().each(function(a) {
    return c.contains(a) ? a : null
  })
};
Array.prototype.each = function(f) {
  f = f || Function.K;
  var b = [];
  var c = Array.prototype.slice.call(arguments, 1);
  for (var e = 0; e < this.length; e++) {
    var d = f.apply(this, [this[e], e].concat(c));
    if (d != null) {
      b.push(d)
    }
  }
  return b
};
Array.prototype.uniquelize = function() {
  var b = new Array();
  for (var a = 0; a < this.length; a++) {
    if (!b.contains(this[a])) {
      b.push(this[a])
    }
  }
  return b
};
Array.complement = function(d, c) {
  return Array.minus(Array.union(d, c), Array.intersect(d, c))
};
Array.intersect = function(d, c) {
  return d.uniquelize().each(function(a) {
    return c.contains(a) ? a : null
  })
};
Array.minus = function(d, c) {
  return d.uniquelize().each(function(a) {
    return c.contains(a) ? null : a
  })
};
Array.union = function(d, c) {
  return d.concat(c).uniquelize()
};
Array.randDiff = function(a, b) {
  var c = new Array();
  var r = 0;
  if (a.length < b) {
    return c;
  } else if (a.length == b) {
    return a;
  }
  for (var i = 0; i < b; i++) {
    r = parseInt(Math.random() * a.length);
    while (c.contains(a[r])) {
      r = parseInt(Math.random() * a.length);
    }
    c.push(a[r]);
  }
  return c;
};
Array.prototype.contains = function(b) {
  for (var a = 0; a < this.length; a++) {
    if (this[a] == b) {
      return true;
    }
  }
  return false;
};
Array.prototype.remove = function(b) {
  for (var a = 0; a < this.length; a++) {
    if (this[a] == b) {
      this.splice(a, 1)
    }
  }
}
