function timeConversions (time) {
  let outTime = ''
  let day
  let hour
  let min
  let sec
  if (time < 60 || time === 60) {
    sec = time
    outTime = sec + '秒'
  } else if (time < 3600 || time === 3600) {
    min = converMin(time)
    sec = time - (min * 60)
    outTime = min + '分钟' + sec + '秒'
  } else if (time < 86400 || time === 86400) {
    hour = converHour(time)
    min = converMin(time - (hour * 3600))
    sec = time - (hour * 3600) - (min * 60)
    outTime = hour + '小时' + min + '分钟' + sec + '秒'
  } else if (time > 86400) {
    day = converDay(time)
    hour = converHour(time - (day * 86400))
    min = converMin(time - (day * 86400) - (hour * 3600))
    sec = time - (day * 86400) - (hour * 3600) - (min * 60)
    outTime = day + '天' + hour + '小时' + min + '分钟' + sec + '秒'
  }

  return outTime

  // 分转换
  function converMin (val) {
    let min = parseInt(val / 60)
    return min
  }

  // 时转换
  function converHour (val) {
    let hour = parseInt(val / 3600)
    return hour
  }

  // 天转换
  function converDay (val) {
    let day = parseInt(val / 86400)
    return day
  }
}

function dateConversions (time) {
  let outTime = ''
  let hour
  let min
  let sec
  if (time < 60) {
    sec = time
    outTime = '0:' + '0:' + sec
  } else if (time < 3600) {
    min = converMin(time)
    sec = time - (min * 60)
    outTime = '0:' + min + ':' + sec
  } else if (time < 86400) {
    hour = converHour(time)
    min = converMin(time - (hour * 3600))
    sec = time - (hour * 3600) - (min * 60)
    outTime = hour + ':' + min + ':' + sec
  } else if (time > 86400 || time === 86400) {
    hour = converHour(time)
    min = converMin(time - (hour * 3600))
    sec = time - (hour * 3600) - (min * 60)
    outTime = hour + ':' + min + ':' + sec
  }

  outTime = outTime.split(':')

  for (let i = 0; i < outTime.length; i++) {
    if (outTime[i] < 10 && outTime[i] >= 0) {
      outTime[i] = '0' + outTime[i]
    }
  }
  outTime = outTime.join(':')

  return outTime

  // 分转换
  function converMin (val) {
    let min = parseInt(val / 60)
    return min
  }

  // 时转换
  function converHour (val) {
    let hour = parseInt(val / 3600)
    return hour
  }
}

export { timeConversions, dateConversions }

