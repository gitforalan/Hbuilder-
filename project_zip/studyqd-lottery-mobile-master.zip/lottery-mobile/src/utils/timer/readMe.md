## 用法
``` 
import { xTimer } from '@/utils/timer/'

 let count = 0
 let t1 = xTimer.setInterval(() => {
   console.log('exec ...')
   if (count > 20) {
     xTimer.clearInterval(t1)
     console.log('t1 clear!', count)
     let t2 = xTimer.setInterval(() => {
       console.log('t2 loop time 1s')
       if (count > 25) {
         xTimer.clearInterval(t2)
         console.log('t2 clear!', count)
       }
       count++
     }, 1000)
   }
   count++
 }, 200)
 ```
