function loopExec (delay, loop, fn) {
  let start = null
  let lastTimestamp = null
  let count = 0
  const req = (timestamp) => {
    if (start === null) {
      start = timestamp
      lastTimestamp = timestamp
    }
    if ((timestamp - lastTimestamp) > delay) {
      count++
      fn()
      lastTimestamp = timestamp
    }
    if (loop === -1 || count < loop) {
      requestAnimationFrame(req)
    }
  }
  requestAnimationFrame(req)
}

export { loopExec }
