// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import store from './store'
import FastClick from 'fastclick'
import 'flex.css'
import '@/assets/baseStylus/index.styl'
import '@/assets/theme/default-skin/index.styl' // 默认皮肤
import '@/icons' // icon
import '@/components/comps-use/' // 注册vux组件以及其它全局组件
import VueTouch from 'vue-touch'
import '@/utils/polyfill' // 新语法兼容处理

Vue.use(VueTouch, { name: 'v-touch' })

Vue.config.productionTip = false
FastClick.attach(document.body)

Vue.prototype.$timer = {} // 挂载倒计时
Vue.prototype.fc = null // 挂载直播对象

/* 使用移动端调试器 */
// Vue.use(vConsole)

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  render: h => h(App)
})
