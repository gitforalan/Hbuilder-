#彩票应用#<br />
一款彩票购买webapp,内含`双色球`、`大乐透`、`福彩`、`排列三`、`排列五`、`七乐彩`、`七星彩`<br />
&应用技术<br />
vue+vue-router+vuex+ES6+webpack+css3<br >
&项目简述<br />
该项目有30多个页面，应用组件化开发，页面切换动画效果，摇一摇机选等<br />
demo效果预览<br /><br />
<img src="https://github.com/Dantyli/Lottery-project/blob/master/lottery/static/img/demo.png" width="200" height="200"  />
