export default {
    isLogin:false,
    dlt:{
        qi:1,
        bei:1,
        det:[
           // {id:'',red:[],blue:[],zhu:'',pric:'',type:'',number:''}
        ]
    },
    dbc:{
        qi:1,
        bei:1,
        det:[
           // {id:'',red:[],blue:[],zhu:'',pric:'',type:'',number:''}
        ]
    },
    //福彩 1直选2组三3组六
    fc:{
        det:[
            //{id:'',number:'',zhu:'',pric:'',type:'',ge:'',shi:'',bai:''}
        ]
    },
    plt:{
        det:[
            //同福彩
        ]
    },
    //排列五
    plf:{
        det:[
            //{id:'',number:'',zhu,pric:'',type:1,wan,qian,bai,shi,ge}
        ]
    },
    //七星彩
    qxc:{
        det:[
            //{id,type,number,zhu,pric,type:1,bwan,swan,wan,qian,bai,shi,ge}
        ]
    },
    //七乐彩
    qlc:{
        det:[
            //{id,type,number,zhu,pric,nums}
        ]
    }
}