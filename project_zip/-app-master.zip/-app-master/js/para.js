/*
 * 全局变量 
 */
//定时器-检查用户在线时间
//var cusTimer;
//接口前缀
//var uri = window.localStorage['uri'];
//var uri='http://vip.zfpt3.com/api/';
var uri='http://112.74.173.20/api/';
//sign值
var sign = '89f3s0NewRarqoqACmCGjAEOh';
//token
var token = window.localStorage['token'];
//用户ID
var user_id = window.localStorage['user_id'];
//用户名
var username = window.localStorage['username'];
//返点
var flevel_fd = window.localStorage['flevel_fd'];
//余额
var balance = window.localStorage['balance'];
//彩种列表
var lotteryList = window.localStorage['lotteryList'];
//自定义彩种
var customLot = window.localStorage['customLot'];
//首页未选彩种
var lotArr = window.localStorage['lotArr'];
//倒计时
var countTime;
//单价
var price = window.localStorage['price'];
//倍数
var bs = 0;
//模式
var ms = 0;
//注数
var zs = 0;

//window.onload = function(){
//	getOnlineTime()
//}
