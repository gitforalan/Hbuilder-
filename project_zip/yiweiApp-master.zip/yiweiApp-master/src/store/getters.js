export const getUser = state => state.user
export const getUserName = state => state.user.userName
