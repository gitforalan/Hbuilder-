import ssc from './ssc'
import selectElevenFive from './select-eleven-five'
import selectThree from './select-three'
import pk10 from './pk10'
export default {
	'cai1' : ssc,
	'cai2' : ssc,
    'cai3' : ssc,
    'cai4' : selectThree,
	'cai5' : selectThree,
	'cai6' : ssc,
    'cai7' : ssc,
    'cai8' : selectElevenFive,
    'cai9' : selectElevenFive,
	'cai10' : selectElevenFive,
	'cai11' : ssc,
    'cai12' : ssc,
	'cai13' : pk10,
	'cai15' : ssc,
}
