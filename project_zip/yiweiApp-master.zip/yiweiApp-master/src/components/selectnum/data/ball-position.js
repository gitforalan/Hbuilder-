export default [
'direct_any_three_sum',
'group_any_three_three_duplex',
'group_any_three_six_duplex',
'direct_any_two_sum',
'group_any_two_duplex',
]