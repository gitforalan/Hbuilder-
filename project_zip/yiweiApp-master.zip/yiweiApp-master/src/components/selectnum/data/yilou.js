export default [
  'direct_duplex',
  'direct_first_four_duplex',
  'direct_last_four_duplex',
  'direct_first_three_duplex',
  'direct_middle_three_duplex',
  'direct_last_three_duplex',
  'direct_any_three_duplex',
  'direct_first_two_duplex',
  'direct_last_two_duplex',
  'direct_any_two_duplex',
  'location_gall_type',
]