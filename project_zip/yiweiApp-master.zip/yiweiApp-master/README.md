# yiwei web app 1.0

```
// 使用国内淘宝镜像
npm config set registry https://registry.npm.taobao.org

// 安装依赖
npm install

// 生产模式
npm run build

// 开发模式
npm run dev
```

首页
http://localhost:8086


# yiweiApp
