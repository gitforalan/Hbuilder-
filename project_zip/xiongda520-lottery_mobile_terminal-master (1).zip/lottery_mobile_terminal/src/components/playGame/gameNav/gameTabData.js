export default {
  wanfaName: '重庆时时彩',
  secondLevel: [
    {
      secondName: '定位胆',
      threeLevel: [
        {
          threeName: '定位胆1',
          type: '1'
        }
      ]
    },
    {
      secondName: '不定位胆',
      threeLevel: [
        {
          threeName: '前三一码',
          type: '1'
        },
        {
          threeName: '中三一码',
          type: '2'
        },
        {
          threeName: '后三一码',
          type: '3'
        }
      ]
    },
    {
      secondName: '任选玩法',
      threeLevel: [
        {
          threeName: '定位胆1',
          type: '1'
        },
        {
          threeName: '定位胆2',
          type: '2'
        },
        {
          threeName: '定位胆3',
          type: '3'
        }
      ]
    },
    {
      secondName: '二星直选',
      threeLevel: [
        {
          threeName: '二星直选1',
          type: '1'
        },
        {
          threeName: '二星直选2',
          type: '2'
        },
        {
          threeName: '二星直选3',
          type: '3'
        }
      ]
    },
    {
      secondName: '三星组选',
      threeLevel: [
        {
          threeName: '三星组选1',
          type: '1'
        },
        {
          threeName: '三星组选2',
          type: '2'
        },
        {
          threeName: '三星组选3',
          type: '3'
        }
      ]
    },
    {
      secondName: '三星玩法',
      threeLevel: [
        {
          threeName: '三星玩法1',
          type: '1'
        },
        {
          threeName: '三星玩法2',
          type: '2'
        },
        {
          threeName: '三星玩法3',
          type: '3'
        }
      ]
    },
    {
      secondName: '四星玩法',
      threeLevel: [
        {
          threeName: '四星玩法1',
          type: '1'
        },
        {
          threeName: '四星玩法2',
          type: '2'
        },
        {
          threeName: '四星玩法3',
          type: '3'
        }
      ]
    }
  ]
}
