export default [
  {
    weishu: '定位胆选',
    radioCon: '无',
    checkboxGroup: [],
    checkHaoMa: ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
  }
]
