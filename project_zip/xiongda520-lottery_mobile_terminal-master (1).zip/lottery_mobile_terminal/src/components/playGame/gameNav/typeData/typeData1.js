export default [
  {
    weishu: '万位',
    radioCon: '无',
    checkboxGroup: [],
    checkHaoMa: ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
  },
  {
    weishu: '千位',
    radioCon: '无',
    checkboxGroup: [],
    checkHaoMa: ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
  },
  {
    weishu: '百位',
    radioCon: '无',
    checkboxGroup: [],
    checkHaoMa: ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
  },
  {
    weishu: '十位',
    radioCon: '无',
    checkboxGroup: [],
    checkHaoMa: ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
  },
  {
    weishu: '个位',
    radioCon: '无',
    checkboxGroup: [],
    checkHaoMa: ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
  }
]
