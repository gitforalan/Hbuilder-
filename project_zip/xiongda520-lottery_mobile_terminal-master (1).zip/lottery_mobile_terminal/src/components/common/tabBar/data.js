// 底部导航信息
import img from './img/1.jpg'
export default [
  {
    name: '投注大厅',
    nowPic: img,
    selectedPic: img,
    path: '/bethall',
    icon: 'icon-shouye'
  },
  {
    name: '购彩大厅',
    nowPic: img,
    selectedPic: img,
    path: '/caihall',
    icon: 'icon-fenlei1'
  },
  {
    name: '开奖公告',
    nowPic: img,
    selectedPic: img,
    path: '/notice',
    icon: 'icon-liwu2'
  },
  {
    name: '个人中心',
    nowPic: img,
    selectedPic: img,
    path: '/myinfo',
    icon: 'icon-geren'
  }
]
