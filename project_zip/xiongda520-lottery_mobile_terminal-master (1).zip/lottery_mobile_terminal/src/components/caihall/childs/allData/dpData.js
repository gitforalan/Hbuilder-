export default [
  {
    name: '福彩3D',
    qishu: '201712270805',
    winNum: [3, 4, 5, 6, 8],
    overtime: [2017, 12, 27, 23, 59, 59],
    imgUrl: require('../../../../assets/img/cqssc.png'),
    left: ''
  },
  {
    name: '福彩3D',
    qishu: '201712270805',
    winNum: [3, 4, 5, 6, 8],
    overtime: [2017, 12, 27, 23, 59, 59],
    imgUrl: require('../../../../assets/img/cqssc.png'),
    left: ''
  },
  {
    name: '福彩3D',
    qishu: '201712270805',
    winNum: [3, 4, 5, 6, 8],
    overtime: [2017, 12, 27, 23, 59, 59],
    imgUrl: require('../../../../assets/img/cqssc.png'),
    left: ''
  }
]
