import HeadNav from '../../components/common/headerBar'

export default function (Vue) {
  Vue.component('HeadNav', HeadNav)
}
