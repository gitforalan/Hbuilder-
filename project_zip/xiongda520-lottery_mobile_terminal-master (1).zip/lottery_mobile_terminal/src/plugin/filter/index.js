/**
 * Created by fjl on 2017/7/21.
 */

export default function (Vue) {
  Vue.filter('formatTime', function (date, format) {
    if (date) {
      return ''
    } else {
      return ''
    }
  })
}
