export default {
  // 令牌
  token (state) {
    return state.token
  },
  // 用户信息
  user (state) {
    return state.user
  }
}
