onmessage = function (evt) {
	let d = evt.data;
	postMessage(d);
};