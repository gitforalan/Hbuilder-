import MyAudio from './components/index'

export{
  MyAudio
}