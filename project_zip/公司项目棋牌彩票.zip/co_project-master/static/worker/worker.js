onmessage = function (evt) {
	var d = evt.data;
	postMessage(d);
};