<template>
  <view-box :body-padding-top="viewBox.top" :body-padding-bottom="viewBoxPaddingBottom">
    <router-view v-on:barTab="barTab"></router-view>
    <app-bar slot="bottom" v-if="appBar.tabIndex != null" :tabIndex="appBar.tabIndex"></app-bar>
  </view-box>
</template>

<script>
  import {ViewBox} from 'vux'
  import AppBar from './components/app-bar'

  export default {
    name: 'app',
    components: {ViewBox, AppBar},
    data (){
      return {
        appBar: {tabIndex: null},
        viewBox: {top: '0px', bottom: '60px'}
      }
    },
    computed: {
      viewBoxPaddingBottom: function () {
        return this.appBar.tabIndex == null ? 0 : this.viewBox.bottom;
      }
    },
    methods: {
      barTab: function (tabIndex) {
        this.appBar.tabIndex = tabIndex;
      }
    },
    created: function () {
    }
  }
</script>

<style lang="less">
  @import '~vux/src/styles/reset.less';

  html, body {
    height: 100%;
    width: 100%;
    overflow-x: hidden;
  }

  body {
    background-color: #fbf9fe;
  }

  .form-icon {
    fill: #999;
    vertical-align: middle;
  }

  .weui-icon-warn {
    color: #179B16 !important;
  }
</style>
