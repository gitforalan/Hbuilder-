<template>
  <div>
    <tab active-color="red" bar-active-color="red">
      <tab-item @on-item-click="tabIndex = 0" :selected="tabIndex == 0" style="border-right: 1px solid #eee">登录</tab-item>
      <tab-item @on-item-click="tabIndex = 1" :selected="tabIndex == 1">注册</tab-item>
    </tab>

    <swiper v-model="tabIndex" :aspect-ratio="aspectRatio" :show-dots="showDots">
      <swiper-item key="0">
        <box gap="2em 10px">
          <group>
            <x-input is-type="china-mobile" placeholder="请输入手机号码" required>
              <x-icon slot="label" type="iphone" size="17" class="form-icon" style="padding:0 10px 0 0"></x-icon>
            </x-input>
          </group>
          <group>
            <x-input :type="swiper.password.type" placeholder="请输入密码" :min="swiper.password.min" :max="swiper.password.max" required>
              <x-icon slot="label" type="key" size="17" class="form-icon" style="padding:0 10px 0 0"></x-icon>
              <x-icon slot="right" type="eye" size="17" class="form-icon" @click="togglePassword"></x-icon>
            </x-input>
          </group>
        </box>
        <box gap="2em 10px">
          <x-button type="primary">登录</x-button>
          <x-button>忘记密码</x-button>
        </box>
      </swiper-item>

      <swiper-item key="1">
        <box gap="2em 10px">
          <group>
            <x-input is-type="china-mobile" placeholder="请输入手机号码" required>
              <x-icon slot="label" type="iphone" size="17" class="form-icon" style="padding:0 10px 0 0"></x-icon>
            </x-input>
          </group>
          <group>
            <x-input name="checkCode" type="number" placeholder="请输入验证码" :min="swiper.checkCode.min" :max="swiper.checkCode.max"
                     required>
              <x-icon slot="label" type="ios-keypad" size="17" class="form-icon" style="padding:0 10px 0 0"></x-icon>
              <x-button slot="right" mini>获取验证码</x-button>
            </x-input>
          </group>
        </box>
        <box gap="2em 10px">
          <x-button @click.native="regist" type="primary">注册</x-button>
          <x-button @click.native="tabIndex = 0">返回登录</x-button>
        </box>
      </swiper-item>
    </swiper>
  </div>
</template>

<script>
  import {Tab, TabItem, Swiper, SwiperItem, Box, Group, XInput, XButton} from 'vux'

  export default {
    components: {Tab, TabItem, Swiper, SwiperItem, Box, Group, XInput, XButton},
    data (){
      return {
        tabIndex: 0,
        aspectRatio: 1,
        showDots: false,
        swiper: {
          password: {type: 'password', min: 6, max: 15},
          checkCode: {min: 6, max: 6}
        }
      }
    },
    methods: {
      togglePassword: function () {
        if (this.swiper.password.type == 'password') {
          this.swiper.password.type = 'text';
        } else {
          this.swiper.password.type = 'password';
        }
      },
      regist: function () {
        window.location.href = '#/user/SetPassWord';
      }
    },
    created: function () {
      this.$emit('barTab', 2);
    }
  }
</script>
