<template>
  <div>
    <msg icon="success" title="注册成功" :buttons="buttons"></msg>
  </div>
</template>

<script>
  import {Msg, XButton} from 'vux'

  export default {
    components: {Msg, XButton},
    data (){
      return {
        buttons: [
          {type: 'primary', text: '立即登录', link: '/user/Login'}
        ]
      }
    },
    methods: {}
  }
</script>
