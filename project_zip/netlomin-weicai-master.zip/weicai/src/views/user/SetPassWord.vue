<template>
  <div>
    <box gap="2em 10px">
      <group>
        <x-input v-model="passWord.value" :type="passWord.type" placeholder="请设置登录密码" :min="passWord.min" :max="passWord.max" required>
          <x-icon slot="label" type="key" size="17" class="form-icon" style="padding:0 10px 0 0"></x-icon>
          <x-icon slot="right" type="eye" size="17" class="form-icon" @click="togglePassWord"></x-icon>
        </x-input>
      </group>
      <group>
        <x-input :type="confirm.type" placeholder="请确认登录密码" :min="passWord.min" :max="passWord.max" required :equal-with="passWord.value">
          <x-icon slot="label" type="key" size="17" class="form-icon" style="padding:0 10px 0 0"></x-icon>
          <x-icon slot="right" type="eye" size="17" class="form-icon" @click="toggleConfirm"></x-icon>
        </x-input>
      </group>
    </box>
    <box gap="2em 10px">
      <x-button type="primary" @click.native="setPassWord">保存密码</x-button>
    </box>
  </div>
</template>

<script>
  import {Box, Group, XInput, XButton} from 'vux'

  export default {
    components: {Box, Group, XInput, XButton},
    data (){
      return {
        passWord: {value: '', type: 'password', min: 6, max: 15},
        confirm: {type: 'password'}
      }
    }
    ,
    methods: {
      togglePassWord: function () {
        if (this.passWord.type == 'password') {
          this.passWord.type = 'text';
        } else {
          this.passWord.type = 'password';
        }
      },
      toggleConfirm: function () {
        if (this.confirm.type == 'password') {
          this.confirm.type = 'text';
        } else {
          this.confirm.type = 'password';
        }
      },
      setPassWord: function () {
        window.location.href = '#/user/RegistSuccess';
      }
    }
  }
</script>
