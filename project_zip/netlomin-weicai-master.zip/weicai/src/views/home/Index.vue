<template>
  <div>
    <swiper :list="swiper.list" dots-class="custom-bottom" dots-position="center" auto loop></swiper>

    <grid rows="2">
      <grid-item link="/Hello" label="双色球">
        <img slot="icon" src="../../../static/grid_ssq.png">
      </grid-item>
      <grid-item link="/Hello" label="大乐透">
        <img slot="icon" src="../../../static/grid_dlt.png">
      </grid-item>
    </grid>

    <panel header="彩票资讯" :list="panel.list" type="1"></panel>
  </div>
</template>

<script>
  import {Swiper, SwiperItem, Grid, GridItem, Panel} from 'vux'

  export default {
    components: {Swiper, SwiperItem, Grid, GridItem, Panel},
    data (){
      return {
        swiper: {
          list: [
            {url: 'Hello', img: 'https://static.vux.li/demo/1.jpg'},
            {url: 'https://www.baidu.com', img: 'https://static.vux.li/demo/2.jpg'},
            {url: 'javascript:', img: 'https://static.vux.li/demo/3.jpg'}
          ]
        },
        panel: {
          list: [{
            src: 'http://192.168.0.101:8080/static/grid_ssq.png',
            title: '标题一',
            desc: '由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。',
            url: '/component/cell'
          }, {
            src: 'http://192.168.0.101:8080/static/grid_dlt.png',
            title: '标题二',
            desc: '由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。',
            url: {path: '/component/radio', replace: false}
          }, {
            src: 'http://192.168.0.101:8080/static/grid_dlt.png',
            title: '标题二',
            desc: '由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。',
            url: {path: '/component/radio', replace: false}
          }, {
            src: 'http://192.168.0.101:8080/static/grid_dlt.png',
            title: '标题二',
            desc: '由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。',
            url: {path: '/component/radio', replace: false}
          }, {
            src: 'http://192.168.0.101:8080/static/grid_dlt.png',
            title: '标题二',
            desc: '由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。',
            url: {path: '/component/radio', replace: false}
          }, {
            src: 'http://192.168.0.101:8080/static/grid_dlt.png',
            title: '标题二',
            desc: '由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。',
            url: {path: '/component/radio', replace: false}
          }, {
            src: 'http://192.168.0.101:8080/static/grid_dlt.png',
            title: '标题二',
            desc: '由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。',
            url: {path: '/component/radio', replace: false}
          }, {
            src: 'http://192.168.0.101:8080/static/grid_dlt.png',
            title: '标题二',
            desc: '由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。',
            url: {path: '/component/radio', replace: false}
          }, {
            src: 'http://192.168.0.101:8080/static/grid_dlt.png',
            title: '标题二',
            desc: '由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。',
            url: {path: '/component/radio', replace: false}
          }, {
            src: 'http://192.168.0.101:8080/static/grid_dlt.png',
            title: '标题二',
            desc: '由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。',
            url: {path: '/component/radio', replace: false}
          }, {
            src: 'http://192.168.0.101:8080/static/grid_dlt.png',
            title: '标题二',
            desc: '由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。',
            url: {path: '/component/radio', replace: false}
          }, {
            src: 'http://192.168.0.101:8080/static/grid_dlt.png',
            title: '标题二',
            desc: '由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。',
            url: {path: '/component/radio', replace: false}
          }]
        }
      }
    },
    created: function () {
      this.$emit('barTab', 0); // 选中首页
    }
  }
</script>

<style>

</style>
