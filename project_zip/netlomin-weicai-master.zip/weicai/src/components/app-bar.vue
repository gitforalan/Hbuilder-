<template>
  <tabbar>
    <tabbar-item link="/" :selected="tabIndex == 0">
      <img slot="icon" src="../assets/tabbar-home.png">
      <img slot="icon-active" src="../assets/tabbar-home-active.png">
      <span slot="label">主页</span>
    </tabbar-item>
    <tabbar-item link="/" :selected="tabIndex == 1" :badge="msgCount">
      <img slot="icon" src="../assets/tabbar-msg.png">
      <img slot="icon-active" src="../assets/tabbar-msg-active.png">
      <span slot="label">消息</span>
    </tabbar-item>
    <tabbar-item link="/user/Login" :selected="tabIndex == 2">
      <img slot="icon" src="../assets/tabbar-user.png">
      <img slot="icon-active" src="../assets/tabbar-user-active.png">
      <span slot="label">我的</span>
    </tabbar-item>
  </tabbar>
</template>

<script>
  import {Tabbar, TabbarItem} from 'vux'

  export default {
    components: {Tabbar, TabbarItem},
    props: {
      tabIndex: {type: Number, default: 0}
    },
    data()
    {
      return {
        msgCount: '10'
      }
    }
  }
</script>
