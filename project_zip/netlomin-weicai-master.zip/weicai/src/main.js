import Vue from 'vue'
import FastClick from 'fastclick'
import VueRouter from 'vue-router'
import App from '@/App'
import Index from '@/views/home/Index'
import Login from '@/views/user/Login'
import SetPassWord from '@/views/user/SetPassWord'
import RegistSuccess from '@/views/user/RegistSuccess'

Vue.use(VueRouter)

const routes = [
  {path: '/', component: Index},
  {path: '/user/Login', component: Login},
  {path: '/user/SetPassWord', component: SetPassWord},
  {path: '/user/RegistSuccess', component: RegistSuccess}
]

const router = new VueRouter({
  routes
})

FastClick.attach(document.body)

Vue.config.productionTip = false

new Vue({
  router,
  render: h => h(App)
}).$mount('#app-box')
