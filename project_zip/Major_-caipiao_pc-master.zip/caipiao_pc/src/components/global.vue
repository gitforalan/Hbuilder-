<script>  
  const BASE_URL = 'http://192.168.1.88/lottery/public/index/';  
  export default{  
    BASE_URL  
  }  
</script>  